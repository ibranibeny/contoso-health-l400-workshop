targetScope = 'subscription'

metadata description = 'Microsoft Defender for Cloud plans (Standard tier) on the subscription.'

@description('Defender plan (pricing) names to enable, e.g. Containers, AppServices, OpenSourceRelationalDatabases, KeyVaults, CloudPosture.')
param planNames array

// [REL] Pricing updates on one subscription conflict when sent in parallel: apply one plan at a time.
@batchSize(1)
resource plans 'Microsoft.Security/pricings@2024-01-01' = [for planName in planNames: {
  name: planName
  properties: {
    pricingTier: 'Standard' // [SEC] [COST] billed per protected resource; the Free tier only gives secure-score recommendations
  }
}]

@description('Resource IDs of the enabled plans.')
output ids array = [for i in range(0, length(planNames)): plans[i].id]
