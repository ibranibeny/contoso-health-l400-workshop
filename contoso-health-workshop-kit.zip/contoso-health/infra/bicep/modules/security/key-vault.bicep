metadata description = 'Key Vault (RBAC mode, purge protection, private endpoint only) + "Key Vault Secrets User" for the given identities + diagnostic settings.'

@description('Key Vault name (kv-ch-<env>-<sfx>, 3-24 characters, globally unique).')
param name string

@description('Azure region.')
param location string

@description('Tags applied to every resource in this module.')
param tags object

@description('Principal IDs (managed identities) that get "Key Vault Secrets User" on this vault.')
param secretsUserPrincipalIds array

@description('Resource ID of snet-private-endpoints.')
param privateEndpointSubnetId string

@description('Resource ID of the privatelink.vaultcore.azure.net zone in the hub.')
param privateDnsZoneId string

@description('Resource ID of the Log Analytics workspace for diagnostic settings.')
param logAnalyticsWorkspaceId string

var keyVaultSecretsUserRoleGuid = '4633458b-17de-408a-b874-0445c86b69e6'

resource vault 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name: name
  location: location
  tags: tags
  properties: {
    tenantId: subscription().tenantId
    sku: {
      family: 'A'
      name: 'standard'
    }
    enableRbacAuthorization: true // [SEC] Azure RBAC data plane (no access policies); Key Vault Administrator is granted to nobody
    enableSoftDelete: true
    softDeleteRetentionInDays: 90 // [REL] maximum recovery window
    enablePurgeProtection: true // [SEC] irreversible: a deleted vault/secret cannot be purged before the retention ends
    publicNetworkAccess: 'Disabled' // [SEC] data plane reachable only through the private endpoint
    networkAcls: {
      defaultAction: 'Deny'
      bypass: 'AzureServices' // trusted Microsoft services (e.g. App Gateway certificate retrieval)
    }
    enabledForDeployment: false
    enabledForDiskEncryption: false
    enabledForTemplateDeployment: false
  }
}

resource secretsUsers 'Microsoft.Authorization/roleAssignments@2022-04-01' = [for principalId in secretsUserPrincipalIds: {
  name: guid(vault.id, principalId, keyVaultSecretsUserRoleGuid)
  scope: vault
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', keyVaultSecretsUserRoleGuid)
    principalId: principalId
    principalType: 'ServicePrincipal'
    description: 'Read secrets/certificates (Key Vault references, App Gateway TLS certificate).'
  }
}]

module privateEndpoint '../network/private-endpoint.bicep' = {
  name: 'pe-${name}'
  params: {
    name: 'pe-${name}'
    location: location
    tags: tags
    subnetId: privateEndpointSubnetId
    privateLinkServiceId: vault.id
    groupId: 'vault'
    privateDnsZoneId: privateDnsZoneId
  }
}

resource diagnostics 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: 'diag-log-analytics'
  scope: vault
  properties: {
    workspaceId: logAnalyticsWorkspaceId
    logs: [
      {
        categoryGroup: 'allLogs' // [SEC] AuditEvent: who read which secret, from where
        enabled: true
      }
    ]
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
      }
    ]
  }
}

@description('Name of the Key Vault.')
output name string = vault.name

@description('Resource ID of the Key Vault.')
output id string = vault.id

@description('Vault URI (resolves to the private endpoint inside the linked VNets).')
output uri string = vault.properties.vaultUri
