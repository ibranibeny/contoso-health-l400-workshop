metadata description = 'Built-in policy assignments (Deny/Audit effects only, no managed identity) at resource-group scope.'

@description('Assignments: array of { name, displayName, definitionGuid, parameters, nonComplianceMessage }. parameters uses the ARM shape { <name>: { value: <value> } }.')
param assignments array

resource policyAssignments 'Microsoft.Authorization/policyAssignments@2023-04-01' = [for assignment in assignments: {
  name: assignment.name
  properties: {
    displayName: assignment.displayName
    policyDefinitionId: tenantResourceId('Microsoft.Authorization/policyDefinitions', assignment.definitionGuid) // built-in definitions live at tenant scope
    parameters: assignment.parameters
    enforcementMode: 'Default' // [SEC] Deny effects are enforced; use DoNotEnforce for a what-if style rollout
    nonComplianceMessages: [
      {
        message: assignment.nonComplianceMessage
      }
    ]
  }
}]

@description('Resource IDs of the policy assignments.')
output ids array = [for i in range(0, length(assignments)): policyAssignments[i].id]
