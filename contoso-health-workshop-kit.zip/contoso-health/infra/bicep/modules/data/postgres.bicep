metadata description = 'Azure Database for PostgreSQL flexible server: Microsoft Entra ID-only auth, private endpoint (no VNet injection), managed identity as Entra admin, diagnostic settings. The application database is created by the bootstrap script, not here.'

@description('Server name (psql-ch-<env>-<sfx>, globally unique).')
param name string

@description('Azure region.')
param location string

@description('Tags applied to every resource in this module.')
param tags object

@description('PostgreSQL major version: 17 (default) or 18.')
param postgresVersion string

@description('Compute SKU name: Standard_B1ms (lab) or Standard_D2ds_v5 (prod).')
param skuName string

@description('Compute tier matching skuName: Burstable, GeneralPurpose or MemoryOptimized.')
param skuTier string

@description('High availability: Disabled or ZoneRedundant (GeneralPurpose/MemoryOptimized only).')
param highAvailabilityMode string

@description('Storage size in GiB.')
param storageSizeGB int

@description('Backup retention in days (7-35).')
param backupRetentionDays int

@description('Object ID (principal ID) of the managed identity that becomes the Microsoft Entra administrator.')
param adminPrincipalId string

@description('Name of that managed identity (the Entra admin role name inside PostgreSQL).')
param adminPrincipalName string

@description('Resource ID of snet-private-endpoints.')
param privateEndpointSubnetId string

@description('Resource ID of the privatelink.postgres.database.azure.com zone in the hub.')
param privateDnsZoneId string

@description('Resource ID of the Log Analytics workspace for diagnostic settings.')
param logAnalyticsWorkspaceId string

var zoneRedundantHa = highAvailabilityMode == 'ZoneRedundant'

resource server 'Microsoft.DBforPostgreSQL/flexibleServers@2025-08-01' = {
  name: name
  location: location
  tags: tags
  sku: {
    name: skuName
    tier: skuTier // [COST] Burstable for lab; [REL] GeneralPurpose in prod (required for zone-redundant HA)
  }
  properties: {
    version: postgresVersion
    availabilityZone: '1'
    highAvailability: zoneRedundantHa ? {
      mode: 'ZoneRedundant' // [REL] synchronous standby in another zone, automatic failover
      standbyAvailabilityZone: '2'
    } : {
      mode: 'Disabled'
    }
    storage: {
      storageSizeGB: storageSizeGB
      autoGrow: 'Enabled' // [REL] avoids the read-only state when the disk fills up
    }
    backup: {
      backupRetentionDays: backupRetentionDays
      geoRedundantBackup: 'Disabled' // geo-redundant backup is not available in Indonesia Central (no paired region)
    }
    network: {
      publicNetworkAccess: 'Disabled' // [SEC] private endpoint only; NOT VNet injection (PE unsupported there, conversion is one-way)
    }
    authConfig: {
      activeDirectoryAuth: 'Enabled'
      passwordAuth: 'Disabled' // [SEC] Entra ID only: no admin password exists anywhere
      tenantId: subscription().tenantId
    }
    maintenanceWindow: {
      customWindow: 'Enabled' // [OPS] planned maintenance on Sunday 02:00 (UTC, the service's time zone)
      dayOfWeek: 0
      startHour: 2
      startMinute: 0
    }
  }
}

// The admin child resource is named after the principal's object ID.
resource entraAdmin 'Microsoft.DBforPostgreSQL/flexibleServers/administrators@2025-08-01' = {
  parent: server
  name: adminPrincipalId
  properties: {
    principalName: adminPrincipalName
    principalType: 'ServicePrincipal' // a managed identity is a service principal
    tenantId: subscription().tenantId
  }
}

module privateEndpoint '../network/private-endpoint.bicep' = {
  name: 'pe-${name}'
  params: {
    name: 'pe-${name}'
    location: location
    tags: tags
    subnetId: privateEndpointSubnetId
    privateLinkServiceId: server.id
    groupId: 'postgresqlServer'
    privateDnsZoneId: privateDnsZoneId
  }
  dependsOn: [
    entraAdmin // [REL] serialise server-level operations (concurrent updates fail with ServerBusy)
  ]
}

resource diagnostics 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: 'diag-log-analytics'
  scope: server
  properties: {
    workspaceId: logAnalyticsWorkspaceId
    logs: [
      {
        categoryGroup: 'allLogs'
        enabled: true
      }
    ]
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
      }
    ]
  }
}

@description('Name of the server.')
output name string = server.name

@description('Resource ID of the server.')
output id string = server.id

@description('Fully qualified domain name (resolves to the private endpoint inside the linked VNets).')
output fqdn string = server.properties.fullyQualifiedDomainName
