metadata description = 'Azure Managed Redis (Microsoft.Cache/redisEnterprise): zone-redundant HA, TLS only, Entra ID only (access keys disabled), private endpoint, data access for the given identities.'

@description('Cluster name (redis-ch-<env>-<sfx>, globally unique).')
param name string

@description('Azure region.')
param location string

@description('Tags applied to every resource in this module.')
param tags object

@description('SKU: Balanced_B0 in lab and prod (smallest Balanced size, 0.5 GB); raise it to Balanced_B1 or larger when memory or server load grows.')
param skuName string

@description('Identities that get data access through the built-in "default" access policy: array of { name, objectId }.')
param dataAccessIdentities array

@description('Resource ID of snet-private-endpoints.')
param privateEndpointSubnetId string

@description('Resource ID of the privatelink.redis.azure.net zone in the hub.')
param privateDnsZoneId string

resource redis 'Microsoft.Cache/redisEnterprise@2026-09-01' = {
  name: name
  location: location
  tags: tags
  sku: {
    name: skuName // [COST] Balanced = balanced memory/vCPU ratio; B0 is the smallest HA-capable size
  }
  properties: {
    highAvailability: 'Enabled' // [REL] replicated, zone-redundant in AZ regions; cannot be turned off later
    minimumTlsVersion: '1.2'
    publicNetworkAccess: 'Disabled' // [SEC] required property: private endpoint only
  }
}

resource database 'Microsoft.Cache/redisEnterprise/databases@2026-09-01' = {
  parent: redis
  name: 'default'
  properties: {
    clientProtocol: 'Encrypted' // [SEC] TLS on port 10000
    port: 10000
    // [PERF] EnterpriseCluster exposes a single endpoint and works with any (non-cluster-aware) client, such as
    // node-redis createClient. OSSCluster is faster at scale but requires cluster-aware clients (createCluster).
    clusteringPolicy: 'EnterpriseCluster'
    evictionPolicy: 'VolatileLRU' // cache semantics: evict keys that have a TTL first
    accessKeysAuthentication: 'Disabled' // [SEC] Entra ID tokens only, no shared keys
  }
}

// Access policy assignment names must be alphanumeric: derived from the identity name without hyphens.
@batchSize(1)
resource accessPolicyAssignments 'Microsoft.Cache/redisEnterprise/databases/accessPolicyAssignments@2026-09-01' = [for principal in dataAccessIdentities: {
  parent: database
  name: replace(principal.name, '-', '')
  properties: {
    accessPolicyName: 'default'
    user: {
      objectId: principal.objectId
    }
  }
}]

module privateEndpoint '../network/private-endpoint.bicep' = {
  name: 'pe-${name}'
  params: {
    name: 'pe-${name}'
    location: location
    tags: tags
    subnetId: privateEndpointSubnetId
    privateLinkServiceId: redis.id
    groupId: 'redisEnterprise'
    privateDnsZoneId: privateDnsZoneId
  }
  dependsOn: [
    accessPolicyAssignments // [REL] serialise cluster operations (parallel updates are rejected while one is running)
  ]
}

@description('Name of the cluster.')
output name string = redis.name

@description('Resource ID of the cluster.')
output id string = redis.id

@description('Host name (TLS port 10000; resolves to the private endpoint inside the linked VNets).')
output hostName string = redis.properties.hostName
