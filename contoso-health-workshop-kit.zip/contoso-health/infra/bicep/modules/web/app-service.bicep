metadata description = 'Linux Node.js web app: user-assigned identity, VNet integration with all outbound traffic routed into the VNet, private endpoint, public access denied on the main site, basic auth disabled, diagnostic settings.'

@description('Web app name (globally unique).')
param name string

@description('Azure region.')
param location string

@description('Tags applied to every resource in this module.')
param tags object

@description('Resource ID of the App Service plan.')
param appServicePlanId string

@description('Resource ID of the user-assigned managed identity of this app.')
param identityId string

@description('Resource ID of snet-app-integration (delegated to Microsoft.Web/serverFarms).')
param integrationSubnetId string

@description('Startup command (appCommandLine).')
param startCommand string

@description('Default action of the SCM (Kudu/deployment) site access restrictions: Allow (lab, GitHub-hosted runners) or Deny (prod, self-hosted runner in the VNet).')
param scmIpSecurityRestrictionsDefaultAction string

@description('App settings as a flat object { NAME: \'value\' }. APPLICATIONINSIGHTS_CONNECTION_STRING is added by this module.')
param appSettings object

@description('Name of the Application Insights component (same resource group) whose connection string is injected.')
param appInsightsName string

@description('Resource ID of snet-private-endpoints.')
param privateEndpointSubnetId string

@description('Resource ID of the privatelink.azurewebsites.net zone in the hub.')
param privateDnsZoneId string

@description('Resource ID of the Log Analytics workspace for diagnostic settings.')
param logAnalyticsWorkspaceId string

resource appInsights 'Microsoft.Insights/components@2020-02-02' existing = {
  name: appInsightsName
}

var settingsFromParameters = [for setting in items(appSettings): {
  name: setting.key
  value: setting.value
}]

resource site 'Microsoft.Web/sites@2024-11-01' = {
  name: name
  location: location
  tags: tags
  kind: 'app,linux'
  identity: {
    type: 'UserAssigned' // [SEC] no secrets: PostgreSQL, Redis, Key Vault and App Insights all accept this identity
    userAssignedIdentities: {
      '${identityId}': {}
    }
  }
  properties: {
    serverFarmId: appServicePlanId
    httpsOnly: true
    clientAffinityEnabled: false // [PERF] stateless app, spread requests evenly across instances
    publicNetworkAccess: 'Enabled' // public endpoint stays up for the SCM site; the main site denies everything below
    virtualNetworkSubnetId: integrationSubnetId
    outboundVnetRouting: {
      allTraffic: true // [SEC] every outbound call goes through the VNet (NAT gateway or hub firewall, private DNS)
    }
    keyVaultReferenceIdentity: identityId // Key Vault references resolve with the user-assigned identity
    siteConfig: {
      linuxFxVersion: 'NODE|24-lts'
      appCommandLine: startCommand
      alwaysOn: true // [PERF] no cold start after idle
      http20Enabled: true
      minTlsVersion: '1.2'
      scmMinTlsVersion: '1.2'
      ftpsState: 'Disabled'
      // [REL] Health check = deep readiness endpoint: /readyz returns a 5xx when a required dependency is unreachable
      // (API: PostgreSQL; Redis is optional), so that instance leaves the rotation and is replaced (needs >= 2
      // instances). App Gateway keeps probing the shallow liveness path /healthz.
      healthCheckPath: '/readyz'
      ipSecurityRestrictionsDefaultAction: 'Deny' // [SEC] main site: no public access; private endpoint traffic is not subject to access restrictions
      scmIpSecurityRestrictionsDefaultAction: scmIpSecurityRestrictionsDefaultAction
      scmIpSecurityRestrictionsUseMain: false // SCM has its own rule set (deployments), the main site stays closed
      appSettings: concat(settingsFromParameters, [
        {
          name: 'APPLICATIONINSIGHTS_CONNECTION_STRING' // not a secret; with local auth disabled (prod) ingestion requires Entra ID
          value: appInsights.properties.ConnectionString
        }
      ])
    }
  }
}

// [SEC] Disable basic (publishing profile) auth: only Entra ID principals (GitHub OIDC) can deploy.
resource ftpBasicAuth 'Microsoft.Web/sites/basicPublishingCredentialsPolicies@2024-11-01' = {
  parent: site
  name: 'ftp'
  properties: {
    allow: false
  }
}

resource scmBasicAuth 'Microsoft.Web/sites/basicPublishingCredentialsPolicies@2024-11-01' = {
  parent: site
  name: 'scm'
  properties: {
    allow: false
  }
}

module privateEndpoint '../network/private-endpoint.bicep' = {
  name: 'pe-${name}'
  params: {
    name: 'pe-${name}'
    location: location
    tags: tags
    subnetId: privateEndpointSubnetId
    privateLinkServiceId: site.id
    groupId: 'sites'
    privateDnsZoneId: privateDnsZoneId
  }
  dependsOn: [
    ftpBasicAuth // [REL] serialise site-level writes (parallel updates can fail with "another operation is in progress")
    scmBasicAuth
  ]
}

resource diagnostics 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: 'diag-log-analytics'
  scope: site
  properties: {
    workspaceId: logAnalyticsWorkspaceId
    logs: [
      {
        categoryGroup: 'allLogs' // HTTP, console, app, platform, audit and IP-security audit logs
        enabled: true
      }
    ]
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
      }
    ]
  }
}

@description('Name of the web app.')
output name string = site.name

@description('Resource ID of the web app.')
output id string = site.id

@description('Default host name (<name>.azurewebsites.net; resolves to the private endpoint inside the linked VNets).')
output defaultHostName string = site.properties.defaultHostName
