metadata description = 'Linux App Service plan (Premium v4, zone-redundant).'

@description('App Service plan name (asp-ch-<env>-idc).')
param name string

@description('Azure region.')
param location string

@description('Tags applied to the plan.')
param tags object

@description('SKU name: P0v4 (lab) or P1v4 (prod).')
param skuName string

@description('Instance count; zone redundancy requires at least 2 (one instance per zone up to the zone count).')
@minValue(2)
param capacity int

resource plan 'Microsoft.Web/serverfarms@2024-11-01' = {
  name: name
  location: location
  tags: tags
  kind: 'linux'
  sku: {
    name: skuName // [COST] Premium v4 is the smallest tier with zone redundancy in Indonesia Central
    capacity: capacity
  }
  properties: {
    reserved: true // Linux plan
    zoneRedundant: true // [REL] instances spread across availability zones; Learn allows toggling it on an existing plan only when its scale unit supports zones
  }
}

@description('Resource ID of the App Service plan.')
output id string = plan.id

@description('Name of the App Service plan.')
output name string = plan.name
