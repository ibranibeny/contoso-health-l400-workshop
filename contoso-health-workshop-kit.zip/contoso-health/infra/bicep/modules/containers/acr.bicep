metadata description = 'Azure Container Registry Premium (private endpoint into the workload spoke, no admin user, no anonymous pull) + diagnostic settings.'

@description('Registry name (crch<env><sfx>, alphanumeric, globally unique).')
param name string

@description('Azure region.')
param location string

@description('Tags applied to every resource in this module.')
param tags object

@description('Public network access: Enabled (lab, GitHub-hosted runners push) or Disabled (prod, self-hosted/ARC runners in the VNet).')
param publicNetworkAccess string

@description('Resource ID of the workload snet-private-endpoints.')
param privateEndpointSubnetId string

@description('Resource ID of the privatelink.azurecr.io zone in the hub.')
param privateDnsZoneId string

@description('Resource ID of the Log Analytics workspace for diagnostic settings.')
param logAnalyticsWorkspaceId string

// API 2025-04-01: anonymousPullEnabled is not in the 2023-07-01 schema (preview-only until this GA version).
resource registry 'Microsoft.ContainerRegistry/registries@2025-04-01' = {
  name: name
  location: location
  tags: tags
  sku: {
    name: 'Premium' // required for private endpoints; [REL] zone redundancy is automatic in AZ regions
  }
  properties: {
    adminUserEnabled: false // [SEC] Entra ID only (AcrPull/AcrPush role assignments)
    anonymousPullEnabled: false // [SEC]
    publicNetworkAccess: publicNetworkAccess
    networkRuleBypassOptions: 'AzureServices' // trusted Azure services (e.g. Defender image scanning) keep access
  }
}

module privateEndpoint '../network/private-endpoint.bicep' = {
  name: 'pe-${name}'
  params: {
    name: 'pe-${name}'
    location: location
    tags: tags
    subnetId: privateEndpointSubnetId
    privateLinkServiceId: registry.id
    groupId: 'registry' // also registers the regional data endpoint (<name>.<region>.data.azurecr.io)
    privateDnsZoneId: privateDnsZoneId
  }
}

resource diagnostics 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: 'diag-log-analytics'
  scope: registry
  properties: {
    workspaceId: logAnalyticsWorkspaceId
    logs: [
      {
        categoryGroup: 'allLogs' // repository events (push/pull/delete) and login events
        enabled: true
      }
    ]
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
      }
    ]
  }
}

@description('Name of the registry.')
output name string = registry.name

@description('Resource ID of the registry.')
output id string = registry.id

@description('Login server (<name>.azurecr.io).')
output loginServer string = registry.properties.loginServer
