metadata description = 'AKS cluster (Standard tier, Azure CNI Overlay + Cilium, Entra ID + Azure RBAC, workload identity, zone-redundant pools in the workload spoke) + maintenance windows + Azure RBAC role assignments + control-plane diagnostic settings.'

@description('Cluster name (aks-ch-<env>-idc).')
param name string

@description('Azure region.')
param location string

@description('Tags applied to the cluster and its node pools.')
param tags object

@description('Kubernetes version; a minor version (e.g. 1.36) lets AKS pick the latest patch.')
param kubernetesVersion string

@description('DNS prefix of the API server FQDN (aks-ch-<env>).')
param dnsPrefix string

@description('Name of the AKS-managed node resource group (created by AKS, must not exist).')
param nodeResourceGroupName string

@description('Resource ID of the user-assigned control-plane identity (id-ch-aks-<env>).')
param controlPlaneIdentityId string

@description('Resource ID of the workload snet-aks-nodes.')
param nodesSubnetId string

@description('Resource ID of the workload snet-aks-apiserver (used only when apiServerAccess is private).')
param apiServerSubnetId string

@description('public = public API server (optionally limited by authorizedIpRanges); private = private cluster with API server VNet integration.')
param apiServerAccess string

@description('CIDR ranges allowed to reach a public API server. Empty = unrestricted.')
param authorizedIpRanges array

@description('Spoke egress mode: natGateway -> outboundType userAssignedNATGateway, firewall -> userDefinedRouting.')
param egressMode string

@description('VM size of the system node pool.')
param systemNodeVmSize string

@description('VM size of the apps (user) node pool.')
param userNodeVmSize string

@description('Minimum (and initial) node count of the apps pool.')
param userNodeMinCount int

@description('Maximum node count of the apps pool.')
param userNodeMaxCount int

@description('Enable the application routing Gateway API implementation (gatewayClassName approuting-istio).')
param enableGatewayApi bool

@description('Object IDs (users or groups) that get "Azure Kubernetes Service RBAC Cluster Admin" and "Azure Kubernetes Service Cluster User Role".')
param clusterAdminPrincipalIds array

@description('Object ID of the GitHub deploy identity (service principal), or empty: Cluster User Role on the cluster + RBAC Writer on the app namespace.')
param deployPrincipalId string

@description('Kubernetes namespace of the application (scope of the RBAC Writer assignment).')
param appNamespace string

@description('Resource ID of the Log Analytics workspace for diagnostic settings.')
param logAnalyticsWorkspaceId string

var isPrivateCluster = apiServerAccess == 'private'

var availabilityZones = [
  '1'
  '2'
  '3'
]

var roleGuids = {
  rbacClusterAdmin: 'b1ff04bb-8a4e-4dc4-8eb5-8693973ce19b'
  clusterUser: '4abbcc35-e782-43d8-92c5-2d3c1bd2b3ac'
  rbacWriter: 'a7ffa36f-339b-4b5c-8bdf-e2c188b2c0eb'
}

// [OPS] Same window for Kubernetes patch upgrades and node image upgrades: Sunday 01:00-05:00 WIB (UTC+7).
var maintenanceWindow = {
  schedule: {
    weekly: {
      dayOfWeek: 'Sunday'
      intervalWeeks: 1
    }
  }
  durationHours: 4
  startTime: '01:00'
  utcOffset: '+07:00'
}

var controlPlaneLogCategories = [
  'kube-audit-admin' // [SEC] write operations only: much cheaper than kube-audit
  'kube-apiserver'
  'cluster-autoscaler'
  'guard' // Entra ID / Azure RBAC authorization decisions
]

resource aks 'Microsoft.ContainerService/managedClusters@2026-08-01' = {
  name: name
  location: location
  tags: tags
  sku: {
    name: 'Base'
    tier: 'Standard' // [REL] financially backed API server SLA; Free tier has none
  }
  identity: {
    type: 'UserAssigned' // [SEC] pre-created identity so Network Contributor on the spoke VNet exists before the cluster
    userAssignedIdentities: {
      '${controlPlaneIdentityId}': {}
    }
  }
  properties: {
    kubernetesVersion: kubernetesVersion
    dnsPrefix: dnsPrefix
    nodeResourceGroup: nodeResourceGroupName
    enableRBAC: true
    disableLocalAccounts: true // [SEC] no static cluster-admin kubeconfig; every user signs in with Entra ID
    aadProfile: {
      managed: true
      enableAzureRBAC: true // [SEC] Kubernetes authorization through Azure role assignments
      tenantID: subscription().tenantId
    }
    oidcIssuerProfile: {
      enabled: true // required by workload identity
    }
    securityProfile: {
      workloadIdentity: {
        enabled: true // [SEC] pods get Entra tokens through federated credentials, no secrets
      }
      imageCleaner: {
        enabled: true // [SEC] removes unused (possibly vulnerable) images from nodes
        intervalHours: 168
      }
    }
    autoUpgradeProfile: {
      upgradeChannel: 'patch' // [OPS] automatic patch releases inside the pinned minor version
      nodeOSUpgradeChannel: 'NodeImage' // [SEC] weekly node image with OS security fixes
    }
    networkProfile: {
      networkPlugin: 'azure'
      networkPluginMode: 'overlay' // [PERF] pod IPs come from podCidr, not the VNet: only nodes consume spoke addresses
      networkDataplane: 'cilium' // eBPF dataplane
      networkPolicy: 'cilium'
      podCidr: '192.168.0.0/16'
      serviceCidr: '172.16.0.0/16'
      dnsServiceIP: '172.16.0.10'
      outboundType: egressMode == 'firewall' ? 'userDefinedRouting' : 'userAssignedNATGateway' // egress owned by the spoke, not by AKS
      loadBalancerSku: 'standard'
    }
    apiServerAccessProfile: isPrivateCluster ? {
      enablePrivateCluster: true // [SEC] no public API server endpoint
      enableVnetIntegration: true // API server ILB is projected into snet-aks-apiserver
      subnetId: apiServerSubnetId
      privateDNSZone: 'system'
    } : {
      enablePrivateCluster: false
      authorizedIPRanges: authorizedIpRanges // [SEC] empty = unrestricted (lab); set your egress CIDRs when possible
    }
    agentPoolProfiles: [
      {
        name: 'system'
        mode: 'System'
        // PARITY GAP (workshop exercise, Modules 6 and 8): the Terraform twin sets os_disk_type = "Ephemeral" and
        // upgrade_settings.max_surge = "10%" on both pools; this Bicep leaves osDiskType and upgradeSettings at the AKS defaults.
        vmSize: systemNodeVmSize // [PERF] D4ds_v5 leaves headroom for add-ons and the optional Envoy gateway proxies (up to 2 vCPU / 1 GiB per replica)
        osType: 'Linux'
        osSKU: 'AzureLinux'
        type: 'VirtualMachineScaleSets'
        availabilityZones: availabilityZones // [REL] one node per zone at minimum
        vnetSubnetID: nodesSubnetId
        count: 3
        enableAutoScaling: true
        minCount: 3
        maxCount: 5
        nodeTaints: [
          'CriticalAddonsOnly=true:NoSchedule' // [REL] keep application pods off the system pool
        ]
        tags: tags
      }
      {
        name: 'apps'
        mode: 'User'
        // PARITY GAP (see the system pool): osDiskType and upgradeSettings.maxSurge differ from the Terraform twin.
        vmSize: userNodeVmSize
        osType: 'Linux'
        osSKU: 'AzureLinux'
        type: 'VirtualMachineScaleSets'
        availabilityZones: availabilityZones
        vnetSubnetID: nodesSubnetId
        count: userNodeMinCount
        enableAutoScaling: true // [COST] scale in when idle, [PERF] scale out under load
        minCount: userNodeMinCount
        maxCount: userNodeMaxCount
        tags: tags
      }
    ]
    addonProfiles: {
      azurepolicy: {
        enabled: true // [SEC] enforces the policy assignments on the AKS resource group (privileged containers)
      }
      azureKeyvaultSecretsProvider: {
        enabled: true
        config: {
          enableSecretRotation: 'true'
          rotationPollInterval: '2m'
        }
      }
    }
    // Managed Prometheus, Container insights and (by default) the Gateway API are enabled after provisioning by
    // scripts/aks-postprovision.sh; IaC only creates the Azure Monitor workspace. Re-run that script after
    // every update of this stack so settings applied out-of-band are re-asserted.
    ingressProfile: enableGatewayApi ? {
      gatewayAPI: {
        installation: 'Standard'
      }
      webAppRouting: {
        gatewayAPIImplementations: {
          appRoutingIstio: {
            mode: 'Enabled' // managed Istio-based Gateway API implementation (no NGINX)
          }
        }
      }
    } : null
  }
}

resource autoUpgradeSchedule 'Microsoft.ContainerService/managedClusters/maintenanceConfigurations@2026-08-01' = {
  parent: aks
  name: 'aksManagedAutoUpgradeSchedule'
  properties: {
    maintenanceWindow: maintenanceWindow
  }
}

resource nodeOsUpgradeSchedule 'Microsoft.ContainerService/managedClusters/maintenanceConfigurations@2026-08-01' = {
  parent: aks
  name: 'aksManagedNodeOSUpgradeSchedule'
  properties: {
    maintenanceWindow: maintenanceWindow
  }
  dependsOn: [
    autoUpgradeSchedule // [REL] one cluster operation at a time
  ]
}

// Human administrators: principalType is omitted because they can be users or groups.
resource clusterAdminRbac 'Microsoft.Authorization/roleAssignments@2022-04-01' = [for principalId in clusterAdminPrincipalIds: {
  name: guid(aks.id, principalId, roleGuids.rbacClusterAdmin)
  scope: aks
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleGuids.rbacClusterAdmin)
    principalId: principalId
    description: 'Kubernetes cluster-admin through Azure RBAC.'
  }
}]

resource clusterAdminUser 'Microsoft.Authorization/roleAssignments@2022-04-01' = [for principalId in clusterAdminPrincipalIds: {
  name: guid(aks.id, principalId, roleGuids.clusterUser)
  scope: aks
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleGuids.clusterUser)
    principalId: principalId
    description: 'Download the (Entra ID) kubeconfig.'
  }
}]

resource deployClusterUser 'Microsoft.Authorization/roleAssignments@2022-04-01' = if (!empty(deployPrincipalId)) {
  name: guid(aks.id, deployPrincipalId, roleGuids.clusterUser)
  scope: aks
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleGuids.clusterUser)
    principalId: deployPrincipalId
    principalType: 'ServicePrincipal'
    description: 'GitHub Actions deploy identity: download the kubeconfig.'
  }
}

// [SEC] Azure RBAC namespace scope '<cluster id>/namespaces/<name>' (Learn: az role assignment create --scope
// $AKS_ID/namespaces/<namespace>). It is a role assignment scope, not an ARM resource type at 2026-08-01
// (managedClusters/namespaces only exists in the retired 2025-02-02-preview managed-namespaces API), and Bicep
// accepts only a resource symbol as `scope`, so a nested deployment sets the documented scope string verbatim
// (same approach as AVM avm/ptn/authorization/resource-role-assignment). The namespace itself is created by the
// Kubernetes manifests.
#disable-next-line no-deployments-resources
resource deployNamespaceWriter 'Microsoft.Resources/deployments@2025-04-01' = if (!empty(deployPrincipalId)) {
  name: 'rbac-writer-ns-${appNamespace}'
  properties: {
    mode: 'Incremental'
    template: {
      '$schema': 'https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#'
      contentVersion: '1.0.0.0'
      resources: [
        {
          type: 'Microsoft.Authorization/roleAssignments'
          apiVersion: '2022-04-01'
          name: guid(aks.id, appNamespace, deployPrincipalId, roleGuids.rbacWriter)
          scope: '${aks.id}/namespaces/${appNamespace}'
          properties: {
            roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleGuids.rbacWriter)
            principalId: deployPrincipalId
            principalType: 'ServicePrincipal'
            description: 'GitHub Actions deploy identity: read/write workloads in the application namespace only.'
          }
        }
      ]
    }
  }
}

resource diagnostics 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: 'diag-log-analytics'
  scope: aks
  properties: {
    workspaceId: logAnalyticsWorkspaceId
    logAnalyticsDestinationType: 'Dedicated' // [COST] resource-specific AKSAudit*/AKSControlPlane tables
    logs: [for category in controlPlaneLogCategories: {
      category: category
      enabled: true
    }]
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
      }
    ]
  }
}

@description('Name of the cluster.')
output name string = aks.name

@description('Resource ID of the cluster.')
output id string = aks.id

@description('OIDC issuer URL (issuer of the federated identity credentials).')
output oidcIssuerUrl string = aks.properties.oidcIssuerProfile.issuerURL

@description('Object ID of the AKS-managed kubelet identity (AcrPull).')
output kubeletObjectId string = aks.properties.identityProfile.kubeletidentity.objectId
