metadata description = 'Role assignment on an existing container registry (AcrPull for the kubelet identity, AcrPush for the deploy identity).'

@description('Name of the container registry in the resource group this module is deployed to.')
param acrName string

@description('Object ID of the principal (kubelet identity or GitHub deploy identity).')
param principalId string

@description('GUID of the built-in role definition (AcrPull or AcrPush).')
param roleDefinitionGuid string

@description('Why the assignment exists (shown in the portal and in access reviews).')
param assignmentDescription string

resource registry 'Microsoft.ContainerRegistry/registries@2025-04-01' existing = {
  name: acrName
}

resource roleAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(registry.id, principalId, roleDefinitionGuid)
  scope: registry
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleDefinitionGuid)
    principalId: principalId
    principalType: 'ServicePrincipal' // managed identities and app registrations (GitHub OIDC) are service principals
    description: assignmentDescription
  }
}

@description('Resource ID of the role assignment.')
output id string = roleAssignment.id
