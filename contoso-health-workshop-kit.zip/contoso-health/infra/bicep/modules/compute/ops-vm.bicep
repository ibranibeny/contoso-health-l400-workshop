metadata description = 'Private ops VM (Ubuntu 24.04 LTS): no public IP, SSH key only, runs as the PostgreSQL Entra admin identity; operated with az vm run-command (no inbound port needed).'

@description('VM name (vm-ch-ops-<env>).')
param name string

@description('Azure region.')
param location string

@description('Tags applied to the VM and its NIC.')
param tags object

@description('VM size.')
param vmSize string

@description('Resource ID of snet-ops.')
param subnetId string

@description('Resource ID of the user-assigned identity attached to the VM (id-ch-dbadmin-<env>, the PostgreSQL Entra admin).')
param identityId string

@description('Linux admin user name (SSH key authentication only).')
param adminUsername string = 'azureops'

@description('SSH public key of the admin user. REQUIRED: export OPS_SSH_PUBLIC_KEY before deploying, or set deployOpsVm=false. An empty value fails validation here.')
@minLength(1)
param sshPublicKey string

// Packages only; no secrets in custom data (it is readable by anyone with VM read access).
var cloudInit = '''
#cloud-config
package_update: true
package_upgrade: true
packages:
  - postgresql-client
  - jq
'''

resource nic 'Microsoft.Network/networkInterfaces@2024-05-01' = {
  name: 'nic-${name}'
  location: location
  tags: tags
  properties: {
    ipConfigurations: [
      {
        name: 'ipconfig1'
        properties: {
          subnet: {
            id: subnetId
          }
          privateIPAllocationMethod: 'Dynamic' // [SEC] no public IP (policy: NICs should not have public IPs)
        }
      }
    ]
  }
}

resource vm 'Microsoft.Compute/virtualMachines@2024-07-01' = {
  name: name
  location: location
  tags: tags
  identity: {
    type: 'UserAssigned' // [SEC] the bootstrap script gets a PostgreSQL token from IMDS with this identity
    userAssignedIdentities: {
      '${identityId}': {}
    }
  }
  properties: {
    hardwareProfile: {
      vmSize: vmSize // [COST] burstable size: the VM is idle except during bootstrap/troubleshooting
    }
    osProfile: {
      computerName: name
      adminUsername: adminUsername
      #disable-next-line use-secure-value-for-secure-inputs
      customData: base64(cloudInit)
      linuxConfiguration: {
        disablePasswordAuthentication: true // [SEC] SSH keys only
        ssh: {
          publicKeys: [
            {
              path: '/home/${adminUsername}/.ssh/authorized_keys'
              keyData: sshPublicKey
            }
          ]
        }
        provisionVMAgent: true // required by az vm run-command
      }
    }
    storageProfile: {
      imageReference: {
        publisher: 'Canonical'
        offer: 'ubuntu-24_04-lts'
        sku: 'server'
        version: 'latest'
      }
      osDisk: {
        name: 'osdisk-${name}'
        createOption: 'FromImage'
        caching: 'ReadWrite'
        deleteOption: 'Delete' // [COST] no orphaned disk when the VM is deleted
        managedDisk: {
          storageAccountType: 'StandardSSD_LRS'
        }
      }
    }
    networkProfile: {
      networkInterfaces: [
        {
          id: nic.id
          properties: {
            deleteOption: 'Delete'
          }
        }
      ]
    }
    securityProfile: {
      securityType: 'TrustedLaunch' // [SEC] secure boot + vTPM (Gen2 image)
      uefiSettings: {
        secureBootEnabled: true
        vTpmEnabled: true
      }
    }
    diagnosticsProfile: {
      bootDiagnostics: {
        enabled: true // [OPS] managed boot diagnostics storage: serial console for troubleshooting
      }
    }
  }
}

@description('Name of the VM.')
output name string = vm.name

@description('Private IP address of the VM.')
output privateIp string = nic.properties.ipConfigurations[0].properties.privateIPAddress
