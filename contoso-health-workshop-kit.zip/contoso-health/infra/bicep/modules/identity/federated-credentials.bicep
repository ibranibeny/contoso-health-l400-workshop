metadata description = 'Federated identity credentials (AKS workload identity) on EXISTING user-assigned identities. The AKS stack deploys this module into the workload resource group that owns the identities.'

@description('Credentials to create: array of { identityName, name, subject }. subject = system:serviceaccount:<namespace>:<service account>.')
param credentials array

@description('OIDC issuer URL of the AKS cluster.')
param issuerUrl string

resource identities 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' existing = [for credential in credentials: {
  name: credential.identityName
}]

// [REL] Concurrent writes of federated credentials are not supported by Entra ID: create them one at a time.
@batchSize(1)
resource federatedCredentials 'Microsoft.ManagedIdentity/userAssignedIdentities/federatedIdentityCredentials@2023-01-31' = [for (credential, i) in credentials: {
  parent: identities[i]
  name: credential.name
  properties: {
    issuer: issuerUrl
    subject: credential.subject // [SEC] exact subject, no wildcards: only this service account can use the identity
    audiences: [
      'api://AzureADTokenExchange'
    ]
  }
}]
