metadata description = 'Grants a role (Network Contributor for the AKS control-plane identity) on the spoke VNet and, in firewall egress mode, on the spoke route table. The AKS stack deploys this module into the workload resource group.'

@description('Name of the spoke VNet in the resource group this module is deployed to.')
param vnetName string

@description('Name of the spoke route table to also grant the role on (firewall egress), or empty for none.')
param routeTableName string

@description('Object ID of the identity that receives the role (managed identity).')
param principalId string

@description('GUID of the built-in role definition.')
param roleDefinitionGuid string

var roleDefinitionId = subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleDefinitionGuid)
var grantOnRouteTable = !empty(routeTableName)

resource vnet 'Microsoft.Network/virtualNetworks@2024-05-01' existing = {
  name: vnetName
}

// Placeholder name keeps the reference well-formed when no route table exists; the assignment below is skipped then.
resource routeTable 'Microsoft.Network/routeTables@2024-05-01' existing = {
  name: grantOnRouteTable ? routeTableName : 'none'
}

// [SEC] VNet scope (not resource group): AKS joins snet-aks-nodes / snet-aks-apiserver and creates the
// internal load balancer frontend in snet-aks-ilb, nothing else in the workload resource group.
resource vnetRoleAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(vnet.id, principalId, roleDefinitionGuid)
  scope: vnet
  properties: {
    roleDefinitionId: roleDefinitionId
    principalId: principalId
    principalType: 'ServicePrincipal'
    description: 'AKS control plane manages node/ILB networking in the spoke VNet.'
  }
}

// userDefinedRouting: AKS validates (reads) the route table associated with the node subnet.
resource routeTableRoleAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = if (grantOnRouteTable) {
  name: guid(routeTable.id, principalId, roleDefinitionGuid)
  scope: routeTable
  properties: {
    roleDefinitionId: roleDefinitionId
    principalId: principalId
    principalType: 'ServicePrincipal'
    description: 'AKS control plane reads the spoke route table (userDefinedRouting egress).'
  }
}

@description('Resource ID of the VNet role assignment.')
output vnetRoleAssignmentId string = vnetRoleAssignment.id
