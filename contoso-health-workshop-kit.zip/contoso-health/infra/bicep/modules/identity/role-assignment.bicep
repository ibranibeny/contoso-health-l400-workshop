targetScope = 'resourceGroup'

metadata description = 'Role assignment at resource-group scope (used by the platform stack for RBAC vending on the workload resource groups).'

@description('Object ID of the principal that receives the role.')
param principalId string

@description('GUID of the built-in role definition, e.g. b24988ac-6180-42a0-ab88-20f7382dd24c (Contributor).')
param roleDefinitionGuid string

@description('Principal type: Group, User or ServicePrincipal. Setting it avoids replication-delay failures for new principals.')
param principalType string

@description('Why the assignment exists (shown in the portal and in access reviews).')
param assignmentDescription string

resource roleAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(resourceGroup().id, principalId, roleDefinitionGuid)
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleDefinitionGuid)
    principalId: principalId
    principalType: principalType
    description: assignmentDescription
  }
}

@description('Resource ID of the role assignment.')
output id string = roleAssignment.id
