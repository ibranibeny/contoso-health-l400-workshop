metadata description = 'Workspace-based Application Insights for one environment + "Monitoring Metrics Publisher" for the app identities (Entra ID ingestion).'

@description('Application Insights name (appi-ch-<env>-idc).')
param name string

@description('Azure region.')
param location string

@description('Tags applied to the component.')
param tags object

@description('Resource ID of the platform Log Analytics workspace (data is stored there).')
param logAnalyticsWorkspaceId string

@description('Disable local (instrumentation key) authentication so only Entra ID-authenticated telemetry is accepted: false lab, true prod.')
param disableLocalAuth bool

@description('Principal IDs (managed identities) that get "Monitoring Metrics Publisher" on the component.')
param metricsPublisherPrincipalIds array

var monitoringMetricsPublisherRoleGuid = '3913510d-42f4-4e42-8a64-420c390055eb'

resource appInsights 'Microsoft.Insights/components@2020-02-02' = {
  name: name
  location: location
  tags: tags
  kind: 'web'
  properties: {
    Application_Type: 'web'
    WorkspaceResourceId: logAnalyticsWorkspaceId // [OPS] workspace-based: one place for app + platform logs
    IngestionMode: 'LogAnalytics'
    DisableLocalAuth: disableLocalAuth // [SEC] prod rejects key-only ingestion; the apps send with their managed identity
    publicNetworkAccessForIngestion: 'Enabled' // no Azure Monitor Private Link Scope in this kit; ingestion is authenticated
    publicNetworkAccessForQuery: 'Enabled'
  }
}

resource metricsPublishers 'Microsoft.Authorization/roleAssignments@2022-04-01' = [for principalId in metricsPublisherPrincipalIds: {
  name: guid(appInsights.id, principalId, monitoringMetricsPublisherRoleGuid)
  scope: appInsights
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', monitoringMetricsPublisherRoleGuid)
    principalId: principalId
    principalType: 'ServicePrincipal'
    description: 'Entra ID-authenticated telemetry ingestion (APPLICATIONINSIGHTS_AUTH=entra).'
  }
}]

@description('Name of the Application Insights component.')
output name string = appInsights.name

@description('Resource ID of the Application Insights component.')
output id string = appInsights.id
