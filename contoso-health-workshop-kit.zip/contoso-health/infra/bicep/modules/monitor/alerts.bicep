metadata description = 'Action group and baseline metric alerts for one environment.'

@description('Action group name (ag-ch-<env>); its first 12 characters are the SMS/e-mail short name.')
param actionGroupName string

@description('E-mail address notified by the action group. Empty = the action group is created without receivers.')
param alertEmail string

@description('Tags applied to the action group and alerts.')
param tags object

@description('Name of the Application Gateway (same resource group).')
param appGatewayName string

@description('Name of the PostgreSQL flexible server (same resource group).')
param postgresServerName string

resource appGateway 'Microsoft.Network/applicationGateways@2024-05-01' existing = {
  name: appGatewayName
}

resource postgresServer 'Microsoft.DBforPostgreSQL/flexibleServers@2025-08-01' existing = {
  name: postgresServerName
}

resource actionGroup 'Microsoft.Insights/actionGroups@2023-01-01' = {
  name: actionGroupName
  location: 'global'
  tags: tags
  properties: {
    groupShortName: take(actionGroupName, 12)
    enabled: true
    emailReceivers: empty(alertEmail) ? [] : [
      {
        name: 'platform-team-email'
        emailAddress: alertEmail
        useCommonAlertSchema: true // [OPS] one payload schema for every alert type (easier automation)
      }
    ]
  }
}

// [REL] Any unhealthy backend means users can hit errors. Note: the AKS pool (:8080) stays unhealthy until the
// AKS stack is deployed and the internal "web" Service exists, so this alert fires in a workload-only deployment.
resource appGatewayUnhealthyHosts 'Microsoft.Insights/metricAlerts@2018-03-01' = {
  name: 'alert-${appGatewayName}-unhealthy-hosts'
  location: 'global'
  tags: tags
  properties: {
    description: 'Application Gateway reports at least one unhealthy backend host (5 minute average).'
    severity: 1
    enabled: true
    scopes: [
      appGateway.id
    ]
    evaluationFrequency: 'PT1M'
    windowSize: 'PT5M'
    autoMitigate: true
    criteria: {
      'odata.type': 'Microsoft.Azure.Monitor.SingleResourceMultipleMetricCriteria'
      allOf: [
        {
          criterionType: 'StaticThresholdCriterion'
          name: 'unhealthy-host-count'
          metricNamespace: 'Microsoft.Network/applicationGateways'
          metricName: 'UnhealthyHostCount'
          operator: 'GreaterThan'
          threshold: 0
          timeAggregation: 'Average'
        }
      ]
    }
    actions: [
      {
        actionGroupId: actionGroup.id
      }
    ]
  }
}

// [PERF] Sustained CPU above 80 % on the database: scale up the SKU or look for missing indexes / N+1 queries.
resource postgresCpu 'Microsoft.Insights/metricAlerts@2018-03-01' = {
  name: 'alert-${postgresServerName}-cpu'
  location: 'global'
  tags: tags
  properties: {
    description: 'PostgreSQL flexible server CPU above 80 percent (15 minute average).'
    severity: 2
    enabled: true
    scopes: [
      postgresServer.id
    ]
    evaluationFrequency: 'PT5M'
    windowSize: 'PT15M'
    autoMitigate: true
    criteria: {
      'odata.type': 'Microsoft.Azure.Monitor.SingleResourceMultipleMetricCriteria'
      allOf: [
        {
          criterionType: 'StaticThresholdCriterion'
          name: 'cpu-percent'
          metricNamespace: 'Microsoft.DBforPostgreSQL/flexibleServers'
          metricName: 'cpu_percent'
          operator: 'GreaterThan'
          threshold: 80
          timeAggregation: 'Average'
        }
      ]
    }
    actions: [
      {
        actionGroupId: actionGroup.id
      }
    ]
  }
}

// TODO(copilot-exercise): Redis server load alert

@description('Resource ID of the action group.')
output actionGroupId string = actionGroup.id
