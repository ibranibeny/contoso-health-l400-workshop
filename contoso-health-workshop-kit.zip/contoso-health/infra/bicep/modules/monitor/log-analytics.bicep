metadata description = 'Central Log Analytics workspace (management design area) shared by every environment.'

@description('Workspace name (log-ch-idc).')
param name string

@description('Azure region.')
param location string

@description('Tags applied to the workspace.')
param tags object

@description('Interactive retention in days.')
@minValue(30)
@maxValue(730)
param retentionInDays int

resource workspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: name
  location: location
  tags: tags
  properties: {
    sku: {
      name: 'PerGB2018' // [COST] pay-as-you-go; move to a commitment tier above ~100 GB/day
    }
    retentionInDays: retentionInDays // [COST] 30 days are included in the ingestion price; [OPS] archive tier for longer
    features: {
      enableLogAccessUsingOnlyResourcePermissions: true // [SEC] resource-context RBAC: teams only see logs of resources they can read
    }
  }
}

@description('Resource ID of the workspace.')
output id string = workspace.id

@description('Name of the workspace.')
output name string = workspace.name
