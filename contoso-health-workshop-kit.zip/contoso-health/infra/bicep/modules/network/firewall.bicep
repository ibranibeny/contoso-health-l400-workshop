metadata description = 'Azure Firewall Standard (zone-redundant) in the hub with a firewall policy holding the egress allow-list for the Contoso Health spokes.'

@description('Firewall name (afw-ch-hub-idc).')
param name string

@description('Firewall policy name (afwp-ch-hub-idc).')
param policyName string

@description('Azure region.')
param location string

@description('Tags applied to every resource in this module.')
param tags object

@description('Resource ID of AzureFirewallSubnet in the hub VNet.')
param subnetId string

@description('Spoke address prefixes allowed to egress through the firewall.')
param sourceAddressPrefixes array

@description('Resource ID of the Log Analytics workspace for diagnostic settings.')
param logAnalyticsWorkspaceId string

// Entra ID sign-in host of the current cloud, derived instead of hard-coded (linter rule no-hardcoded-env-urls).
var entraLoginHost = replace(replace(environment().authentication.loginEndpoint, 'https://', ''), '/', '')

resource publicIp 'Microsoft.Network/publicIPAddresses@2024-05-01' = {
  name: 'pip-${name}'
  location: location
  tags: tags
  zones: [
    '1'
    '2'
    '3'
  ] // [REL] zone-redundant frontend, same zones as the firewall
  sku: {
    name: 'Standard'
    tier: 'Regional'
  }
  properties: {
    publicIPAllocationMethod: 'Static'
    publicIPAddressVersion: 'IPv4'
  }
}

resource policy 'Microsoft.Network/firewallPolicies@2024-05-01' = {
  name: policyName
  location: location
  tags: tags
  properties: {
    sku: {
      tier: 'Standard'
    }
    threatIntelMode: 'Alert' // [SEC] logs traffic to known-malicious IPs/FQDNs; switch to Deny once the allow-list is proven
  }
}

// Default deny: anything not allowed below is dropped and logged (AZFWApplicationRule / AZFWNetworkRule tables).
resource egressRules 'Microsoft.Network/firewallPolicies/ruleCollectionGroups@2024-05-01' = {
  parent: policy
  name: 'rcg-contoso-health-egress'
  properties: {
    priority: 200
    ruleCollections: [
      {
        ruleCollectionType: 'FirewallPolicyFilterRuleCollection'
        name: 'net-allow-azure-platform'
        priority: 100
        action: {
          type: 'Allow'
        }
        rules: [
          {
            ruleType: 'NetworkRule'
            name: 'azure-monitor-and-entra-id'
            ipProtocols: [
              'TCP'
            ]
            sourceAddresses: sourceAddressPrefixes
            destinationAddresses: [
              'AzureMonitor' // service tag: telemetry ingestion and live metrics
              'AzureActiveDirectory' // service tag: token endpoints for managed/workload identities
            ]
            destinationPorts: [
              '443'
            ]
          }
          {
            ruleType: 'NetworkRule'
            name: 'ntp'
            ipProtocols: [
              'UDP'
            ]
            sourceAddresses: sourceAddressPrefixes
            destinationAddresses: [
              '*'
            ]
            destinationPorts: [
              '123'
            ] // [REL] AKS nodes and VMs need time sync (token validation fails on clock skew)
          }
        ]
      }
      {
        ruleCollectionType: 'FirewallPolicyFilterRuleCollection'
        name: 'app-allow-aks-and-dependencies'
        priority: 200
        action: {
          type: 'Allow'
        }
        rules: [
          {
            ruleType: 'ApplicationRule'
            name: 'aks-required-fqdns'
            sourceAddresses: sourceAddressPrefixes
            fqdnTags: [
              'AzureKubernetesService' // Microsoft-maintained list of AKS egress FQDNs
            ]
            protocols: [
              {
                protocolType: 'Https'
                port: 443
              }
              {
                protocolType: 'Http'
                port: 80
              }
            ]
          }
          {
            ruleType: 'ApplicationRule'
            name: 'registries-identity-telemetry'
            sourceAddresses: sourceAddressPrefixes
            targetFqdns: [
              '*.azurecr.io'
              '*.data.mcr.microsoft.com'
              'mcr.microsoft.com'
              entraLoginHost
              '*.in.applicationinsights.azure.com'
            ]
            protocols: [
              {
                protocolType: 'Https'
                port: 443
              }
            ]
          }
          {
            ruleType: 'ApplicationRule'
            name: 'ubuntu-packages'
            sourceAddresses: sourceAddressPrefixes
            targetFqdns: [
              '*.ubuntu.com' // ops VM cloud-init (apt mirrors use plain HTTP, packages are GPG-signed)
            ]
            protocols: [
              {
                protocolType: 'Http'
                port: 80
              }
              {
                protocolType: 'Https'
                port: 443
              }
            ]
          }
        ]
      }
    ]
  }
}

resource firewall 'Microsoft.Network/azureFirewalls@2024-05-01' = {
  name: name
  location: location
  tags: tags
  zones: [
    '1'
    '2'
    '3'
  ] // [REL] zone-redundant data path (Indonesia Central has 3 zones)
  properties: {
    sku: {
      name: 'AZFW_VNet'
      tier: 'Standard' // [COST] Standard covers FQDN filtering + threat intel; Premium adds TLS inspection/IDPS
    }
    firewallPolicy: {
      id: policy.id
    }
    ipConfigurations: [
      {
        name: 'ipconfig-public'
        properties: {
          subnet: {
            id: subnetId
          }
          publicIPAddress: {
            id: publicIp.id
          }
        }
      }
    ]
  }
  dependsOn: [
    egressRules // [REL] avoid concurrent policy updates while the firewall is provisioning
  ]
}

resource diagnostics 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: 'diag-log-analytics'
  scope: firewall
  properties: {
    workspaceId: logAnalyticsWorkspaceId
    logAnalyticsDestinationType: 'Dedicated' // [OPS] resource-specific AZFW* tables: cheaper and easier to query
    logs: [
      {
        categoryGroup: 'allLogs'
        enabled: true
      }
    ]
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
      }
    ]
  }
}

@description('Resource ID of the firewall.')
output id string = firewall.id

@description('Private IP of the firewall (next hop for the spoke route tables).')
output privateIp string = firewall.properties.ipConfigurations[0].properties.privateIPAddress
