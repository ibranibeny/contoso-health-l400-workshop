metadata description = 'Central privatelink DNS zones (owned by the platform team in the hub) linked to the hub VNet. Spokes add their own links.'

@description('Private DNS zone names to create, e.g. privatelink.vaultcore.azure.net.')
param zoneNames array

@description('Resource ID of the hub VNet linked to every zone.')
param hubVnetId string

@description('Name of the hub VNet link created in every zone.')
param linkName string

@description('Tags applied to the zones and links.')
param tags object

// [OPS] One zone per service for the whole organisation: private endpoints in any spoke register here,
// which avoids split-brain DNS (the classic "works in one VNet, not in the other" failure).
resource zones 'Microsoft.Network/privateDnsZones@2024-06-01' = [for zoneName in zoneNames: {
  name: zoneName
  location: 'global'
  tags: tags
}]

resource hubLinks 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2024-06-01' = [for i in range(0, length(zoneNames)): {
  parent: zones[i]
  name: linkName
  location: 'global'
  tags: tags
  properties: {
    registrationEnabled: false // [SEC] privatelink zones hold private endpoint records only
    virtualNetwork: {
      id: hubVnetId
    }
  }
}]
