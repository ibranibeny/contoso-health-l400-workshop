metadata description = 'Azure Bastion (Basic) in the hub for interactive SSH to the private ops VMs in peered spokes.'

@description('Bastion host name (bas-ch-hub-idc).')
param name string

@description('Azure region.')
param location string

@description('Tags applied to every resource in this module.')
param tags object

@description('Resource ID of AzureBastionSubnet in the hub VNet.')
param subnetId string

resource publicIp 'Microsoft.Network/publicIPAddresses@2024-05-01' = {
  name: 'pip-${name}'
  location: location
  tags: tags
  sku: {
    name: 'Standard' // Bastion requires a Standard, static public IP
    tier: 'Regional'
  }
  properties: {
    publicIPAllocationMethod: 'Static'
    publicIPAddressVersion: 'IPv4'
  }
}

resource bastion 'Microsoft.Network/bastionHosts@2024-05-01' = {
  name: name
  location: location
  tags: tags
  sku: {
    name: 'Basic' // [COST] Basic covers portal SSH/RDP to peered VNets; Standard adds native client and IP-based connect
  }
  properties: {
    ipConfigurations: [
      {
        name: 'ipconfig-public'
        properties: {
          subnet: {
            id: subnetId
          }
          publicIPAddress: {
            id: publicIp.id
          }
        }
      }
    ]
  }
}

@description('Resource ID of the Bastion host.')
output id string = bastion.id
