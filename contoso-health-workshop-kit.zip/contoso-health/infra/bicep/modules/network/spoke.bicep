metadata description = 'Workload spoke: VNet with private subnets (default outbound access disabled where supported), one NSG per subnet, explicit egress (NAT gateway or hub firewall) and the spoke-to-hub peering.'

@description('Spoke VNet name (vnet-ch-<env>-idc).')
param name string

@description('Azure region.')
param location string

@description('Tags applied to every resource in this module.')
param tags object

@description('Spoke address space (/20): lab 10.110.0.0/20, prod 10.120.0.0/20. Every subnet is derived from it.')
param addressPrefix string

@description('Egress mode for snet-app-integration, snet-aks-nodes and snet-ops: natGateway or firewall.')
param egressMode string

@description('Private IP of the hub Azure Firewall; required when egressMode is firewall, ignored otherwise.')
param firewallPrivateIp string

@description('NAT gateway name (created when egressMode is natGateway).')
param natGatewayName string

@description('Route table name (created when egressMode is firewall).')
param routeTableName string

@description('Resource ID of the hub VNet (remote side of the spoke-to-hub peering).')
param hubVnetId string

@description('Name of the spoke-to-hub peering.')
param hubPeeringName string

@description('Address prefix of the hub AzureBastionSubnet; the only source allowed to SSH to snet-ops.')
param bastionSubnetPrefix string

@description('Resource ID of a DDoS protection plan to associate with the spoke, or empty for none.')
param ddosProtectionPlanId string

var useNatGateway = egressMode == 'natGateway'
var useFirewall = egressMode == 'firewall'
var natGatewayId = resourceId('Microsoft.Network/natGateways', natGatewayName)
var routeTableId = resourceId('Microsoft.Network/routeTables', routeTableName)

// App Gateway v2 subnet rules (Learn "Application Gateway infrastructure configuration").
var appGatewayNsgRules = [
  {
    name: 'Allow-GatewayManager-Inbound'
    properties: {
      description: 'App Gateway v2 control plane (health/management). Required.'
      priority: 100
      direction: 'Inbound'
      access: 'Allow'
      protocol: 'Tcp'
      sourceAddressPrefix: 'GatewayManager'
      sourcePortRange: '*'
      destinationAddressPrefix: '*'
      destinationPortRange: '65200-65535'
    }
  }
  {
    name: 'Allow-AzureLoadBalancer-Inbound'
    properties: {
      description: 'Azure infrastructure health probes. Required.'
      priority: 110
      direction: 'Inbound'
      access: 'Allow'
      protocol: '*'
      sourceAddressPrefix: 'AzureLoadBalancer'
      sourcePortRange: '*'
      destinationAddressPrefix: '*'
      destinationPortRange: '*'
    }
  }
  {
    name: 'Allow-Internet-Web-Inbound'
    properties: {
      description: 'Public listeners: 80/443 (App Service path) and 8080 (AKS path).'
      priority: 120
      direction: 'Inbound'
      access: 'Allow'
      protocol: 'Tcp'
      sourceAddressPrefix: 'Internet'
      sourcePortRange: '*'
      destinationAddressPrefix: '*'
      destinationPortRanges: [
        '80'
        '443'
        '8080'
      ]
    }
  }
]

// Ops VM: no inbound from inside the VNet except SSH from Bastion; az vm run-command needs no inbound port.
var opsNsgRules = [
  {
    name: 'Allow-Ssh-From-Bastion'
    properties: {
      description: 'Interactive SSH only through Azure Bastion in the hub (when deployed).'
      priority: 100
      direction: 'Inbound'
      access: 'Allow'
      protocol: 'Tcp'
      sourceAddressPrefix: bastionSubnetPrefix
      sourcePortRange: '*'
      destinationAddressPrefix: '*'
      destinationPortRange: '22'
    }
  }
  {
    name: 'Deny-VirtualNetwork-Inbound'
    properties: {
      description: 'Overrides the default AllowVnetInBound rule: no lateral movement into the jump host.'
      priority: 4000
      direction: 'Inbound'
      access: 'Deny'
      protocol: '*'
      sourceAddressPrefix: 'VirtualNetwork'
      sourcePortRange: '*'
      destinationAddressPrefix: '*'
      destinationPortRange: '*'
    }
  }
]

// Address plan (lab values for 10.110.0.0/20; prod is identical inside 10.120.0.0/20).
// egress = subnet gets the NAT gateway (natGateway mode) or the 0.0.0.0/0 route to the hub firewall (firewall mode).
// privateSubnet = defaultOutboundAccess: false; set only where Learn supports private subnets.
var subnets = [
  {
    name: 'snet-appgw'
    prefix: cidrSubnet(addressPrefix, 24, 0) // x.x.0.0/24 (App Gateway v2 recommends a /24)
    delegation: ''
    egress: false // App Gateway egresses through its own public IP; a 0.0.0.0/0 UDR is not supported here
    // Left at the platform default pending verification: no Learn statement that Application Gateway v2 supports
    // private subnets (defaultOutboundAccess: false).
    privateSubnet: false
    privateEndpointNetworkPolicies: 'Disabled'
    securityRules: appGatewayNsgRules
  }
  {
    name: 'snet-app-integration'
    prefix: cidrSubnet(addressPrefix, 26, 4) // x.x.1.0/26 (App Service VNet integration, /26 recommended)
    delegation: 'Microsoft.Web/serverFarms'
    egress: true
    privateSubnet: false // delegated: Learn "private subnets aren't applicable to delegated or managed subnets"
    privateEndpointNetworkPolicies: 'Disabled'
    securityRules: []
  }
  {
    name: 'snet-private-endpoints'
    prefix: cidrSubnet(addressPrefix, 24, 2) // x.x.2.0/24
    delegation: ''
    egress: false
    privateSubnet: true
    privateEndpointNetworkPolicies: 'Enabled' // [SEC] NSG rules are enforced on private endpoint traffic
    securityRules: []
  }
  {
    name: 'snet-ops'
    prefix: cidrSubnet(addressPrefix, 27, 24) // x.x.3.0/27
    delegation: ''
    egress: true
    privateSubnet: true
    privateEndpointNetworkPolicies: 'Disabled'
    securityRules: opsNsgRules
  }
  {
    name: 'snet-aks-ilb'
    prefix: cidrSubnet(addressPrefix, 27, 26) // x.x.3.64/27 (frontend of the AKS internal load balancer)
    delegation: ''
    egress: false
    privateSubnet: true
    privateEndpointNetworkPolicies: 'Disabled'
    securityRules: []
  }
  {
    name: 'snet-aks-apiserver'
    prefix: cidrSubnet(addressPrefix, 28, 54) // x.x.3.96/28 (API server VNet integration, reserved in lab)
    delegation: 'Microsoft.ContainerService/managedClusters'
    egress: false
    privateSubnet: false // delegated: Learn "private subnets aren't applicable to delegated or managed subnets"
    privateEndpointNetworkPolicies: 'Disabled'
    securityRules: []
  }
  {
    name: 'snet-aks-nodes'
    prefix: cidrSubnet(addressPrefix, 22, 1) // x.x.4.0/22 (nodes only: CNI Overlay keeps pod IPs off the VNet)
    delegation: ''
    egress: true // [REL] outboundType userAssignedNATGateway: the NAT gateway must be on this subnet before the cluster exists
    privateSubnet: true
    privateEndpointNetworkPolicies: 'Disabled'
    securityRules: []
  }
]

// [SEC] One NSG per subnet (policy "Subnets should be associated with a Network Security Group").
resource nsgs 'Microsoft.Network/networkSecurityGroups@2024-05-01' = [for subnet in subnets: {
  name: 'nsg-${subnet.name}'
  location: location
  tags: tags
  properties: {
    securityRules: subnet.securityRules
  }
}]

// [COST] lab egress: one NAT gateway (no hourly firewall cost) with a static, allow-listable public IP.
// [REL] Standard NAT gateway is a zonal/regional resource, not zone-redundant: acceptable for lab, prod uses the firewall.
resource natPublicIp 'Microsoft.Network/publicIPAddresses@2024-05-01' = if (useNatGateway) {
  name: 'pip-${natGatewayName}'
  location: location
  tags: tags
  sku: {
    name: 'Standard'
    tier: 'Regional'
  }
  properties: {
    publicIPAllocationMethod: 'Static'
    publicIPAddressVersion: 'IPv4'
  }
}

resource natGateway 'Microsoft.Network/natGateways@2024-05-01' = if (useNatGateway) {
  name: natGatewayName
  location: location
  tags: tags
  sku: {
    name: 'Standard'
  }
  properties: {
    idleTimeoutInMinutes: 4
    publicIpAddresses: [
      {
        id: resourceId('Microsoft.Network/publicIPAddresses', 'pip-${natGatewayName}')
      }
    ]
  }
  dependsOn: [
    natPublicIp
  ]
}

// [SEC] prod egress: force all internet-bound traffic through the hub firewall allow-list.
resource routeTable 'Microsoft.Network/routeTables@2024-05-01' = if (useFirewall) {
  name: routeTableName
  location: location
  tags: tags
  properties: {
    disableBgpRoutePropagation: true // no gateway routes may bypass the firewall
    routes: [
      {
        name: 'default-via-hub-firewall'
        properties: {
          addressPrefix: '0.0.0.0/0'
          nextHopType: 'VirtualAppliance'
          nextHopIpAddress: firewallPrivateIp
        }
      }
    ]
  }
}

// Subnets are declared inline (not as child resources) so redeployments never try to delete/recreate them.
resource vnet 'Microsoft.Network/virtualNetworks@2024-05-01' = {
  name: name
  location: location
  tags: tags
  properties: {
    addressSpace: {
      addressPrefixes: [
        addressPrefix
      ]
    }
    enableDdosProtection: !empty(ddosProtectionPlanId) // [SEC] protects the App Gateway public IP when the platform plan exists
    ddosProtectionPlan: empty(ddosProtectionPlanId) ? null : { id: ddosProtectionPlanId }
    subnets: [for (subnet, i) in subnets: {
      name: subnet.name
      // defaultOutboundAccess is sent only for private subnets; the others leave it unset (platform default).
      properties: union({
        addressPrefix: subnet.prefix
        networkSecurityGroup: {
          id: nsgs[i].id
        }
        natGateway: (subnet.egress && useNatGateway) ? { id: natGatewayId } : null
        routeTable: (subnet.egress && useFirewall) ? { id: routeTableId } : null
        privateEndpointNetworkPolicies: subnet.privateEndpointNetworkPolicies
        delegations: empty(subnet.delegation) ? [] : [
          {
            name: 'delegation'
            properties: {
              serviceName: subnet.delegation
            }
          }
        ]
      }, subnet.privateSubnet ? {
        defaultOutboundAccess: false // [SEC] private subnet: default outbound access is retired, egress must be explicit
      } : {})
    }]
  }
  dependsOn: [
    natGateway
    routeTable
  ]
}

resource spokeToHub 'Microsoft.Network/virtualNetworks/virtualNetworkPeerings@2024-05-01' = {
  parent: vnet
  name: hubPeeringName
  properties: {
    remoteVirtualNetwork: {
      id: hubVnetId
    }
    allowVirtualNetworkAccess: true
    allowForwardedTraffic: true // [SEC] return traffic forwarded by the hub firewall
    allowGatewayTransit: false
    useRemoteGateways: false // no VPN/ExpressRoute gateway in the hub
  }
}

@description('Resource ID of the spoke VNet.')
output vnetId string = vnet.id

@description('Name of the spoke VNet.')
output vnetName string = vnet.name

@description('Resource ID of snet-appgw.')
output appGatewaySubnetId string = resourceId('Microsoft.Network/virtualNetworks/subnets', vnet.name, 'snet-appgw')

@description('Resource ID of snet-app-integration.')
output appIntegrationSubnetId string = resourceId('Microsoft.Network/virtualNetworks/subnets', vnet.name, 'snet-app-integration')

@description('Resource ID of snet-private-endpoints.')
output privateEndpointsSubnetId string = resourceId('Microsoft.Network/virtualNetworks/subnets', vnet.name, 'snet-private-endpoints')

@description('Resource ID of snet-ops.')
output opsSubnetId string = resourceId('Microsoft.Network/virtualNetworks/subnets', vnet.name, 'snet-ops')

@description('Resource ID of snet-aks-ilb.')
output aksIlbSubnetId string = resourceId('Microsoft.Network/virtualNetworks/subnets', vnet.name, 'snet-aks-ilb')

@description('Resource ID of snet-aks-apiserver.')
output aksApiServerSubnetId string = resourceId('Microsoft.Network/virtualNetworks/subnets', vnet.name, 'snet-aks-apiserver')

@description('Resource ID of snet-aks-nodes.')
output aksNodesSubnetId string = resourceId('Microsoft.Network/virtualNetworks/subnets', vnet.name, 'snet-aks-nodes')

@description('Resource ID of the NAT gateway, or empty when egressMode is firewall.')
output natGatewayId string = useNatGateway ? natGatewayId : ''

@description('Resource ID of the spoke-to-hub peering.')
output hubPeeringId string = spokeToHub.id
