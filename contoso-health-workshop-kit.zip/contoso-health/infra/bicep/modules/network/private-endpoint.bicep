metadata description = 'One private endpoint for a PaaS data plane plus its DNS zone group, which registers the A record(s) in the hub private DNS zone.'

@description('Private endpoint name, e.g. pe-kv-ch-lab-abc123.')
param name string

@description('Azure region of the private endpoint (must match the VNet region).')
param location string

@description('Tags applied to the private endpoint.')
param tags object

@description('Resource ID of the subnet that hosts the private endpoint NIC (snet-private-endpoints).')
param subnetId string

@description('Resource ID of the target resource (the private link service).')
param privateLinkServiceId string

@description('Private link sub-resource (group ID): sites, postgresqlServer, redisEnterprise, vault or registry.')
param groupId string

@description('Resource ID of the private DNS zone in the hub that receives the A record(s).')
param privateDnsZoneId string

resource privateEndpoint 'Microsoft.Network/privateEndpoints@2024-05-01' = {
  name: name
  location: location
  tags: tags
  properties: {
    subnet: {
      id: subnetId
    }
    customNetworkInterfaceName: 'nic-${name}' // [OPS] predictable NIC name instead of an auto-generated one
    privateLinkServiceConnections: [
      {
        name: name
        properties: {
          privateLinkServiceId: privateLinkServiceId
          groupIds: [
            groupId
          ]
        }
      }
    ]
  }
}

// The zone group keeps the A record in sync with the endpoint lifecycle (created and deleted with it).
resource dnsZoneGroup 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2024-05-01' = {
  parent: privateEndpoint
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: replace(last(split(privateDnsZoneId, '/')), '.', '-')
        properties: {
          privateDnsZoneId: privateDnsZoneId
        }
      }
    ]
  }
}

@description('Resource ID of the private endpoint.')
output id string = privateEndpoint.id

@description('Name of the private endpoint.')
output name string = privateEndpoint.name
