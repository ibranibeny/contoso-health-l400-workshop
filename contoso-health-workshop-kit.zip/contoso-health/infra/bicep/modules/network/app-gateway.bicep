metadata description = 'Application Gateway WAF_v2 (zone-redundant, autoscaling) in the workload spoke: :80/:443 -> App Service web app (via its private endpoint), :8080 -> AKS internal load balancer.'

@description('Application Gateway name (agw-ch-<env>-idc).')
param name string

@description('Azure region.')
param location string

@description('Tags applied to every resource in this module.')
param tags object

@description('Public IP name (pip-agw-ch-<env>-idc).')
param publicIpName string

@description('WAF policy name.')
param wafPolicyName string

@description('Resource ID of snet-appgw (dedicated subnet).')
param subnetId string

@description('Resource ID of the user-assigned identity (id-ch-agw-<env>) used to read the TLS certificate from Key Vault.')
param identityId string

@description('Autoscale minimum instance count (lab 1, prod 2).')
@minValue(0)
param minCapacity int

@description('Autoscale maximum instance count.')
@maxValue(125)
param maxCapacity int

@description('Default host name of the web app (backend FQDN, resolves to its private endpoint through the linked private DNS zone).')
param webAppHostName string

@description('Static private IP of the AKS internal load balancer in snet-aks-ilb.')
param aksIngressPrivateIp string

@description('Key Vault secret ID of the TLS certificate. Empty = HTTP only (lab only).')
#disable-next-line secure-secrets-in-params
param tlsCertificateSecretId string

@description('Resource ID of the Log Analytics workspace for diagnostic settings.')
param logAnalyticsWorkspaceId string

@description('WAF policy mode: Prevention (blocks) or Detection (logs only).')
@allowed([
  'Prevention'
  'Detection'
])
param wafMode string = 'Prevention'

@description('POST requests to /api/claims allowed per client IP and minute before the WAF blocks them (custom rule RateLimitClaimSubmissions).')
@minValue(1)
param wafClaimsRateLimitPerMinute int = 60

@description('Add the custom rule BlockOpsApiFromInternet: block /api/ops/* at the edge.')
param wafBlockOpsApi bool = false

@description('ISO 3166-1 alpha-2 country codes the traffic is expected from; requests from other countries are logged, not blocked (custom rule LogOutsideAllowedCountries).')
@minLength(1)
param wafAllowedCountryCodes array = [
  'ID'
]

var enableHttps = !empty(tlsCertificateSecretId)

// Child resource IDs (App Gateway sub-resources are referenced by ID inside the same resource body).
var frontendIpConfigId = resourceId('Microsoft.Network/applicationGateways/frontendIPConfigurations', name, 'fe-public')
var listenerHttpId = resourceId('Microsoft.Network/applicationGateways/httpListeners', name, 'listener-http-80')
var listenerHttpsId = resourceId('Microsoft.Network/applicationGateways/httpListeners', name, 'listener-https-443')
var listenerAksId = resourceId('Microsoft.Network/applicationGateways/httpListeners', name, 'listener-http-8080')
var poolAppServiceId = resourceId('Microsoft.Network/applicationGateways/backendAddressPools', name, 'pool-appservice-web')
var poolAksId = resourceId('Microsoft.Network/applicationGateways/backendAddressPools', name, 'pool-aks-ilb')
var settingsAppServiceId = resourceId('Microsoft.Network/applicationGateways/backendHttpSettingsCollection', name, 'settings-appservice-https')
var settingsAksId = resourceId('Microsoft.Network/applicationGateways/backendHttpSettingsCollection', name, 'settings-aks-http')

var frontendPorts = concat([
  {
    name: 'port-80'
    properties: {
      port: 80
    }
  }
  {
    name: 'port-8080'
    properties: {
      port: 8080
    }
  }
], enableHttps ? [
  {
    name: 'port-443'
    properties: {
      port: 443
    }
  }
] : [])

// lab only: without tlsCertificateSecretId the public listeners are plain HTTP. Production must set the
// certificate (Key Vault secret ID) so :443 terminates TLS and :80 only redirects.
var httpListeners = concat([
  {
    name: 'listener-http-80'
    properties: {
      frontendIPConfiguration: {
        id: frontendIpConfigId
      }
      frontendPort: {
        id: resourceId('Microsoft.Network/applicationGateways/frontendPorts', name, 'port-80')
      }
      protocol: 'Http'
    }
  }
  {
    name: 'listener-http-8080'
    properties: {
      frontendIPConfiguration: {
        id: frontendIpConfigId
      }
      frontendPort: {
        id: resourceId('Microsoft.Network/applicationGateways/frontendPorts', name, 'port-8080')
      }
      protocol: 'Http'
    }
  }
], enableHttps ? [
  {
    name: 'listener-https-443'
    properties: {
      frontendIPConfiguration: {
        id: frontendIpConfigId
      }
      frontendPort: {
        id: resourceId('Microsoft.Network/applicationGateways/frontendPorts', name, 'port-443')
      }
      protocol: 'Https'
      sslCertificate: {
        id: resourceId('Microsoft.Network/applicationGateways/sslCertificates', name, 'cert-key-vault')
      }
    }
  }
] : [])

var appServiceRule = {
  name: 'rule-appservice-web'
  properties: {
    ruleType: 'Basic'
    priority: 100
    httpListener: {
      id: enableHttps ? listenerHttpsId : listenerHttpId
    }
    backendAddressPool: {
      id: poolAppServiceId
    }
    backendHttpSettings: {
      id: settingsAppServiceId
    }
  }
}

var aksRule = {
  name: 'rule-aks-ilb'
  properties: {
    ruleType: 'Basic'
    priority: 200
    httpListener: {
      id: listenerAksId
    }
    backendAddressPool: {
      id: poolAksId
    }
    backendHttpSettings: {
      id: settingsAksId
    }
  }
}

var redirectRule = {
  name: 'rule-http-to-https'
  properties: {
    ruleType: 'Basic'
    priority: 110
    httpListener: {
      id: listenerHttpId
    }
    redirectConfiguration: {
      id: resourceId('Microsoft.Network/applicationGateways/redirectConfigurations', name, 'redirect-http-to-https')
    }
  }
}

// WAF custom rules: evaluated before the managed rules, lowest priority first. A Block answers with HTTP 403.
// [SEC] Defence in depth at the edge, per client IP (sliding window, counted per WAF policy association). The API's own
// per-member limit (5 claims a minute, HTTP 429) still applies behind it.
var claimsRateLimitRule = {
  name: 'RateLimitClaimSubmissions'
  priority: 10
  state: 'Enabled'
  ruleType: 'RateLimitRule'
  rateLimitDuration: 'OneMin'
  rateLimitThreshold: wafClaimsRateLimitPerMinute
  groupByUserSession: [
    {
      groupByVariables: [
        {
          variableName: 'ClientAddr'
        }
      ]
    }
  ]
  action: 'Block'
  matchConditions: [
    {
      matchVariables: [
        {
          variableName: 'RequestMethod'
        }
      ]
      operator: 'Equal'
      matchValues: [
        'POST'
      ]
    }
    {
      matchVariables: [
        {
          variableName: 'RequestUri'
        }
      ]
      operator: 'BeginsWith'
      matchValues: [
        '/api/claims'
      ]
      transforms: [
        'Lowercase'
      ]
    }
  ]
}

// [SEC] The portal and API only use GET, HEAD and POST: block every other method.
var unexpectedMethodsRule = {
  name: 'BlockUnexpectedMethods'
  priority: 20
  state: 'Enabled'
  ruleType: 'MatchRule'
  action: 'Block'
  matchConditions: [
    {
      matchVariables: [
        {
          variableName: 'RequestMethod'
        }
      ]
      operator: 'Equal'
      negationConditon: true // sic: the API spells it this way; matches any method NOT in the list
      matchValues: [
        'GET'
        'HEAD'
        'POST'
      ]
    }
  ]
}

// [SEC] Optional (wafBlockOpsApi): the claims-desk endpoints (/api/ops/*) are not reachable from the internet.
var opsApiRule = {
  name: 'BlockOpsApiFromInternet'
  priority: 30
  state: 'Enabled'
  ruleType: 'MatchRule'
  action: 'Block'
  matchConditions: [
    {
      matchVariables: [
        {
          variableName: 'RequestUri'
        }
      ]
      operator: 'BeginsWith'
      matchValues: [
        '/api/ops/'
      ]
      transforms: [
        'Lowercase'
      ]
    }
  ]
}

// [SEC] Log only: workshop participants and partners connect from anywhere; switching to Block is a business and legal
// decision. Learn recommends adding 'ZZ' (addresses not yet mapped to a country) before a geo rule ever blocks.
var geoLogRule = {
  name: 'LogOutsideAllowedCountries'
  priority: 40
  state: 'Enabled'
  ruleType: 'MatchRule'
  action: 'Log'
  matchConditions: [
    {
      matchVariables: [
        {
          variableName: 'RemoteAddr'
        }
      ]
      operator: 'GeoMatch'
      negationConditon: true // matches every country NOT in wafAllowedCountryCodes
      matchValues: wafAllowedCountryCodes
    }
  ]
}

resource wafPolicy 'Microsoft.Network/ApplicationGatewayWebApplicationFirewallPolicies@2024-05-01' = {
  name: wafPolicyName
  location: location
  tags: tags
  properties: {
    policySettings: {
      state: 'Enabled'
      mode: wafMode // [SEC] Prevention blocks; tune false positives with exclusions, never by leaving production in Detection
      // [SEC] The portal and API accept only small JSON bodies: inspect all of it and reject anything larger.
      requestBodyCheck: true
      requestBodyInspectLimitInKB: 128
      maxRequestBodySizeInKb: 128
      requestBodyEnforcement: true
      fileUploadLimitInMb: 100
      fileUploadEnforcement: true
      logScrubbing: {
        state: 'Enabled'
        scrubbingRules: [
          {
            // [SEC] The claim note is free-text health information and must not be copied into WAF logs.
            matchVariable: 'RequestJSONArgNames'
            selectorMatchOperator: 'Equals'
            selector: 'note' // case-sensitive; the JSON key the API accepts
            state: 'Enabled'
          }
        ]
      }
    }
    customRules: concat([
      claimsRateLimitRule
      unexpectedMethodsRule
    ], wafBlockOpsApi ? [
      opsApiRule
    ] : [], [
      geoLogRule
    ])
    // No exclusions on purpose: the workshop adds a per-rule exclusion as an exercise.
    managedRules: {
      managedRuleSets: [
        {
          ruleSetType: 'Microsoft_DefaultRuleSet'
          ruleSetVersion: '2.2' // [SEC] DRS 2.2 is the recommended rule set for new WAF policies
        }
        {
          ruleSetType: 'Microsoft_BotManagerRuleSet'
          ruleSetVersion: '1.1'
        }
      ]
    }
  }
}

resource publicIp 'Microsoft.Network/publicIPAddresses@2024-05-01' = {
  name: publicIpName
  location: location
  tags: tags
  zones: [
    '1'
    '2'
    '3'
  ] // [REL] zone-redundant frontend IP
  sku: {
    name: 'Standard'
    tier: 'Regional'
  }
  properties: {
    publicIPAllocationMethod: 'Static'
    publicIPAddressVersion: 'IPv4'
  }
}

resource appGateway 'Microsoft.Network/applicationGateways@2024-05-01' = {
  name: name
  location: location
  tags: tags
  zones: [
    '1'
    '2'
    '3'
  ] // [REL] instances spread across the three zones
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${identityId}': {}
    }
  }
  properties: {
    sku: {
      name: 'WAF_v2'
      tier: 'WAF_v2'
    }
    autoscaleConfiguration: {
      minCapacity: minCapacity // [COST]/[PERF] warm instances; each instance handles ~10 capacity units
      maxCapacity: maxCapacity
    }
    enableHttp2: true // [PERF]
    firewallPolicy: {
      id: wafPolicy.id
    }
    sslPolicy: {
      policyType: 'Predefined'
      policyName: 'AppGwSslPolicy20220101' // [SEC] TLS 1.2+ with modern cipher suites only
    }
    gatewayIPConfigurations: [
      {
        name: 'gwipc-appgw'
        properties: {
          subnet: {
            id: subnetId
          }
        }
      }
    ]
    frontendIPConfigurations: [
      {
        name: 'fe-public'
        properties: {
          publicIPAddress: {
            id: publicIp.id
          }
        }
      }
    ]
    frontendPorts: frontendPorts
    sslCertificates: enableHttps ? [
      {
        name: 'cert-key-vault'
        properties: {
          keyVaultSecretId: tlsCertificateSecretId // [SEC] read with the user-assigned identity; versionless ID = automatic renewal
        }
      }
    ] : []
    backendAddressPools: [
      {
        name: 'pool-appservice-web'
        properties: {
          backendAddresses: [
            {
              fqdn: webAppHostName
            }
          ]
        }
      }
      {
        name: 'pool-aks-ilb'
        properties: {
          backendAddresses: [
            {
              ipAddress: aksIngressPrivateIp // static IP of the internal LoadBalancer Service "web" (created by the AKS manifests)
            }
          ]
        }
      }
    ]
    backendHttpSettingsCollection: [
      {
        name: 'settings-appservice-https'
        properties: {
          port: 443
          protocol: 'Https' // [SEC] end-to-end TLS to App Service
          cookieBasedAffinity: 'Disabled'
          pickHostNameFromBackendAddress: true // App Service routes on the Host header
          requestTimeout: 30
          probe: {
            id: resourceId('Microsoft.Network/applicationGateways/probes', name, 'probe-appservice')
          }
        }
      }
      {
        name: 'settings-aks-http'
        properties: {
          port: 80
          protocol: 'Http' // private hop inside the VNet; add TLS on the Service when the data classification demands it
          cookieBasedAffinity: 'Disabled'
          pickHostNameFromBackendAddress: false
          requestTimeout: 30
          probe: {
            id: resourceId('Microsoft.Network/applicationGateways/probes', name, 'probe-aks')
          }
        }
      }
    ]
    probes: [
      {
        name: 'probe-appservice'
        properties: {
          protocol: 'Https'
          path: '/healthz'
          interval: 30
          timeout: 30
          unhealthyThreshold: 3
          pickHostNameFromBackendHttpSettings: true
          match: {
            statusCodes: [
              '200-399'
            ]
          }
        }
      }
      {
        name: 'probe-aks'
        properties: {
          protocol: 'Http'
          host: '127.0.0.1'
          path: '/healthz'
          interval: 30
          timeout: 30
          unhealthyThreshold: 3
          pickHostNameFromBackendHttpSettings: false
          match: {
            statusCodes: [
              '200-399'
            ]
          }
        }
      }
    ]
    httpListeners: httpListeners
    requestRoutingRules: concat([
      appServiceRule
      aksRule
    ], enableHttps ? [
      redirectRule
    ] : [])
    redirectConfigurations: enableHttps ? [
      {
        name: 'redirect-http-to-https'
        properties: {
          redirectType: 'Permanent'
          targetListener: {
            id: listenerHttpsId
          }
          includePath: true
          includeQueryString: true
        }
      }
    ] : []
  }
}

resource diagnostics 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: 'diag-log-analytics'
  scope: appGateway
  properties: {
    workspaceId: logAnalyticsWorkspaceId
    // [OPS] Resource-specific tables AGWAccessLogs, AGWPerformanceLogs and AGWFirewallLogs instead of AzureDiagnostics.
    // The performance log exists only for the v1 SKU, so on WAF_v2 use the metrics for performance data.
    logAnalyticsDestinationType: 'Dedicated'
    logs: [
      {
        categoryGroup: 'allLogs' // access, performance and WAF (firewall) logs
        enabled: true
      }
    ]
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
      }
    ]
  }
}

@description('Resource ID of the Application Gateway.')
output id string = appGateway.id

@description('Name of the Application Gateway.')
output name string = appGateway.name

@description('Public IP address of the Application Gateway frontend.')
output publicIpAddress string = publicIp.properties.ipAddress
