metadata description = 'Links existing private DNS zones (in the hub resource group) to a spoke VNet. The workload stack deploys this module into the hub resource group.'

@description('Names of the private DNS zones (privatelink.*) in the resource group this module is deployed to.')
param zoneNames array

@description('Resource ID of the VNet to link (the spoke).')
param vnetId string

@description('Name of the virtual network link created in every zone, e.g. link-vnet-ch-lab-idc.')
param linkName string

@description('Tags applied to the virtual network links.')
param tags object

resource zones 'Microsoft.Network/privateDnsZones@2024-06-01' existing = [for zoneName in zoneNames: {
  name: zoneName
}]

resource links 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2024-06-01' = [for i in range(0, length(zoneNames)): {
  parent: zones[i]
  name: linkName
  location: 'global'
  tags: tags
  properties: {
    registrationEnabled: false // [SEC] privatelink zones hold private endpoint records only; VMs must not auto-register
    virtualNetwork: {
      id: vnetId
    }
  }
}]
