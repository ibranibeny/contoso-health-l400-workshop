metadata description = 'Hub VNet (connectivity design area) with the reserved platform subnets and an optional DDoS Network Protection plan.'

@description('Hub VNet name (vnet-ch-hub-idc).')
param name string

@description('Azure region.')
param location string

@description('Tags applied to every resource in this module.')
param tags object

@description('Hub address space (/22), e.g. 10.100.0.0/22. The three /26 subnets are derived from it.')
param addressPrefix string

@description('Create a DDoS Network Protection plan and associate it with the hub VNet.')
param deployDdosPlan bool

@description('Name of the DDoS protection plan (used only when deployDdosPlan is true).')
param ddosPlanName string

// [COST] DDoS Network Protection is billed per plan (roughly USD 3,000/month, covers up to 100 public IPs
// across every VNet associated with the plan) plus overage. One plan per tenant/region is usually enough;
// the cheaper alternative is DDoS IP Protection on individual public IPs. Default is off for the workshop.
resource ddosPlan 'Microsoft.Network/ddosProtectionPlans@2024-05-01' = if (deployDdosPlan) {
  name: ddosPlanName
  location: location
  tags: tags
  properties: {}
}

resource vnet 'Microsoft.Network/virtualNetworks@2024-05-01' = {
  name: name
  location: location
  tags: tags
  properties: {
    addressSpace: {
      addressPrefixes: [
        addressPrefix
      ]
    }
    enableDdosProtection: deployDdosPlan // [SEC] protects the firewall/bastion public IPs when the plan exists
    ddosProtectionPlan: deployDdosPlan ? { id: resourceId('Microsoft.Network/ddosProtectionPlans', ddosPlanName) } : null
    // Firewall/Bastion subnets keep the platform default for outbound access: both services
    // egress through their own public IPs and nothing else may be deployed in these subnets.
    subnets: [
      {
        name: 'AzureFirewallSubnet' // name and /26 size required by Azure Firewall
        properties: {
          addressPrefix: cidrSubnet(addressPrefix, 26, 0) // 10.100.0.0/26
        }
      }
      {
        name: 'AzureFirewallManagementSubnet' // reserved for forced tunnelling (management NIC), unused by Standard
        properties: {
          addressPrefix: cidrSubnet(addressPrefix, 26, 1) // 10.100.0.64/26
        }
      }
      {
        name: 'AzureBastionSubnet' // name and /26 minimum required by Azure Bastion
        properties: {
          addressPrefix: cidrSubnet(addressPrefix, 26, 2) // 10.100.0.128/26
        }
      }
    ]
  }
  dependsOn: [
    ddosPlan
  ]
}

@description('Resource ID of the hub VNet.')
output vnetId string = vnet.id

@description('Name of the hub VNet.')
output vnetName string = vnet.name

@description('Resource ID of AzureFirewallSubnet.')
output firewallSubnetId string = resourceId('Microsoft.Network/virtualNetworks/subnets', vnet.name, 'AzureFirewallSubnet')

@description('Resource ID of AzureBastionSubnet.')
output bastionSubnetId string = resourceId('Microsoft.Network/virtualNetworks/subnets', vnet.name, 'AzureBastionSubnet')
