metadata description = 'Hub-side VNet peering (hub -> spoke). The workload stack deploys this module into the hub resource group.'

@description('Name of the hub VNet in the resource group this module is deployed to.')
param hubVnetName string

@description('Resource ID of the spoke VNet.')
param spokeVnetId string

@description('Peering name, e.g. peer-vnet-ch-hub-idc-to-vnet-ch-lab-idc.')
param peeringName string

resource hubVnet 'Microsoft.Network/virtualNetworks@2024-05-01' existing = {
  name: hubVnetName
}

resource hubToSpoke 'Microsoft.Network/virtualNetworks/virtualNetworkPeerings@2024-05-01' = {
  parent: hubVnet
  name: peeringName
  properties: {
    remoteVirtualNetwork: {
      id: spokeVnetId
    }
    allowVirtualNetworkAccess: true
    allowForwardedTraffic: true // [SEC] lets traffic that the hub firewall forwards reach the spoke
    allowGatewayTransit: false // no VPN/ExpressRoute gateway in this mini landing zone
    useRemoteGateways: false
  }
}

@description('Resource ID of the hub-side peering.')
output id string = hubToSpoke.id
