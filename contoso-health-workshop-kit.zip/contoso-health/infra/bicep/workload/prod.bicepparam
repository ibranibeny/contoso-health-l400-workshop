using './main.bicep'

// Prod: zone-redundant sizes, egress through the hub firewall (platform prod profile), Entra-only telemetry,
// SCM site closed to the internet (deploy from a self-hosted runner inside the VNet).
param env = 'prod'

param addressPrefix = '10.120.0.0/20'

param egressMode = 'firewall'

param enableDdosProtection = false

param appServicePlanSku = 'P1v4'

param appServicePlanCapacity = 3

param scmIpSecurityRestrictionsDefaultAction = 'Deny'

param postgresVersion = '17'

param postgresSkuName = 'Standard_D2ds_v5'

param postgresSkuTier = 'GeneralPurpose'

param postgresHighAvailabilityMode = 'ZoneRedundant'

param postgresStorageSizeGB = 128

param postgresBackupRetentionDays = 35

// [COST] Azure Managed Redis Balanced_B0 in every environment: the smallest Balanced size (0.5 GB), still zone-redundant with HA.
// [PERF] Watch used memory and server load; move to Balanced_B1 or larger before they become the bottleneck.
param redisSkuName = 'Balanced_B0'

param appGatewayMinCapacity = 2

param appGatewayMaxCapacity = 10

// [SEC] WAF in Prevention in every environment.
param wafMode = 'Prevention'

// [REL] Many members can share one public IP (carrier-grade NAT), so the per-IP edge limit is higher than in lab.
param wafClaimsRateLimitPerMinute = 300

// [SEC] The API already refuses /api/ops/* in prod (opsApiEnabled = false); the WAF also stops it at the edge.
param wafBlockOpsApi = true

param wafAllowedCountryCodes = [
  'ID'
]

param aksIngressPrivateIp = '10.120.3.70'

// Production should always terminate TLS: set the versionless Key Vault secret ID of the certificate.
param tlsCertificateSecretId = readEnvironmentVariable('TLS_CERTIFICATE_SECRET_ID', '')

param deployOpsVm = true

param opsSshPublicKey = readEnvironmentVariable('OPS_SSH_PUBLIC_KEY', '')

param opsVmSize = 'Standard_B2s'

param alertEmail = readEnvironmentVariable('ALERT_EMAIL', '')

param appInsightsDisableLocalAuth = true

param seedOnStart = false

param opsApiEnabled = false
