using './main.bicep'

// Lab: same topology as prod, cost-aware sizes, NAT gateway egress, HTTP-only App Gateway unless a certificate is set.
param env = 'lab'

param addressPrefix = '10.110.0.0/20'

param egressMode = 'natGateway'

param enableDdosProtection = false

param appServicePlanSku = 'P0v4'

param appServicePlanCapacity = 2

// GitHub-hosted runners deploy over the public SCM endpoint with Entra ID (basic auth is disabled).
param scmIpSecurityRestrictionsDefaultAction = 'Allow'

param postgresVersion = '17'

param postgresSkuName = 'Standard_B1ms'

param postgresSkuTier = 'Burstable'

param postgresHighAvailabilityMode = 'Disabled'

param postgresStorageSizeGB = 32

param postgresBackupRetentionDays = 7

param redisSkuName = 'Balanced_B0'

param appGatewayMinCapacity = 1

param appGatewayMaxCapacity = 10

// [SEC] WAF in Prevention in every environment.
param wafMode = 'Prevention'

// [OPS] Counted per client IP: participants behind one venue NAT share the budget. Raise it if the burst exercise
// starts to get HTTP 403 from the WAF instead of HTTP 429 from the API.
param wafClaimsRateLimitPerMinute = 60

// The claims desk (/api/ops/*) is part of the lab exercises (opsApiEnabled = true).
param wafBlockOpsApi = false

param wafAllowedCountryCodes = [
  'ID'
]

param aksIngressPrivateIp = '10.110.3.70'

// Optional HTTPS: versionless Key Vault secret ID of the certificate (lab default: HTTP only).
param tlsCertificateSecretId = readEnvironmentVariable('TLS_CERTIFICATE_SECRET_ID', '')

// The ops VM needs an SSH public key: export OPS_SSH_PUBLIC_KEY="$(cat ~/.ssh/id_ed25519.pub)".
// Without it the deployment fails validation; set deployOpsVm = false to skip the VM instead.
param deployOpsVm = true

param opsSshPublicKey = readEnvironmentVariable('OPS_SSH_PUBLIC_KEY', '')

param opsVmSize = 'Standard_B2s'

param alertEmail = readEnvironmentVariable('ALERT_EMAIL', '')

param appInsightsDisableLocalAuth = false

param seedOnStart = true

param opsApiEnabled = true
