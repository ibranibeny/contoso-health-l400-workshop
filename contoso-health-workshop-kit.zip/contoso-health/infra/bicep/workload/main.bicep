targetScope = 'resourceGroup'

metadata name = 'Contoso Health - workload (application landing zone)'
metadata description = 'Deployed into rg-ch-<env>-idc: spoke VNet peered to the hub, App Service web + API, PostgreSQL, Azure Managed Redis, Key Vault, Application Gateway WAF_v2, ops VM, identities and alerts. Platform resources are looked up by their deterministic names.'

// ---------------------------------------------------------------------------
// Parameters
// ---------------------------------------------------------------------------
@description('Environment name.')
@allowed([
  'lab'
  'prod'
])
param env string

@description('Region; defaults to the resource group location (indonesiacentral).')
param location string = resourceGroup().location

@description('Spoke VNet address space (/20): lab 10.110.0.0/20, prod 10.120.0.0/20. Subnets are derived with cidrSubnet().')
param addressPrefix string

@description('Egress of the private subnets: natGateway (lab) or firewall (prod; requires the platform firewall, deployFirewall=true).')
@allowed([
  'natGateway'
  'firewall'
])
param egressMode string = 'natGateway'

@description('Associate the spoke VNet with the platform DDoS plan ddos-ch-hub-idc (requires platform deployDdosPlan=true).')
param enableDdosProtection bool = false

@description('App Service plan SKU (Premium v4): P0v4 lab, P1v4 prod.')
param appServicePlanSku string = 'P0v4'

@description('App Service plan instance count (>= 2 for zone redundancy and health-check instance replacement): 2 lab, 3 prod.')
@minValue(2)
param appServicePlanCapacity int = 2

@description('Default action of the SCM (Kudu) access restrictions: Allow (lab, GitHub-hosted runners deploy with Entra ID) or Deny (prod, self-hosted runner in the VNet).')
param scmIpSecurityRestrictionsDefaultAction string = 'Allow'

@description('PostgreSQL major version (17 default; 18 is also GA).')
param postgresVersion string = '17'

@description('PostgreSQL compute SKU: Standard_B1ms (lab) or Standard_D2ds_v5 (prod).')
param postgresSkuName string = 'Standard_B1ms'

@description('PostgreSQL compute tier matching postgresSkuName: Burstable (lab) or GeneralPurpose (prod).')
param postgresSkuTier string = 'Burstable'

@description('PostgreSQL high availability: Disabled (lab) or ZoneRedundant (prod; GeneralPurpose/MemoryOptimized only).')
param postgresHighAvailabilityMode string = 'Disabled'

@description('PostgreSQL storage size in GiB.')
param postgresStorageSizeGB int = 32

@description('PostgreSQL backup retention in days.')
@minValue(7)
@maxValue(35)
param postgresBackupRetentionDays int = 7

@description('Azure Managed Redis SKU: Balanced_B0 in lab and prod (smallest Balanced size, 0.5 GB); raise it to Balanced_B1 or larger when memory or server load grows.')
param redisSkuName string = 'Balanced_B0'

@description('Application Gateway autoscale minimum instance count: 1 lab, 2 prod.')
param appGatewayMinCapacity int = 1

@description('Application Gateway autoscale maximum instance count.')
param appGatewayMaxCapacity int = 10

@description('WAF policy mode: Prevention (blocks) or Detection (logs only). Prevention in lab and prod; tune false positives with exclusions.')
@allowed([
  'Prevention'
  'Detection'
])
param wafMode string = 'Prevention'

@description('WAF custom rule RateLimitClaimSubmissions: POST requests to /api/claims allowed per client IP and minute (lab 60, prod 300).')
@minValue(1)
param wafClaimsRateLimitPerMinute int = 60

@description('WAF custom rule BlockOpsApiFromInternet: block /api/ops/* at the edge (lab false, prod true).')
param wafBlockOpsApi bool = false

@description('WAF custom rule LogOutsideAllowedCountries: ISO 3166-1 alpha-2 country codes the traffic is expected from; other countries are logged, not blocked.')
@minLength(1)
param wafAllowedCountryCodes array = [
  'ID'
]

@description('Static private IP of the AKS internal load balancer ("web" Service) inside snet-aks-ilb; the App Gateway :8080 listener forwards to it. Default: 7th address of snet-aks-ilb (10.110.3.70 in lab).')
param aksIngressPrivateIp string = cidrHost(cidrSubnet(addressPrefix, 27, 26), 5)

@description('Optional Key Vault secret ID of the TLS certificate (HTTPS listener on 443 + redirect from 80). Empty = HTTP only (lab only).')
#disable-next-line secure-secrets-in-params
param tlsCertificateSecretId string = ''

@description('Deploy the ops VM (database bootstrap and private DNS checks via az vm run-command). When true, opsSshPublicKey must be set or the deployment fails validation.')
param deployOpsVm bool = true

@description('SSH public key of the ops VM admin user (not a secret). The .bicepparam files read it from OPS_SSH_PUBLIC_KEY.')
param opsSshPublicKey string = ''

@description('Ops VM size.')
param opsVmSize string = 'Standard_B2s'

@description('E-mail address for alert notifications. Empty = action group without receivers.')
param alertEmail string = ''

@description('Disable local (key) authentication on Application Insights so only Entra ID ingestion is accepted: false lab, true prod.')
param appInsightsDisableLocalAuth bool = false

@description('API setting SEED_ON_START (load demo data on start): true lab, false prod.')
param seedOnStart bool = false

@description('API setting OPS_API_ENABLED (ops/fault-injection endpoints): true lab, false prod.')
param opsApiEnabled bool = false

// ---------------------------------------------------------------------------
// Variables
// ---------------------------------------------------------------------------
var sfx = take(uniqueString(subscription().id, 'ch', env), 6) // only for globally unique names

var tags = {
  workload: 'contoso-health'
  environment: env
  owner: 'platform-team'
  costCenter: 'CH-1001'
  dataClassification: 'confidential'
  managedBy: 'bicep'
}

// Platform resources (deterministic names, created by the platform stack).
var hubResourceGroupName = 'rg-ch-hub-idc'
var mgmtResourceGroupName = 'rg-ch-mgmt-idc'
var hubVnetName = 'vnet-ch-hub-idc'
var hubFirewallName = 'afw-ch-hub-idc'
var hubDdosPlanName = 'ddos-ch-hub-idc'
var hubBastionSubnetPrefix = '10.100.0.128/26'
var logAnalyticsWorkspaceName = 'log-ch-idc'
var privateDnsZoneNames = {
  appService: 'privatelink.azurewebsites.net'
  postgres: 'privatelink.postgres.database.azure.com'
  redis: 'privatelink.redis.azure.net'
  keyVault: 'privatelink.vaultcore.azure.net'
  acr: 'privatelink.azurecr.io'
}

var names = {
  vnet: 'vnet-ch-${env}-idc'
  natGateway: 'ng-ch-${env}-idc'
  routeTable: 'rt-ch-${env}-idc'
  apiIdentity: 'id-ch-api-${env}'
  webIdentity: 'id-ch-web-${env}'
  dbAdminIdentity: 'id-ch-dbadmin-${env}'
  agwIdentity: 'id-ch-agw-${env}'
  appInsights: 'appi-ch-${env}-idc'
  keyVault: 'kv-ch-${env}-${sfx}'
  appServicePlan: 'asp-ch-${env}-idc'
  webApp: 'app-ch-web-${env}-${sfx}'
  apiApp: 'app-ch-api-${env}-${sfx}'
  postgres: 'psql-ch-${env}-${sfx}'
  redis: 'redis-ch-${env}-${sfx}'
  appGateway: 'agw-ch-${env}-idc'
  appGatewayPublicIp: 'pip-agw-ch-${env}-idc'
  wafPolicy: 'waf-ch-${env}-idc'
  opsVm: 'vm-ch-ops-${env}'
  actionGroup: 'ag-ch-${env}'
}

var appInsightsAuthMode = appInsightsDisableLocalAuth ? 'entra' : ''

// ---------------------------------------------------------------------------
// Platform resources (existing, looked up by name)
// ---------------------------------------------------------------------------
resource hubVnet 'Microsoft.Network/virtualNetworks@2024-05-01' existing = {
  name: hubVnetName
  scope: resourceGroup(hubResourceGroupName)
}

resource hubFirewall 'Microsoft.Network/azureFirewalls@2024-05-01' existing = {
  name: hubFirewallName
  scope: resourceGroup(hubResourceGroupName)
}

resource logAnalytics 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: logAnalyticsWorkspaceName
  scope: resourceGroup(mgmtResourceGroupName)
}

resource dnsZoneAppService 'Microsoft.Network/privateDnsZones@2024-06-01' existing = {
  name: privateDnsZoneNames.appService
  scope: resourceGroup(hubResourceGroupName)
}

resource dnsZonePostgres 'Microsoft.Network/privateDnsZones@2024-06-01' existing = {
  name: privateDnsZoneNames.postgres
  scope: resourceGroup(hubResourceGroupName)
}

resource dnsZoneRedis 'Microsoft.Network/privateDnsZones@2024-06-01' existing = {
  name: privateDnsZoneNames.redis
  scope: resourceGroup(hubResourceGroupName)
}

resource dnsZoneKeyVault 'Microsoft.Network/privateDnsZones@2024-06-01' existing = {
  name: privateDnsZoneNames.keyVault
  scope: resourceGroup(hubResourceGroupName)
}

// ---------------------------------------------------------------------------
// Identities (one user-assigned identity per caller; no secrets anywhere)
// ---------------------------------------------------------------------------
resource apiIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: names.apiIdentity
  location: location
  tags: tags
}

resource webIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: names.webIdentity
  location: location
  tags: tags
}

resource dbAdminIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: names.dbAdminIdentity
  location: location
  tags: tags
}

resource agwIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: names.agwIdentity
  location: location
  tags: tags
}

// ---------------------------------------------------------------------------
// Network: spoke, hub peering (hub side), private DNS zone links
// ---------------------------------------------------------------------------
module spoke '../modules/network/spoke.bicep' = {
  name: 'spoke-network'
  params: {
    name: names.vnet
    location: location
    tags: tags
    addressPrefix: addressPrefix
    egressMode: egressMode
    // The firewall is only read when it is used (ARM if() evaluates one branch only).
    firewallPrivateIp: egressMode == 'firewall' ? hubFirewall.properties.ipConfigurations[0].properties.privateIPAddress : ''
    natGatewayName: names.natGateway
    routeTableName: names.routeTable
    hubVnetId: hubVnet.id
    hubPeeringName: 'peer-${names.vnet}-to-${hubVnetName}'
    bastionSubnetPrefix: hubBastionSubnetPrefix
    ddosProtectionPlanId: enableDdosProtection ? resourceId(subscription().subscriptionId, hubResourceGroupName, 'Microsoft.Network/ddosProtectionPlans', hubDdosPlanName) : ''
  }
}

// Writes in the hub resource group are done by modules scoped there (the platform team can still own the hub).
module hubPeering '../modules/network/hub-peering.bicep' = {
  name: 'hub-peering-${env}' // env suffix: lab and prod deploy into the same hub resource group
  scope: resourceGroup(hubResourceGroupName)
  params: {
    hubVnetName: hubVnetName
    spokeVnetId: spoke.outputs.vnetId
    peeringName: 'peer-${hubVnetName}-to-${names.vnet}'
  }
}

module dnsZoneLinks '../modules/network/dns-zone-links.bicep' = {
  name: 'dns-zone-links-${env}'
  scope: resourceGroup(hubResourceGroupName)
  params: {
    zoneNames: map(items(privateDnsZoneNames), zone => zone.value)
    vnetId: spoke.outputs.vnetId
    linkName: 'link-${names.vnet}'
    tags: tags
  }
}

// ---------------------------------------------------------------------------
// Monitoring and secrets
// ---------------------------------------------------------------------------
module appInsights '../modules/monitor/app-insights.bicep' = {
  name: 'app-insights'
  params: {
    name: names.appInsights
    location: location
    tags: tags
    logAnalyticsWorkspaceId: logAnalytics.id
    disableLocalAuth: appInsightsDisableLocalAuth
    metricsPublisherPrincipalIds: [
      apiIdentity.properties.principalId
      webIdentity.properties.principalId
    ]
  }
}

module keyVault '../modules/security/key-vault.bicep' = {
  name: 'key-vault'
  params: {
    name: names.keyVault
    location: location
    tags: tags
    secretsUserPrincipalIds: [
      apiIdentity.properties.principalId
      agwIdentity.properties.principalId
    ]
    privateEndpointSubnetId: spoke.outputs.privateEndpointsSubnetId
    privateDnsZoneId: dnsZoneKeyVault.id
    logAnalyticsWorkspaceId: logAnalytics.id
  }
}

// ---------------------------------------------------------------------------
// Data: PostgreSQL (Entra admin = dbadmin identity) and Azure Managed Redis
// ---------------------------------------------------------------------------
module postgres '../modules/data/postgres.bicep' = {
  name: 'postgres'
  params: {
    name: names.postgres
    location: location
    tags: tags
    postgresVersion: postgresVersion
    skuName: postgresSkuName
    skuTier: postgresSkuTier
    highAvailabilityMode: postgresHighAvailabilityMode
    storageSizeGB: postgresStorageSizeGB
    backupRetentionDays: postgresBackupRetentionDays
    adminPrincipalId: dbAdminIdentity.properties.principalId
    adminPrincipalName: dbAdminIdentity.name
    privateEndpointSubnetId: spoke.outputs.privateEndpointsSubnetId
    privateDnsZoneId: dnsZonePostgres.id
    logAnalyticsWorkspaceId: logAnalytics.id
  }
}

module redis '../modules/data/managed-redis.bicep' = {
  name: 'managed-redis'
  params: {
    name: names.redis
    location: location
    tags: tags
    skuName: redisSkuName
    dataAccessIdentities: [
      {
        name: apiIdentity.name
        objectId: apiIdentity.properties.principalId
      }
    ]
    privateEndpointSubnetId: spoke.outputs.privateEndpointsSubnetId
    privateDnsZoneId: dnsZoneRedis.id
  }
}

// ---------------------------------------------------------------------------
// App Service: plan, API and web apps
// ---------------------------------------------------------------------------
module appServicePlan '../modules/web/app-service-plan.bicep' = {
  name: 'app-service-plan'
  params: {
    name: names.appServicePlan
    location: location
    tags: tags
    skuName: appServicePlanSku
    capacity: appServicePlanCapacity
  }
}

module apiApp '../modules/web/app-service.bicep' = {
  name: 'app-service-api'
  params: {
    name: names.apiApp
    location: location
    tags: tags
    appServicePlanId: appServicePlan.outputs.id
    identityId: apiIdentity.id
    integrationSubnetId: spoke.outputs.appIntegrationSubnetId
    startCommand: 'node --import ./src/telemetry.js src/index.js' // preload OpenTelemetry before the app imports http/pg/redis
    scmIpSecurityRestrictionsDefaultAction: scmIpSecurityRestrictionsDefaultAction
    appInsightsName: appInsights.outputs.name // APPLICATIONINSIGHTS_CONNECTION_STRING is added by the module
    privateEndpointSubnetId: spoke.outputs.privateEndpointsSubnetId
    privateDnsZoneId: dnsZoneAppService.id
    logAnalyticsWorkspaceId: logAnalytics.id
    appSettings: {
      STORAGE_MODE: 'postgres'
      CACHE_MODE: 'redis'
      PGHOST: postgres.outputs.fqdn
      PGPORT: '5432'
      PGDATABASE: 'contoso_health' // created by the bootstrap script, not by IaC
      PGUSER: apiIdentity.name // Entra principal name of the API identity inside PostgreSQL
      PGSCHEMA: 'app'
      PG_AUTH: 'entra'
      PGSSL: 'true'
      REDIS_HOST: redis.outputs.hostName
      REDIS_PORT: '10000'
      REDIS_TLS: 'true'
      REDIS_AUTH: 'entra'
      AZURE_CLIENT_ID: apiIdentity.properties.clientId // selects the user-assigned identity in ManagedIdentityCredential
      AZURE_REGION: location
      MIGRATE_ON_START: 'true'
      SEED_ON_START: seedOnStart ? 'true' : 'false'
      OPS_API_ENABLED: opsApiEnabled ? 'true' : 'false'
      APPLICATIONINSIGHTS_AUTH: appInsightsAuthMode
      SCM_DO_BUILD_DURING_DEPLOYMENT: 'false' // CI ships a ready-to-run package (node_modules included)
    }
  }
}

module webApp '../modules/web/app-service.bicep' = {
  name: 'app-service-web'
  params: {
    name: names.webApp
    location: location
    tags: tags
    appServicePlanId: appServicePlan.outputs.id
    identityId: webIdentity.id
    integrationSubnetId: spoke.outputs.appIntegrationSubnetId
    startCommand: 'node server.js'
    scmIpSecurityRestrictionsDefaultAction: scmIpSecurityRestrictionsDefaultAction
    appInsightsName: appInsights.outputs.name
    privateEndpointSubnetId: spoke.outputs.privateEndpointsSubnetId
    privateDnsZoneId: dnsZoneAppService.id
    logAnalyticsWorkspaceId: logAnalytics.id
    appSettings: {
      API_BASE_URL: 'https://${apiApp.outputs.defaultHostName}' // resolves to the API private endpoint through VNet integration
      AZURE_CLIENT_ID: webIdentity.properties.clientId
      APPLICATIONINSIGHTS_AUTH: appInsightsAuthMode
      SCM_DO_BUILD_DURING_DEPLOYMENT: 'false'
    }
  }
}

// ---------------------------------------------------------------------------
// Ingress: Application Gateway WAF_v2 (App Service on :80/:443, AKS ILB on :8080)
// ---------------------------------------------------------------------------
module appGateway '../modules/network/app-gateway.bicep' = {
  name: 'app-gateway'
  params: {
    name: names.appGateway
    location: location
    tags: tags
    publicIpName: names.appGatewayPublicIp
    wafPolicyName: names.wafPolicy
    subnetId: spoke.outputs.appGatewaySubnetId
    identityId: agwIdentity.id
    minCapacity: appGatewayMinCapacity
    maxCapacity: appGatewayMaxCapacity
    webAppHostName: webApp.outputs.defaultHostName
    aksIngressPrivateIp: aksIngressPrivateIp
    tlsCertificateSecretId: tlsCertificateSecretId
    logAnalyticsWorkspaceId: logAnalytics.id
    wafMode: wafMode
    wafClaimsRateLimitPerMinute: wafClaimsRateLimitPerMinute
    wafBlockOpsApi: wafBlockOpsApi
    wafAllowedCountryCodes: wafAllowedCountryCodes
  }
  dependsOn: [
    dnsZoneLinks // [REL] backend FQDN and Key Vault must already resolve to private endpoints
    keyVault // Key Vault Secrets User for id-ch-agw must exist before an HTTPS listener reads the certificate
  ]
}

// ---------------------------------------------------------------------------
// Operations: ops VM (PostgreSQL Entra admin identity) and alerts
// ---------------------------------------------------------------------------
// When deployOpsVm is true and opsSshPublicKey is empty, validation fails in the module (@minLength(1)).
module opsVm '../modules/compute/ops-vm.bicep' = if (deployOpsVm) {
  name: 'ops-vm'
  params: {
    name: names.opsVm
    location: location
    tags: tags
    vmSize: opsVmSize
    subnetId: spoke.outputs.opsSubnetId
    identityId: dbAdminIdentity.id
    sshPublicKey: opsSshPublicKey
  }
}

module alerts '../modules/monitor/alerts.bicep' = {
  name: 'alerts'
  params: {
    actionGroupName: names.actionGroup
    alertEmail: alertEmail
    tags: tags
    appGatewayName: appGateway.outputs.name
    postgresServerName: postgres.outputs.name
  }
}

// ---------------------------------------------------------------------------
// Outputs (names are a contract with the AKS stack, scripts and GitHub workflows)
// ---------------------------------------------------------------------------
@description('Workload resource group name.')
output resourceGroupName string = resourceGroup().name

@description('Web app name.')
output webAppName string = webApp.outputs.name

@description('API app name.')
output apiAppName string = apiApp.outputs.name

@description('Web app default host name.')
output webAppHostName string = webApp.outputs.defaultHostName

@description('API app default host name.')
output apiAppHostName string = apiApp.outputs.defaultHostName

@description('Public IP address of the Application Gateway.')
output appGatewayPublicIp string = appGateway.outputs.publicIpAddress

@description('PostgreSQL flexible server name.')
output postgresServerName string = postgres.outputs.name

@description('PostgreSQL FQDN.')
output postgresFqdn string = postgres.outputs.fqdn

@description('Azure Managed Redis cluster name.')
output redisName string = redis.outputs.name

@description('Azure Managed Redis host name (port 10000).')
output redisHostName string = redis.outputs.hostName

@description('Key Vault name.')
output keyVaultName string = keyVault.outputs.name

@description('Application Insights name.')
output appInsightsName string = appInsights.outputs.name

@description('API identity name (also the PostgreSQL role name).')
output apiIdentityName string = apiIdentity.name

@description('API identity client ID.')
output apiIdentityClientId string = apiIdentity.properties.clientId

@description('API identity principal (object) ID.')
output apiIdentityPrincipalId string = apiIdentity.properties.principalId

@description('Web identity name.')
output webIdentityName string = webIdentity.name

@description('Web identity client ID.')
output webIdentityClientId string = webIdentity.properties.clientId

@description('Web identity principal (object) ID.')
output webIdentityPrincipalId string = webIdentity.properties.principalId

@description('Database admin identity name (PostgreSQL Entra admin, attached to the ops VM).')
output dbAdminIdentityName string = dbAdminIdentity.name

@description('Database admin identity client ID (used for the IMDS token request on the ops VM).')
output dbAdminIdentityClientId string = dbAdminIdentity.properties.clientId

@description('Ops VM name, or empty when deployOpsVm is false.')
output opsVmName string = deployOpsVm ? names.opsVm : ''

@description('Spoke VNet name.')
output spokeVnetName string = spoke.outputs.vnetName

@description('Spoke VNet resource ID.')
output spokeVnetId string = spoke.outputs.vnetId

@description('Resource ID of snet-aks-nodes.')
output aksNodesSubnetId string = spoke.outputs.aksNodesSubnetId

@description('Resource ID of snet-aks-ilb.')
output aksIlbSubnetId string = spoke.outputs.aksIlbSubnetId

@description('Resource ID of snet-aks-apiserver.')
output aksApiServerSubnetId string = spoke.outputs.aksApiServerSubnetId

@description('Resource ID of snet-private-endpoints.')
output privateEndpointsSubnetId string = spoke.outputs.privateEndpointsSubnetId

@description('Resource ID of the NAT gateway, or empty when egressMode is firewall.')
output natGatewayId string = spoke.outputs.natGatewayId

@description('Static private IP the AKS internal load balancer must use (App Gateway :8080 backend).')
output aksIngressPrivateIp string = aksIngressPrivateIp
