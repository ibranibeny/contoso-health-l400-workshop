targetScope = 'subscription'

metadata name = 'Contoso Health - platform (mini landing zone)'
metadata description = 'Connectivity (hub VNet, private DNS zones, optional Firewall/Bastion/DDoS), management (Log Analytics), security (Defender plans, policy) and subscription vending of the workload resource groups.'

// Built-in policy definitions assigned to the vended resource groups.
// verify with az policy definition show --name <guid>
var policyDefinitionGuids = {
  allowedLocations: 'e56962a6-4747-49cd-b67b-bf8b01975c4c' // Allowed locations (Deny)
  nicNoPublicIp: '83a86a26-fd1f-447c-b59d-e51f44264114' // Network interfaces should not have public IPs (Deny)
  subnetRequiresNsg: 'e71308d3-144b-4262-b144-efdc3cc90517' // Subnets should be associated with a Network Security Group (AuditIfNotExists)
  aksNoPrivilegedContainers: '95edb821-ddaf-4404-9732-666045e056b4' // Kubernetes cluster should not allow privileged containers (effect parameter)
  appGatewayWafEnabled: '564feb30-bf6a-4854-b4bb-0d2d2d1e6c66' // Web Application Firewall (WAF) should be enabled for Application Gateway (Audit)
  appGatewayWafMode: '12430be1-6cc8-4527-a9a8-e3d38f250096' // Web Application Firewall (WAF) should use the specified mode for Application Gateway (Audit; modeRequirement)
  appGatewayWafBots: 'ebea0d86-7fbd-42e3-8a46-27e7568c2525' // Bot Protection should be enabled for Azure Application Gateway WAF (Audit)
  appGatewayWafBody: 'ca85ef9a-741d-461d-8b7a-18c2da82c666' // Azure Web Application Firewall on Azure Application Gateway should have request body inspection enabled (Audit)
}

// ---------------------------------------------------------------------------
// Parameters
// ---------------------------------------------------------------------------
@description('Platform profile, used for tags: lab (cost-aware) or prod (production profile).')
@allowed([
  'lab'
  'prod'
])
param env string

@description('Region of every platform resource and resource group. Defaults to the stack/deployment location (indonesiacentral).')
param location string = deployment().location

@description('Workload environments to vend resource groups for: rg-ch-<env>-idc and rg-ch-aks-<env>-idc.')
@allowed([
  'lab'
  'prod'
])
param environments array = [
  'lab'
]

@description('Regions allowed by the "Allowed locations" policy on the vended resource groups.')
param allowedLocations array = [
  location
]

@description('Log Analytics interactive retention in days.')
@minValue(30)
@maxValue(730)
param logRetentionInDays int = 30

@description('Deploy Azure Firewall Standard (afw-ch-hub-idc) and its policy. Required by workloads that use egressMode firewall.')
param deployFirewall bool = false

@description('Deploy Azure Bastion Basic (bas-ch-hub-idc) for interactive SSH to the ops VMs.')
param deployBastion bool = false

@description('Deploy an Azure DDoS Network Protection plan (ddos-ch-hub-idc) for the hub. Expensive: see the cost note in modules/network/hub-network.bicep.')
param deployDdosPlan bool = false

@description('Enable Microsoft Defender for Cloud (Standard) for Containers, App Service, open-source relational databases, Key Vault and CSPM on the subscription.')
param enableDefenderPlans bool = false

@description('Object ID of the workload team (Entra group recommended) that gets Contributor on every vended resource group. Empty = skip.')
param workloadTeamPrincipalId string = ''

@description('Principal type of workloadTeamPrincipalId: Group, User or ServicePrincipal.')
param workloadTeamPrincipalType string = 'Group'

@description('Effect of "Kubernetes cluster should not allow privileged containers" per environment (audit or deny).')
param aksPrivilegedContainerPolicyEffects object = {
  lab: 'audit'
  prod: 'deny'
}

@description('Spoke address spaces allowed to egress through the hub firewall (lab and prod spokes).')
param spokeAddressPrefixes array = [
  '10.110.0.0/20'
  '10.120.0.0/20'
]

// ---------------------------------------------------------------------------
// Variables
// ---------------------------------------------------------------------------
var tags = {
  workload: 'contoso-health'
  environment: env
  owner: 'platform-team'
  costCenter: 'CH-1001'
  dataClassification: 'internal'
  managedBy: 'bicep'
}

var hubResourceGroupName = 'rg-ch-hub-idc'
var mgmtResourceGroupName = 'rg-ch-mgmt-idc'
var hubVnetName = 'vnet-ch-hub-idc'
var firewallName = 'afw-ch-hub-idc'

var privateDnsZoneNames = {
  appService: 'privatelink.azurewebsites.net'
  postgres: 'privatelink.postgres.database.azure.com'
  redis: 'privatelink.redis.azure.net'
  keyVault: 'privatelink.vaultcore.azure.net'
  acr: 'privatelink.azurecr.io'
}

var contributorRoleGuid = 'b24988ac-6180-42a0-ab88-20f7382dd24c'

var workloadResourceGroupNames = [for e in environments: 'rg-ch-${e}-idc']
var aksResourceGroupNames = [for e in environments: 'rg-ch-aks-${e}-idc']

var defenderPlanNames = [
  'Containers'
  'AppServices'
  'OpenSourceRelationalDatabases'
  'KeyVaults'
  'CloudPosture'
]

// Policies for every vended resource group (workload and AKS).
var baselinePolicyAssignments = [
  {
    name: 'pa-ch-allowed-locations'
    displayName: 'Contoso Health - Allowed locations'
    definitionGuid: policyDefinitionGuids.allowedLocations
    parameters: {
      listOfAllowedLocations: {
        value: allowedLocations
      }
    }
    nonComplianceMessage: 'Contoso Health resources must be deployed to an approved region (Indonesia Central).'
  }
  {
    name: 'pa-ch-nic-no-public-ip'
    displayName: 'Contoso Health - Network interfaces should not have public IPs'
    definitionGuid: policyDefinitionGuids.nicNoPublicIp
    parameters: {}
    nonComplianceMessage: 'Workload NICs stay private: use az vm run-command or Azure Bastion instead of public IPs.'
  }
]

// Additional policies for rg-ch-<env>-idc (network + App Gateway).
var workloadPolicyAssignments = [
  {
    name: 'pa-ch-subnet-nsg'
    displayName: 'Contoso Health - Subnets should be associated with a Network Security Group'
    definitionGuid: policyDefinitionGuids.subnetRequiresNsg
    parameters: {}
    nonComplianceMessage: 'Every workload subnet needs its own NSG.'
  }
  {
    name: 'pa-ch-appgw-waf'
    displayName: 'Contoso Health - WAF should be enabled for Application Gateway'
    definitionGuid: policyDefinitionGuids.appGatewayWafEnabled
    parameters: {}
    nonComplianceMessage: 'Internet-facing Application Gateways must run a WAF policy.'
  }
  {
    name: 'pa-ch-appgw-waf-mode'
    displayName: 'Contoso Health - WAF should use Prevention mode for Application Gateway'
    definitionGuid: policyDefinitionGuids.appGatewayWafMode
    parameters: {
      modeRequirement: {
        value: 'Prevention' // the definition defaults to Detection
      }
    }
    nonComplianceMessage: 'Application Gateway WAF policies must run in Prevention mode; tune false positives with exclusions.'
  }
  {
    name: 'pa-ch-appgw-waf-bots'
    displayName: 'Contoso Health - Bot Protection should be enabled for Application Gateway WAF'
    definitionGuid: policyDefinitionGuids.appGatewayWafBots
    parameters: {}
    nonComplianceMessage: 'Application Gateway WAF policies must include the Microsoft_BotManagerRuleSet.'
  }
  {
    name: 'pa-ch-appgw-waf-body'
    displayName: 'Contoso Health - Application Gateway WAF should have request body inspection enabled'
    definitionGuid: policyDefinitionGuids.appGatewayWafBody
    parameters: {}
    nonComplianceMessage: 'Application Gateway WAF policies must inspect request bodies (requestBodyCheck).'
  }
]

// ---------------------------------------------------------------------------
// Resource groups (platform + vended workload resource groups)
// ---------------------------------------------------------------------------
resource hubRg 'Microsoft.Resources/resourceGroups@2024-03-01' = {
  name: hubResourceGroupName
  location: location
  tags: tags
}

resource mgmtRg 'Microsoft.Resources/resourceGroups@2024-03-01' = {
  name: mgmtResourceGroupName
  location: location
  tags: tags
}

resource workloadRgs 'Microsoft.Resources/resourceGroups@2024-03-01' = [for (e, i) in environments: {
  name: workloadResourceGroupNames[i]
  location: location
  tags: union(tags, {
    environment: e
    dataClassification: 'confidential'
  })
}]

resource aksRgs 'Microsoft.Resources/resourceGroups@2024-03-01' = [for (e, i) in environments: {
  name: aksResourceGroupNames[i]
  location: location
  tags: union(tags, {
    environment: e
    dataClassification: 'confidential'
  })
}]

// ---------------------------------------------------------------------------
// Management: one Log Analytics workspace for every environment
// ---------------------------------------------------------------------------
module logAnalytics '../modules/monitor/log-analytics.bicep' = {
  name: 'platform-log-analytics'
  scope: mgmtRg
  params: {
    name: 'log-ch-idc'
    location: location
    tags: tags
    retentionInDays: logRetentionInDays
  }
}

// ---------------------------------------------------------------------------
// Connectivity: hub VNet, private DNS zones, optional Firewall / Bastion / DDoS
// ---------------------------------------------------------------------------
module hubNetwork '../modules/network/hub-network.bicep' = {
  name: 'platform-hub-network'
  scope: hubRg
  params: {
    name: hubVnetName
    location: location
    tags: tags
    addressPrefix: '10.100.0.0/22'
    deployDdosPlan: deployDdosPlan
    ddosPlanName: 'ddos-ch-hub-idc'
  }
}

module privateDnsZones '../modules/network/private-dns-zones.bicep' = {
  name: 'platform-private-dns-zones'
  scope: hubRg
  params: {
    zoneNames: map(items(privateDnsZoneNames), zone => zone.value)
    hubVnetId: hubNetwork.outputs.vnetId
    linkName: 'link-${hubVnetName}'
    tags: tags
  }
}

module firewall '../modules/network/firewall.bicep' = if (deployFirewall) {
  name: 'platform-firewall'
  scope: hubRg
  params: {
    name: firewallName
    policyName: 'afwp-ch-hub-idc'
    location: location
    tags: tags
    subnetId: hubNetwork.outputs.firewallSubnetId
    sourceAddressPrefixes: spokeAddressPrefixes
    logAnalyticsWorkspaceId: logAnalytics.outputs.id
  }
}

module bastion '../modules/network/bastion.bicep' = if (deployBastion) {
  name: 'platform-bastion'
  scope: hubRg
  params: {
    name: 'bas-ch-hub-idc'
    location: location
    tags: tags
    subnetId: hubNetwork.outputs.bastionSubnetId
  }
}

// ---------------------------------------------------------------------------
// Security: Defender for Cloud plans and policy on the vended resource groups
// ---------------------------------------------------------------------------
module defenderPlans '../modules/security/defender-plans.bicep' = if (enableDefenderPlans) {
  name: 'platform-defender-plans'
  params: {
    planNames: defenderPlanNames
  }
}

// Policy is assigned per vended resource group (never at subscription scope) so that other teams sharing the
// subscription are not affected. Deny/Audit effects only: no managed identity, no remediation tasks.
module workloadRgPolicies '../modules/security/policy-assignments.bicep' = [for (e, i) in environments: {
  name: 'platform-policies-workload-${e}'
  scope: workloadRgs[i]
  params: {
    assignments: concat(baselinePolicyAssignments, workloadPolicyAssignments)
  }
}]

module aksRgPolicies '../modules/security/policy-assignments.bicep' = [for (e, i) in environments: {
  name: 'platform-policies-aks-${e}'
  scope: aksRgs[i]
  params: {
    assignments: concat(baselinePolicyAssignments, [
      {
        name: 'pa-ch-aks-no-privileged'
        displayName: 'Contoso Health - Kubernetes cluster should not allow privileged containers'
        definitionGuid: policyDefinitionGuids.aksNoPrivilegedContainers
        parameters: {
          effect: {
            value: aksPrivilegedContainerPolicyEffects[e] // audit in lab, deny in prod
          }
        }
        nonComplianceMessage: 'Privileged containers are not allowed in Contoso Health clusters.'
      }
    ])
  }
}]

// ---------------------------------------------------------------------------
// RBAC vending: the workload team gets Contributor on its resource groups only
// ---------------------------------------------------------------------------
module workloadRgRbac '../modules/identity/role-assignment.bicep' = [for (e, i) in environments: if (!empty(workloadTeamPrincipalId)) {
  name: 'platform-rbac-workload-${e}'
  scope: workloadRgs[i]
  params: {
    principalId: workloadTeamPrincipalId
    principalType: workloadTeamPrincipalType
    roleDefinitionGuid: contributorRoleGuid
    assignmentDescription: 'Workload team access to the vended ${e} workload resource group.'
  }
}]

module aksRgRbac '../modules/identity/role-assignment.bicep' = [for (e, i) in environments: if (!empty(workloadTeamPrincipalId)) {
  name: 'platform-rbac-aks-${e}'
  scope: aksRgs[i]
  params: {
    principalId: workloadTeamPrincipalId
    principalType: workloadTeamPrincipalType
    roleDefinitionGuid: contributorRoleGuid
    assignmentDescription: 'Workload team access to the vended ${e} AKS resource group.'
  }
}]

// Read back the firewall private IP (only evaluated when the firewall is deployed).
resource hubFirewall 'Microsoft.Network/azureFirewalls@2024-05-01' existing = {
  name: firewallName
  scope: resourceGroup(hubResourceGroupName)
}

// ---------------------------------------------------------------------------
// Outputs
// ---------------------------------------------------------------------------
@description('Resource ID of the hub VNet.')
output hubVnetId string = hubNetwork.outputs.vnetId

@description('Name of the hub VNet.')
output hubVnetName string = hubNetwork.outputs.vnetName

@description('Name of the hub (connectivity) resource group.')
output hubResourceGroupName string = hubRg.name

@description('Name of the management resource group.')
output mgmtResourceGroupName string = mgmtRg.name

@description('Resource ID of the Log Analytics workspace.')
output logAnalyticsWorkspaceId string = logAnalytics.outputs.id

@description('Private DNS zone resource IDs keyed by service (appService, postgres, redis, keyVault, acr).')
output privateDnsZoneIds object = toObject(items(privateDnsZoneNames), zone => zone.key, zone => resourceId(subscription().subscriptionId, hubResourceGroupName, 'Microsoft.Network/privateDnsZones', zone.value))

@description('Private IP of the hub firewall, or empty when deployFirewall is false.')
output firewallPrivateIp string = deployFirewall ? hubFirewall.properties.ipConfigurations[0].properties.privateIPAddress : ''

@description('Names of the vended workload and AKS resource groups.')
output vendedResourceGroupNames array = concat(workloadResourceGroupNames, aksResourceGroupNames)
