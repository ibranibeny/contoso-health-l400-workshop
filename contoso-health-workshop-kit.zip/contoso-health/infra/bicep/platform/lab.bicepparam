using './main.bicep'

// Workshop profile: hub + DNS + Log Analytics + policy, vends the lab resource groups only.
// Optional hub services stay off to keep the cost low (lab workloads egress through a NAT gateway).
param env = 'lab'

param environments = [
  'lab'
]

param logRetentionInDays = 30

param deployFirewall = false

param deployBastion = false

param deployDdosPlan = false

param enableDefenderPlans = false

// Optional: object ID of the workload team's Entra group (gets Contributor on the vended resource groups).
param workloadTeamPrincipalId = readEnvironmentVariable('WORKLOAD_TEAM_PRINCIPAL_ID', '')

param workloadTeamPrincipalType = readEnvironmentVariable('WORKLOAD_TEAM_PRINCIPAL_TYPE', 'Group')

param aksPrivilegedContainerPolicyEffects = {
  lab: 'audit'
  prod: 'deny'
}
