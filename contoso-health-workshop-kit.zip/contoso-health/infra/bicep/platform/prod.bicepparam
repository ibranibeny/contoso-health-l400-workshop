using './main.bicep'

// Production platform profile: vends lab AND prod resource groups (same stack name, so it supersedes the lab
// profile), deploys the hub firewall (required by egressMode=firewall), Bastion and Defender for Cloud.
param env = 'prod'

param environments = [
  'lab'
  'prod'
]

param logRetentionInDays = 90

param deployFirewall = true

param deployBastion = true

// [COST] DDoS Network Protection is a flat ~USD 3,000/month plan: enable when the organisation does not already
// have one (one plan can cover many subscriptions) and the internet-facing exposure justifies it.
param deployDdosPlan = false

param enableDefenderPlans = true

param workloadTeamPrincipalId = readEnvironmentVariable('WORKLOAD_TEAM_PRINCIPAL_ID', '')

param workloadTeamPrincipalType = readEnvironmentVariable('WORKLOAD_TEAM_PRINCIPAL_TYPE', 'Group')

param aksPrivilegedContainerPolicyEffects = {
  lab: 'audit'
  prod: 'deny'
}
