using './main.bicep'

param env = 'lab'

param kubernetesVersion = '1.36'

// Public API server; optionally restrict it: export AKS_AUTHORIZED_IP_RANGES="203.0.113.10/32,198.51.100.0/24".
param apiServerAccess = 'public'

param authorizedIpRanges = split(readEnvironmentVariable('AKS_AUTHORIZED_IP_RANGES', ''), ',')

param egressMode = 'natGateway'

param systemNodeVmSize = 'Standard_D4ds_v5'

param userNodeVmSize = 'Standard_D4ds_v5'

param userNodeMinCount = 2

param userNodeMaxCount = 6

// export CLUSTER_ADMIN_OBJECT_ID="$(az ad signed-in-user show --query id -o tsv)"
param clusterAdminPrincipalIds = [
  readEnvironmentVariable('CLUSTER_ADMIN_OBJECT_ID', '')
]

// Object ID (service principal) of the GitHub Actions deploy identity; empty = skip its role assignments.
param deployPrincipalId = readEnvironmentVariable('DEPLOY_PRINCIPAL_ID', '')

param enableGatewayApi = false

param acrPublicNetworkAccess = 'Enabled'
