using './main.bicep'

param env = 'prod'

param kubernetesVersion = '1.36'

// Private cluster with API server VNet integration: kubectl from inside the VNet (self-hosted runner)
// or through az aks command invoke.
param apiServerAccess = 'private'

param authorizedIpRanges = []

param egressMode = 'firewall'

param systemNodeVmSize = 'Standard_D4ds_v5'

param userNodeVmSize = 'Standard_D4ds_v5'

param userNodeMinCount = 3

param userNodeMaxCount = 10

// Use an Entra group object ID in prod (break-glass/platform admins), not individual users.
param clusterAdminPrincipalIds = [
  readEnvironmentVariable('CLUSTER_ADMIN_OBJECT_ID', '')
]

param deployPrincipalId = readEnvironmentVariable('DEPLOY_PRINCIPAL_ID', '')

param enableGatewayApi = false

// Requires self-hosted/ARC runners inside the VNet to push images.
param acrPublicNetworkAccess = 'Disabled'
