targetScope = 'resourceGroup'

metadata name = 'Contoso Health - AKS'
metadata description = 'Deployed into rg-ch-aks-<env>-idc: AKS cluster in the workload spoke, ACR with private endpoint, Azure Monitor workspace, role assignments and workload identity federation. Workload resources are looked up by their deterministic names.'

// ---------------------------------------------------------------------------
// Parameters
// ---------------------------------------------------------------------------
@description('Environment name.')
@allowed([
  'lab'
  'prod'
])
param env string

@description('Region; defaults to the resource group location (indonesiacentral).')
param location string = resourceGroup().location

@description('Kubernetes minor version (1.36 = current default; AKS picks the latest patch).')
param kubernetesVersion string = '1.36'

@description('API server exposure: public (lab, optionally restricted by authorizedIpRanges) or private (prod, private cluster with API server VNet integration).')
@allowed([
  'public'
  'private'
])
param apiServerAccess string = 'public'

@description('CIDR ranges allowed to reach a public API server (empty entries are ignored; empty list = unrestricted).')
param authorizedIpRanges array = []

@description('Egress mode of the workload spoke (must match the workload stack): natGateway or firewall.')
@allowed([
  'natGateway'
  'firewall'
])
param egressMode string = 'natGateway'

@description('VM size of the system node pool (3 zonal nodes, autoscale 3-5).')
param systemNodeVmSize string = 'Standard_D4ds_v5'

@description('VM size of the apps node pool.')
param userNodeVmSize string = 'Standard_D4ds_v5'

@description('Minimum node count of the apps pool: 2 lab, 3 prod.')
@minValue(1)
param userNodeMinCount int = 2

@description('Maximum node count of the apps pool: 6 lab, 10 prod.')
param userNodeMaxCount int = 6

@description('Object IDs (users or groups) that get AKS RBAC Cluster Admin + Cluster User Role. Empty entries are ignored.')
param clusterAdminPrincipalIds array = []

@description('Object ID of the GitHub deploy identity (service principal). Empty = skip its AcrPush, Cluster User and namespace RBAC Writer assignments.')
param deployPrincipalId string = ''

@description('Enable the application routing Gateway API implementation (approuting-istio). Usually enabled by scripts/aks-postprovision.sh instead.')
param enableGatewayApi bool = false

@description('ACR public network access: Enabled (lab, GitHub-hosted runners push) or Disabled (prod, requires self-hosted/ARC runners in the VNet).')
param acrPublicNetworkAccess string = 'Enabled'

// ---------------------------------------------------------------------------
// Variables
// ---------------------------------------------------------------------------
var sfx = take(uniqueString(subscription().id, 'ch', env), 6) // only for globally unique names

var tags = {
  workload: 'contoso-health'
  environment: env
  owner: 'platform-team'
  costCenter: 'CH-1001'
  dataClassification: 'confidential'
  managedBy: 'bicep'
}

var workloadResourceGroupName = 'rg-ch-${env}-idc'
var hubResourceGroupName = 'rg-ch-hub-idc'
var mgmtResourceGroupName = 'rg-ch-mgmt-idc'
var appNamespace = 'contoso-health'

var names = {
  aksIdentity: 'id-ch-aks-${env}'
  acr: 'crch${env}${sfx}'
  aks: 'aks-ch-${env}-idc'
  monitorWorkspace: 'amw-ch-${env}-idc'
  nodeResourceGroup: 'rg-ch-aks-${env}-idc-nodes'
  spokeVnet: 'vnet-ch-${env}-idc'
  routeTable: 'rt-ch-${env}-idc'
  apiIdentity: 'id-ch-api-${env}'
  webIdentity: 'id-ch-web-${env}'
}

var roleGuids = {
  networkContributor: '4d97b98b-1d4f-4787-a291-c67834d212e7'
  acrPull: '7f951dda-4ed3-4680-a7ca-43fe172d538d'
  acrPush: '8311e382-0749-4cb8-b61a-304f252e45ec'
}

// .bicepparam files read these from environment variables, which may be empty.
var clusterAdmins = filter(clusterAdminPrincipalIds, principalId => !empty(principalId))
var apiServerAuthorizedIpRanges = filter(authorizedIpRanges, cidr => !empty(cidr))

// ---------------------------------------------------------------------------
// Workload and platform resources (existing, looked up by name)
// ---------------------------------------------------------------------------
resource spokeVnet 'Microsoft.Network/virtualNetworks@2024-05-01' existing = {
  name: names.spokeVnet
  scope: resourceGroup(workloadResourceGroupName)
}

resource nodesSubnet 'Microsoft.Network/virtualNetworks/subnets@2024-05-01' existing = {
  parent: spokeVnet
  name: 'snet-aks-nodes'
}

resource apiServerSubnet 'Microsoft.Network/virtualNetworks/subnets@2024-05-01' existing = {
  parent: spokeVnet
  name: 'snet-aks-apiserver'
}

resource privateEndpointsSubnet 'Microsoft.Network/virtualNetworks/subnets@2024-05-01' existing = {
  parent: spokeVnet
  name: 'snet-private-endpoints'
}

resource apiIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' existing = {
  name: names.apiIdentity
  scope: resourceGroup(workloadResourceGroupName)
}

resource webIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' existing = {
  name: names.webIdentity
  scope: resourceGroup(workloadResourceGroupName)
}

resource acrDnsZone 'Microsoft.Network/privateDnsZones@2024-06-01' existing = {
  name: 'privatelink.azurecr.io'
  scope: resourceGroup(hubResourceGroupName)
}

resource logAnalytics 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: 'log-ch-idc'
  scope: resourceGroup(mgmtResourceGroupName)
}

// ---------------------------------------------------------------------------
// Identity and networking permissions (must exist before the cluster)
// ---------------------------------------------------------------------------
resource aksIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: names.aksIdentity
  location: location
  tags: tags
}

// Written in the workload resource group: Network Contributor on the spoke VNet (and route table in firewall mode).
module spokeNetworkContributor '../modules/identity/network-role-assignments.bicep' = {
  name: 'aks-network-contributor-${env}'
  scope: resourceGroup(workloadResourceGroupName)
  params: {
    vnetName: names.spokeVnet
    routeTableName: egressMode == 'firewall' ? names.routeTable : ''
    principalId: aksIdentity.properties.principalId
    roleDefinitionGuid: roleGuids.networkContributor
  }
}

// ---------------------------------------------------------------------------
// Registry and monitoring
// ---------------------------------------------------------------------------
module acr '../modules/containers/acr.bicep' = {
  name: 'acr'
  params: {
    name: names.acr
    location: location
    tags: tags
    publicNetworkAccess: acrPublicNetworkAccess
    privateEndpointSubnetId: privateEndpointsSubnet.id // PE lives in the AKS RG, its NIC in the workload spoke
    privateDnsZoneId: acrDnsZone.id
    logAnalyticsWorkspaceId: logAnalytics.id
  }
}

// Managed Prometheus store. Metrics collection is enabled by scripts/aks-postprovision.sh
// (az aks update --enable-azure-monitor-metrics --azure-monitor-workspace-resource-id ...).
resource monitorWorkspace 'Microsoft.Monitor/accounts@2023-04-03' = {
  name: names.monitorWorkspace
  location: location
  tags: tags
}

// ---------------------------------------------------------------------------
// Cluster
// ---------------------------------------------------------------------------
module aks '../modules/containers/aks.bicep' = {
  name: 'aks-cluster'
  params: {
    name: names.aks
    location: location
    tags: tags
    kubernetesVersion: kubernetesVersion
    dnsPrefix: 'aks-ch-${env}'
    nodeResourceGroupName: names.nodeResourceGroup
    controlPlaneIdentityId: aksIdentity.id
    nodesSubnetId: nodesSubnet.id
    apiServerSubnetId: apiServerSubnet.id
    apiServerAccess: apiServerAccess
    authorizedIpRanges: apiServerAuthorizedIpRanges
    egressMode: egressMode
    systemNodeVmSize: systemNodeVmSize
    userNodeVmSize: userNodeVmSize
    userNodeMinCount: userNodeMinCount
    userNodeMaxCount: userNodeMaxCount
    enableGatewayApi: enableGatewayApi
    clusterAdminPrincipalIds: clusterAdmins
    deployPrincipalId: deployPrincipalId
    appNamespace: appNamespace
    logAnalyticsWorkspaceId: logAnalytics.id
  }
  dependsOn: [
    spokeNetworkContributor // [REL] AKS validates subnet permissions of the control-plane identity at creation
  ]
}

// ---------------------------------------------------------------------------
// Role assignments and workload identity federation
// ---------------------------------------------------------------------------
module kubeletAcrPull '../modules/containers/acr-role-assignment.bicep' = {
  name: 'acr-pull-kubelet'
  params: {
    acrName: acr.outputs.name
    principalId: aks.outputs.kubeletObjectId
    roleDefinitionGuid: roleGuids.acrPull
    assignmentDescription: 'AKS kubelet identity pulls images (no imagePullSecrets).'
  }
}

module deployAcrPush '../modules/containers/acr-role-assignment.bicep' = if (!empty(deployPrincipalId)) {
  name: 'acr-push-deploy'
  params: {
    acrName: acr.outputs.name
    principalId: deployPrincipalId
    roleDefinitionGuid: roleGuids.acrPush
    assignmentDescription: 'GitHub Actions deploy identity pushes images.'
  }
}

// Written in the workload resource group: federated credentials on the EXISTING app identities, so the same
// identity (and its PostgreSQL/Redis/Key Vault permissions) serves App Service and AKS.
module workloadIdentityFederation '../modules/identity/federated-credentials.bicep' = {
  name: 'fic-aks-${env}'
  scope: resourceGroup(workloadResourceGroupName)
  params: {
    issuerUrl: aks.outputs.oidcIssuerUrl
    credentials: [
      {
        identityName: names.apiIdentity
        name: 'fic-${names.aks}-api'
        subject: 'system:serviceaccount:${appNamespace}:contoso-health-api'
      }
      {
        identityName: names.webIdentity
        name: 'fic-${names.aks}-web'
        subject: 'system:serviceaccount:${appNamespace}:contoso-health-web'
      }
    ]
  }
}

// ---------------------------------------------------------------------------
// Outputs (names are a contract with scripts and GitHub workflows)
// ---------------------------------------------------------------------------
@description('AKS cluster name.')
output aksName string = aks.outputs.name

@description('Resource group of the AKS cluster.')
output aksResourceGroup string = resourceGroup().name

@description('Container registry name.')
output acrName string = acr.outputs.name

@description('Container registry login server.')
output acrLoginServer string = acr.outputs.loginServer

@description('OIDC issuer URL of the cluster.')
output oidcIssuerUrl string = aks.outputs.oidcIssuerUrl

@description('Object ID of the kubelet identity.')
output kubeletObjectId string = aks.outputs.kubeletObjectId

@description('Resource ID of the Azure Monitor workspace (Managed Prometheus).')
output azureMonitorWorkspaceId string = monitorWorkspace.id

@description('Client ID of id-ch-api-<env> (service account annotation azure.workload.identity/client-id).')
output apiIdentityClientId string = apiIdentity.properties.clientId

@description('Client ID of id-ch-web-<env> (service account annotation azure.workload.identity/client-id).')
output webIdentityClientId string = webIdentity.properties.clientId
