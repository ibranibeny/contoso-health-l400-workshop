# Contoso Health – Bicep infrastructure

Three Bicep stacks, deployed as **Azure deployment stacks**, build the Contoso Health landing zone in
**Indonesia Central** (`indonesiacentral`, 3 availability zones, no paired region):

| Stack | Scope | Deployed into | Stack name |
|---|---|---|---|
| `platform` | subscription | creates `rg-ch-hub-idc`, `rg-ch-mgmt-idc` and the vended `rg-ch-<env>-idc` / `rg-ch-aks-<env>-idc` | `stack-ch-platform` |
| `workload` | resource group | `rg-ch-<env>-idc` | `stack-ch-workload-<env>` |
| `aks` | resource group | `rg-ch-aks-<env>-idc` | `stack-ch-aks-<env>` |

Stacks never pass values to each other. Each stack finds the resources it needs by their **fixed names**
(`rg-ch-hub-idc`, `vnet-ch-hub-idc`, `log-ch-idc`, the `privatelink.*` zones, `vnet-ch-<env>-idc`, `id-ch-api-<env>` ...),
so you can compile and deploy each stack on its own. Global names use the suffix
`sfx = take(uniqueString(subscription().id, 'ch', env), 6)`.

No secrets: every service authenticates with Microsoft Entra ID (managed or workload identities), PostgreSQL password auth and
Redis access keys are disabled, and Key Vault has no access policies (RBAC only). No parameter is `@secure()`.

```
infra/bicep
├── bicepconfig.json                 # linter: no-hardcoded-env-urls=error, secure-secrets-in-params=error, ...
├── platform/  main.bicep  lab.bicepparam  prod.bicepparam
├── workload/  main.bicep  lab.bicepparam  prod.bicepparam
├── aks/       main.bicep  lab.bicepparam  prod.bicepparam
└── modules
    ├── compute/     ops-vm.bicep
    ├── containers/  acr.bicep  acr-role-assignment.bicep  aks.bicep
    ├── data/        postgres.bicep  managed-redis.bicep
    ├── identity/    role-assignment.bicep  network-role-assignments.bicep  federated-credentials.bicep
    ├── monitor/     log-analytics.bicep  app-insights.bicep  alerts.bicep
    ├── network/     hub-network.bicep  private-dns-zones.bicep  firewall.bicep  bastion.bicep  spoke.bicep
    │                hub-peering.bicep  dns-zone-links.bicep  private-endpoint.bicep  app-gateway.bicep
    ├── security/    key-vault.bicep  policy-assignments.bicep  defender-plans.bicep
    └── web/         app-service-plan.bicep  app-service.bicep
```

## What each stack deploys

### platform (subscription scope – the "mini landing zone" owned by the platform team)

- **Resource groups**: `rg-ch-hub-idc` (connectivity), `rg-ch-mgmt-idc` (management) and, for each entry in
  `environments`, the vended `rg-ch-<env>-idc` and `rg-ch-aks-<env>-idc`.
- **Hub VNet** `vnet-ch-hub-idc` `10.100.0.0/22`: `AzureFirewallSubnet` 10.100.0.0/26, `AzureFirewallManagementSubnet` 10.100.0.64/26,
  `AzureBastionSubnet` 10.100.0.128/26.
- **Private DNS zones** (global, hub RG, linked to the hub VNet): `privatelink.azurewebsites.net`,
  `privatelink.postgres.database.azure.com`, `privatelink.redis.azure.net`, `privatelink.vaultcore.azure.net`, `privatelink.azurecr.io`.
- **Log Analytics** `log-ch-idc` (PerGB2018, 30 days by default) in `rg-ch-mgmt-idc`.
- Optional: **Azure Firewall Standard** `afw-ch-hub-idc` + policy `afwp-ch-hub-idc` (egress allow-list: AKS FQDN tag, ACR/MCR,
  Entra ID sign-in, App Insights ingestion, Ubuntu mirrors; TCP 443 to `AzureMonitor`/`AzureActiveDirectory`; UDP 123),
  **Bastion Basic**, **DDoS Network Protection plan** (expensive), **Defender for Cloud** plans (Containers, AppServices,
  OpenSourceRelationalDatabases, KeyVaults, CloudPosture).
- **Policy** (built-in, Deny/Audit only, no identity) assigned **per vended resource group**: Allowed locations and "NICs should not
  have public IPs" (both RGs), "Subnets should have an NSG" and four Application Gateway WAF audits (workload RG: WAF enabled,
  Prevention mode, bot protection, request body inspection; see [Web Application Firewall](#web-application-firewall)),
  "Kubernetes cluster should not allow privileged containers" (AKS RG, `audit` lab / `deny` prod).
  The definition GUIDs are in one map at the top of `platform/main.bicep`.
- **RBAC vending**: `workloadTeamPrincipalId` (optional) gets Contributor on the vended RGs.

Outputs: `hubVnetId`, `hubVnetName`, `hubResourceGroupName`, `mgmtResourceGroupName`, `logAnalyticsWorkspaceId`,
`privateDnsZoneIds` (map), `firewallPrivateIp` (`''` without firewall), `vendedResourceGroupNames`.

### workload (resource-group scope – `rg-ch-<env>-idc`)

- **Spoke VNet** `vnet-ch-<env>-idc` (lab `10.110.0.0/20`, prod `10.120.0.0/20`). The subnets are derived with `cidrSubnet()`:

  | Subnet | Lab prefix | Notes |
  |---|---|---|
  | `snet-appgw` | 10.110.0.0/24 | App Gateway v2 (NSG allows GatewayManager 65200-65535, AzureLoadBalancer, Internet 80/443/8080) |
  | `snet-app-integration` | 10.110.1.0/26 | delegated `Microsoft.Web/serverFarms`, egress |
  | `snet-private-endpoints` | 10.110.2.0/24 | all private endpoints (NSG enforced on PE traffic) |
  | `snet-ops` | 10.110.3.0/27 | ops VM, egress, SSH only from the hub Bastion subnet |
  | `snet-aks-ilb` | 10.110.3.64/27 | AKS internal load balancer (`aksIngressPrivateIp` 10.110.3.70) |
  | `snet-aks-apiserver` | 10.110.3.96/28 | delegated `Microsoft.ContainerService/managedClusters` (API server VNet integration, prod) |
  | `snet-aks-nodes` | 10.110.4.0/22 | AKS nodes (CNI Overlay), egress |

  Every subnet has its own NSG `nsg-<subnet>`. `snet-private-endpoints`, `snet-ops`, `snet-aks-ilb` and `snet-aks-nodes` are
  private subnets (`defaultOutboundAccess: false`). `snet-appgw` keeps the platform default until Application Gateway v2 support
  for private subnets is documented, and so do the delegated `snet-app-integration` and `snet-aks-apiserver` (Learn: private
  subnets aren't applicable to delegated subnets). Egress is set by `egressMode`. `natGateway`
  attaches `ng-ch-<env>-idc` and its public IP to the three egress subnets. `firewall` attaches route table `rt-ch-<env>-idc`
  (0.0.0.0/0 to the hub firewall private IP).
- **Peering** spoke ⇄ hub (the hub side is written by a module scoped to `rg-ch-hub-idc`) and **links** of all five hub private DNS
  zones to the spoke (also written in the hub RG).
- **Identities**: `id-ch-api-<env>`, `id-ch-web-<env>`, `id-ch-dbadmin-<env>`, `id-ch-agw-<env>`.
- **Application Insights** `appi-ch-<env>-idc` (workspace-based on `log-ch-idc`, local auth disabled in prod).
- **Key Vault** `kv-ch-<env>-<sfx>` (RBAC, purge protection, 90 days soft delete, public access disabled, private endpoint).
- **App Service**: plan `asp-ch-<env>-idc` (Linux, Premium v4, zone-redundant). Web apps `app-ch-web-<env>-<sfx>` and
  `app-ch-api-<env>-<sfx>` run Node 24 LTS with VNet integration (`outboundVnetRouting.allTraffic`). Each app has a private
  endpoint, a main site that denies all public traffic, an SCM site set by `scmIpSecurityRestrictionsDefaultAction`, basic auth
  disabled, a user-assigned identity, `keyVaultReferenceIdentity` and the exact app settings of the build contract. The App Service
  health check uses the readiness path `/readyz` (5xx when a required dependency such as PostgreSQL is unreachable); App Gateway
  probes the shallow liveness path `/healthz`.
- **PostgreSQL flexible server** `psql-ch-<env>-<sfx>`: version 17, Entra ID only, `id-ch-dbadmin-<env>` as Entra admin, private endpoint,
  Sunday 02:00 (UTC) maintenance. Zone-redundant HA in prod. The `contoso_health` database is **not** created here: the bootstrap
  script creates it so that the admin owns it and can grant on it.
- **Azure Managed Redis** `redis-ch-<env>-<sfx>` (HA, TLS 1.2, `EnterpriseCluster`, access keys disabled, private endpoint) plus an
  access policy assignment for `id-ch-api-<env>`.
- **Application Gateway WAF_v2** `agw-ch-<env>-idc` (zones 1-3, autoscale) with WAF policy `waf-ch-<env>-idc` (DRS 2.2 + Bot
  Manager 1.1, `wafMode` Prevention, custom rules, log scrubbing; see [Web Application Firewall](#web-application-firewall)):
  `:80` → web app (HTTPS 443 through its private endpoint, probe `/healthz`); `:8080` → `aksIngressPrivateIp` (HTTP 80, probe
  `/healthz` with host `127.0.0.1`). Setting `tlsCertificateSecretId` adds `:443` with the Key Vault certificate and redirects `:80` to it.
- **Ops VM** `vm-ch-ops-<env>` (Ubuntu 24.04, `Standard_B2s`). It has no public IP, uses SSH key auth only and runs as
  `id-ch-dbadmin-<env>`. cloud-init installs `postgresql-client` and `jq`. Operate it with `az vm run-command`.
- **Role assignments**: web and api identities get Monitoring Metrics Publisher (App Insights). The api and agw identities get
  Key Vault Secrets User. Nobody gets Key Vault Administrator.
- **Alerts**: action group `ag-ch-<env>` (`alertEmail`), App Gateway `UnhealthyHostCount > 0` (5 min) and PostgreSQL
  `cpu_percent > 80` (15 min). `modules/monitor/alerts.bicep` contains `TODO(copilot-exercise)` for the Redis server load alert.

Outputs: `resourceGroupName`, `webAppName`, `apiAppName`, `webAppHostName`, `apiAppHostName`, `appGatewayPublicIp`,
`postgresServerName`, `postgresFqdn`, `redisName`, `redisHostName`, `keyVaultName`, `appInsightsName`, `apiIdentityName`,
`apiIdentityClientId`, `apiIdentityPrincipalId`, `webIdentityName`, `webIdentityClientId`, `webIdentityPrincipalId`,
`dbAdminIdentityName`, `dbAdminIdentityClientId`, `opsVmName`, `spokeVnetName`, `spokeVnetId`, `aksNodesSubnetId`,
`aksIlbSubnetId`, `aksApiServerSubnetId`, `privateEndpointsSubnetId`, `natGatewayId`, `aksIngressPrivateIp`.

### aks (resource-group scope – `rg-ch-aks-<env>-idc`)

- **Control-plane identity** `id-ch-aks-<env>`. It gets **Network Contributor on the spoke VNet** (and on the route table in firewall
  mode) through a module scoped to the workload RG, and this happens before the cluster is created.
- **ACR** `crch<env><sfx>`: Premium, no admin user, no anonymous pull. Public network access is enabled in lab and disabled in prod.
  It has a private endpoint in the workload `snet-private-endpoints`, registered in the hub `privatelink.azurecr.io` zone.
- **AKS** `aks-ch-<env>-idc` (Kubernetes 1.36, Standard tier) with:
  - Networking: Azure CNI Overlay with the Cilium dataplane and network policy. Nodes run in the workload `snet-aks-nodes`, and
    the outbound type follows `egressMode`.
  - Identity: Entra ID with Azure RBAC, local accounts disabled, OIDC issuer and workload identity enabled.
  - Maintenance: Image Cleaner, `patch` and `NodeImage` upgrade channels, and maintenance windows on Sunday 01:00 for 4 hours
    (UTC+07:00).
  - Node pools: system pool of 3 to 5 nodes (`CriticalAddonsOnly` taint) and `apps` pool, both spread over zones 1, 2 and 3.
  - Add-ons: Azure Policy and the Key Vault CSI driver with rotation.
  - API server: public in lab (optional `authorizedIpRanges`). Prod is a private cluster with API server VNet integration into
    `snet-aks-apiserver`.
- **Azure Monitor workspace** `amw-ch-<env>-idc` (Managed Prometheus). Monitoring add-ons and, by default, the Gateway API are enabled
  afterwards by `scripts/aks-postprovision.sh`.
- **Role assignments**:
  - Kubelet identity: AcrPull.
  - `clusterAdminPrincipalIds`: AKS RBAC Cluster Admin and Cluster User Role.
  - `deployPrincipalId` (optional): AcrPush, Cluster User Role, and AKS RBAC Writer on `namespaces/contoso-health`.
- **Federated credentials** on the existing `id-ch-api-<env>` / `id-ch-web-<env>` (subjects
  `system:serviceaccount:contoso-health:contoso-health-api|web`, issuer = cluster OIDC issuer), written in the workload RG.
- Diagnostic settings: AKS (`kube-audit-admin`, `kube-apiserver`, `cluster-autoscaler`, `guard`) and ACR.

Outputs: `aksName`, `aksResourceGroup`, `acrName`, `acrLoginServer`, `oidcIssuerUrl`, `kubeletObjectId`,
`azureMonitorWorkspaceId`, `apiIdentityClientId`, `webIdentityClientId`.

### Web Application Firewall

WAF policy `waf-ch-<env>-idc` (`modules/network/app-gateway.bicep`) is attached to the whole gateway, so the `:80`/`:443` and
`:8080` listeners share it.

- **Managed rule sets**: `Microsoft_DefaultRuleSet` 2.2 and `Microsoft_BotManagerRuleSet` 1.1 in `wafMode` (Prevention in lab and
  prod). There are no exclusions on purpose: adding a per-rule exclusion is a workshop exercise.
- **Request limits**: body inspection on, inspection limit and maximum body size 128 KB, file uploads 100 MB, all enforced. The
  portal and API only accept small JSON bodies.
- **Custom rules** run before the managed rules, lowest priority first. A block returns HTTP 403.

  | Priority | Rule | Matches | Action |
  |---|---|---|---|
  | 10 | `RateLimitClaimSubmissions` | `POST` to a URI that begins with `/api/claims` (lowercased), counted per client IP (`ClientAddr`) over one minute | Block above `wafClaimsRateLimitPerMinute` |
  | 20 | `BlockUnexpectedMethods` | any method except `GET`, `HEAD` and `POST` | Block |
  | 30 | `BlockOpsApiFromInternet` (only when `wafBlockOpsApi`) | URI begins with `/api/ops/` (lowercased) | Block |
  | 40 | `LogOutsideAllowedCountries` | client IP (`RemoteAddr`, GeoMatch) outside `wafAllowedCountryCodes` | Log |

  The rate limit is defence in depth: the API still allows each member 5 claims a minute (HTTP 429). It counts per client IP in a
  sliding window, so participants behind one venue NAT share it; raise the lab value if the burst exercise gets HTTP 403 instead of
  429. Blocking by country is a business and legal decision, so the geo rule only logs. Learn recommends adding `ZZ` (addresses
  not yet mapped to a country) to the list before a geo rule ever blocks.
- **Log scrubbing**: the JSON argument `note` (the free-text claim note, which is health information) is masked in the WAF logs
  (`RequestJSONArgNames`, `Equals`; the selector is case-sensitive). Scrubbing needs a matching `Content-Type`, and the API only
  accepts `application/json`.
- **Diagnostics**: `logAnalyticsDestinationType: 'Dedicated'` sends the logs to the resource-specific tables `AGWAccessLogs`,
  `AGWFirewallLogs` and `AGWPerformanceLogs` instead of `AzureDiagnostics`. The performance log exists only for the v1 SKU; on
  WAF_v2 use the metrics.
- **Policy** (platform stack, workload RG, Audit): `pa-ch-appgw-waf` (WAF enabled), `pa-ch-appgw-waf-mode` (WAF mode, with
  `modeRequirement: 'Prevention'` because the definition defaults to Detection), `pa-ch-appgw-waf-bots` (Bot Manager rule set
  present) and `pa-ch-appgw-waf-body` (request body inspection on).
- **Check**: with `AGW_IP` from [Verify after deploy](#verify-after-deploy), `scripts/waf-test.sh "http://$AGW_IP"` (and
  `:8080`; the deploy workflows run it too) expects HTTP 403 from the gateway for its attack probes and for `DELETE`
  (`BlockUnexpectedMethods`). Add `WAF_RATE_LIMIT=true WAF_RATE_LIMIT_PER_MINUTE=<wafClaimsRateLimitPerMinute>` to test the
  rate limit. Its SQL-injection probe sends the payload in `note`, so search `AGWFirewallLogs` for `******` to see the
  scrubbing; `AGWFirewallLogs | where TimeGenerated > ago(1h) | summarize count() by RuleId, Action` summarises the matches.

## Prerequisites

- Azure CLI with Bicep **0.49+** (`az bicep upgrade`), signed in (`az login`) to the target subscription
  (`az account set --subscription <id>`).
- Resource providers registered (`scripts/preflight.sh`): Microsoft.Network, Web, DBforPostgreSQL, Cache, KeyVault,
  ContainerService, ContainerRegistry, Monitor, Insights, OperationalInsights, ManagedIdentity, Compute, Security, PolicyInsights,
  AlertsManagement.
- Permissions:
  - **platform** needs Owner on the subscription, or Contributor plus Role Based Access Control Administrator, Resource Policy
    Contributor and Security Admin.
  - **workload** and **aks** need Owner (or Contributor plus Role Based Access Control Administrator) on their resource groups,
    plus Network Contributor and Private DNS Zone Contributor on `rg-ch-hub-idc` for the peering and zone links.
  - **Deny settings** (`denyWriteAndDelete`, used in prod) also require the **Azure Deployment Stack Owner** role.
- Per-user values are read by the `.bicepparam` files from environment variables (all optional except the SSH key when the ops VM
  is deployed):

| Variable | Used by | Purpose |
|---|---|---|
| `OPS_SSH_PUBLIC_KEY` | workload | SSH public key of the ops VM (`export OPS_SSH_PUBLIC_KEY="$(cat ~/.ssh/id_ed25519.pub)"`) |
| `ALERT_EMAIL` | workload | e-mail receiver of the action group (empty = no receiver) |
| `TLS_CERTIFICATE_SECRET_ID` | workload | versionless Key Vault secret ID of the App Gateway certificate (empty = HTTP only, lab only) |
| `CLUSTER_ADMIN_OBJECT_ID` | aks | your object ID (`az ad signed-in-user show --query id -o tsv`) or an Entra group (prod) |
| `DEPLOY_PRINCIPAL_ID` | aks | object ID of the GitHub Actions deploy identity's service principal |
| `AKS_AUTHORIZED_IP_RANGES` | aks (lab) | comma-separated CIDRs allowed to reach the public API server (empty = unrestricted) |
| `WORKLOAD_TEAM_PRINCIPAL_ID` / `WORKLOAD_TEAM_PRINCIPAL_TYPE` | platform | Entra group (default type `Group`) that gets Contributor on the vended RGs |

> **Ops VM and the SSH key**: `deployOpsVm` defaults to `true`. If `OPS_SSH_PUBLIC_KEY` is empty, the deployment **fails
> validation** on `sshPublicKey` (`@minLength(1)` in `modules/compute/ops-vm.bicep`). Export the key, or set
> `param deployOpsVm = false` in the `.bicepparam` file to skip the VM.

## Deploy

Run every command from the repository root (`contoso-health/`). The order is **platform → workload → (database bootstrap) → aks →
`scripts/aks-postprovision.sh`**. Before each deployment, preview it with what-if (stacks have no what-if of their own).

### 1. Platform (once per subscription)

`lab.bicepparam` is the workshop profile: it vends the lab resource groups only, without firewall, Bastion, DDoS or Defender.
`prod.bicepparam` is the production profile: it vends **lab and prod** and adds the firewall (required by `egressMode=firewall`),
Bastion and Defender. Both profiles use the same stack name, so deploying the prod profile replaces the lab profile. Resources
removed from the template are only detached.

```bash
# lab profile: what-if + deploy
az deployment sub what-if --location indonesiacentral \
  --template-file infra/bicep/platform/main.bicep \
  --parameters infra/bicep/platform/lab.bicepparam

az stack sub create --name stack-ch-platform --location indonesiacentral \
  --template-file infra/bicep/platform/main.bicep \
  --parameters infra/bicep/platform/lab.bicepparam \
  --deny-settings-mode none --action-on-unmanage detachAll

# prod profile: what-if + deploy (same stack name: supersedes the lab profile)
az deployment sub what-if --location indonesiacentral \
  --template-file infra/bicep/platform/main.bicep \
  --parameters infra/bicep/platform/prod.bicepparam

az stack sub create --name stack-ch-platform --location indonesiacentral \
  --template-file infra/bicep/platform/main.bicep \
  --parameters infra/bicep/platform/prod.bicepparam \
  --deny-settings-mode none --action-on-unmanage detachAll
```

### 2. Workload

```bash
export OPS_SSH_PUBLIC_KEY="$(cat ~/.ssh/id_ed25519.pub)"
export ALERT_EMAIL="platform-team@contoso-health.example"     # optional

# lab: what-if + deploy
az deployment group what-if --resource-group rg-ch-lab-idc \
  --parameters infra/bicep/workload/lab.bicepparam

az stack group create --name stack-ch-workload-lab --resource-group rg-ch-lab-idc \
  --parameters infra/bicep/workload/lab.bicepparam \
  --deny-settings-mode none --action-on-unmanage deleteResources

# prod: what-if + deploy (needs the platform prod profile, i.e. the hub firewall)
az deployment group what-if --resource-group rg-ch-prod-idc \
  --parameters infra/bicep/workload/prod.bicepparam

# denyWriteAndDelete needs the "Azure Deployment Stack Owner" role. Only the excluded principal (the GitHub
# deploy identity running this command) can change the stack's resources afterwards.
az stack group create --name stack-ch-workload-prod --resource-group rg-ch-prod-idc \
  --parameters infra/bicep/workload/prod.bicepparam \
  --deny-settings-mode denyWriteAndDelete \
  --deny-settings-excluded-principals "$DEPLOY_PRINCIPAL_ID" \
  --action-on-unmanage deleteResources
```

Next, create the `contoso_health` database and the Entra roles of the app identities. Run the database bootstrap script from
`scripts/`; it reaches PostgreSQL from the ops VM via `az vm run-command` using `id-ch-dbadmin-<env>`.

### 3. AKS

```bash
export CLUSTER_ADMIN_OBJECT_ID="$(az ad signed-in-user show --query id -o tsv)"
export DEPLOY_PRINCIPAL_ID="<object id of the GitHub deploy identity>"   # optional

# lab
az deployment group what-if --resource-group rg-ch-aks-lab-idc \
  --parameters infra/bicep/aks/lab.bicepparam

az stack group create --name stack-ch-aks-lab --resource-group rg-ch-aks-lab-idc \
  --parameters infra/bicep/aks/lab.bicepparam \
  --deny-settings-mode none --action-on-unmanage deleteResources

# prod (needs the Azure Deployment Stack Owner role for denyWriteAndDelete)
az deployment group what-if --resource-group rg-ch-aks-prod-idc \
  --parameters infra/bicep/aks/prod.bicepparam

az stack group create --name stack-ch-aks-prod --resource-group rg-ch-aks-prod-idc \
  --parameters infra/bicep/aks/prod.bicepparam \
  --deny-settings-mode denyWriteAndDelete \
  --deny-settings-excluded-principals "$DEPLOY_PRINCIPAL_ID" \
  --action-on-unmanage deleteResources

# then enable Managed Prometheus, Container insights and the Gateway API
scripts/aks-postprovision.sh prod
```

Add `--yes` to skip the confirmation prompt in CI. To read the outputs of a stack:
`az stack group show --name stack-ch-workload-lab --resource-group rg-ch-lab-idc --query outputs`.

### Local validation (same checks as CI)

```bash
for s in platform workload aks; do
  az bicep build --file infra/bicep/$s/main.bicep --stdout > /dev/null
  az bicep lint  --file infra/bicep/$s/main.bicep
  az bicep build-params --file infra/bicep/$s/lab.bicepparam  --stdout > /dev/null
  az bicep build-params --file infra/bicep/$s/prod.bicepparam --stdout > /dev/null
done
```

## Parameters

Values shown are the ones set in `lab.bicepparam` / `prod.bicepparam`. "default" means the template default is used.
`env:NAME` means the value comes from that environment variable.

### platform

| Parameter | lab | prod | Description |
|---|---|---|---|
| `env` | `lab` | `prod` | Platform profile, used for tags. |
| `location` | default | default | Region; defaults to the stack location (`indonesiacentral`). |
| `environments` | `['lab']` | `['lab','prod']` | Environments to vend `rg-ch-<env>-idc` + `rg-ch-aks-<env>-idc` for. |
| `allowedLocations` | default | default | Regions allowed by the Allowed-locations policy (default `[location]`). |
| `logRetentionInDays` | `30` | `90` | Log Analytics interactive retention. |
| `deployFirewall` | `false` | `true` | Azure Firewall Standard + policy (required by `egressMode=firewall`). |
| `deployBastion` | `false` | `true` | Azure Bastion Basic in the hub. |
| `deployDdosPlan` | `false` | `false` | DDoS Network Protection plan (~USD 3,000/month, see the cost note). |
| `enableDefenderPlans` | `false` | `true` | Defender for Cloud Standard: Containers, AppServices, OpenSourceRelationalDatabases, KeyVaults, CloudPosture. |
| `workloadTeamPrincipalId` | env:`WORKLOAD_TEAM_PRINCIPAL_ID` | same | Gets Contributor on the vended RGs (empty = skip). |
| `workloadTeamPrincipalType` | env:`WORKLOAD_TEAM_PRINCIPAL_TYPE` (`Group`) | same | Principal type of the above. |
| `aksPrivilegedContainerPolicyEffects` | `{lab:'audit', prod:'deny'}` | same | Effect of the privileged-containers policy per environment. |
| `spokeAddressPrefixes` | default | default | Sources allowed through the firewall (`10.110.0.0/20`, `10.120.0.0/20`). |

### workload

| Parameter | lab | prod | Description |
|---|---|---|---|
| `env` | `lab` | `prod` | Environment name (`@allowed`). |
| `location` | default | default | Defaults to the resource group location. |
| `addressPrefix` | `10.110.0.0/20` | `10.120.0.0/20` | Spoke address space; subnets are derived from it. |
| `egressMode` | `natGateway` | `firewall` | Egress of the private subnets (`@allowed`). |
| `enableDdosProtection` | `false` | `false` | Associate the spoke with `ddos-ch-hub-idc` (needs platform `deployDdosPlan`). |
| `appServicePlanSku` | `P0v4` | `P1v4` | Premium v4 SKU. |
| `appServicePlanCapacity` | `2` | `3` | Instances (>= 2 for zone redundancy and health check). |
| `scmIpSecurityRestrictionsDefaultAction` | `Allow` | `Deny` | SCM site default action (GitHub-hosted vs self-hosted runners). |
| `postgresVersion` | `17` | `17` | PostgreSQL major version (18 is also GA). |
| `postgresSkuName` / `postgresSkuTier` | `Standard_B1ms` / `Burstable` | `Standard_D2ds_v5` / `GeneralPurpose` | Compute. |
| `postgresHighAvailabilityMode` | `Disabled` | `ZoneRedundant` | Zone-redundant HA (primary zone 1, standby zone 2). |
| `postgresStorageSizeGB` | `32` | `128` | Storage (auto-grow enabled). |
| `postgresBackupRetentionDays` | `7` | `35` | Backup retention (geo-redundant backup is not available in the region). |
| `redisSkuName` | `Balanced_B0` | `Balanced_B0` | Azure Managed Redis SKU: the smallest Balanced size in both environments; scale up when load grows. |
| `appGatewayMinCapacity` / `appGatewayMaxCapacity` | `1` / `10` | `2` / `10` | App Gateway autoscale bounds. |
| `wafMode` | `Prevention` | `Prevention` | WAF policy mode (`@allowed` `Prevention`, `Detection`). Tune false positives with exclusions, not with Detection. |
| `wafClaimsRateLimitPerMinute` | `60` | `300` | Custom rule `RateLimitClaimSubmissions`: POSTs to `/api/claims` per client IP and minute (`@minValue(1)`). |
| `wafBlockOpsApi` | `false` | `true` | Adds custom rule `BlockOpsApiFromInternet`: `/api/ops/*` blocked at the edge. |
| `wafAllowedCountryCodes` | `['ID']` | `['ID']` | Custom rule `LogOutsideAllowedCountries`: requests from other countries are logged, not blocked (`@minLength(1)`). |
| `aksIngressPrivateIp` | `10.110.3.70` | `10.120.3.70` | Static IP of the AKS internal LB (`web` Service) in `snet-aks-ilb`. |
| `tlsCertificateSecretId` | env:`TLS_CERTIFICATE_SECRET_ID` | same | Key Vault secret ID → HTTPS listener + 80→443 redirect; empty = HTTP (lab only). |
| `deployOpsVm` | `true` | `true` | Deploy the ops VM (needs `opsSshPublicKey`). |
| `opsSshPublicKey` | env:`OPS_SSH_PUBLIC_KEY` | same | SSH public key of the ops VM admin (`azureops`). |
| `opsVmSize` | `Standard_B2s` | `Standard_B2s` | Ops VM size. |
| `alertEmail` | env:`ALERT_EMAIL` | same | Action group e-mail (empty = no receiver). |
| `appInsightsDisableLocalAuth` | `false` | `true` | Entra-only telemetry ingestion; also sets `APPLICATIONINSIGHTS_AUTH=entra`. |
| `seedOnStart` | `true` | `false` | API `SEED_ON_START`. |
| `opsApiEnabled` | `true` | `false` | API `OPS_API_ENABLED`. |

### aks

| Parameter | lab | prod | Description |
|---|---|---|---|
| `env` | `lab` | `prod` | Environment name (`@allowed`). |
| `location` | default | default | Defaults to the resource group location. |
| `kubernetesVersion` | `1.36` | `1.36` | Minor version; AKS picks the latest patch. |
| `apiServerAccess` | `public` | `private` | Public API server or private cluster with API server VNet integration (`@allowed`). |
| `authorizedIpRanges` | env:`AKS_AUTHORIZED_IP_RANGES` (comma-separated) | `[]` | Allowed CIDRs for the public API server (empty = unrestricted). |
| `egressMode` | `natGateway` | `firewall` | Must match the workload stack (`userAssignedNATGateway` / `userDefinedRouting`). |
| `systemNodeVmSize` / `userNodeVmSize` | `Standard_D4ds_v5` | `Standard_D4ds_v5` | Node sizes (system pool 3-5 nodes). |
| `userNodeMinCount` / `userNodeMaxCount` | `2` / `6` | `3` / `10` | `apps` pool autoscale bounds. |
| `clusterAdminPrincipalIds` | `[env:CLUSTER_ADMIN_OBJECT_ID]` | same (use a group) | AKS RBAC Cluster Admin + Cluster User Role (empty entries ignored). |
| `deployPrincipalId` | env:`DEPLOY_PRINCIPAL_ID` | same | GitHub deploy identity: AcrPush, Cluster User Role, RBAC Writer on `contoso-health` (empty = skip). |
| `enableGatewayApi` | `false` | `false` | Gateway API (`approuting-istio`) from IaC instead of the post-provision script. |
| `acrPublicNetworkAccess` | `Enabled` | `Disabled` | ACR public endpoint (prod needs self-hosted/ARC runners). |

## Verify after deploy

Set the variables once (lab shown):

```bash
RG=rg-ch-lab-idc; STACK=stack-ch-workload-lab; VM=vm-ch-ops-lab
out() { az stack group show --name "$STACK" --resource-group "$RG" --query "outputs.$1.value" -o tsv; }
PSQL=$(out postgresFqdn); REDIS=$(out redisHostName); KV=$(out keyVaultName)
WEB=$(out webAppHostName); API=$(out apiAppHostName); AGW_IP=$(out appGatewayPublicIp)
ACR=$(az stack group show --name stack-ch-aks-lab --resource-group rg-ch-aks-lab-idc --query outputs.acrLoginServer.value -o tsv)
```

1. **Stacks succeeded**:
   `az stack sub show --name stack-ch-platform --query provisioningState -o tsv` and
   `az stack group show --name "$STACK" --resource-group "$RG" --query provisioningState -o tsv` both return `succeeded`.
2. **Peering is connected** in both directions:
   `az network vnet peering list --resource-group "$RG" --vnet-name vnet-ch-lab-idc --query "[].{name:name,state:peeringState,sync:peeringSyncLevel}" -o table`
   and the same for `--resource-group rg-ch-hub-idc --vnet-name vnet-ch-hub-idc` both show `Connected` / `FullyInSync`.
3. **Private DNS from inside the spoke**: every name resolves through a `privatelink.*` CNAME to an IP in `10.110.2.0/24`:
   ```bash
   az vm run-command invoke --resource-group "$RG" --name "$VM" --command-id RunShellScript \
     --scripts "for h in $PSQL $REDIS $KV.vault.azure.net $WEB $API $ACR; do nslookup \$h; done"
   ```
   If `nslookup` is missing on the image, use `getent hosts <name>`.
4. **The apps are not public**: `curl -s -o /dev/null -w '%{http_code}\n' "https://$WEB/"` from your laptop returns `403`.
   From the VM, `curl -s "https://$API/healthz"` through `az vm run-command invoke` succeeds (private endpoint).
5. **App Gateway**: `curl -s "http://$AGW_IP/healthz"` returns 200 after the app is deployed. Check the backends with
   `az network application-gateway show-backend-health --resource-group "$RG" --name agw-ch-lab-idc --query "backendAddressPools[].backendHttpSettingsCollection[].servers[].{address:address,health:health}" -o table`.
   The `:8080` (AKS) backend stays unhealthy until the AKS stack and the `web` Service exist.
6. **Explicit egress**: `az vm run-command invoke --resource-group "$RG" --name "$VM" --command-id RunShellScript --scripts "curl -s https://api.ipify.org"`
   returns the NAT gateway IP (`az network public-ip show --resource-group "$RG" --name pip-ng-ch-lab-idc --query ipAddress -o tsv`).
   In prod the request is **blocked** by the firewall allow-list; it shows up in the `AZFWApplicationRule` table.
7. **PostgreSQL is Entra-only and private**:
   `az postgres flexible-server show --resource-group "$RG" --name "${PSQL%%.*}" --query "{auth:authConfig,public:network.publicNetworkAccess,ha:highAvailability.mode}"`
   and `az postgres flexible-server microsoft-entra-admin list --resource-group "$RG" --server-name "${PSQL%%.*}" -o table` (older CLIs: `ad-admin list`) shows `id-ch-dbadmin-lab`.
8. **Redis, Key Vault and web apps are locked down**:
   - `az redisenterprise show -g "$RG" -n "${REDIS%%.*}" --query "{ha:highAvailability,public:publicNetworkAccess,tls:minimumTlsVersion}"`
   - `az keyvault show --name "$KV" --query "properties.{rbac:enableRbacAuthorization,purge:enablePurgeProtection,public:publicNetworkAccess}"`
   - `az webapp show --resource-group "$RG" --name "${WEB%%.*}" --query "{public:publicNetworkAccess,https:httpsOnly,routing:outboundVnetRouting}"`
   - `az resource show --ids "$(az webapp show --resource-group "$RG" --name "${WEB%%.*}" --query id -o tsv)/basicPublishingCredentialsPolicies/scm" --query properties.allow` returns `false`.
9. **Policy** is assigned on the vended RGs: `az policy assignment list --resource-group "$RG" -o table`.
   Compliance is evaluated after about 30 minutes: `az policy state summarize --resource-group "$RG"`.
10. **AKS**:
    - `az aks show --resource-group rg-ch-aks-lab-idc --name aks-ch-lab-idc --query "{version:currentKubernetesVersion,outbound:networkProfile.outboundType,oidc:oidcIssuerProfile.issuerUrl,wi:securityProfile.workloadIdentity.enabled}"`
    - `az aks get-credentials --resource-group rg-ch-aks-lab-idc --name aks-ch-lab-idc && kubelogin convert-kubeconfig -l azurecli && kubectl get nodes -L topology.kubernetes.io/zone`
    - Federated credentials: `az identity federated-credential list --resource-group "$RG" --identity-name id-ch-api-lab -o table`.
11. **Alerts**: `az monitor metrics alert list --resource-group "$RG" -o table` lists the App Gateway and PostgreSQL alerts.

## Operational notes

- **Key Vault purge protection**: if you delete the lab stack and redeploy within 90 days, the name `kv-ch-lab-<sfx>` is still held
  by the soft-deleted vault. Run `az keyvault recover --name kv-ch-lab-<sfx>` first, then redeploy; the stack adopts it again.
- **AKS out-of-band settings**: `scripts/aks-postprovision.sh` enables Managed Prometheus, Container insights and the Gateway API.
  Re-run it after every update of the AKS stack, because a cluster PUT from IaC can reset add-ons that were enabled outside it.
- **Prod deny settings**: `denyWriteAndDelete` also covers resources that the workload stack writes in the hub RG (peering, zone
  links). Changes then need the excluded deploy identity. The AKS stack writes a role assignment on the spoke VNet and federated
  credentials on the workload identities, so run it with that same deploy identity. If a resource provider operation is
  denied, add the principal to `--deny-settings-excluded-principals` (up to 5) or the action to `--deny-settings-excluded-actions`.
- **Teardown** (lab):
  1. `az stack group delete --name stack-ch-aks-lab --resource-group rg-ch-aks-lab-idc --action-on-unmanage deleteResources --yes`
  2. `az stack group delete --name stack-ch-workload-lab --resource-group rg-ch-lab-idc --action-on-unmanage deleteResources --yes`
  3. Optionally `az stack sub delete --name stack-ch-platform --action-on-unmanage deleteAll --yes`. This also deletes the vended
     resource groups.
