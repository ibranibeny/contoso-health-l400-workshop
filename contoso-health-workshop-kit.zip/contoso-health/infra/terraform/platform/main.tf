# Platform stack ("mini landing zone", subscription scope): connectivity (hub VNet, private DNS zones,
# optional Firewall / Bastion / DDoS), management (Log Analytics), security (Defender plans, policy) and
# subscription vending of the workload resource groups. Terraform twin of infra/bicep/platform/main.bicep.

# -------------------------------------------------------------------------------------------------
# Resource groups (platform + vended workload resource groups)
# -------------------------------------------------------------------------------------------------
resource "azurerm_resource_group" "hub" {
  name     = local.names.hub_rg
  location = var.location
  tags     = local.platform_tags
}

resource "azurerm_resource_group" "mgmt" {
  name     = local.names.mgmt_rg
  location = var.location
  tags     = local.platform_tags
}

# [OPS] Vended RGs: the workload and aks stacks deploy INTO them; the platform owns their guardrails and RBAC.
# AzureRM refuses to delete a resource group that still contains resources (provider default), so destroying
# the platform cannot silently wipe a workload.
resource "azurerm_resource_group" "vended" {
  for_each = local.vended_rgs

  name     = each.value.name
  location = var.location
  tags     = local.vended_tags[each.value.env]
}

# -------------------------------------------------------------------------------------------------
# Management: one Log Analytics workspace for every environment
# -------------------------------------------------------------------------------------------------
resource "azurerm_log_analytics_workspace" "this" {
  name                = local.names.law
  location            = var.location
  resource_group_name = azurerm_resource_group.mgmt.name
  sku                 = "PerGB2018"
  # [COST] 30 days is included in the ingestion price; raise it (prod.tfvars) for longer investigations.
  retention_in_days = var.log_retention_in_days
  tags              = local.platform_tags
}

# -------------------------------------------------------------------------------------------------
# Connectivity: hub VNet, private DNS zones, optional Firewall / Bastion / DDoS
# -------------------------------------------------------------------------------------------------

# [COST] DDoS Network Protection costs roughly USD 2,900/month per plan (+ overage above 100 protected public
# IPs). It is worth it for internet-facing production estates; the free infrastructure-level protection is the
# workshop default. One plan per tenant/region can cover many VNets.
resource "azurerm_network_ddos_protection_plan" "this" {
  count = var.deploy_ddos_plan ? 1 : 0

  name                = local.names.ddos_plan
  location            = var.location
  resource_group_name = azurerm_resource_group.hub.name
  tags                = local.platform_tags
}

resource "azurerm_virtual_network" "hub" {
  name                = local.names.hub_vnet
  location            = var.location
  resource_group_name = azurerm_resource_group.hub.name
  address_space       = [local.hub_address_prefix]
  tags                = local.platform_tags

  dynamic "ddos_protection_plan" {
    for_each = var.deploy_ddos_plan ? [1] : []
    content {
      id     = azurerm_network_ddos_protection_plan.this[0].id
      enable = true
    }
  }
}

# Firewall/Bastion subnets keep the platform default for outbound access (same as the Bicep twin): both services
# egress through their own public IPs and nothing else may be deployed in these subnets. The workload's private
# endpoint, ops, AKS ILB and AKS node subnets are private (default_outbound_access_enabled = false there).
resource "azurerm_subnet" "hub" {
  for_each = local.hub_subnets

  name                 = each.key
  resource_group_name  = azurerm_resource_group.hub.name
  virtual_network_name = azurerm_virtual_network.hub.name
  address_prefixes     = [each.value]
}

# Private DNS zones (global) for every PaaS private endpoint of the workloads, owned by the platform.
resource "azurerm_private_dns_zone" "this" {
  for_each = local.private_dns_zone_names

  name                = each.value
  resource_group_name = azurerm_resource_group.hub.name
  tags                = local.platform_tags
}

# Hub link; each workload stack links its own spoke VNet to the same zones (those links also live in the hub RG).
resource "azurerm_private_dns_zone_virtual_network_link" "hub" {
  for_each = azurerm_private_dns_zone.this

  name                = "link-${local.names.hub_vnet}"
  private_dns_zone_id = each.value.id
  virtual_network_id  = azurerm_virtual_network.hub.id
  # [SEC] privatelink zones hold private endpoint records only; VMs must not auto-register.
  registration_enabled = false
  tags                 = local.platform_tags
}

# --- Azure Firewall (optional, required by egress_mode = firewall) ---------------------------------
resource "azurerm_public_ip" "firewall" {
  count = var.deploy_firewall ? 1 : 0

  name                = "pip-${local.names.firewall}"
  location            = var.location
  resource_group_name = azurerm_resource_group.hub.name
  allocation_method   = "Static"
  sku                 = "Standard"
  # [REL] Zone-redundant frontend, same zones as the firewall.
  zones = local.zones
  tags  = local.platform_tags
}

resource "azurerm_firewall_policy" "this" {
  count = var.deploy_firewall ? 1 : 0

  name                = local.names.firewall_policy
  location            = var.location
  resource_group_name = azurerm_resource_group.hub.name
  sku                 = "Standard"
  # [SEC] Log traffic to known-malicious IPs/FQDNs (switch to Deny once the allow-list is proven).
  threat_intelligence_mode = "Alert"
  tags                     = local.platform_tags
}

# [SEC] Default deny: only the platform dependencies of the spokes are allowed out.
resource "azurerm_firewall_policy_rule_collection_group" "egress" {
  count = var.deploy_firewall ? 1 : 0

  name               = "rcg-contoso-health-egress"
  firewall_policy_id = azurerm_firewall_policy.this[0].id
  priority           = 200

  # Network rules are evaluated before application rules.
  network_rule_collection {
    name     = "net-allow-azure-platform"
    priority = 100
    action   = "Allow"

    # Service tags: telemetry ingestion / live metrics and the token endpoints of managed and workload identities.
    rule {
      name                  = "azure-monitor-and-entra-id"
      protocols             = ["TCP"]
      source_addresses      = var.spoke_address_prefixes
      destination_addresses = ["AzureMonitor", "AzureActiveDirectory"]
      destination_ports     = ["443"]
    }

    # [REL] AKS nodes and VMs need time sync (token validation fails on clock skew).
    rule {
      name                  = "ntp"
      protocols             = ["UDP"]
      source_addresses      = var.spoke_address_prefixes
      destination_addresses = ["*"]
      destination_ports     = ["123"]
    }
  }

  application_rule_collection {
    name     = "app-allow-aks-and-dependencies"
    priority = 200
    action   = "Allow"

    # [OPS] Microsoft-maintained FQDN tag: every endpoint AKS nodes need (API server, MCR, packages, ...).
    rule {
      name                  = "aks-required-fqdns"
      source_addresses      = var.spoke_address_prefixes
      destination_fqdn_tags = ["AzureKubernetesService"]

      protocols {
        type = "Https"
        port = 443
      }

      protocols {
        type = "Http"
        port = 80
      }
    }

    rule {
      name              = "registries-identity-telemetry"
      source_addresses  = var.spoke_address_prefixes
      destination_fqdns = local.firewall_dependency_fqdns

      protocols {
        type = "Https"
        port = 443
      }
    }

    # Ops VM cloud-init: Ubuntu mirrors serve apt over plain HTTP (packages are GPG-signed).
    rule {
      name              = "ubuntu-packages"
      source_addresses  = var.spoke_address_prefixes
      destination_fqdns = ["*.ubuntu.com"]

      protocols {
        type = "Http"
        port = 80
      }

      protocols {
        type = "Https"
        port = 443
      }
    }
  }
}

resource "azurerm_firewall" "this" {
  count = var.deploy_firewall ? 1 : 0

  name                = local.names.firewall
  location            = var.location
  resource_group_name = azurerm_resource_group.hub.name
  sku_name            = "AZFW_VNet"
  sku_tier            = "Standard"
  firewall_policy_id  = azurerm_firewall_policy.this[0].id
  # [REL] Zone-redundant data path (Indonesia Central has 3 zones).
  zones = local.zones
  tags  = local.platform_tags

  ip_configuration {
    name                 = "ipconfig-public"
    subnet_id            = azurerm_subnet.hub["AzureFirewallSubnet"].id
    public_ip_address_id = azurerm_public_ip.firewall[0].id
  }

  # [REL] Create the rules before the firewall starts enforcing the policy (avoids concurrent policy updates).
  depends_on = [azurerm_firewall_policy_rule_collection_group.egress]
}

module "firewall_diagnostics" {
  source = "../modules/diagnostic_setting"
  count  = var.deploy_firewall ? 1 : 0

  target_resource_id         = azurerm_firewall.this[0].id
  log_analytics_workspace_id = azurerm_log_analytics_workspace.this.id
  # [OPS] Resource-specific tables (AZFWApplicationRule, AZFWNetworkRule, ...) are cheaper and faster to query.
  log_analytics_destination_type = "Dedicated"
}

# --- Azure Bastion (optional) -----------------------------------------------------------------------
resource "azurerm_public_ip" "bastion" {
  count = var.deploy_bastion ? 1 : 0

  name                = "pip-${local.names.bastion}"
  location            = var.location
  resource_group_name = azurerm_resource_group.hub.name
  # Bastion requires a Standard, static public IP.
  allocation_method = "Static"
  sku               = "Standard"
  tags              = local.platform_tags
}

# [COST] Basic covers portal SSH/RDP to peered VNets; Standard adds native client and IP-based connect.
resource "azurerm_bastion_host" "this" {
  count = var.deploy_bastion ? 1 : 0

  name                = local.names.bastion
  location            = var.location
  resource_group_name = azurerm_resource_group.hub.name
  sku                 = "Basic"
  tags                = local.platform_tags

  ip_configuration {
    name                 = "ipconfig-public"
    subnet_id            = azurerm_subnet.hub["AzureBastionSubnet"].id
    public_ip_address_id = azurerm_public_ip.bastion[0].id
  }
}

# -------------------------------------------------------------------------------------------------
# Security: Defender for Cloud plans and policy on the vended resource groups
# -------------------------------------------------------------------------------------------------

# [SEC] Subscription-wide plans (billed per protected resource), hence opt-in.
resource "azurerm_security_center_subscription_pricing" "this" {
  for_each = var.enable_defender_plans ? toset(local.defender_plans) : toset([])

  tier          = "Standard"
  resource_type = each.key
}

# Policy is assigned per vended resource group (never at subscription scope) so that other teams sharing the
# subscription are not affected.
resource "azurerm_resource_group_policy_assignment" "guardrails" {
  for_each = local.policy_assignments

  name                 = each.value.name
  display_name         = each.value.display_name
  resource_group_id    = azurerm_resource_group.vended[each.value.rg_key].id
  policy_definition_id = each.value.definition_id
  parameters           = each.value.parameters

  non_compliance_message {
    content = each.value.message
  }
}

# -------------------------------------------------------------------------------------------------
# RBAC vending: the workload team gets Contributor on its resource groups only
# -------------------------------------------------------------------------------------------------
resource "azurerm_role_assignment" "workload_team" {
  for_each = var.workload_team_principal_id == "" ? toset([]) : toset(keys(local.vended_rgs))

  scope              = azurerm_resource_group.vended[each.key].id
  role_definition_id = local.role_definition_ids.contributor
  principal_id       = var.workload_team_principal_id
  principal_type     = var.workload_team_principal_type
}
