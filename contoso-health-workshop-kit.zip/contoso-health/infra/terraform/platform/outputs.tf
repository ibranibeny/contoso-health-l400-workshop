# Output names are identical to the Bicep twin (camelCase on purpose).

output "hubVnetId" {
  description = "Resource ID of the hub VNet."
  value       = azurerm_virtual_network.hub.id
}

output "hubVnetName" {
  description = "Name of the hub VNet."
  value       = azurerm_virtual_network.hub.name
}

output "hubResourceGroupName" {
  description = "Name of the hub (connectivity) resource group."
  value       = azurerm_resource_group.hub.name
}

output "mgmtResourceGroupName" {
  description = "Name of the management resource group."
  value       = azurerm_resource_group.mgmt.name
}

output "logAnalyticsWorkspaceId" {
  description = "Resource ID of the Log Analytics workspace."
  value       = azurerm_log_analytics_workspace.this.id
}

output "privateDnsZoneIds" {
  description = "Private DNS zone resource IDs keyed by service (appService, postgres, redis, keyVault, acr)."
  value       = { for key, zone in azurerm_private_dns_zone.this : key => zone.id }
}

output "firewallPrivateIp" {
  description = "Private IP of the hub firewall, or empty when deploy_firewall is false."
  value       = try(azurerm_firewall.this[0].ip_configuration[0].private_ip_address, "")
}

output "vendedResourceGroupNames" {
  description = "Names of the vended workload and AKS resource groups."
  value       = concat([for e in var.environments : azurerm_resource_group.vended["${e}-workload"].name], [for e in var.environments : azurerm_resource_group.vended["${e}-aks"].name])
}
