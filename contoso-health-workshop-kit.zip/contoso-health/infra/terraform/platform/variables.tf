variable "subscription_id" {
  description = "Target subscription ID. Pass it with TF_VAR_subscription_id (CI: the AZURE_SUBSCRIPTION_ID repository variable)."
  type        = string

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id))
    error_message = "subscription_id must be a GUID."
  }
}

variable "env" {
  description = "Platform profile, used for the environment tag of the shared hub/management resources: lab (cost-aware) or prod."
  type        = string

  validation {
    condition     = contains(["lab", "prod"], var.env)
    error_message = "env must be lab or prod."
  }
}

variable "location" {
  description = "Region of every platform resource and vended resource group."
  type        = string
  default     = "indonesiacentral"
}

variable "environments" {
  description = "Workload environments to vend resource groups for: rg-ch-<env>-idc and rg-ch-aks-<env>-idc."
  type        = list(string)
  default     = ["lab"]

  validation {
    condition     = length(var.environments) > 0 && alltrue([for e in var.environments : contains(["lab", "prod"], e)])
    error_message = "environments must be a non-empty list containing only \"lab\" and/or \"prod\"."
  }
}

variable "allowed_locations" {
  description = "Regions allowed by the \"Allowed locations\" policy on the vended resource groups."
  type        = list(string)
  default     = ["indonesiacentral"]
}

variable "log_retention_in_days" {
  description = "Log Analytics interactive retention in days."
  type        = number
  default     = 30

  validation {
    condition     = var.log_retention_in_days >= 30 && var.log_retention_in_days <= 730
    error_message = "log_retention_in_days must be between 30 and 730."
  }
}

variable "deploy_firewall" {
  description = "Deploy Azure Firewall Standard (afw-ch-hub-idc) and its policy. Required by workloads that use egress_mode = firewall."
  type        = bool
  default     = false
}

variable "deploy_bastion" {
  description = "Deploy Azure Bastion Basic (bas-ch-hub-idc) for interactive SSH to the ops VMs."
  type        = bool
  default     = false
}

variable "deploy_ddos_plan" {
  description = "Deploy an Azure DDoS Network Protection plan (ddos-ch-hub-idc) for the hub. Expensive: see the cost note in main.tf."
  type        = bool
  default     = false
}

variable "enable_defender_plans" {
  description = "Enable Microsoft Defender for Cloud (Standard) for Containers, App Service, open-source relational databases, Key Vault and CSPM on the subscription."
  type        = bool
  default     = false
}

variable "workload_team_principal_id" {
  description = "Object ID of the workload team (Entra group recommended) that gets Contributor on every vended resource group. Empty = skip. Pass with TF_VAR_workload_team_principal_id."
  type        = string
  default     = ""

  validation {
    condition     = var.workload_team_principal_id == "" || can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.workload_team_principal_id))
    error_message = "workload_team_principal_id must be empty or an Entra object ID (GUID)."
  }
}

variable "workload_team_principal_type" {
  description = "Principal type of workload_team_principal_id: Group, User or ServicePrincipal."
  type        = string
  default     = "Group"

  validation {
    condition     = contains(["Group", "User", "ServicePrincipal"], var.workload_team_principal_type)
    error_message = "workload_team_principal_type must be Group, User or ServicePrincipal."
  }
}

variable "aks_privileged_container_policy_effects" {
  description = "Effect of \"Kubernetes cluster should not allow privileged containers\" per environment."
  type        = map(string)
  default = {
    lab  = "audit"
    prod = "deny"
  }

  validation {
    condition     = alltrue([for effect in values(var.aks_privileged_container_policy_effects) : contains(["audit", "deny", "disabled"], effect)])
    error_message = "Effects must be audit, deny or disabled."
  }
}

variable "spoke_address_prefixes" {
  description = "Spoke address spaces allowed to egress through the hub firewall (must match the workload address_prefix values)."
  type        = list(string)
  default     = ["10.110.0.0/20", "10.120.0.0/20"]
}
