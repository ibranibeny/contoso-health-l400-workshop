provider "azurerm" {
  features {}

  subscription_id = var.subscription_id
  # [SEC] Storage data-plane calls use Entra ID, never shared keys.
  storage_use_azuread = true
  # [OPS] AzureRM 5.x registers no resource providers by default (stated explicitly for readers):
  # scripts/preflight.sh registers the ones this kit needs before the first apply.
  resource_provider_registrations = "none"
}
