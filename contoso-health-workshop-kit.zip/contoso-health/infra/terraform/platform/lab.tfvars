# Platform - lab profile (cost-aware). subscription_id comes from TF_VAR_subscription_id, never from a file.
env          = "lab"
environments = ["lab"]

log_retention_in_days = 30

# lab workloads egress through a NAT gateway: no firewall, Bastion, DDoS plan or Defender plans.
deploy_firewall       = false
deploy_bastion        = false
deploy_ddos_plan      = false
enable_defender_plans = false
