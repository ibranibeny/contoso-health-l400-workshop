# Platform - production profile. subscription_id comes from TF_VAR_subscription_id, never from a file.
env = "prod"
# Superset: in a single shared subscription the lab spoke keeps its vended RGs when prod is added.
# In a dedicated production subscription use ["prod"].
environments = ["lab", "prod"]

log_retention_in_days = 90

# prod workloads use egress_mode = "firewall": the hub firewall is mandatory.
deploy_firewall       = true
deploy_bastion        = true
enable_defender_plans = true
# [COST] Off by default even in prod: see the cost note on azurerm_network_ddos_protection_plan.
deploy_ddos_plan = false
