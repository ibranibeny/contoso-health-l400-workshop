locals {
  # Built-in policy definitions assigned to the vended resource groups.
  # verify with az policy definition show --name <guid>
  policy_definition_ids = {
    allowed_locations = "e56962a6-4747-49cd-b67b-bf8b01975c4c" # Allowed locations (Deny)
    nic_no_public_ip  = "83a86a26-fd1f-447c-b59d-e51f44264114" # Network interfaces should not have public IPs (Deny)
    subnet_nsg        = "e71308d3-144b-4262-b144-efdc3cc90517" # Subnets should be associated with a Network Security Group (AuditIfNotExists)
    aks_no_privileged = "95edb821-ddaf-4404-9732-666045e056b4" # Kubernetes cluster should not allow privileged containers (effect parameter)
    appgw_waf_enabled = "564feb30-bf6a-4854-b4bb-0d2d2d1e6c66" # Web Application Firewall (WAF) should be enabled for Application Gateway (Audit)
    appgw_waf_mode    = "12430be1-6cc8-4527-a9a8-e3d38f250096" # Web Application Firewall (WAF) should use the specified mode for Application Gateway (Audit; modeRequirement)
    appgw_waf_bots    = "ebea0d86-7fbd-42e3-8a46-27e7568c2525" # Bot Protection should be enabled for Azure Application Gateway WAF (Audit)
    appgw_waf_body    = "ca85ef9a-741d-461d-8b7a-18c2da82c666" # Azure Web Application Firewall on Azure Application Gateway should have request body inspection enabled (Audit)
  }

  role_definition_ids = {
    contributor = "/subscriptions/${var.subscription_id}/providers/Microsoft.Authorization/roleDefinitions/b24988ac-6180-42a0-ab88-20f7382dd24c"
  }

  # The platform owns no globally-unique names, so no suffix is needed here (see the workload/aks locals).
  names = {
    hub_rg          = "rg-ch-hub-idc"
    mgmt_rg         = "rg-ch-mgmt-idc"
    hub_vnet        = "vnet-ch-hub-idc"
    law             = "log-ch-idc"
    firewall        = "afw-ch-hub-idc"
    firewall_policy = "afwp-ch-hub-idc"
    bastion         = "bas-ch-hub-idc"
    ddos_plan       = "ddos-ch-hub-idc"
  }

  # Hub address plan: 10.100.0.0/22 split into /26 blocks.
  hub_address_prefix = "10.100.0.0/22"
  hub_subnets = {
    AzureFirewallSubnet           = cidrsubnet(local.hub_address_prefix, 4, 0) # 10.100.0.0/26 (name and size required by Azure Firewall)
    AzureFirewallManagementSubnet = cidrsubnet(local.hub_address_prefix, 4, 1) # 10.100.0.64/26 (reserved for forced tunnelling)
    AzureBastionSubnet            = cidrsubnet(local.hub_address_prefix, 4, 2) # 10.100.0.128/26 (name and /26 minimum required by Bastion)
  }

  # Keys mirror the Bicep twin's privateDnsZoneIds output (appService, postgres, redis, keyVault, acr).
  private_dns_zone_names = {
    appService = "privatelink.azurewebsites.net"
    postgres   = "privatelink.postgres.database.azure.com"
    redis      = "privatelink.redis.azure.net"
    keyVault   = "privatelink.vaultcore.azure.net"
    acr        = "privatelink.azurecr.io"
  }

  zones = ["1", "2", "3"]

  defender_plans = ["Containers", "AppServices", "OpenSourceRelationalDatabases", "KeyVaults", "CloudPosture"]

  # Application rule FQDNs (besides the AzureKubernetesService FQDN tag and the Ubuntu mirrors).
  firewall_dependency_fqdns = [
    "*.azurecr.io",
    "*.data.mcr.microsoft.com",
    "mcr.microsoft.com",
    "login.microsoftonline.com",
    "*.in.applicationinsights.azure.com",
  ]

  base_tags = {
    workload   = "contoso-health"
    owner      = "platform-team"
    costCenter = "CH-1001"
    managedBy  = "terraform"
  }

  # Hub and management resources are shared platform assets: internal data classification.
  platform_tags = merge(local.base_tags, { environment = var.env, dataClassification = "internal" })

  # Vended resource groups hold workload (patient) data: confidential.
  vended_tags = { for e in var.environments : e => merge(local.base_tags, { environment = e, dataClassification = "confidential" }) }

  # Two vended resource groups per environment: the PaaS workload RG and the AKS RG.
  vended_rgs = merge([
    for e in var.environments : {
      "${e}-workload" = { name = "rg-ch-${e}-idc", env = e, kind = "workload" }
      "${e}-aks"      = { name = "rg-ch-aks-${e}-idc", env = e, kind = "aks" }
    }
  ]...)

  # Guardrails (same names as the Bicep twin): baseline on every vended RG, network/App Gateway policies on the
  # workload RG, the Kubernetes policy on the AKS RG. Deny/Audit effects only: no identity, no remediation.
  guardrails = {
    allowed_locations = {
      name         = "pa-ch-allowed-locations"
      display_name = "Contoso Health - Allowed locations"
      message      = "Contoso Health resources must be deployed to an approved region (Indonesia Central)."
      kinds        = ["workload", "aks"]
    }
    nic_no_public_ip = {
      name         = "pa-ch-nic-no-public-ip"
      display_name = "Contoso Health - Network interfaces should not have public IPs"
      message      = "Workload NICs stay private: use az vm run-command or Azure Bastion instead of public IPs."
      kinds        = ["workload", "aks"]
    }
    subnet_nsg = {
      name         = "pa-ch-subnet-nsg"
      display_name = "Contoso Health - Subnets should be associated with a Network Security Group"
      message      = "Every workload subnet needs its own NSG."
      kinds        = ["workload"]
    }
    appgw_waf_enabled = {
      name         = "pa-ch-appgw-waf"
      display_name = "Contoso Health - WAF should be enabled for Application Gateway"
      message      = "Internet-facing Application Gateways must run a WAF policy."
      kinds        = ["workload"]
    }
    appgw_waf_mode = {
      name         = "pa-ch-appgw-waf-mode"
      display_name = "Contoso Health - WAF should use Prevention mode for Application Gateway"
      message      = "Application Gateway WAF policies must run in Prevention mode; tune false positives with exclusions."
      kinds        = ["workload"]
    }
    appgw_waf_bots = {
      name         = "pa-ch-appgw-waf-bots"
      display_name = "Contoso Health - Bot Protection should be enabled for Application Gateway WAF"
      message      = "Application Gateway WAF policies must include the Microsoft_BotManagerRuleSet."
      kinds        = ["workload"]
    }
    appgw_waf_body = {
      name         = "pa-ch-appgw-waf-body"
      display_name = "Contoso Health - Application Gateway WAF should have request body inspection enabled"
      message      = "Application Gateway WAF policies must inspect request bodies (requestBodyCheck)."
      kinds        = ["workload"]
    }
    aks_no_privileged = {
      name         = "pa-ch-aks-no-privileged"
      display_name = "Contoso Health - Kubernetes cluster should not allow privileged containers"
      message      = "Privileged containers are not allowed in Contoso Health clusters."
      kinds        = ["aks"]
    }
  }

  policy_assignments = merge([
    for rg_key, rg in local.vended_rgs : {
      for policy_key, policy in local.guardrails : "${rg_key}-${policy_key}" => {
        rg_key        = rg_key
        name          = policy.name
        display_name  = policy.display_name
        message       = policy.message
        definition_id = "/providers/Microsoft.Authorization/policyDefinitions/${local.policy_definition_ids[policy_key]}"
        # ARM parameter values; null keeps the definition defaults (every App Gateway WAF definition defaults to Audit).
        parameters = (
          policy_key == "allowed_locations" ? jsonencode({ listOfAllowedLocations = { value = var.allowed_locations } }) :
          policy_key == "aks_no_privileged" ? jsonencode({ effect = { value = var.aks_privileged_container_policy_effects[rg.env] } }) :
          policy_key == "appgw_waf_mode" ? jsonencode({ modeRequirement = { value = "Prevention" } }) :
          null
        )
      } if contains(policy.kinds, rg.kind)
    }
  ]...)
}
