variable "subscription_id" {
  description = "Target subscription ID. Pass it with TF_VAR_subscription_id. Also seeds the globally-unique name suffix."
  type        = string

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id))
    error_message = "subscription_id must be a GUID."
  }
}

variable "env" {
  description = "Environment: lab or prod. Must match the workload stack deployed in rg-ch-<env>-idc."
  type        = string

  validation {
    condition     = contains(["lab", "prod"], var.env)
    error_message = "env must be lab or prod."
  }
}

variable "location" {
  description = "Azure region of the cluster, registry and Azure Monitor workspace."
  type        = string
  default     = "indonesiacentral"
}

variable "egress_mode" {
  description = "Egress of the workload spoke (same value as the workload stack): natGateway -> outboundType userAssignedNATGateway, firewall -> userDefinedRouting."
  type        = string
  default     = "natGateway"

  validation {
    condition     = contains(["natGateway", "firewall"], var.egress_mode)
    error_message = "egress_mode must be natGateway or firewall."
  }
}

variable "api_server_access" {
  description = "public (lab, optional authorized_ip_ranges) or private (prod: private cluster with API server VNet integration into snet-aks-apiserver)."
  type        = string
  default     = "public"

  validation {
    condition     = contains(["public", "private"], var.api_server_access)
    error_message = "api_server_access must be public or private."
  }
}

variable "authorized_ip_ranges" {
  description = "CIDRs allowed to reach a public API server (empty = unrestricted; GitHub-hosted runners need it open or listed)."
  type        = list(string)
  default     = []

  validation {
    condition     = alltrue([for cidr in var.authorized_ip_ranges : can(cidrhost(cidr, 0))])
    error_message = "authorized_ip_ranges must contain CIDR blocks, e.g. 203.0.113.0/24."
  }
}

variable "kubernetes_version" {
  description = "Kubernetes minor version alias (1.36 = current default; 1.34 is EOL end of Nov 2026)."
  type        = string
  default     = "1.36"

  validation {
    condition     = can(regex("^1\\.[0-9]+$", var.kubernetes_version))
    error_message = "kubernetes_version must be a minor version alias such as 1.36 (the patch channel picks the patch)."
  }
}

variable "system_node_vm_size" {
  description = "VM size of the system pool (also hosts the optional Gateway API Envoy proxies)."
  type        = string
  default     = "Standard_D4ds_v5"
}

variable "system_node_min_count" {
  description = "Autoscaler minimum of the system pool (3 = one node per zone)."
  type        = number
  default     = 3
}

variable "system_node_max_count" {
  description = "Autoscaler maximum of the system pool."
  type        = number
  default     = 5
}

variable "apps_node_vm_size" {
  description = "VM size of the apps (user) pool."
  type        = string
  default     = "Standard_D4ds_v5"
}

variable "apps_node_min_count" {
  description = "Autoscaler minimum of the apps pool (lab 2, prod 3)."
  type        = number
  default     = 2
}

variable "apps_node_max_count" {
  description = "Autoscaler maximum of the apps pool (lab 6, prod 10)."
  type        = number
  default     = 6
}

variable "acr_public_network_access_enabled" {
  description = "true in lab (GitHub-hosted runners push), false in prod (self-hosted/ARC runners in the VNet)."
  type        = bool
  default     = true
}

variable "enable_gateway_api" {
  description = "Enable the application routing Gateway API implementation (approuting-istio) through azapi_update_resource."
  type        = bool
  default     = false
}

variable "app_namespace" {
  description = "Kubernetes namespace of the application (scope of the deploy identity's AKS RBAC Writer role)."
  type        = string
  default     = "contoso-health"
}

variable "cluster_admin_object_ids" {
  description = "Entra object IDs (users or groups) granted Azure Kubernetes Service RBAC Cluster Admin + Cluster User Role. Per user: pass with TF_VAR_cluster_admin_object_ids='[\"<guid>\"]'."
  type        = list(string)
  default     = []

  validation {
    condition     = alltrue([for id in var.cluster_admin_object_ids : can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", id))])
    error_message = "cluster_admin_object_ids must contain Entra object IDs (GUIDs)."
  }
}

variable "cluster_admin_group_object_ids" {
  description = "Optional break-glass Entra GROUP object IDs bound to cluster-admin by AKS (aadProfile.adminGroupObjectIDs)."
  type        = list(string)
  default     = []
}

variable "deploy_principal_id" {
  description = "Object ID of the GitHub Actions deploy identity (AcrPush, AKS Cluster User, AKS RBAC Writer on the app namespace). Empty = skip. Pass with TF_VAR_deploy_principal_id."
  type        = string
  default     = ""

  validation {
    condition     = var.deploy_principal_id == "" || can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.deploy_principal_id))
    error_message = "deploy_principal_id must be empty or an Entra object ID (GUID)."
  }
}
