# AKS - lab. Per-user values come from TF_VAR_* environment variables:
# TF_VAR_subscription_id, TF_VAR_cluster_admin_object_ids, TF_VAR_deploy_principal_id.
env         = "lab"
egress_mode = "natGateway"

# Public API server (Entra-authenticated); list your egress CIDRs here to restrict it further.
api_server_access    = "public"
authorized_ip_ranges = []

kubernetes_version = "1.36"

apps_node_min_count = 2
apps_node_max_count = 6

# GitHub-hosted runners push images over the internet (Entra tokens, no admin user).
acr_public_network_access_enabled = true

enable_gateway_api = false
