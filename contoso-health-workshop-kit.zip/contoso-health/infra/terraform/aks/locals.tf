locals {
  # Same suffix rule as the workload stack: the registry name is globally unique.
  suffix = substr(sha1("${var.subscription_id}-ch-${var.env}"), 0, 6)

  private_cluster = var.api_server_access == "private"

  # [SEC] Egress is owned by the spoke: AKS uses the subnet's NAT gateway or its 0.0.0.0/0 route to the firewall.
  outbound_type = var.egress_mode == "natGateway" ? "userAssignedNATGateway" : "userDefinedRouting"

  names = {
    resource_group    = "rg-ch-aks-${var.env}-idc"
    node_rg           = "rg-ch-aks-${var.env}-idc-nodes"
    workload_rg       = "rg-ch-${var.env}-idc"
    hub_rg            = "rg-ch-hub-idc"
    mgmt_rg           = "rg-ch-mgmt-idc"
    log_analytics     = "log-ch-idc"
    spoke_vnet        = "vnet-ch-${var.env}-idc"
    aks_identity      = "id-ch-aks-${var.env}"
    aks               = "aks-ch-${var.env}-idc"
    dns_prefix        = "aks-ch-${var.env}"
    acr               = "crch${var.env}${local.suffix}"
    monitor_workspace = "amw-ch-${var.env}-idc"
  }

  # Workload resources consumed by name (created by the workload stack in rg-ch-<env>-idc).
  spoke_subnets = {
    nodes             = "snet-aks-nodes"
    api_server        = "snet-aks-apiserver"
    private_endpoints = "snet-private-endpoints"
  }

  # Existing workload identities that get a federated credential for their Kubernetes service account.
  workload_identities = {
    api = { name = "id-ch-api-${var.env}", service_account = "contoso-health-api" }
    web = { name = "id-ch-web-${var.env}", service_account = "contoso-health-web" }
  }

  # CNI Overlay ranges: never routed on the VNet, must not overlap any connected network.
  pod_cidr       = "192.168.0.0/16"
  service_cidr   = "172.16.0.0/16"
  dns_service_ip = cidrhost(local.service_cidr, 10) # 172.16.0.10

  role_definition_prefix = "/subscriptions/${var.subscription_id}/providers/Microsoft.Authorization/roleDefinitions"
  role_definition_ids = {
    network_contributor    = "${local.role_definition_prefix}/4d97b98b-1d4f-4787-a291-c67834d212e7"
    acr_pull               = "${local.role_definition_prefix}/7f951dda-4ed3-4680-a7ca-43fe172d538d"
    acr_push               = "${local.role_definition_prefix}/8311e382-0749-4cb8-b61a-304f252e45ec"
    aks_rbac_cluster_admin = "${local.role_definition_prefix}/b1ff04bb-8a4e-4dc4-8eb5-8693973ce19b"
    aks_rbac_writer        = "${local.role_definition_prefix}/a7ffa36f-339b-4b5c-8bdf-e2c188b2c0eb"
    aks_cluster_user       = "${local.role_definition_prefix}/4abbcc35-e782-43d8-92c5-2d3c1bd2b3ac"
  }

  tags = {
    workload           = "contoso-health"
    environment        = var.env
    owner              = "platform-team"
    costCenter         = "CH-1001"
    dataClassification = "confidential"
    managedBy          = "terraform"
  }
}
