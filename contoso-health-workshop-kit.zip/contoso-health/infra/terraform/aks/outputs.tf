# Output names are identical to the Bicep twin (camelCase on purpose).

output "aksName" {
  description = "Name of the AKS cluster."
  value       = module.aks.name
}

output "aksResourceGroup" {
  description = "Resource group of the AKS cluster."
  value       = data.azurerm_resource_group.aks.name
}

output "acrName" {
  description = "Name of the container registry."
  value       = module.acr.name
}

output "acrLoginServer" {
  description = "Login server of the container registry."
  value       = module.acr.login_server
}

output "oidcIssuerUrl" {
  description = "OIDC issuer URL of the cluster (federated credentials)."
  value       = module.aks.oidc_issuer_url
}

output "kubeletObjectId" {
  description = "Object ID of the kubelet identity (AcrPull)."
  value       = module.aks.kubelet_object_id
}

output "azureMonitorWorkspaceId" {
  description = "Resource ID of the Azure Monitor workspace (input of scripts/aks-postprovision.sh)."
  value       = azurerm_monitor_workspace.this.id
}

output "apiIdentityClientId" {
  description = "Client ID of id-ch-api-<env> (azure.workload.identity/client-id of the API service account)."
  value       = data.azurerm_user_assigned_identity.workload["api"].client_id
}

output "webIdentityClientId" {
  description = "Client ID of id-ch-web-<env> (azure.workload.identity/client-id of the web service account)."
  value       = data.azurerm_user_assigned_identity.workload["web"].client_id
}
