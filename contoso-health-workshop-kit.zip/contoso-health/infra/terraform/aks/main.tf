# AKS stack (resource-group scope, deployed INTO rg-ch-aks-<env>-idc vended by the platform). It consumes the
# workload stack by NAME (spoke VNet/subnets, identities) with data sources. Terraform twin of
# infra/bicep/aks/main.bicep. Managed Prometheus, Container insights and (by default) the Gateway API are enabled
# after provisioning by scripts/aks-postprovision.sh; IaC only creates the Azure Monitor workspace.

# -------------------------------------------------------------------------------------------------
# Lookups by deterministic name (no remote-state coupling between stacks)
# -------------------------------------------------------------------------------------------------
data "azurerm_client_config" "current" {}

data "azurerm_resource_group" "aks" {
  name = local.names.resource_group
}

data "azurerm_virtual_network" "spoke" {
  name                = local.names.spoke_vnet
  resource_group_name = local.names.workload_rg
}

data "azurerm_subnet" "spoke" {
  for_each = local.spoke_subnets

  name                 = each.value
  virtual_network_name = data.azurerm_virtual_network.spoke.name
  resource_group_name  = local.names.workload_rg
}

data "azurerm_log_analytics_workspace" "platform" {
  name                = local.names.log_analytics
  resource_group_name = local.names.mgmt_rg
}

data "azurerm_private_dns_zone" "acr" {
  name                = "privatelink.azurecr.io"
  resource_group_name = local.names.hub_rg
}

data "azurerm_user_assigned_identity" "workload" {
  for_each = local.workload_identities

  name                = each.value.name
  resource_group_name = local.names.workload_rg
}

# -------------------------------------------------------------------------------------------------
# Control-plane identity and its network permissions
# -------------------------------------------------------------------------------------------------
resource "azurerm_user_assigned_identity" "aks" {
  name                = local.names.aks_identity
  location            = var.location
  resource_group_name = data.azurerm_resource_group.aks.name
  tags                = local.tags
}

# [SEC] Least privilege: the control plane joins nodes to snet-aks-nodes, places internal load balancer IPs in
# snet-aks-ilb and (prod) the API server in snet-aks-apiserver - Network Contributor on the spoke VNet only.
resource "azurerm_role_assignment" "aks_network_contributor" {
  scope              = data.azurerm_virtual_network.spoke.id
  role_definition_id = local.role_definition_ids.network_contributor
  principal_id       = azurerm_user_assigned_identity.aks.principal_id
  principal_type     = "ServicePrincipal"
}

# -------------------------------------------------------------------------------------------------
# Container registry (Premium, private endpoint in the workload snet-private-endpoints)
# -------------------------------------------------------------------------------------------------
module "acr" {
  source = "../modules/acr"

  name                          = local.names.acr
  location                      = var.location
  resource_group_name           = data.azurerm_resource_group.aks.name
  public_network_access_enabled = var.acr_public_network_access_enabled
  private_endpoint_subnet_id    = data.azurerm_subnet.spoke["private_endpoints"].id
  private_dns_zone_id           = data.azurerm_private_dns_zone.acr.id
  log_analytics_workspace_id    = data.azurerm_log_analytics_workspace.platform.id
  tags                          = local.tags
}

# -------------------------------------------------------------------------------------------------
# AKS cluster (+ apps pool, maintenance windows, diagnostic settings)
# -------------------------------------------------------------------------------------------------
module "aks" {
  source = "../modules/aks_cluster"

  name                       = local.names.aks
  location                   = var.location
  resource_group_name        = data.azurerm_resource_group.aks.name
  dns_prefix                 = local.names.dns_prefix
  node_resource_group        = local.names.node_rg
  kubernetes_version         = var.kubernetes_version
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  identity_id                = azurerm_user_assigned_identity.aks.id
  admin_group_object_ids     = var.cluster_admin_group_object_ids
  nodes_subnet_id            = data.azurerm_subnet.spoke["nodes"].id
  private_cluster_enabled    = local.private_cluster
  api_server_subnet_id       = data.azurerm_subnet.spoke["api_server"].id
  authorized_ip_ranges       = var.authorized_ip_ranges
  outbound_type              = local.outbound_type
  pod_cidr                   = local.pod_cidr
  service_cidr               = local.service_cidr
  dns_service_ip             = local.dns_service_ip
  system_node_vm_size        = var.system_node_vm_size
  system_node_min_count      = var.system_node_min_count
  system_node_max_count      = var.system_node_max_count
  apps_node_vm_size          = var.apps_node_vm_size
  apps_node_min_count        = var.apps_node_min_count
  apps_node_max_count        = var.apps_node_max_count
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.platform.id
  tags                       = local.tags

  # [REL] The control plane must already hold Network Contributor on the spoke when the cluster is created.
  depends_on = [azurerm_role_assignment.aks_network_contributor]
}

# Optional Gateway API (application routing, gatewayClassName approuting-istio). AzureRM 5.x has no argument
# for ingressProfile.gatewayAPI / webAppRouting.gatewayAPIImplementations, so azapi patches just those
# properties (GET + merge + PUT) and reports drift on them. The Envoy proxies run on the system pool.
resource "azapi_update_resource" "gateway_api" {
  count = var.enable_gateway_api ? 1 : 0

  type        = "Microsoft.ContainerService/managedClusters@2026-08-01"
  resource_id = module.aks.id

  body = {
    properties = {
      ingressProfile = {
        gatewayAPI = {
          installation = "Standard"
        }
        webAppRouting = {
          gatewayAPIImplementations = {
            appRoutingIstio = {
              mode = "Enabled"
            }
          }
        }
      }
    }
  }

  # [REL] One cluster operation at a time: wait for the apps pool and the diagnostic setting.
  depends_on = [module.aks]
}

# -------------------------------------------------------------------------------------------------
# RBAC
# -------------------------------------------------------------------------------------------------
# [SEC] The AKS-managed kubelet identity pulls images with Entra tokens (no imagePullSecrets, no admin user).
resource "azurerm_role_assignment" "kubelet_acr_pull" {
  scope              = module.acr.id
  role_definition_id = local.role_definition_ids.acr_pull
  principal_id       = module.aks.kubelet_object_id
  principal_type     = "ServicePrincipal"
}

# Human administrators: Kubernetes cluster-admin through Azure RBAC + permission to download the Entra
# kubeconfig. principal_type is omitted because they can be users or groups.
resource "azurerm_role_assignment" "cluster_admin" {
  for_each = {
    for pair in setproduct(var.cluster_admin_object_ids, ["aks_rbac_cluster_admin", "aks_cluster_user"]) :
    "${pair[0]}-${pair[1]}" => { principal_id = pair[0], role = pair[1] }
  }

  scope              = module.aks.id
  role_definition_id = local.role_definition_ids[each.value.role]
  principal_id       = each.value.principal_id
}

# GitHub Actions deploy identity (optional): push images, download the kubeconfig, and read/write workloads in
# the application namespace only (Azure RBAC scope <cluster id>/namespaces/<name>).
resource "azurerm_role_assignment" "deploy" {
  for_each = {
    for key, assignment in {
      acr_push = { scope = module.acr.id, role = "acr_push" }
      aks_user = { scope = module.aks.id, role = "aks_cluster_user" }
      ns_write = { scope = "${module.aks.id}/namespaces/${var.app_namespace}", role = "aks_rbac_writer" }
    } : key => assignment if var.deploy_principal_id != ""
  }

  scope              = each.value.scope
  role_definition_id = local.role_definition_ids[each.value.role]
  principal_id       = var.deploy_principal_id
  principal_type     = "ServicePrincipal"
}

# -------------------------------------------------------------------------------------------------
# Workload identity federation on the EXISTING workload identities (they live in the workload RG)
# -------------------------------------------------------------------------------------------------
resource "azurerm_federated_identity_credential" "workload" {
  for_each = local.workload_identities

  name                      = "fic-${local.names.aks}-${each.key}"
  user_assigned_identity_id = data.azurerm_user_assigned_identity.workload[each.key].id
  audience                  = ["api://AzureADTokenExchange"]
  issuer                    = module.aks.oidc_issuer_url
  # [SEC] Exact subject, no wildcards: only this service account can use the identity.
  subject = "system:serviceaccount:${var.app_namespace}:${each.value.service_account}"
}

# -------------------------------------------------------------------------------------------------
# Azure Monitor workspace (Managed Prometheus) - wired to the cluster by scripts/aks-postprovision.sh
# -------------------------------------------------------------------------------------------------
resource "azurerm_monitor_workspace" "this" {
  name                = local.names.monitor_workspace
  location            = var.location
  resource_group_name = data.azurerm_resource_group.aks.name
  tags                = local.tags
}
