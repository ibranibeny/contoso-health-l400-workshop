# AKS - production profile. Per-user values come from TF_VAR_* environment variables:
# TF_VAR_subscription_id, TF_VAR_cluster_admin_object_ids, TF_VAR_deploy_principal_id.
# Requires a self-hosted runner inside the VNet (private API server, private registry).
env         = "prod"
egress_mode = "firewall"

# Private cluster with API server VNet integration into snet-aks-apiserver.
api_server_access = "private"

kubernetes_version = "1.36"

apps_node_min_count = 3
apps_node_max_count = 10

acr_public_network_access_enabled = false

enable_gateway_api = false
