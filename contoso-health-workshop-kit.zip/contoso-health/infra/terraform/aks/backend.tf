terraform {
  # Partial configuration: storage account, container and key come from backend-<env>.hcl
  # (terraform init -backend-config=backend-lab.hcl). scripts/bootstrap-tfstate.sh creates the storage.
  # In CI set ARM_USE_OIDC=true (+ ARM_CLIENT_ID, ARM_TENANT_ID, ARM_SUBSCRIPTION_ID) so the backend signs in
  # with the GitHub OIDC token: no storage keys, SAS tokens or client secrets anywhere.
  backend "azurerm" {
    # [SEC] Blob access with Entra ID (Storage Blob Data Contributor on the container), not account keys.
    use_azuread_auth = true
  }
}
