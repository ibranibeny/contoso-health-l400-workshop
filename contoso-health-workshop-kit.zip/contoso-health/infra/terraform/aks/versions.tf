terraform {
  required_version = ">= 1.9"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 5.14"
    }
    # Only for the optional Gateway API settings, which AzureRM 5.x does not expose (see main.tf).
    azapi = {
      source  = "Azure/azapi"
      version = "~> 2.13"
    }
  }
}
