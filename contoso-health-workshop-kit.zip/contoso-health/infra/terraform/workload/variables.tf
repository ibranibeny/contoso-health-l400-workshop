variable "subscription_id" {
  description = "Target subscription ID. Pass it with TF_VAR_subscription_id. Also seeds the globally-unique name suffix."
  type        = string

  validation {
    condition     = can(regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", var.subscription_id))
    error_message = "subscription_id must be a GUID."
  }
}

variable "env" {
  description = "Environment: lab (cost-aware, same topology) or prod (production profile)."
  type        = string

  validation {
    condition     = contains(["lab", "prod"], var.env)
    error_message = "env must be lab or prod."
  }
}

variable "location" {
  description = "Azure region of every workload resource."
  type        = string
  default     = "indonesiacentral"
}

variable "address_prefix" {
  description = "Spoke VNet address space, a /20 (lab 10.110.0.0/20, prod 10.120.0.0/20); every subnet is derived from it."
  type        = string

  validation {
    condition     = can(cidrhost(var.address_prefix, 0)) && endswith(var.address_prefix, "/20")
    error_message = "address_prefix must be an IPv4 /20 CIDR, e.g. 10.110.0.0/20."
  }
}

variable "egress_mode" {
  description = "Explicit egress of snet-app-integration, snet-ops and snet-aks-nodes: natGateway (lab) or firewall (prod, requires the platform firewall)."
  type        = string
  default     = "natGateway"

  validation {
    condition     = contains(["natGateway", "firewall"], var.egress_mode)
    error_message = "egress_mode must be natGateway or firewall."
  }
}

variable "ddos_protection_enabled" {
  description = "Associate the spoke with the platform DDoS plan (ddos-ch-hub-idc, platform deploy_ddos_plan = true) to protect the App Gateway public IP."
  type        = bool
  default     = false
}

variable "app_service_sku" {
  description = "Premium v4 App Service plan SKU: P0v4 (lab) or P1v4 (prod)."
  type        = string
  default     = "P0v4"

  validation {
    condition     = can(regex("^P[0-9]m?v4$", var.app_service_sku))
    error_message = "app_service_sku must be a Premium v4 SKU (zone redundancy), e.g. P0v4 or P1v4."
  }
}

variable "app_service_capacity" {
  description = "Instance count of the zone-redundant plan (lab 2, prod 3)."
  type        = number
  default     = 2

  validation {
    condition     = var.app_service_capacity >= 2
    error_message = "Zone redundancy and health-check based replacement need at least 2 instances."
  }
}

variable "scm_ip_restriction_default_action" {
  description = "Default action of the SCM (deployment) site: Allow in lab (GitHub-hosted runners), Deny in prod (self-hosted runner in the VNet)."
  type        = string
  default     = "Allow"

  validation {
    condition     = contains(["Allow", "Deny"], var.scm_ip_restriction_default_action)
    error_message = "scm_ip_restriction_default_action must be Allow or Deny."
  }
}

variable "seed_on_start" {
  description = "SEED_ON_START app setting: load demo data at startup (lab true, prod false)."
  type        = bool
  default     = true
}

variable "ops_api_enabled" {
  description = "OPS_API_ENABLED app setting: expose the workshop ops endpoints (lab true, prod false)."
  type        = bool
  default     = true
}

variable "app_insights_local_auth_enabled" {
  description = "Allow instrumentation-key ingestion in Application Insights (lab true). false (prod) = Entra ID only, APPLICATIONINSIGHTS_AUTH=entra."
  type        = bool
  default     = true
}

variable "postgres_version" {
  description = "PostgreSQL major version (17 is the default; 18 is also GA)."
  type        = string
  default     = "17"
}

variable "postgres_sku_name" {
  description = "PostgreSQL compute SKU: B_Standard_B1ms (lab) or GP_Standard_D2ds_v5 (prod)."
  type        = string
  default     = "B_Standard_B1ms"
}

variable "postgres_storage_mb" {
  description = "PostgreSQL storage in MB."
  type        = number
  default     = 32768
}

variable "postgres_backup_retention_days" {
  description = "PostgreSQL point-in-time restore window in days (7-35)."
  type        = number
  default     = 7

  validation {
    condition     = var.postgres_backup_retention_days >= 7 && var.postgres_backup_retention_days <= 35
    error_message = "postgres_backup_retention_days must be between 7 and 35."
  }
}

variable "postgres_high_availability" {
  description = "Zone-redundant HA (primary zone 1, standby zone 2). Not available on Burstable SKUs."
  type        = bool
  default     = false

  validation {
    condition     = !var.postgres_high_availability || !startswith(var.postgres_sku_name, "B_")
    error_message = "Zone-redundant HA requires a GeneralPurpose (GP_) or MemoryOptimized (MO_) SKU."
  }
}

variable "redis_sku_name" {
  description = "Azure Managed Redis SKU: Balanced_B0 in lab and prod (smallest Balanced size, 0.5 GB); raise it to Balanced_B1 or larger when memory or server load grows."
  type        = string
  default     = "Balanced_B0"
}

variable "app_gateway_min_capacity" {
  description = "Application Gateway autoscale minimum (lab 1, prod 2)."
  type        = number
  default     = 1
}

variable "app_gateway_max_capacity" {
  description = "Application Gateway autoscale maximum."
  type        = number
  default     = 10
}

variable "waf_mode" {
  description = "WAF policy mode: Prevention (blocks) or Detection (logs only). Prevention in lab and prod; tune false positives with exclusions."
  type        = string
  default     = "Prevention"

  validation {
    condition     = contains(["Prevention", "Detection"], var.waf_mode)
    error_message = "waf_mode must be Prevention or Detection."
  }
}

variable "waf_claims_rate_limit_per_minute" {
  description = "WAF custom rule RateLimitClaimSubmissions: POST requests to /api/claims allowed per client IP and minute (lab 60, prod 300)."
  type        = number
  default     = 60

  validation {
    condition     = var.waf_claims_rate_limit_per_minute >= 1 && floor(var.waf_claims_rate_limit_per_minute) == var.waf_claims_rate_limit_per_minute
    error_message = "waf_claims_rate_limit_per_minute must be a whole number of at least 1."
  }
}

variable "waf_block_ops_api" {
  description = "WAF custom rule BlockOpsApiFromInternet: block /api/ops/* at the edge (lab false, prod true)."
  type        = bool
  default     = false
}

variable "waf_allowed_country_codes" {
  description = "WAF custom rule LogOutsideAllowedCountries: ISO 3166-1 alpha-2 country codes the traffic is expected from; other countries are logged, not blocked."
  type        = list(string)
  default     = ["ID"]

  validation {
    condition     = length(var.waf_allowed_country_codes) > 0
    error_message = "waf_allowed_country_codes needs at least one country code."
  }
}

variable "aks_ingress_private_ip" {
  description = "Static private IP of the AKS internal LoadBalancer Service \"web\" inside snet-aks-ilb (lab 10.110.3.70). Empty = 7th address of snet-aks-ilb."
  type        = string
  default     = ""

  validation {
    condition     = var.aks_ingress_private_ip == "" || can(cidrhost("${var.aks_ingress_private_ip}/32", 0))
    error_message = "aks_ingress_private_ip must be empty or an IPv4 address."
  }
}

variable "tls_certificate_secret_id" {
  description = "Versionless Key Vault secret ID of the App Gateway TLS certificate. Empty = HTTP listeners only (lab only)."
  type        = string
  default     = ""

  validation {
    condition     = var.tls_certificate_secret_id == "" || startswith(var.tls_certificate_secret_id, "https://")
    error_message = "tls_certificate_secret_id must be empty or a Key Vault secret URI (https://...)."
  }
}

variable "ops_vm_size" {
  description = "Size of the ops (bootstrap / troubleshooting) VM."
  type        = string
  default     = "Standard_B2s"
}

variable "ops_ssh_public_key" {
  description = "OpenSSH public key (ssh-ed25519 or ssh-rsa) of the ops VM admin. Per user: pass with TF_VAR_ops_ssh_public_key. Empty = no ops VM."
  type        = string
  default     = ""

  validation {
    # Azure (and the AzureRM admin_ssh_key validation) accept only Ed25519 and RSA >= 2048-bit keys, not ECDSA.
    condition     = var.ops_ssh_public_key == "" || can(regex("^(ssh-ed25519|ssh-rsa) ", var.ops_ssh_public_key))
    error_message = "ops_ssh_public_key must be empty or an OpenSSH ssh-ed25519 / ssh-rsa (>= 2048 bit) public key; Azure does not support ECDSA keys."
  }
}

variable "alert_email" {
  description = "E-mail receiver of the action group. Per user: pass with TF_VAR_alert_email. Empty = action group without receivers."
  type        = string
  default     = ""

  validation {
    condition     = var.alert_email == "" || can(regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$", var.alert_email))
    error_message = "alert_email must be empty or an e-mail address."
  }
}
