# Workload - production profile. Requires the platform with deploy_firewall = true (egress_mode = firewall).
# Per-user values come from TF_VAR_* environment variables: TF_VAR_subscription_id, TF_VAR_ops_ssh_public_key,
# TF_VAR_alert_email (and set TF_VAR_tls_certificate_secret_id to serve HTTPS).
env            = "prod"
address_prefix = "10.120.0.0/20"
egress_mode    = "firewall"

app_service_sku      = "P1v4"
app_service_capacity = 3
# SCM site closed to the internet: deploy from a self-hosted runner inside the VNet.
scm_ip_restriction_default_action = "Deny"
seed_on_start                     = false
ops_api_enabled                   = false
app_insights_local_auth_enabled   = false

postgres_sku_name              = "GP_Standard_D2ds_v5"
postgres_high_availability     = true
postgres_backup_retention_days = 35

# [COST] Azure Managed Redis Balanced_B0 in every environment: the smallest Balanced size (0.5 GB), still zone-redundant with HA.
# [PERF] Watch used memory and server load; move to Balanced_B1 or larger before they become the bottleneck.
redis_sku_name = "Balanced_B0"

app_gateway_min_capacity = 2
aks_ingress_private_ip   = "10.120.3.70"

# [SEC] WAF in Prevention in every environment. [REL] Many members can share one public IP (carrier-grade NAT), so the
# per-IP claims limit is higher than in lab. [SEC] The API already refuses /api/ops/* in prod (ops_api_enabled = false);
# the WAF also stops it at the edge.
waf_mode                         = "Prevention"
waf_claims_rate_limit_per_minute = 300
waf_block_ops_api                = true
waf_allowed_country_codes        = ["ID"]
