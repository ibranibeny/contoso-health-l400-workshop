# Workload stack (resource-group scope, deployed INTO rg-ch-<env>-idc vended by the platform): the application
# landing zone (spoke network, egress, DNS, peering) and the PaaS application (App Service, PostgreSQL, Managed
# Redis, Key Vault, App Gateway WAF_v2, ops VM, monitoring). Terraform twin of infra/bicep/workload/main.bicep.

# -------------------------------------------------------------------------------------------------
# Platform lookups by deterministic name (no remote-state coupling between stacks)
# -------------------------------------------------------------------------------------------------
data "azurerm_client_config" "current" {}

data "azurerm_resource_group" "workload" {
  name = local.names.resource_group
}

data "azurerm_virtual_network" "hub" {
  name                = local.names.hub_vnet
  resource_group_name = local.names.hub_rg
}

data "azurerm_subnet" "hub_bastion" {
  name                 = "AzureBastionSubnet"
  virtual_network_name = local.names.hub_vnet
  resource_group_name  = local.names.hub_rg
}

data "azurerm_log_analytics_workspace" "platform" {
  name                = local.names.log_analytics
  resource_group_name = local.names.mgmt_rg
}

data "azurerm_private_dns_zone" "hub" {
  for_each = local.private_dns_zones

  name                = each.value
  resource_group_name = local.names.hub_rg
}

# Only in firewall mode: the platform must have been applied with deploy_firewall = true.
data "azurerm_firewall" "hub" {
  count = var.egress_mode == "firewall" ? 1 : 0

  name                = local.names.firewall
  resource_group_name = local.names.hub_rg
}

data "azurerm_network_ddos_protection_plan" "hub" {
  count = var.ddos_protection_enabled ? 1 : 0

  name                = local.names.ddos_plan
  resource_group_name = local.names.hub_rg
}

# -------------------------------------------------------------------------------------------------
# Spoke network
# -------------------------------------------------------------------------------------------------
resource "azurerm_virtual_network" "spoke" {
  name                = local.names.vnet
  location            = var.location
  resource_group_name = data.azurerm_resource_group.workload.name
  address_space       = [var.address_prefix]
  tags                = local.tags

  # [SEC] Protects the App Gateway public IP when the platform DDoS plan exists.
  dynamic "ddos_protection_plan" {
    for_each = data.azurerm_network_ddos_protection_plan.hub
    content {
      id     = ddos_protection_plan.value.id
      enable = true
    }
  }
}

resource "azurerm_subnet" "this" {
  for_each = local.subnets

  name                 = each.key
  resource_group_name  = data.azurerm_resource_group.workload.name
  virtual_network_name = azurerm_virtual_network.spoke.name
  address_prefixes     = [each.value.address_prefix]
  # [SEC] Private subnets get no default outbound access: egress must be explicit (NAT gateway or firewall).
  # null keeps the provider default on the App Gateway subnet and on the delegated subnets (see local.subnets).
  default_outbound_access_enabled   = each.value.private ? false : null
  private_endpoint_network_policies = each.value.pe_policies

  dynamic "delegation" {
    for_each = each.value.delegation == "" ? [] : [each.value.delegation]
    content {
      name = "delegation"

      service_delegation {
        name    = delegation.value
        actions = each.value.delegation_actions
      }
    }
  }
}

# [SEC] One NSG per subnet (policy "Subnets should be associated with a Network Security Group"); custom rules
# only where needed (local.nsg_rules), the Azure default rules everywhere else.
resource "azurerm_network_security_group" "this" {
  for_each = local.subnets

  name                = "nsg-${each.key}"
  location            = var.location
  resource_group_name = data.azurerm_resource_group.workload.name
  tags                = local.tags

  dynamic "security_rule" {
    for_each = [for rule in local.nsg_rules : rule if rule.subnet == each.key]
    content {
      name                       = security_rule.value.name
      description                = security_rule.value.description
      priority                   = security_rule.value.priority
      direction                  = "Inbound"
      access                     = security_rule.value.access
      protocol                   = security_rule.value.protocol
      source_port_range          = "*"
      source_address_prefix      = security_rule.value.source
      destination_address_prefix = "*"
      destination_port_range     = length(security_rule.value.ports) == 1 ? security_rule.value.ports[0] : null
      destination_port_ranges    = length(security_rule.value.ports) > 1 ? security_rule.value.ports : null
    }
  }
}

resource "azurerm_subnet_network_security_group_association" "this" {
  for_each = local.subnets

  subnet_id                 = azurerm_subnet.this[each.key].id
  network_security_group_id = azurerm_network_security_group.this[each.key].id
}

# Spoke -> hub peering.
resource "azurerm_virtual_network_peering" "spoke_to_hub" {
  name                         = "peer-${azurerm_virtual_network.spoke.name}-to-${data.azurerm_virtual_network.hub.name}"
  resource_group_name          = data.azurerm_resource_group.workload.name
  virtual_network_name         = azurerm_virtual_network.spoke.name
  remote_virtual_network_id    = data.azurerm_virtual_network.hub.id
  allow_virtual_network_access = true
  # [SEC] Accept the return traffic that the hub firewall forwards.
  allow_forwarded_traffic = true
  allow_gateway_transit   = false
  # No VPN/ExpressRoute gateway in this mini landing zone.
  use_remote_gateways = false
}

# Hub -> spoke peering, created in the hub RG (the hub VNet itself is owned by the platform stack).
resource "azurerm_virtual_network_peering" "hub_to_spoke" {
  name                         = "peer-${data.azurerm_virtual_network.hub.name}-to-${azurerm_virtual_network.spoke.name}"
  resource_group_name          = data.azurerm_virtual_network.hub.resource_group_name
  virtual_network_name         = data.azurerm_virtual_network.hub.name
  remote_virtual_network_id    = azurerm_virtual_network.spoke.id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  allow_gateway_transit        = false
  use_remote_gateways          = false
}

# Links every hub private DNS zone to the spoke; AzureRM 5.x derives the zone's resource group (the hub RG)
# from private_dns_zone_id, so the links live next to the zones.
resource "azurerm_private_dns_zone_virtual_network_link" "spoke" {
  for_each = data.azurerm_private_dns_zone.hub

  name                = "link-${azurerm_virtual_network.spoke.name}"
  private_dns_zone_id = each.value.id
  virtual_network_id  = azurerm_virtual_network.spoke.id
  # [SEC] privatelink zones hold private endpoint records only; VMs must not auto-register.
  registration_enabled = false
  tags                 = local.tags
}

# --- Explicit egress: NAT gateway (lab) --------------------------------------------------------------
# [COST] One NAT gateway (no hourly firewall cost) with a static, allow-listable public IP.
# [REL] A Standard NAT gateway is zonal/regional, not zone-redundant: acceptable for lab, prod uses the firewall.
resource "azurerm_public_ip" "nat_gateway" {
  count = var.egress_mode == "natGateway" ? 1 : 0

  name                = "pip-${local.names.nat_gateway}"
  location            = var.location
  resource_group_name = data.azurerm_resource_group.workload.name
  allocation_method   = "Static"
  sku                 = "Standard"
  tags                = local.tags
}

resource "azurerm_nat_gateway" "this" {
  count = var.egress_mode == "natGateway" ? 1 : 0

  name                    = local.names.nat_gateway
  location                = var.location
  resource_group_name     = data.azurerm_resource_group.workload.name
  sku_name                = "Standard"
  idle_timeout_in_minutes = 4
  tags                    = local.tags
}

resource "azurerm_nat_gateway_public_ip_association" "this" {
  count = var.egress_mode == "natGateway" ? 1 : 0

  nat_gateway_id       = azurerm_nat_gateway.this[0].id
  public_ip_address_id = azurerm_public_ip.nat_gateway[0].id
}

# [REL] AKS outbound_type userAssignedNATGateway requires this association on snet-aks-nodes BEFORE the cluster is
# created: the aks stack is applied after this stack.
resource "azurerm_subnet_nat_gateway_association" "egress" {
  for_each = var.egress_mode == "natGateway" ? toset(local.egress_subnet_names) : toset([])

  subnet_id      = azurerm_subnet.this[each.key].id
  nat_gateway_id = azurerm_nat_gateway.this[0].id
}

# --- Explicit egress: hub Azure Firewall (prod) ----------------------------------------------------
# [SEC] Every internet-bound packet goes through the hub firewall allow-list.
resource "azurerm_route_table" "egress" {
  count = var.egress_mode == "firewall" ? 1 : 0

  name                = local.names.route_table
  location            = var.location
  resource_group_name = data.azurerm_resource_group.workload.name
  # [SEC] No gateway-learned route may bypass the firewall.
  bgp_route_propagation_enabled = false
  tags                          = local.tags

  route {
    name                   = "default-via-hub-firewall"
    address_prefix         = "0.0.0.0/0"
    next_hop_type          = "VirtualAppliance"
    next_hop_in_ip_address = data.azurerm_firewall.hub[0].ip_configuration[0].private_ip_address
  }
}

resource "azurerm_subnet_route_table_association" "egress" {
  for_each = var.egress_mode == "firewall" ? toset(local.egress_subnet_names) : toset([])

  subnet_id      = azurerm_subnet.this[each.key].id
  route_table_id = azurerm_route_table.egress[0].id
}

# [REL] Barrier: everything placed in a subnet waits until the subnet's NSG / NAT gateway / route table
# associations, the peerings and the DNS links exist (no concurrent subnet updates, working egress and name
# resolution from the first boot).
resource "terraform_data" "network_ready" {
  depends_on = [
    azurerm_subnet_network_security_group_association.this,
    azurerm_subnet_nat_gateway_association.egress,
    azurerm_subnet_route_table_association.egress,
    azurerm_nat_gateway_public_ip_association.this,
    azurerm_virtual_network_peering.spoke_to_hub,
    azurerm_virtual_network_peering.hub_to_spoke,
    azurerm_private_dns_zone_virtual_network_link.spoke,
  ]
}

# -------------------------------------------------------------------------------------------------
# Identities and monitoring
# -------------------------------------------------------------------------------------------------
# [SEC] One user-assigned identity per caller: api, web, dbadmin (PostgreSQL Entra admin + ops VM), agw.
resource "azurerm_user_assigned_identity" "this" {
  for_each = local.identities

  name                = each.value
  location            = var.location
  resource_group_name = data.azurerm_resource_group.workload.name
  tags                = local.tags
}

# Workspace-based Application Insights: telemetry lands in the platform Log Analytics workspace.
resource "azurerm_application_insights" "this" {
  name                = local.names.app_insights
  location            = var.location
  resource_group_name = data.azurerm_resource_group.workload.name
  workspace_id        = data.azurerm_log_analytics_workspace.platform.id
  application_type    = "web"
  # [SEC] prod rejects key-only ingestion (the apps send with their managed identity); lab keeps key ingestion.
  local_authentication_enabled = var.app_insights_local_auth_enabled
  tags                         = local.tags
}

# -------------------------------------------------------------------------------------------------
# Key Vault (RBAC mode, private endpoint only)
# -------------------------------------------------------------------------------------------------
module "key_vault" {
  source = "../modules/key_vault"

  name                       = local.names.key_vault
  location                   = var.location
  resource_group_name        = data.azurerm_resource_group.workload.name
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  private_endpoint_subnet_id = azurerm_subnet.this["snet-private-endpoints"].id
  private_dns_zone_id        = data.azurerm_private_dns_zone.hub["keyVault"].id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.platform.id
  tags                       = local.tags

  depends_on = [terraform_data.network_ready]
}

# -------------------------------------------------------------------------------------------------
# App Service: zone-redundant Linux plan + web and API apps (Node 24 LTS)
# -------------------------------------------------------------------------------------------------
resource "azurerm_service_plan" "this" {
  name                = local.names.app_service_plan
  location            = var.location
  resource_group_name = data.azurerm_resource_group.workload.name
  os_type             = "Linux"
  # [COST] Premium v4 is the smallest tier with availability zones in Indonesia Central (P0v4 lab, P1v4 prod).
  sku_name = var.app_service_sku
  # [REL] Instances spread across availability zones (needs >= 2 instances). Learn allows toggling zone redundancy on an
  # existing plan only when its scale unit supports zones; read the plan output to see whether a change updates or replaces it.
  zone_balancing_enabled = true
  worker_count           = var.app_service_capacity
  tags                   = local.tags
}

module "api_app" {
  source = "../modules/app_service_app"

  name                              = local.names.api_app
  location                          = var.location
  resource_group_name               = data.azurerm_resource_group.workload.name
  service_plan_id                   = azurerm_service_plan.this.id
  identity_id                       = azurerm_user_assigned_identity.this["api"].id
  app_command_line                  = "node --import ./src/telemetry.js src/index.js"
  scm_ip_restriction_default_action = var.scm_ip_restriction_default_action
  virtual_network_subnet_id         = azurerm_subnet.this["snet-app-integration"].id
  private_endpoint_subnet_id        = azurerm_subnet.this["snet-private-endpoints"].id
  private_dns_zone_id               = data.azurerm_private_dns_zone.hub["appService"].id
  log_analytics_workspace_id        = data.azurerm_log_analytics_workspace.platform.id
  tags                              = local.tags

  # Exactly the settings read by app/api/src/config.js and telemetry.js. No secrets: PostgreSQL and Redis use
  # Entra tokens of the API identity (PGUSER = identity NAME, AZURE_CLIENT_ID = its client ID).
  app_settings = {
    STORAGE_MODE                          = "postgres"
    CACHE_MODE                            = "redis"
    PGHOST                                = module.postgres.fqdn
    PGPORT                                = "5432"
    PGDATABASE                            = "contoso_health"
    PGUSER                                = azurerm_user_assigned_identity.this["api"].name
    PGSCHEMA                              = "app"
    PG_AUTH                               = "entra"
    PGSSL                                 = "true"
    REDIS_HOST                            = module.redis.hostname
    REDIS_PORT                            = "10000"
    REDIS_TLS                             = "true"
    REDIS_AUTH                            = "entra"
    AZURE_CLIENT_ID                       = azurerm_user_assigned_identity.this["api"].client_id
    AZURE_REGION                          = var.location
    MIGRATE_ON_START                      = "true"
    SEED_ON_START                         = tostring(var.seed_on_start)
    OPS_API_ENABLED                       = tostring(var.ops_api_enabled)
    APPLICATIONINSIGHTS_CONNECTION_STRING = azurerm_application_insights.this.connection_string
    APPLICATIONINSIGHTS_AUTH              = var.app_insights_local_auth_enabled ? "" : "entra"
    SCM_DO_BUILD_DURING_DEPLOYMENT        = "false"
  }

  depends_on = [terraform_data.network_ready]
}

module "web_app" {
  source = "../modules/app_service_app"

  name                              = local.names.web_app
  location                          = var.location
  resource_group_name               = data.azurerm_resource_group.workload.name
  service_plan_id                   = azurerm_service_plan.this.id
  identity_id                       = azurerm_user_assigned_identity.this["web"].id
  app_command_line                  = "node server.js"
  scm_ip_restriction_default_action = var.scm_ip_restriction_default_action
  virtual_network_subnet_id         = azurerm_subnet.this["snet-app-integration"].id
  private_endpoint_subnet_id        = azurerm_subnet.this["snet-private-endpoints"].id
  private_dns_zone_id               = data.azurerm_private_dns_zone.hub["appService"].id
  log_analytics_workspace_id        = data.azurerm_log_analytics_workspace.platform.id
  tags                              = local.tags

  # The web tier calls the API through the API's private endpoint (VNet integration + private DNS).
  app_settings = {
    API_BASE_URL                          = "https://${module.api_app.default_hostname}"
    AZURE_CLIENT_ID                       = azurerm_user_assigned_identity.this["web"].client_id
    APPLICATIONINSIGHTS_CONNECTION_STRING = azurerm_application_insights.this.connection_string
    APPLICATIONINSIGHTS_AUTH              = var.app_insights_local_auth_enabled ? "" : "entra"
    SCM_DO_BUILD_DURING_DEPLOYMENT        = "false"
  }

  depends_on = [terraform_data.network_ready]
}

# -------------------------------------------------------------------------------------------------
# Data: PostgreSQL flexible server and Azure Managed Redis (Entra-only, private endpoints)
# -------------------------------------------------------------------------------------------------
module "postgres" {
  source = "../modules/postgres"

  name                       = local.names.postgres
  location                   = var.location
  resource_group_name        = data.azurerm_resource_group.workload.name
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  postgres_version           = var.postgres_version
  sku_name                   = var.postgres_sku_name
  storage_mb                 = var.postgres_storage_mb
  backup_retention_days      = var.postgres_backup_retention_days
  high_availability_enabled  = var.postgres_high_availability
  admin_principal_id         = azurerm_user_assigned_identity.this["dbadmin"].principal_id
  admin_principal_name       = azurerm_user_assigned_identity.this["dbadmin"].name
  private_endpoint_subnet_id = azurerm_subnet.this["snet-private-endpoints"].id
  private_dns_zone_id        = data.azurerm_private_dns_zone.hub["postgres"].id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.platform.id
  tags                       = local.tags

  depends_on = [terraform_data.network_ready]
}

module "redis" {
  source = "../modules/managed_redis"

  name                       = local.names.redis
  location                   = var.location
  resource_group_name        = data.azurerm_resource_group.workload.name
  sku_name                   = var.redis_sku_name
  private_endpoint_subnet_id = azurerm_subnet.this["snet-private-endpoints"].id
  private_dns_zone_id        = data.azurerm_private_dns_zone.hub["redis"].id
  tags                       = local.tags

  # [SEC] Data access for the API identity only.
  access_policy_object_ids = {
    api = azurerm_user_assigned_identity.this["api"].principal_id
  }

  depends_on = [terraform_data.network_ready]
}

# -------------------------------------------------------------------------------------------------
# Edge: Application Gateway WAF_v2 (workload spoke, not the hub - CAF)
# -------------------------------------------------------------------------------------------------
module "app_gateway" {
  source = "../modules/app_gateway"

  name                       = local.names.app_gateway
  location                   = var.location
  resource_group_name        = data.azurerm_resource_group.workload.name
  public_ip_name             = local.names.app_gateway_pip
  waf_policy_name            = local.names.waf_policy
  subnet_id                  = azurerm_subnet.this["snet-appgw"].id
  identity_id                = azurerm_user_assigned_identity.this["agw"].id
  min_capacity               = var.app_gateway_min_capacity
  max_capacity               = var.app_gateway_max_capacity
  appsvc_backend_fqdn        = module.web_app.default_hostname
  aks_backend_ip             = local.aks_ingress_private_ip
  tls_certificate_secret_id  = var.tls_certificate_secret_id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.platform.id
  tags                       = local.tags

  # [SEC] WAF policy: mode and custom-rule settings per environment.
  waf_mode                         = var.waf_mode
  waf_claims_rate_limit_per_minute = var.waf_claims_rate_limit_per_minute
  waf_block_ops_api                = var.waf_block_ops_api
  waf_allowed_country_codes        = var.waf_allowed_country_codes

  # The NSG must allow GatewayManager before the gateway is created, and the gateway identity must be able
  # to read the certificate before an HTTPS listener references it.
  depends_on = [terraform_data.network_ready, azurerm_role_assignment.key_vault_secrets_user]
}

# -------------------------------------------------------------------------------------------------
# Ops VM (only when an SSH public key is supplied: TF_VAR_ops_ssh_public_key)
# -------------------------------------------------------------------------------------------------
module "ops_vm" {
  source = "../modules/ops_vm"
  count  = var.ops_ssh_public_key == "" ? 0 : 1

  name                = local.names.ops_vm
  location            = var.location
  resource_group_name = data.azurerm_resource_group.workload.name
  subnet_id           = azurerm_subnet.this["snet-ops"].id
  size                = var.ops_vm_size
  ssh_public_key      = var.ops_ssh_public_key
  identity_id         = azurerm_user_assigned_identity.this["dbadmin"].id
  tags                = local.tags

  # cloud-init installs packages: explicit egress (NAT gateway / firewall route) must exist first.
  depends_on = [terraform_data.network_ready]
}

# -------------------------------------------------------------------------------------------------
# RBAC (least privilege; Key Vault Administrator is deliberately granted to nobody)
# -------------------------------------------------------------------------------------------------
# web + api identities -> Monitoring Metrics Publisher on Application Insights (Entra-authenticated telemetry).
resource "azurerm_role_assignment" "monitoring_metrics_publisher" {
  for_each = toset(["api", "web"])

  scope              = azurerm_application_insights.this.id
  role_definition_id = local.role_definition_ids.monitoring_metrics_publisher
  principal_id       = azurerm_user_assigned_identity.this[each.key].principal_id
  principal_type     = "ServicePrincipal"
}

# api identity (Key Vault references) and agw identity (TLS certificate) -> Key Vault Secrets User.
resource "azurerm_role_assignment" "key_vault_secrets_user" {
  for_each = toset(["api", "agw"])

  scope              = module.key_vault.id
  role_definition_id = local.role_definition_ids.key_vault_secrets_user
  principal_id       = azurerm_user_assigned_identity.this[each.key].principal_id
  principal_type     = "ServicePrincipal"
}

# -------------------------------------------------------------------------------------------------
# Alerts
# -------------------------------------------------------------------------------------------------
# Receivers are skipped when alert_email is empty (the action group still exists for later wiring).
resource "azurerm_monitor_action_group" "this" {
  name                = local.names.action_group
  resource_group_name = data.azurerm_resource_group.workload.name
  # ag-ch-<env> is at most 12 characters, the short-name limit.
  short_name = local.names.action_group
  tags       = local.tags

  dynamic "email_receiver" {
    for_each = var.alert_email == "" ? [] : [var.alert_email]
    content {
      name                    = "platform-team-email"
      email_address           = email_receiver.value
      use_common_alert_schema = true
    }
  }
}

# [REL] Note: the :8080 (AKS) pool reports unhealthy until the aks stack and the "web" Service exist.
resource "azurerm_monitor_metric_alert" "app_gateway_unhealthy_hosts" {
  name                = "alert-${local.names.app_gateway}-unhealthy-hosts"
  resource_group_name = data.azurerm_resource_group.workload.name
  scopes              = [module.app_gateway.id]
  description         = "At least one Application Gateway backend failed its /healthz probe (5-minute window)."
  severity            = 1
  frequency           = "PT1M"
  window_size         = "PT5M"
  tags                = local.tags

  criteria {
    metric_namespace = "Microsoft.Network/applicationGateways"
    metric_name      = "UnhealthyHostCount"
    aggregation      = "Average"
    operator         = "GreaterThan"
    threshold        = 0
  }

  action {
    action_group_id = azurerm_monitor_action_group.this.id
  }
}

resource "azurerm_monitor_metric_alert" "postgres_cpu" {
  name                = "alert-${local.names.postgres}-cpu"
  resource_group_name = data.azurerm_resource_group.workload.name
  scopes              = [module.postgres.id]
  description         = "PostgreSQL CPU above 80% for 15 minutes: scale the SKU or look for missing indexes."
  severity            = 2
  frequency           = "PT5M"
  window_size         = "PT15M"
  tags                = local.tags

  criteria {
    metric_namespace = "Microsoft.DBforPostgreSQL/flexibleServers"
    metric_name      = "cpu_percent"
    aggregation      = "Average"
    operator         = "GreaterThan"
    threshold        = 80
  }

  action {
    action_group_id = azurerm_monitor_action_group.this.id
  }
}

# TODO(copilot-exercise): Redis server load alert
