# Output names are identical to the Bicep twin (camelCase on purpose): scripts and workflows read either flavour.

output "resourceGroupName" {
  description = "Workload resource group."
  value       = data.azurerm_resource_group.workload.name
}

output "webAppName" {
  description = "Name of the web (frontend) app."
  value       = module.web_app.name
}

output "apiAppName" {
  description = "Name of the API app."
  value       = module.api_app.name
}

output "webAppHostName" {
  description = "Default host name of the web app."
  value       = module.web_app.default_hostname
}

output "apiAppHostName" {
  description = "Default host name of the API app."
  value       = module.api_app.default_hostname
}

output "appGatewayPublicIp" {
  description = "Public IP of the Application Gateway (:80 App Service path, :8080 AKS path)."
  value       = module.app_gateway.public_ip_address
}

output "postgresServerName" {
  description = "Name of the PostgreSQL flexible server."
  value       = module.postgres.name
}

output "postgresFqdn" {
  description = "FQDN of the PostgreSQL flexible server (private endpoint)."
  value       = module.postgres.fqdn
}

output "redisName" {
  description = "Name of the Azure Managed Redis instance."
  value       = module.redis.name
}

output "redisHostName" {
  description = "Host name of the Azure Managed Redis endpoint (port 10000, TLS)."
  value       = module.redis.hostname
}

output "keyVaultName" {
  description = "Name of the Key Vault."
  value       = module.key_vault.name
}

output "appInsightsName" {
  description = "Name of the Application Insights component."
  value       = azurerm_application_insights.this.name
}

output "apiIdentityName" {
  description = "Name of the API managed identity (also the PostgreSQL role name, PGUSER)."
  value       = azurerm_user_assigned_identity.this["api"].name
}

output "apiIdentityClientId" {
  description = "Client ID of the API managed identity."
  value       = azurerm_user_assigned_identity.this["api"].client_id
}

output "apiIdentityPrincipalId" {
  description = "Principal (object) ID of the API managed identity."
  value       = azurerm_user_assigned_identity.this["api"].principal_id
}

output "webIdentityName" {
  description = "Name of the web managed identity."
  value       = azurerm_user_assigned_identity.this["web"].name
}

output "webIdentityClientId" {
  description = "Client ID of the web managed identity."
  value       = azurerm_user_assigned_identity.this["web"].client_id
}

output "webIdentityPrincipalId" {
  description = "Principal (object) ID of the web managed identity."
  value       = azurerm_user_assigned_identity.this["web"].principal_id
}

output "dbAdminIdentityName" {
  description = "Name of the PostgreSQL Entra admin identity (also attached to the ops VM)."
  value       = azurerm_user_assigned_identity.this["dbadmin"].name
}

output "dbAdminIdentityClientId" {
  description = "Client ID of the PostgreSQL Entra admin identity."
  value       = azurerm_user_assigned_identity.this["dbadmin"].client_id
}

output "opsVmName" {
  description = "Name of the ops VM, or empty when no SSH public key was supplied."
  value       = try(module.ops_vm[0].name, "")
}

output "spokeVnetName" {
  description = "Name of the spoke VNet."
  value       = azurerm_virtual_network.spoke.name
}

output "spokeVnetId" {
  description = "Resource ID of the spoke VNet."
  value       = azurerm_virtual_network.spoke.id
}

output "aksNodesSubnetId" {
  description = "Resource ID of snet-aks-nodes."
  value       = azurerm_subnet.this["snet-aks-nodes"].id
}

output "aksIlbSubnetId" {
  description = "Resource ID of snet-aks-ilb."
  value       = azurerm_subnet.this["snet-aks-ilb"].id
}

output "aksApiServerSubnetId" {
  description = "Resource ID of snet-aks-apiserver."
  value       = azurerm_subnet.this["snet-aks-apiserver"].id
}

output "privateEndpointsSubnetId" {
  description = "Resource ID of snet-private-endpoints."
  value       = azurerm_subnet.this["snet-private-endpoints"].id
}

output "natGatewayId" {
  description = "Resource ID of the NAT gateway, or empty when egress_mode is firewall."
  value       = try(azurerm_nat_gateway.this[0].id, "")
}

output "aksIngressPrivateIp" {
  description = "Static private IP the AKS \"web\" internal LoadBalancer Service must use (App Gateway :8080 backend)."
  value       = local.aks_ingress_private_ip
}
