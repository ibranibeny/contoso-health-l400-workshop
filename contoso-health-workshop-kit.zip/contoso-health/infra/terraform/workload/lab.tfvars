# Workload - lab (cost-aware, same topology as prod). Per-user values come from TF_VAR_* environment variables:
# TF_VAR_subscription_id, TF_VAR_ops_ssh_public_key, TF_VAR_alert_email.
env            = "lab"
address_prefix = "10.110.0.0/20"
egress_mode    = "natGateway"

app_service_sku                   = "P0v4"
app_service_capacity              = 2
scm_ip_restriction_default_action = "Allow"
seed_on_start                     = true
ops_api_enabled                   = true
app_insights_local_auth_enabled   = true

postgres_sku_name          = "B_Standard_B1ms"
postgres_high_availability = false

redis_sku_name = "Balanced_B0"

app_gateway_min_capacity = 1
aks_ingress_private_ip   = "10.110.3.70"

# [SEC] WAF in Prevention in every environment. [OPS] The claims limit is counted per client IP: participants behind
# one venue NAT share it, so raise it if the burst exercise gets HTTP 403 from the WAF instead of HTTP 429 from the API.
# The claims desk (/api/ops/*) is part of the lab exercises (ops_api_enabled = true), so it stays reachable.
waf_mode                         = "Prevention"
waf_claims_rate_limit_per_minute = 60
waf_block_ops_api                = false
waf_allowed_country_codes        = ["ID"]

# lab only: no TLS certificate, the App Gateway listeners are plain HTTP.
tls_certificate_secret_id = ""
