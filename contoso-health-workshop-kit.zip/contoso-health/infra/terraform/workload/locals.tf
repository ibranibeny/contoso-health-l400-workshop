locals {
  # Globally-unique suffix (6 lowercase hex chars), used ONLY for globally-unique names.
  # Bicep twin: take(uniqueString(subscription().id, 'ch', env), 6).
  suffix = substr(sha1("${var.subscription_id}-ch-${var.env}"), 0, 6)

  is_prod = var.env == "prod"

  # Deterministic names: the aks stack finds these resources by name, without reading this stack's state.
  names = {
    resource_group   = "rg-ch-${var.env}-idc"
    hub_rg           = "rg-ch-hub-idc"
    mgmt_rg          = "rg-ch-mgmt-idc"
    hub_vnet         = "vnet-ch-hub-idc"
    log_analytics    = "log-ch-idc"
    firewall         = "afw-ch-hub-idc"
    ddos_plan        = "ddos-ch-hub-idc"
    vnet             = "vnet-ch-${var.env}-idc"
    nat_gateway      = "ng-ch-${var.env}-idc"
    route_table      = "rt-ch-${var.env}-idc"
    app_insights     = "appi-ch-${var.env}-idc"
    key_vault        = "kv-ch-${var.env}-${local.suffix}"
    app_service_plan = "asp-ch-${var.env}-idc"
    web_app          = "app-ch-web-${var.env}-${local.suffix}"
    api_app          = "app-ch-api-${var.env}-${local.suffix}"
    postgres         = "psql-ch-${var.env}-${local.suffix}"
    redis            = "redis-ch-${var.env}-${local.suffix}"
    app_gateway      = "agw-ch-${var.env}-idc"
    app_gateway_pip  = "pip-agw-ch-${var.env}-idc"
    waf_policy       = "waf-ch-${var.env}-idc"
    ops_vm           = "vm-ch-ops-${var.env}"
    action_group     = "ag-ch-${var.env}"
  }

  identities = {
    api     = "id-ch-api-${var.env}"
    web     = "id-ch-web-${var.env}"
    dbadmin = "id-ch-dbadmin-${var.env}"
    agw     = "id-ch-agw-${var.env}"
  }

  # Address plan derived from the /20 with cidrsubnet (lab values shown; prod is identical inside 10.120.0.0/20).
  # egress = the subnet gets the NAT gateway (natGateway mode) or the 0.0.0.0/0 route to the hub firewall.
  # private = Azure private subnet (default_outbound_access_enabled = false); false keeps the platform default.
  subnets = {
    "snet-appgw" = {
      # x.x.0.0/24 - App Gateway v2 recommends a dedicated /24; it egresses through its own public IP.
      address_prefix     = cidrsubnet(var.address_prefix, 4, 0)
      delegation         = ""
      delegation_actions = []
      egress             = false
      pe_policies        = "Disabled"
      private            = false # No Learn statement that Application Gateway v2 supports private subnets.
    }
    "snet-app-integration" = {
      # x.x.1.0/26 - App Service regional VNet integration (/26 recommended).
      address_prefix     = cidrsubnet(var.address_prefix, 6, 4)
      delegation         = "Microsoft.Web/serverFarms"
      delegation_actions = ["Microsoft.Network/virtualNetworks/subnets/action"]
      egress             = true
      pe_policies        = "Disabled"
      private            = false # Delegated subnet: private subnets don't apply to subnets hosting PaaS services.
    }
    "snet-private-endpoints" = {
      # x.x.2.0/24 - [SEC] NSG rules are enforced on private endpoint traffic.
      address_prefix     = cidrsubnet(var.address_prefix, 4, 2)
      delegation         = ""
      delegation_actions = []
      egress             = false
      pe_policies        = "Enabled"
      private            = true
    }
    "snet-ops" = {
      # x.x.3.0/27 - ops VM.
      address_prefix     = cidrsubnet(var.address_prefix, 7, 24)
      delegation         = ""
      delegation_actions = []
      egress             = true
      pe_policies        = "Disabled"
      private            = true
    }
    "snet-aks-ilb" = {
      # x.x.3.64/27 - frontend IPs of the AKS internal load balancer.
      address_prefix     = cidrsubnet(var.address_prefix, 7, 26)
      delegation         = ""
      delegation_actions = []
      egress             = false
      pe_policies        = "Disabled"
      private            = true
    }
    "snet-aks-apiserver" = {
      # x.x.3.96/28 - API server VNet integration (prod private cluster; reserved in lab).
      address_prefix     = cidrsubnet(var.address_prefix, 8, 54)
      delegation         = "Microsoft.ContainerService/managedClusters"
      delegation_actions = ["Microsoft.Network/virtualNetworks/subnets/join/action"]
      egress             = false
      pe_policies        = "Disabled"
      private            = false # Delegated subnet: private subnets don't apply to subnets hosting PaaS services.
    }
    "snet-aks-nodes" = {
      # x.x.4.0/22 - nodes only: CNI Overlay keeps pod IPs off the VNet.
      address_prefix     = cidrsubnet(var.address_prefix, 2, 1)
      delegation         = ""
      delegation_actions = []
      egress             = true
      pe_policies        = "Disabled"
      private            = true
    }
  }

  egress_subnet_names = [for name, subnet in local.subnets : name if subnet.egress]

  # Default 10.110.3.70 in lab: 7th address of snet-aks-ilb (x.x.3.64/27).
  aks_ingress_private_ip = var.aks_ingress_private_ip != "" ? var.aks_ingress_private_ip : cidrhost(local.subnets["snet-aks-ilb"].address_prefix, 6)

  # Custom inbound rules per subnet (every other NSG keeps the Azure default rules only).
  # snet-appgw: what App Gateway v2 requires (Learn "Application Gateway infrastructure configuration").
  # snet-ops: SSH only from Azure Bastion in the hub and no lateral movement from the rest of the VNet
  # (az vm run-command needs no inbound port at all).
  nsg_rules = [
    {
      subnet      = "snet-appgw"
      name        = "Allow-GatewayManager-Inbound"
      description = "App Gateway v2 control plane (health/management). Required."
      priority    = 100
      access      = "Allow"
      protocol    = "Tcp"
      source      = "GatewayManager"
      ports       = ["65200-65535"]
    },
    {
      subnet      = "snet-appgw"
      name        = "Allow-AzureLoadBalancer-Inbound"
      description = "Azure infrastructure health probes. Required."
      priority    = 110
      access      = "Allow"
      protocol    = "*"
      source      = "AzureLoadBalancer"
      ports       = ["*"]
    },
    {
      subnet      = "snet-appgw"
      name        = "Allow-Internet-Web-Inbound"
      description = "Public listeners: 80/443 (App Service path) and 8080 (AKS path)."
      priority    = 120
      access      = "Allow"
      protocol    = "Tcp"
      source      = "Internet"
      ports       = ["80", "443", "8080"]
    },
    {
      subnet      = "snet-ops"
      name        = "Allow-Ssh-From-Bastion"
      description = "Interactive SSH only through Azure Bastion in the hub (when deployed)."
      priority    = 100
      access      = "Allow"
      protocol    = "Tcp"
      source      = data.azurerm_subnet.hub_bastion.address_prefixes[0]
      ports       = ["22"]
    },
    {
      subnet      = "snet-ops"
      name        = "Deny-VirtualNetwork-Inbound"
      description = "Overrides the default AllowVnetInBound rule: no lateral movement into the jump host."
      priority    = 4000
      access      = "Deny"
      protocol    = "*"
      source      = "VirtualNetwork"
      ports       = ["*"]
    },
  ]

  # Keys of the hub private DNS zones (same keys as the platform output privateDnsZoneIds).
  private_dns_zones = {
    appService = "privatelink.azurewebsites.net"
    postgres   = "privatelink.postgres.database.azure.com"
    redis      = "privatelink.redis.azure.net"
    keyVault   = "privatelink.vaultcore.azure.net"
    acr        = "privatelink.azurecr.io"
  }

  role_definition_prefix = "/subscriptions/${var.subscription_id}/providers/Microsoft.Authorization/roleDefinitions"
  role_definition_ids = {
    monitoring_metrics_publisher = "${local.role_definition_prefix}/3913510d-42f4-4e42-8a64-420c390055eb"
    key_vault_secrets_user       = "${local.role_definition_prefix}/4633458b-17de-408a-b874-0445c86b69e6"
  }

  tags = {
    workload           = "contoso-health"
    environment        = var.env
    owner              = "platform-team"
    costCenter         = "CH-1001"
    dataClassification = "confidential"
    managedBy          = "terraform"
  }
}
