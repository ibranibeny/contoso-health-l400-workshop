terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 5.14"
    }
  }
}

resource "azurerm_key_vault" "this" {
  name                = var.name
  location            = var.location
  resource_group_name = var.resource_group_name
  tenant_id           = var.tenant_id
  sku_name            = var.sku_name
  # [SEC] Azure RBAC data-plane authorization (a required argument in AzureRM 5.x): no access policies to drift.
  rbac_authorization_enabled = true
  # [REL] Purge protection + 90-day soft delete: a deleted vault and its secrets can always be recovered.
  purge_protection_enabled   = true
  soft_delete_retention_days = 90
  # [SEC] The data plane is reachable only through the private endpoint.
  public_network_access_enabled = false
  tags                          = var.tags

  network_acls {
    default_action = "Deny"
    # [OPS] Trusted Microsoft services keep working; everything else must come through the private endpoint.
    bypass = "AzureServices"
  }
}

module "private_endpoint" {
  source = "../private_endpoint"

  name                           = "pe-${var.name}"
  location                       = var.location
  resource_group_name            = var.resource_group_name
  subnet_id                      = var.private_endpoint_subnet_id
  private_connection_resource_id = azurerm_key_vault.this.id
  subresource_names              = ["vault"]
  private_dns_zone_ids           = [var.private_dns_zone_id]
  tags                           = var.tags
}

# [OPS] AuditEvent (via allLogs) records every secret read: who, when, from where.
module "diagnostics" {
  source = "../diagnostic_setting"

  target_resource_id         = azurerm_key_vault.this.id
  log_analytics_workspace_id = var.log_analytics_workspace_id
}
