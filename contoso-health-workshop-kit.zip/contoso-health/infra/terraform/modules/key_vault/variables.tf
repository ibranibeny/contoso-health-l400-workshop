variable "name" {
  description = "Key Vault name (kv-ch-<env>-<sfx>, globally unique, max 24 characters)."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group of the vault."
  type        = string
}

variable "tenant_id" {
  description = "Microsoft Entra tenant ID that authenticates data-plane requests."
  type        = string
}

variable "sku_name" {
  description = "standard or premium (HSM-backed keys)."
  type        = string
  default     = "standard"
}

variable "private_endpoint_subnet_id" {
  description = "Resource ID of snet-private-endpoints."
  type        = string
}

variable "private_dns_zone_id" {
  description = "Resource ID of the hub privatelink.vaultcore.azure.net zone."
  type        = string
}

variable "log_analytics_workspace_id" {
  description = "Resource ID of the platform Log Analytics workspace."
  type        = string
}

variable "tags" {
  description = "Tags applied to every resource of the module."
  type        = map(string)
  default     = {}
}
