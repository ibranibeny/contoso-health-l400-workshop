output "id" {
  description = "Resource ID of the Managed Redis instance."
  value       = azurerm_managed_redis.this.id
}

output "name" {
  description = "Name of the Managed Redis instance."
  value       = azurerm_managed_redis.this.name
}

output "hostname" {
  description = "Endpoint host name (<name>.<region>.redis.azure.net)."
  value       = azurerm_managed_redis.this.hostname
}

output "port" {
  description = "TLS port of the default database (10000)."
  value       = azurerm_managed_redis.this.default_database[0].port
}
