variable "name" {
  description = "Managed Redis name (redis-ch-<env>-<sfx>, globally unique)."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group of the cache."
  type        = string
}

variable "sku_name" {
  description = "Managed Redis SKU: Balanced_B0 in lab and prod (smallest Balanced size, 0.5 GB); raise it to Balanced_B1 or larger when memory or server load grows."
  type        = string
}

variable "access_policy_object_ids" {
  description = "Map of static key => Entra object ID granted the default data access policy (keys must be known at plan time)."
  type        = map(string)
  default     = {}
}

variable "private_endpoint_subnet_id" {
  description = "Resource ID of snet-private-endpoints."
  type        = string
}

variable "private_dns_zone_id" {
  description = "Resource ID of the hub privatelink.redis.azure.net zone."
  type        = string
}

variable "tags" {
  description = "Tags applied to every resource of the module."
  type        = map(string)
  default     = {}
}
