terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 5.14"
    }
  }
}

# Azure Managed Redis (Microsoft.Cache/redisEnterprise). Azure Cache for Redis is retiring: never use it here.
resource "azurerm_managed_redis" "this" {
  name                = var.name
  location            = var.location
  resource_group_name = var.resource_group_name
  # [COST] Balanced = balanced memory/vCPU ratio; B0 is the smallest HA-capable size.
  sku_name = var.sku_name
  # [REL] Replicated and zone-redundant in AZ regions; it cannot be switched off later (ForceNew).
  high_availability_enabled = true
  # [SEC] Private endpoint only. AzureRM 5.x exposes no minimum TLS argument here: the service default (TLS 1.2)
  # applies, while the Bicep twin sets minimumTlsVersion '1.2' explicitly.
  public_network_access = "Disabled"
  tags                  = var.tags

  default_database {
    # [SEC] Entra ID tokens only (access policy assignments below); no shared access keys.
    access_keys_authentication_enabled = false
    # [SEC] TLS on port 10000.
    client_protocol = "Encrypted"
    # [PERF] trade-off: EnterpriseCluster exposes one endpoint that works with non-cluster-aware clients (node-redis
    # here); OSSCluster is faster at scale but requires cluster-aware clients.
    clustering_policy = "EnterpriseCluster"
    # Cache semantics: evict keys that have a TTL first.
    eviction_policy = "VolatileLRU"
  }
}

# Data-plane access for managed identities (the "default" access policy on the default database).
resource "azurerm_managed_redis_access_policy_assignment" "this" {
  for_each = var.access_policy_object_ids

  managed_redis_id = azurerm_managed_redis.this.id
  object_id        = each.value
}

module "private_endpoint" {
  source = "../private_endpoint"

  name                           = "pe-${var.name}"
  location                       = var.location
  resource_group_name            = var.resource_group_name
  subnet_id                      = var.private_endpoint_subnet_id
  private_connection_resource_id = azurerm_managed_redis.this.id
  subresource_names              = ["redisEnterprise"]
  private_dns_zone_ids           = [var.private_dns_zone_id]
  tags                           = var.tags

  # [REL] The cache rejects concurrent updates: let the access policy assignments finish first.
  depends_on = [azurerm_managed_redis_access_policy_assignment.this]
}
