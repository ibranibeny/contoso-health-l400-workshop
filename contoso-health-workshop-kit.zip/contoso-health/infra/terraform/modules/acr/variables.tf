variable "name" {
  description = "Registry name (crch<env><sfx>: alphanumeric, globally unique)."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group of the registry and its private endpoint."
  type        = string
}

variable "public_network_access_enabled" {
  description = "true in lab (GitHub-hosted runners push), false in prod (private endpoint only)."
  type        = bool
}

variable "private_endpoint_subnet_id" {
  description = "Resource ID of the workload snet-private-endpoints."
  type        = string
}

variable "private_dns_zone_id" {
  description = "Resource ID of the hub privatelink.azurecr.io zone."
  type        = string
}

variable "log_analytics_workspace_id" {
  description = "Resource ID of the platform Log Analytics workspace."
  type        = string
}

variable "tags" {
  description = "Tags applied to every resource of the module."
  type        = map(string)
  default     = {}
}
