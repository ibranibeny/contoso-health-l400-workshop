terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 5.14"
    }
  }
}

resource "azurerm_container_registry" "this" {
  name                = var.name
  location            = var.location
  resource_group_name = var.resource_group_name
  # Premium is required for private endpoints; [REL] zone redundancy is automatic in AZ regions, so
  # zone_redundancy_enabled is deliberately left unset (ForceNew, and the twin does not set it either).
  sku = "Premium"
  # [SEC] No admin user and no anonymous pull: kubelet pulls with AcrPull, CI pushes with AcrPush (Entra only).
  admin_enabled          = false
  anonymous_pull_enabled = false
  # [SEC] Enabled in lab (GitHub-hosted runners push over the internet with Entra tokens), Disabled in prod
  # (self-hosted/ARC runners inside the VNet push through the private endpoint).
  public_network_access_enabled = var.public_network_access_enabled
  # [OPS] Trusted Azure services (e.g. Defender image scanning) bypass the network rules.
  network_rule_bypass_option = "AzureServices"
  tags                       = var.tags
}

module "private_endpoint" {
  source = "../private_endpoint"

  name                           = "pe-${var.name}"
  location                       = var.location
  resource_group_name            = var.resource_group_name
  subnet_id                      = var.private_endpoint_subnet_id
  private_connection_resource_id = azurerm_container_registry.this.id
  subresource_names              = ["registry"]
  private_dns_zone_ids           = [var.private_dns_zone_id]
  tags                           = var.tags
}

module "diagnostics" {
  source = "../diagnostic_setting"

  target_resource_id         = azurerm_container_registry.this.id
  log_analytics_workspace_id = var.log_analytics_workspace_id
}
