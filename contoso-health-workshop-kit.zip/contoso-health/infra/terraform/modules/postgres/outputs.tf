output "id" {
  description = "Resource ID of the PostgreSQL flexible server."
  value       = azurerm_postgresql_flexible_server.this.id
}

output "name" {
  description = "Name of the PostgreSQL flexible server."
  value       = azurerm_postgresql_flexible_server.this.name
}

output "fqdn" {
  description = "Server FQDN (resolves to the private endpoint IP inside the linked VNets)."
  value       = azurerm_postgresql_flexible_server.this.fqdn
}
