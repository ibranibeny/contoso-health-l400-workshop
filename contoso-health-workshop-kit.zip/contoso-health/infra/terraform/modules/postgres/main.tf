terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 5.14"
    }
  }
}

resource "azurerm_postgresql_flexible_server" "this" {
  name                = var.name
  location            = var.location
  resource_group_name = var.resource_group_name
  version             = var.postgres_version
  # [COST] Burstable B1ms in lab; [REL] GeneralPurpose in prod (zone-redundant HA is not offered on Burstable).
  sku_name   = var.sku_name
  storage_mb = var.storage_mb
  # [REL] Grows the disk before it fills up and the server turns read-only.
  auto_grow_enabled     = true
  zone                  = var.primary_zone
  backup_retention_days = var.backup_retention_days
  # Geo-redundant backup is not available in Indonesia Central (no paired region).
  geo_redundant_backup_enabled = false
  # [SEC] Private endpoint only. No VNet injection: private endpoints are not supported on VNet-integrated
  # servers and the conversion is one-way.
  public_network_access_enabled = false
  tags                          = var.tags

  # [SEC] Microsoft Entra ID only: no local admin password exists to leak or rotate.
  authentication {
    active_directory_auth_enabled = true
    password_auth_enabled         = false
    tenant_id                     = var.tenant_id
  }

  # [REL] Synchronous standby in another zone with automatic failover (prod); omitted = HA disabled (lab).
  dynamic "high_availability" {
    for_each = var.high_availability_enabled ? [1] : []
    content {
      mode                      = "ZoneRedundant"
      standby_availability_zone = var.standby_zone
    }
  }

  # [OPS] Planned maintenance in a fixed weekly slot: Sunday 02:00 (custom windows are expressed in UTC).
  maintenance_window {
    day_of_week  = 0
    start_hour   = 2
    start_minute = 0
  }

  lifecycle {
    # [REL] After a failover Azure swaps primary and standby zones; do not let Terraform fight that.
    ignore_changes = [
      zone,
      high_availability[0].standby_availability_zone,
    ]
  }
}

# The Entra admin is the dbadmin managed identity; the bootstrap script (run on the ops VM with that identity)
# creates the contoso_health database so the admin owns it and can GRANT to the API identity.
resource "azurerm_postgresql_flexible_server_active_directory_administrator" "this" {
  server_name         = azurerm_postgresql_flexible_server.this.name
  resource_group_name = var.resource_group_name
  tenant_id           = var.tenant_id
  object_id           = var.admin_principal_id
  principal_name      = var.admin_principal_name
  principal_type      = "ServicePrincipal"
}

module "private_endpoint" {
  source = "../private_endpoint"

  name                           = "pe-${var.name}"
  location                       = var.location
  resource_group_name            = var.resource_group_name
  subnet_id                      = var.private_endpoint_subnet_id
  private_connection_resource_id = azurerm_postgresql_flexible_server.this.id
  subresource_names              = ["postgresqlServer"]
  private_dns_zone_ids           = [var.private_dns_zone_id]
  tags                           = var.tags

  # [REL] The server accepts one management operation at a time: wait for the admin assignment.
  depends_on = [azurerm_postgresql_flexible_server_active_directory_administrator.this]
}

module "diagnostics" {
  source = "../diagnostic_setting"

  target_resource_id         = azurerm_postgresql_flexible_server.this.id
  log_analytics_workspace_id = var.log_analytics_workspace_id
}
