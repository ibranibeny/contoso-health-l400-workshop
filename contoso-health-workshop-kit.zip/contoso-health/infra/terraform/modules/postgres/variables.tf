variable "name" {
  description = "Server name (psql-ch-<env>-<sfx>, globally unique)."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group of the server."
  type        = string
}

variable "tenant_id" {
  description = "Microsoft Entra tenant ID used for Entra authentication."
  type        = string
}

variable "postgres_version" {
  description = "PostgreSQL major version."
  type        = string
  default     = "17"
}

variable "sku_name" {
  description = "Compute SKU in <tier>_<size> form, e.g. B_Standard_B1ms (lab) or GP_Standard_D2ds_v5 (prod)."
  type        = string
}

variable "storage_mb" {
  description = "Provisioned storage in MB."
  type        = number
  default     = 32768
}

variable "backup_retention_days" {
  description = "Point-in-time restore window in days (7-35)."
  type        = number
  default     = 7
}

variable "high_availability_enabled" {
  description = "Zone-redundant HA (GeneralPurpose/MemoryOptimized SKUs only)."
  type        = bool
  default     = false
}

variable "primary_zone" {
  description = "Availability zone of the primary server."
  type        = string
  default     = "1"
}

variable "standby_zone" {
  description = "Availability zone of the HA standby."
  type        = string
  default     = "2"
}

variable "admin_principal_id" {
  description = "Object (principal) ID of the managed identity that becomes the Entra admin."
  type        = string
}

variable "admin_principal_name" {
  description = "Display name of the Entra admin (the managed identity name)."
  type        = string
}

variable "private_endpoint_subnet_id" {
  description = "Resource ID of snet-private-endpoints."
  type        = string
}

variable "private_dns_zone_id" {
  description = "Resource ID of the hub privatelink.postgres.database.azure.com zone."
  type        = string
}

variable "log_analytics_workspace_id" {
  description = "Resource ID of the platform Log Analytics workspace."
  type        = string
}

variable "tags" {
  description = "Tags applied to every resource of the module."
  type        = map(string)
  default     = {}
}
