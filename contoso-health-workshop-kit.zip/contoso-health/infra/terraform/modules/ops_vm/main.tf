terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 5.14"
    }
  }
}

locals {
  # psql + jq for the database bootstrap script, which `az vm run-command invoke` executes on this VM.
  cloud_init = <<-EOT
    #cloud-config
    package_update: true
    packages:
      - postgresql-client
      - jq
  EOT
}

# [SEC] No public IP (also denied by policy on the workload RG): reach the VM with az vm run-command or Bastion.
resource "azurerm_network_interface" "this" {
  name                = "nic-${var.name}"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  ip_configuration {
    name                          = "ipconfig1"
    subnet_id                     = var.subnet_id
    private_ip_address_allocation = "Dynamic"
  }
}

resource "azurerm_linux_virtual_machine" "this" {
  name                = var.name
  location            = var.location
  resource_group_name = var.resource_group_name
  zone                = var.zone
  admin_username      = var.admin_username
  tags                = var.tags
  # [COST] Burstable size: the VM idles except during bootstrap and troubleshooting.
  size = var.size
  # [SEC] SSH key only, no password; the key comes from TF_VAR_ops_ssh_public_key, never from the repo.
  disable_password_authentication = true
  network_interface_ids           = [azurerm_network_interface.this.id]
  custom_data                     = base64encode(local.cloud_init)
  # [SEC] Trusted Launch: secure boot + vTPM on the Gen2 Ubuntu image.
  secure_boot_enabled = true
  vtpm_enabled        = true

  admin_ssh_key {
    username   = var.admin_username
    public_key = var.ssh_public_key
  }

  os_disk {
    name                 = "osdisk-${var.name}"
    caching              = "ReadWrite"
    storage_account_type = "StandardSSD_LRS"
  }

  source_image_reference {
    publisher = "Canonical"
    offer     = "ubuntu-24_04-lts"
    sku       = "server"
    version   = "latest"
  }

  # [SEC] Runs as id-ch-dbadmin-<env> (the PostgreSQL Entra admin): Entra tokens from IMDS, no passwords.
  identity {
    type         = "UserAssigned"
    identity_ids = [var.identity_id]
  }

  # [OPS] Managed boot diagnostics storage: serial console and screenshots without a storage account.
  boot_diagnostics {}
}
