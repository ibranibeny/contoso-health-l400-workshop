output "id" {
  description = "Resource ID of the ops VM."
  value       = azurerm_linux_virtual_machine.this.id
}

output "name" {
  description = "Name of the ops VM."
  value       = azurerm_linux_virtual_machine.this.name
}

output "private_ip_address" {
  description = "Private IP of the ops VM in snet-ops."
  value       = azurerm_network_interface.this.private_ip_address
}
