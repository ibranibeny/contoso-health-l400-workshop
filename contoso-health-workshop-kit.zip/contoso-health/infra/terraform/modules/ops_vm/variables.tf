variable "name" {
  description = "VM name (vm-ch-ops-<env>)."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group of the VM and its NIC."
  type        = string
}

variable "subnet_id" {
  description = "Resource ID of snet-ops."
  type        = string
}

variable "size" {
  description = "VM size."
  type        = string
  default     = "Standard_B2s"
}

variable "zone" {
  description = "Availability zone of the VM (null = no zone)."
  type        = string
  default     = null
}

variable "admin_username" {
  description = "Local admin user that owns the SSH key."
  type        = string
  default     = "azureuser"
}

variable "ssh_public_key" {
  description = "OpenSSH public key (ssh-ed25519 or ssh-rsa) for the admin user."
  type        = string
}

variable "identity_id" {
  description = "Resource ID of the user-assigned identity of the VM (id-ch-dbadmin-<env>)."
  type        = string
}

variable "tags" {
  description = "Tags applied to every resource of the module."
  type        = map(string)
  default     = {}
}
