variable "name" {
  description = "Cluster name (aks-ch-<env>-idc)."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group of the cluster (rg-ch-aks-<env>-idc)."
  type        = string
}

variable "dns_prefix" {
  description = "DNS prefix of the API server FQDN (aks-ch-<env>)."
  type        = string
}

variable "node_resource_group" {
  description = "Name of the AKS-managed node resource group (must not exist yet)."
  type        = string
}

variable "kubernetes_version" {
  description = "Kubernetes minor version alias, e.g. 1.36."
  type        = string
}

variable "tenant_id" {
  description = "Microsoft Entra tenant ID for the managed Entra integration."
  type        = string
}

variable "identity_id" {
  description = "Resource ID of the user-assigned control-plane identity (id-ch-aks-<env>)."
  type        = string
}

variable "admin_group_object_ids" {
  description = "Optional Entra group object IDs bound to cluster-admin (break-glass)."
  type        = list(string)
  default     = []
}

variable "zones" {
  description = "Availability zones of both node pools."
  type        = list(string)
  default     = ["1", "2", "3"]
}

variable "nodes_subnet_id" {
  description = "Resource ID of the workload snet-aks-nodes."
  type        = string
}

variable "private_cluster_enabled" {
  description = "true = private cluster with API server VNet integration (prod)."
  type        = bool
}

variable "api_server_subnet_id" {
  description = "Resource ID of snet-aks-apiserver (delegated to Microsoft.ContainerService/managedClusters); used when private."
  type        = string
}

variable "authorized_ip_ranges" {
  description = "Authorized IP ranges of a public API server (empty = unrestricted)."
  type        = list(string)
  default     = []
}

variable "outbound_type" {
  description = "userAssignedNATGateway (egress_mode natGateway) or userDefinedRouting (egress_mode firewall)."
  type        = string
}

variable "pod_cidr" {
  description = "Overlay pod CIDR (never routed on the VNet)."
  type        = string
}

variable "service_cidr" {
  description = "Kubernetes service CIDR."
  type        = string
}

variable "dns_service_ip" {
  description = "kube-dns service IP inside service_cidr."
  type        = string
}

variable "system_node_vm_size" {
  description = "VM size of the system pool."
  type        = string
}

variable "system_node_min_count" {
  description = "Autoscaler minimum of the system pool."
  type        = number
}

variable "system_node_max_count" {
  description = "Autoscaler maximum of the system pool."
  type        = number
}

variable "apps_node_vm_size" {
  description = "VM size of the apps (user) pool."
  type        = string
}

variable "apps_node_min_count" {
  description = "Autoscaler minimum of the apps pool."
  type        = number
}

variable "apps_node_max_count" {
  description = "Autoscaler maximum of the apps pool."
  type        = number
}

variable "maintenance_day_of_week" {
  description = "Day of the weekly auto-upgrade and node OS maintenance windows."
  type        = string
  default     = "Sunday"
}

variable "maintenance_start_time" {
  description = "Start time (HH:mm) of the maintenance windows, in maintenance_utc_offset."
  type        = string
  default     = "01:00"
}

variable "maintenance_utc_offset" {
  description = "UTC offset of the maintenance windows (+07:00 = Western Indonesia Time)."
  type        = string
  default     = "+07:00"
}

variable "maintenance_duration_hours" {
  description = "Duration of the maintenance windows in hours (minimum 4)."
  type        = number
  default     = 4
}

variable "log_analytics_workspace_id" {
  description = "Resource ID of the platform Log Analytics workspace."
  type        = string
}

variable "tags" {
  description = "Tags applied to the cluster and its node pools."
  type        = map(string)
  default     = {}
}
