terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 5.14"
    }
  }
}

resource "azurerm_kubernetes_cluster" "this" {
  name                = var.name
  location            = var.location
  resource_group_name = var.resource_group_name
  dns_prefix          = var.dns_prefix
  node_resource_group = var.node_resource_group
  # Minor-version alias (e.g. "1.36"): AKS picks the latest patch, the patch channel keeps it current.
  kubernetes_version = var.kubernetes_version
  # [REL] Financially backed API server SLA (the Free tier has none).
  sku_tier = "Standard"
  # [OPS] Automatic patch upgrades inside the pinned minor version, inside the maintenance window below.
  automatic_upgrade_channel = "patch"
  # [SEC] Weekly node image with OS security fixes.
  node_os_upgrade_channel = "NodeImage"
  # [SEC] Workload identity: pods exchange a projected service account token for an Entra token (no secrets).
  oidc_issuer_enabled       = true
  workload_identity_enabled = true
  # [SEC] No static admin kubeconfig: every kubectl call is authenticated by Entra ID and authorized by Azure RBAC.
  local_account_disabled            = true
  role_based_access_control_enabled = true
  # [SEC] Enforces the policy assignments on the AKS resource group (e.g. no privileged containers).
  azure_policy_enabled = true
  # [SEC] Removes unused, vulnerable images from the nodes every 7 days.
  image_cleaner_enabled        = true
  image_cleaner_interval_hours = 168
  # [SEC] prod: private cluster, no public API server endpoint (AKS-managed private DNS zone).
  private_cluster_enabled             = var.private_cluster_enabled
  private_dns_zone_id                 = var.private_cluster_enabled ? "System" : null
  private_cluster_public_fqdn_enabled = false
  tags                                = var.tags

  identity {
    type         = "UserAssigned"
    identity_ids = [var.identity_id]
  }

  azure_active_directory_role_based_access_control {
    tenant_id          = var.tenant_id
    azure_rbac_enabled = true
    # Optional break-glass Entra groups bound to cluster-admin; day-to-day access uses Azure RBAC role assignments.
    admin_group_object_ids = var.admin_group_object_ids
  }

  default_node_pool {
    name = "system"
    # [PERF] D4ds_v5 leaves headroom for add-ons and the optional Gateway API Envoy proxies, which run on the
    # system pool (up to 2 vCPU / 1 GiB per replica).
    vm_size = var.system_node_vm_size
    os_sku  = "AzureLinux"
    # [PERF] Ephemeral OS disk on the VM's local disk: faster node boot and reimage, no managed disk cost.
    os_disk_type = "Ephemeral"
    # [REL] At least one node per zone.
    zones          = var.zones
    vnet_subnet_id = var.nodes_subnet_id
    # [REL] Taint CriticalAddonsOnly=true:NoSchedule keeps application pods off the system pool.
    only_critical_addons_enabled = true
    auto_scaling_enabled         = true
    min_count                    = var.system_node_min_count
    max_count                    = var.system_node_max_count
    node_count                   = var.system_node_min_count
    # Required to change rotation-only properties (vm_size, zones, ...) without recreating the cluster.
    temporary_name_for_rotation = "systemtmp"
    tags                        = var.tags

    upgrade_settings {
      max_surge = "10%"
    }
  }

  # Required block since AzureRM 5.0: Manual = classic node pools, no node auto-provisioning (Karpenter).
  node_provisioning_profile {
    mode = "Manual"
  }

  network_profile {
    # [PERF] Azure CNI Overlay powered by Cilium: pod IPs come from pod_cidr, not from the VNet; eBPF data plane.
    network_plugin      = "azure"
    network_plugin_mode = "overlay"
    network_data_plane  = "cilium"
    network_policy      = "cilium"
    pod_cidr            = var.pod_cidr
    service_cidr        = var.service_cidr
    dns_service_ip      = var.dns_service_ip
    # [SEC] Egress is owned by the spoke: NAT gateway (lab) or 0.0.0.0/0 UDR to the hub firewall (prod).
    outbound_type     = var.outbound_type
    load_balancer_sku = "standard"
  }

  # Private: API server VNet integration into snet-aks-apiserver. Public: optional authorized IP ranges
  # (empty = unrestricted; every request is still authenticated by Entra ID).
  dynamic "api_server_access_profile" {
    for_each = var.private_cluster_enabled || length(var.authorized_ip_ranges) > 0 ? [1] : []
    content {
      authorized_ip_ranges                = var.private_cluster_enabled ? null : var.authorized_ip_ranges
      subnet_id                           = var.private_cluster_enabled ? var.api_server_subnet_id : null
      virtual_network_integration_enabled = var.private_cluster_enabled
    }
  }

  # [SEC] Secrets Store CSI driver with rotation: pods mount Key Vault secrets via workload identity.
  key_vault_secrets_provider {
    secret_rotation_enabled  = true
    secret_rotation_interval = "2m"
  }

  # Maintenance configuration aksManagedAutoUpgradeSchedule.
  maintenance_window_auto_upgrade {
    frequency   = "Weekly"
    interval    = 1
    day_of_week = var.maintenance_day_of_week
    start_time  = var.maintenance_start_time
    utc_offset  = var.maintenance_utc_offset
    duration    = var.maintenance_duration_hours
  }

  # Maintenance configuration aksManagedNodeOSUpgradeSchedule.
  maintenance_window_node_os {
    frequency   = "Weekly"
    interval    = 1
    day_of_week = var.maintenance_day_of_week
    start_time  = var.maintenance_start_time
    utc_offset  = var.maintenance_utc_offset
    duration    = var.maintenance_duration_hours
  }

  lifecycle {
    ignore_changes = [
      # [PERF] The cluster autoscaler owns the node count.
      default_node_pool[0].node_count,
      # Azure stores no default_node_pools value in Manual mode; the provider default would cause drift.
      node_provisioning_profile[0].default_node_pools,
      # [OPS] Managed Prometheus and Container insights are enabled by scripts/aks-postprovision.sh (az CLI).
      monitor_metrics,
      oms_agent,
      # The optional Gateway API (azapi_update_resource in the aks stack) also touches ingressProfile.
      web_app_routing,
    ]
  }
}

resource "azurerm_kubernetes_cluster_node_pool" "apps" {
  name                  = "apps"
  kubernetes_cluster_id = azurerm_kubernetes_cluster.this.id
  mode                  = "User"
  vm_size               = var.apps_node_vm_size
  os_sku                = "AzureLinux"
  os_disk_type          = "Ephemeral"
  # [REL] Spread across the three zones; the autoscaler balances them.
  zones          = var.zones
  vnet_subnet_id = var.nodes_subnet_id
  # [COST] Scale in when idle; [PERF] scale out under load (lab 2-6, prod 3-10).
  auto_scaling_enabled        = true
  min_count                   = var.apps_node_min_count
  max_count                   = var.apps_node_max_count
  node_count                  = var.apps_node_min_count
  temporary_name_for_rotation = "appstmp"
  tags                        = var.tags

  upgrade_settings {
    max_surge = "10%"
  }

  lifecycle {
    ignore_changes = [node_count]
  }
}

# [OPS] Curated control-plane logs (kube-audit-admin excludes get/list noise) plus all metrics.
module "diagnostics" {
  source = "../diagnostic_setting"

  target_resource_id         = azurerm_kubernetes_cluster.this.id
  log_analytics_workspace_id = var.log_analytics_workspace_id
  log_category_groups        = []
  log_categories             = ["kube-audit-admin", "kube-apiserver", "cluster-autoscaler", "guard"]
}
