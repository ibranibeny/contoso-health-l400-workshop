variable "name" {
  description = "Diagnostic setting name (unique per target resource). Same name as the Bicep twin."
  type        = string
  default     = "diag-log-analytics"
}

variable "target_resource_id" {
  description = "Resource ID whose logs and metrics are exported."
  type        = string
}

variable "log_analytics_workspace_id" {
  description = "Resource ID of the destination Log Analytics workspace."
  type        = string
}

variable "log_analytics_destination_type" {
  description = "Dedicated (resource-specific tables) or AzureDiagnostics. null keeps the service default; some resource types (e.g. Key Vault) reject this setting."
  type        = string
  default     = null
}

variable "log_category_groups" {
  description = "Log category groups to enable."
  type        = list(string)
  default     = ["allLogs"]
}

variable "log_categories" {
  description = "Individual log categories to enable (combine with log_category_groups = [] for a curated set)."
  type        = list(string)
  default     = []
}

variable "metric_categories" {
  description = "Metric categories to enable."
  type        = list(string)
  default     = ["AllMetrics"]
}
