terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 5.14"
    }
  }
}

# [OPS] Every resource ships its logs and metrics to the single platform Log Analytics workspace.
resource "azurerm_monitor_diagnostic_setting" "this" {
  name                           = var.name
  target_resource_id             = var.target_resource_id
  log_analytics_workspace_id     = var.log_analytics_workspace_id
  log_analytics_destination_type = var.log_analytics_destination_type

  # [OPS] Category groups (allLogs) pick up log categories the service adds later without a code change.
  dynamic "enabled_log" {
    for_each = toset(var.log_category_groups)
    content {
      category_group = enabled_log.value
    }
  }

  # [COST] Explicit categories where allLogs would be too noisy (e.g. AKS: kube-audit-admin instead of kube-audit).
  dynamic "enabled_log" {
    for_each = toset(var.log_categories)
    content {
      category = enabled_log.value
    }
  }

  # AzureRM 5.x syntax: the `metric` block was removed in favour of `enabled_metric`.
  dynamic "enabled_metric" {
    for_each = toset(var.metric_categories)
    content {
      category = enabled_metric.value
    }
  }
}
