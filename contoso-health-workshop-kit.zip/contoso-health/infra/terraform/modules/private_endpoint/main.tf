terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 5.14"
    }
  }
}

resource "azurerm_private_endpoint" "this" {
  name                = var.name
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = var.subnet_id
  # [OPS] Predictable NIC name instead of the auto-generated "<endpoint>.nic.<guid>".
  custom_network_interface_name = "nic-${var.name}"
  tags                          = var.tags

  private_service_connection {
    name                           = var.name
    private_connection_resource_id = var.private_connection_resource_id
    subresource_names              = var.subresource_names
    # [SEC] Auto-approved: the same deployer owns the endpoint and the target resource.
    is_manual_connection = false
  }

  # [OPS] The zone group creates and deletes the A record(s) in the hub zone together with the endpoint.
  private_dns_zone_group {
    name                 = "default"
    private_dns_zone_ids = var.private_dns_zone_ids
  }
}
