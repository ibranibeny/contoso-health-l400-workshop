output "id" {
  description = "Resource ID of the private endpoint."
  value       = azurerm_private_endpoint.this.id
}

output "name" {
  description = "Name of the private endpoint."
  value       = azurerm_private_endpoint.this.name
}

output "private_ip_address" {
  description = "Private IP address allocated to the endpoint in snet-private-endpoints."
  value       = azurerm_private_endpoint.this.private_service_connection[0].private_ip_address
}
