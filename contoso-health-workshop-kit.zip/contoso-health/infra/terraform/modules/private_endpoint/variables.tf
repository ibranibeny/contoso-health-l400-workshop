variable "name" {
  description = "Private endpoint name (convention: pe-<target resource name>)."
  type        = string
}

variable "location" {
  description = "Azure region; must match the region of the subnet's VNet."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group of the private endpoint (it may differ from the subnet's resource group)."
  type        = string
}

variable "subnet_id" {
  description = "Resource ID of snet-private-endpoints in the spoke VNet."
  type        = string
}

variable "private_connection_resource_id" {
  description = "Resource ID of the PaaS resource exposed through the endpoint."
  type        = string
}

variable "subresource_names" {
  description = "Private link group IDs, e.g. [\"vault\"], [\"sites\"], [\"postgresqlServer\"], [\"redisEnterprise\"], [\"registry\"]."
  type        = list(string)
}

variable "private_dns_zone_ids" {
  description = "Resource IDs of the hub private DNS zones that receive the endpoint's A records."
  type        = list(string)
}

variable "tags" {
  description = "Tags applied to the private endpoint."
  type        = map(string)
  default     = {}
}
