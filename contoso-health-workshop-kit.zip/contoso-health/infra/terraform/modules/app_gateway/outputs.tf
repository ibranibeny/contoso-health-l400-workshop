output "id" {
  description = "Resource ID of the Application Gateway."
  value       = azurerm_application_gateway.this.id
}

output "name" {
  description = "Name of the Application Gateway."
  value       = azurerm_application_gateway.this.name
}

output "public_ip_address" {
  description = "Public IP address of the gateway frontend."
  value       = azurerm_public_ip.this.ip_address
}

output "waf_policy_id" {
  description = "Resource ID of the WAF policy."
  value       = azurerm_web_application_firewall_policy.this.id
}
