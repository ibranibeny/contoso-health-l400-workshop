variable "name" {
  description = "Application Gateway name (agw-ch-<env>-idc)."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group of the gateway, its public IP and WAF policy."
  type        = string
}

variable "public_ip_name" {
  description = "Name of the frontend public IP (pip-agw-ch-<env>-idc)."
  type        = string
}

variable "waf_policy_name" {
  description = "Name of the WAF policy."
  type        = string
}

variable "zones" {
  description = "Availability zones of the gateway and its public IP."
  type        = list(string)
  default     = ["1", "2", "3"]
}

variable "subnet_id" {
  description = "Resource ID of snet-appgw (dedicated subnet)."
  type        = string
}

variable "identity_id" {
  description = "Resource ID of the gateway's user-assigned identity (id-ch-agw-<env>)."
  type        = string
}

variable "min_capacity" {
  description = "Autoscale minimum instance count (lab 1, prod 2)."
  type        = number
}

variable "max_capacity" {
  description = "Autoscale maximum instance count."
  type        = number
  default     = 10
}

variable "appsvc_backend_fqdn" {
  description = "Default host name of the web app (backend of the :80/:443 listener)."
  type        = string
}

variable "aks_backend_ip" {
  description = "Static private IP of the AKS internal load balancer Service \"web\" (backend of the :8080 listener)."
  type        = string
}

variable "tls_certificate_secret_id" {
  description = "Versionless Key Vault secret ID of the TLS certificate. Empty = HTTP only (lab only)."
  type        = string
  default     = ""
}

variable "log_analytics_workspace_id" {
  description = "Resource ID of the platform Log Analytics workspace."
  type        = string
}

variable "waf_mode" {
  description = "WAF policy mode: Prevention (blocks) or Detection (logs only)."
  type        = string
  default     = "Prevention"

  validation {
    condition     = contains(["Prevention", "Detection"], var.waf_mode)
    error_message = "waf_mode must be Prevention or Detection."
  }
}

variable "waf_claims_rate_limit_per_minute" {
  description = "POST requests to /api/claims allowed per client IP and minute before the WAF blocks them (custom rule RateLimitClaimSubmissions)."
  type        = number
  default     = 60

  validation {
    condition     = var.waf_claims_rate_limit_per_minute >= 1 && floor(var.waf_claims_rate_limit_per_minute) == var.waf_claims_rate_limit_per_minute
    error_message = "waf_claims_rate_limit_per_minute must be a whole number of at least 1."
  }
}

variable "waf_block_ops_api" {
  description = "Add the custom rule BlockOpsApiFromInternet: block /api/ops/* at the edge."
  type        = bool
  default     = false
}

variable "waf_allowed_country_codes" {
  description = "ISO 3166-1 alpha-2 country codes the traffic is expected from; requests from other countries are logged, not blocked (custom rule LogOutsideAllowedCountries)."
  type        = list(string)
  default     = ["ID"]

  validation {
    condition     = length(var.waf_allowed_country_codes) > 0
    error_message = "waf_allowed_country_codes needs at least one country code."
  }
}

variable "tags" {
  description = "Tags applied to every resource of the module."
  type        = map(string)
  default     = {}
}
