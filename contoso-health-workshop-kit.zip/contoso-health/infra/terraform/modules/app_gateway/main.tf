terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 5.14"
    }
  }
}

locals {
  # lab only: without tls_certificate_secret_id every public listener is plain HTTP. Production must set the
  # Key Vault secret ID so :443 terminates TLS and :80 only redirects to it.
  https_enabled = var.tls_certificate_secret_id != ""

  frontend_ip_configuration_name = "fe-public"

  # Component names mirror the Bicep twin (portal/runbook parity).
  frontend_ports = [
    { name = "port-80", port = 80, enabled = true },
    { name = "port-8080", port = 8080, enabled = true },
    { name = "port-443", port = 443, enabled = local.https_enabled },
  ]

  http_listeners = [
    { name = "listener-http-80", port_name = "port-80", protocol = "Http", certificate = "", enabled = true },
    { name = "listener-http-8080", port_name = "port-8080", protocol = "Http", certificate = "", enabled = true },
    { name = "listener-https-443", port_name = "port-443", protocol = "Https", certificate = "cert-key-vault", enabled = local.https_enabled },
  ]

  routing_rules = [
    # :80 (or :443 once a certificate is configured) -> App Service web app through its private endpoint.
    { name = "rule-appservice-web", priority = 100, listener = local.https_enabled ? "listener-https-443" : "listener-http-80", pool = "pool-appservice-web", settings = "settings-appservice-https", redirect = "", enabled = true },
    # :8080 -> static private IP of the AKS internal load balancer Service "web".
    { name = "rule-aks-ilb", priority = 200, listener = "listener-http-8080", pool = "pool-aks-ilb", settings = "settings-aks-http", redirect = "", enabled = true },
    # [SEC] With TLS configured, plain HTTP only redirects to HTTPS.
    { name = "rule-http-to-https", priority = 110, listener = "listener-http-80", pool = "", settings = "", redirect = "redirect-http-to-https", enabled = local.https_enabled },
  ]
}

resource "azurerm_web_application_firewall_policy" "this" {
  name                = var.waf_policy_name
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  policy_settings {
    enabled = true
    # [SEC] Prevention blocks; tune false positives with exclusions, never by leaving production in Detection.
    mode = var.waf_mode
    # [SEC] The portal and API accept only small JSON bodies: inspect all of it and reject anything larger.
    request_body_check               = true
    request_body_inspect_limit_in_kb = 128
    max_request_body_size_in_kb      = 128
    request_body_enforcement         = true
    file_upload_limit_in_mb          = 100
    # Set explicitly: AzureRM 5.0 changed this default and would otherwise show drift.
    file_upload_enforcement = true

    log_scrubbing {
      enabled = true

      # [SEC] The claim note is free-text health information and must not be copied into WAF logs.
      rule {
        enabled                 = true
        match_variable          = "RequestJSONArgNames"
        selector_match_operator = "Equals"
        # Case-sensitive; the JSON key the API accepts.
        selector = "note"
      }
    }
  }

  # WAF custom rules: evaluated before the managed rules, lowest priority first. A Block answers with HTTP 403.
  # [SEC] Defence in depth at the edge, per client IP (sliding window, counted per WAF policy association). The API's
  # own per-member limit (5 claims a minute, HTTP 429) still applies behind it.
  custom_rules {
    name                 = "RateLimitClaimSubmissions"
    priority             = 10
    enabled              = true
    rule_type            = "RateLimitRule"
    rate_limit_duration  = "OneMin"
    rate_limit_threshold = var.waf_claims_rate_limit_per_minute
    group_rate_limit_by  = "ClientAddr"
    action               = "Block"

    match_conditions {
      match_variables {
        variable_name = "RequestMethod"
      }
      operator     = "Equal"
      match_values = ["POST"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestUri"
      }
      operator     = "BeginsWith"
      match_values = ["/api/claims"]
      transforms   = ["Lowercase"]
    }
  }

  # [SEC] The portal and API only use GET, HEAD and POST: block every other method.
  custom_rules {
    name      = "BlockUnexpectedMethods"
    priority  = 20
    enabled   = true
    rule_type = "MatchRule"
    action    = "Block"

    match_conditions {
      match_variables {
        variable_name = "RequestMethod"
      }
      operator = "Equal"
      # Matches any method NOT in the list (ARM spells this property negationConditon).
      negation_condition = true
      match_values       = ["GET", "HEAD", "POST"]
    }
  }

  # [SEC] Optional (waf_block_ops_api): the claims-desk endpoints (/api/ops/*) are not reachable from the internet.
  dynamic "custom_rules" {
    for_each = var.waf_block_ops_api ? ["BlockOpsApiFromInternet"] : []
    content {
      name      = custom_rules.value
      priority  = 30
      enabled   = true
      rule_type = "MatchRule"
      action    = "Block"

      match_conditions {
        match_variables {
          variable_name = "RequestUri"
        }
        operator     = "BeginsWith"
        match_values = ["/api/ops/"]
        transforms   = ["Lowercase"]
      }
    }
  }

  # [SEC] Log only: workshop participants and partners connect from anywhere; switching to Block is a business and
  # legal decision. Learn recommends adding "ZZ" (addresses not yet mapped to a country) before a geo rule ever blocks.
  custom_rules {
    name      = "LogOutsideAllowedCountries"
    priority  = 40
    enabled   = true
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "RemoteAddr"
      }
      operator = "GeoMatch"
      # Matches every country NOT in waf_allowed_country_codes.
      negation_condition = true
      match_values       = var.waf_allowed_country_codes
    }
  }

  # No exclusions on purpose: the workshop adds a per-rule exclusion as an exercise.
  managed_rules {
    # [SEC] DRS 2.2 is the recommended managed rule set for new WAF policies.
    managed_rule_set {
      type    = "Microsoft_DefaultRuleSet"
      version = "2.2"
    }

    # [SEC] Blocks known-bad bots and scanners before they reach the app.
    managed_rule_set {
      type    = "Microsoft_BotManagerRuleSet"
      version = "1.1"
    }
  }
}

resource "azurerm_public_ip" "this" {
  name                = var.public_ip_name
  location            = var.location
  resource_group_name = var.resource_group_name
  allocation_method   = "Static"
  sku                 = "Standard"
  # [REL] Zone-redundant frontend IP, same zones as the gateway instances.
  zones = var.zones
  tags  = var.tags
}

resource "azurerm_application_gateway" "this" {
  name                = var.name
  location            = var.location
  resource_group_name = var.resource_group_name
  # [REL] Instances spread across the three availability zones.
  zones = var.zones
  # [PERF] AzureRM 5.x: no longer computed, so it is set explicitly.
  http2_enabled = true
  # [SEC] WAF policy attached at gateway level (applies to every listener).
  firewall_policy_id                = azurerm_web_application_firewall_policy.this.id
  force_firewall_policy_association = true
  tags                              = var.tags

  sku {
    name = "WAF_v2"
    tier = "WAF_v2"
  }

  # [COST]/[PERF] Warm minimum instances (lab 1, prod 2) and burst headroom up to max_capacity.
  autoscale_configuration {
    min_capacity = var.min_capacity
    max_capacity = var.max_capacity
  }

  # [SEC] Reads the TLS certificate from Key Vault with this identity (Key Vault Secrets User).
  identity {
    type         = "UserAssigned"
    identity_ids = [var.identity_id]
  }

  # [SEC] TLS 1.2+ with modern cipher suites only.
  ssl_policy {
    policy_type = "Predefined"
    policy_name = "AppGwSslPolicy20220101"
  }

  gateway_ip_configuration {
    name      = "gwipc-appgw"
    subnet_id = var.subnet_id
  }

  frontend_ip_configuration {
    name                 = local.frontend_ip_configuration_name
    public_ip_address_id = azurerm_public_ip.this.id
  }

  dynamic "frontend_port" {
    for_each = { for p in local.frontend_ports : p.name => p.port if p.enabled }
    content {
      name = frontend_port.key
      port = frontend_port.value
    }
  }

  dynamic "ssl_certificate" {
    for_each = local.https_enabled ? [var.tls_certificate_secret_id] : []
    content {
      name = "cert-key-vault"
      # [SEC] Versionless secret ID: App Gateway picks up renewed certificates automatically.
      key_vault_secret_id = ssl_certificate.value
    }
  }

  # [SEC] FQDN of the web app: resolved through the private DNS zone to its private endpoint.
  backend_address_pool {
    name  = "pool-appservice-web"
    fqdns = [var.appsvc_backend_fqdn]
  }

  backend_address_pool {
    name         = "pool-aks-ilb"
    ip_addresses = [var.aks_backend_ip]
  }

  # [SEC] End-to-end TLS to App Service; the Host header must be the app's host name.
  backend_http_settings {
    name                                = "settings-appservice-https"
    port                                = 443
    protocol                            = "Https"
    cookie_based_affinity               = "Disabled"
    request_timeout                     = 30
    pick_host_name_from_backend_address = true
    probe_name                          = "probe-appservice"
  }

  # Private hop inside the VNet; add TLS on the Service when the data classification demands it.
  backend_http_settings {
    name                  = "settings-aks-http"
    port                  = 80
    protocol              = "Http"
    cookie_based_affinity = "Disabled"
    request_timeout       = 30
    probe_name            = "probe-aks"
  }

  probe {
    name                                      = "probe-appservice"
    protocol                                  = "Https"
    path                                      = "/healthz"
    interval                                  = 30
    timeout                                   = 30
    unhealthy_threshold                       = 3
    pick_host_name_from_backend_http_settings = true

    match {
      status_code = ["200-399"]
    }
  }

  probe {
    name                = "probe-aks"
    protocol            = "Http"
    path                = "/healthz"
    host                = "127.0.0.1"
    interval            = 30
    timeout             = 30
    unhealthy_threshold = 3

    match {
      status_code = ["200-399"]
    }
  }

  dynamic "http_listener" {
    for_each = { for l in local.http_listeners : l.name => l if l.enabled }
    content {
      name                           = http_listener.key
      frontend_ip_configuration_name = local.frontend_ip_configuration_name
      frontend_port_name             = http_listener.value.port_name
      protocol                       = http_listener.value.protocol
      ssl_certificate_name           = http_listener.value.certificate == "" ? null : http_listener.value.certificate
    }
  }

  dynamic "redirect_configuration" {
    for_each = local.https_enabled ? ["redirect-http-to-https"] : []
    content {
      name                 = redirect_configuration.value
      redirect_type        = "Permanent"
      target_listener_name = "listener-https-443"
      include_path         = true
      include_query_string = true
    }
  }

  dynamic "request_routing_rule" {
    for_each = { for r in local.routing_rules : r.name => r if r.enabled }
    content {
      name                        = request_routing_rule.key
      priority                    = request_routing_rule.value.priority
      rule_type                   = "Basic"
      http_listener_name          = request_routing_rule.value.listener
      backend_address_pool_name   = request_routing_rule.value.pool == "" ? null : request_routing_rule.value.pool
      backend_http_settings_name  = request_routing_rule.value.settings == "" ? null : request_routing_rule.value.settings
      redirect_configuration_name = request_routing_rule.value.redirect == "" ? null : request_routing_rule.value.redirect
    }
  }
}

# [OPS] Access, performance and WAF (firewall) logs plus all metrics (UnhealthyHostCount drives an alert).
module "diagnostics" {
  source = "../diagnostic_setting"

  target_resource_id         = azurerm_application_gateway.this.id
  log_analytics_workspace_id = var.log_analytics_workspace_id
  # [OPS] Resource-specific tables AGWAccessLogs, AGWPerformanceLogs and AGWFirewallLogs instead of AzureDiagnostics.
  # The performance log exists only for the v1 SKU, so on WAF_v2 use the metrics for performance data.
  log_analytics_destination_type = "Dedicated"
}
