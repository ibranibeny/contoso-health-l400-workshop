terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 5.14"
    }
  }
}

resource "azurerm_linux_web_app" "this" {
  name                = var.name
  location            = var.location
  resource_group_name = var.resource_group_name
  service_plan_id     = var.service_plan_id
  https_only          = true
  # [PERF] Stateless Node.js app: no ARR affinity cookie, requests spread across all zone-redundant instances.
  client_affinity_enabled = false
  # Learn N-tier pattern: the public endpoint stays enabled for the SCM (deploy) site; the main site denies
  # all public traffic below, and access restrictions never apply to private endpoint traffic.
  public_network_access_enabled = true
  # [SEC] Regional VNet integration: outbound calls to PostgreSQL / Redis / Key Vault use private endpoints.
  virtual_network_subnet_id = var.virtual_network_subnet_id
  # [SEC] Key Vault references resolve with the user-assigned identity (no system-assigned identity exists).
  key_vault_reference_identity_id = var.identity_id
  # [SEC] Basic (FTP / Web Deploy) publishing credentials disabled: only Entra principals (GitHub OIDC) can deploy.
  ftp_publish_basic_authentication_enabled       = false
  webdeploy_publish_basic_authentication_enabled = false
  app_settings                                   = var.app_settings
  tags                                           = var.tags

  identity {
    type         = "UserAssigned"
    identity_ids = [var.identity_id]
  }

  site_config {
    # [REL] Keeps the worker process warm: no cold start after idle periods.
    always_on               = true
    http2_enabled           = true
    minimum_tls_version     = "1.2"
    scm_minimum_tls_version = "1.2"
    ftps_state              = "Disabled"
    app_command_line        = var.app_command_line
    # [REL] Readiness, not liveness: /readyz answers 5xx when a required dependency is down (api: PostgreSQL, Redis
    # optional; web: the api), so App Service takes the instance out of rotation and replaces it (>= 2 instances).
    health_check_path = var.health_check_path
    # AzureRM requires the eviction time together with the path; 10 minutes is the platform default.
    health_check_eviction_time_in_min = 10
    # [SEC] Main site: deny all public traffic (App Gateway and the web app reach this app via private endpoints).
    ip_restriction_default_action = "Deny"
    # [SEC] SCM site: Allow in lab (GitHub-hosted runners + Entra-only auth), Deny in prod (self-hosted runner in the VNet).
    scm_ip_restriction_default_action = var.scm_ip_restriction_default_action
    scm_use_main_ip_restriction       = false
    # [SEC] Route ALL outbound traffic through the VNet (NAT gateway or hub firewall). AzureRM 5.x exposes only
    # vnet_route_all_enabled (siteConfig.vnetRouteAllEnabled), the legacy equivalent of outboundVnetRouting.allTraffic.
    vnet_route_all_enabled = true

    application_stack {
      node_version = var.node_version
    }
  }
}

module "private_endpoint" {
  source = "../private_endpoint"

  name                           = "pe-${var.name}"
  location                       = var.location
  resource_group_name            = var.resource_group_name
  subnet_id                      = var.private_endpoint_subnet_id
  private_connection_resource_id = azurerm_linux_web_app.this.id
  subresource_names              = ["sites"]
  private_dns_zone_ids           = [var.private_dns_zone_id]
  tags                           = var.tags
}

module "diagnostics" {
  source = "../diagnostic_setting"

  target_resource_id         = azurerm_linux_web_app.this.id
  log_analytics_workspace_id = var.log_analytics_workspace_id
}
