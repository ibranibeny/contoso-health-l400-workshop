output "id" {
  description = "Resource ID of the web app."
  value       = azurerm_linux_web_app.this.id
}

output "name" {
  description = "Name of the web app."
  value       = azurerm_linux_web_app.this.name
}

output "default_hostname" {
  description = "Default host name (<name>.azurewebsites.net or the unique default host name)."
  value       = azurerm_linux_web_app.this.default_hostname
}

output "private_endpoint_ip" {
  description = "Private IP of the app's private endpoint."
  value       = module.private_endpoint.private_ip_address
}
