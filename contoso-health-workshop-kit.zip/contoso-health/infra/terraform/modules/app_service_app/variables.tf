variable "name" {
  description = "Web app name (app-ch-<web|api>-<env>-<sfx>, globally unique)."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group of the web app."
  type        = string
}

variable "service_plan_id" {
  description = "Resource ID of the zone-redundant Linux App Service plan."
  type        = string
}

variable "identity_id" {
  description = "Resource ID of the user-assigned managed identity of the app."
  type        = string
}

variable "node_version" {
  description = "Node.js runtime of the Linux app (NODE|24-lts)."
  type        = string
  default     = "24-lts"
}

variable "app_command_line" {
  description = "Startup command (siteConfig.appCommandLine)."
  type        = string
}

variable "app_settings" {
  description = "Application settings (environment variables read by the app)."
  type        = map(string)
}

variable "health_check_path" {
  description = "App Service health check path: the deep readiness endpoint (5xx when a required dependency is down), not the shallow /healthz liveness path."
  type        = string
  default     = "/readyz"
}

variable "scm_ip_restriction_default_action" {
  description = "Default action of the SCM (deployment) site access restrictions: Allow (lab) or Deny (prod)."
  type        = string

  validation {
    condition     = contains(["Allow", "Deny"], var.scm_ip_restriction_default_action)
    error_message = "scm_ip_restriction_default_action must be Allow or Deny."
  }
}

variable "virtual_network_subnet_id" {
  description = "Resource ID of snet-app-integration (delegated to Microsoft.Web/serverFarms)."
  type        = string
}

variable "private_endpoint_subnet_id" {
  description = "Resource ID of snet-private-endpoints."
  type        = string
}

variable "private_dns_zone_id" {
  description = "Resource ID of the hub privatelink.azurewebsites.net zone."
  type        = string
}

variable "log_analytics_workspace_id" {
  description = "Resource ID of the platform Log Analytics workspace."
  type        = string
}

variable "tags" {
  description = "Tags applied to every resource of the module."
  type        = map(string)
  default     = {}
}
