# Contoso Health — Terraform (AzureRM 5.x)

Terraform twin of [`infra/bicep`](../bicep): the same three stacks, resource names, address plan, properties
and **identical (camelCase) output names**, so scripts and workflows work with either flavour
(`IAC_TOOL=bicep|terraform`).

| | |
|---|---|
| Terraform | `>= 1.9` (CI: 1.17.x via `hashicorp/setup-terraform@v4`, `terraform_wrapper: false`) |
| Providers | `hashicorp/azurerm ~> 5.14`, `Azure/azapi ~> 2.13` (aks stack only, optional Gateway API) |
| Region | `indonesiacentral` (3 zones, no paired region) |
| State | `azurerm` backend, Entra ID auth (`use_azuread_auth = true`), key `ch/<stack>/<env>.tfstate` |

```text
infra/terraform/
├── platform/   subscription scope: hub VNet + private DNS zones, Log Analytics, optional Firewall/Bastion/DDoS,
│               Defender plans, vended RGs (rg-ch-<env>-idc, rg-ch-aks-<env>-idc) + policy + RBAC
├── workload/   INTO rg-ch-<env>-idc: spoke VNet/NSGs/egress/peering/DNS links, identities, App Insights, Key Vault,
│               App Service (web + api), PostgreSQL, Managed Redis, App Gateway WAF_v2, ops VM, alerts
├── aks/        INTO rg-ch-aks-<env>-idc: AKS (CNI Overlay + Cilium), ACR, workload identity federation,
│               Azure Monitor workspace, optional Gateway API (azapi)
└── modules/    acr, aks_cluster, app_gateway, app_service_app, diagnostic_setting, key_vault, managed_redis,
                ops_vm, postgres, private_endpoint
```

Every stack has `versions.tf`, `providers.tf`, `backend.tf`, `backend-<env>.hcl.example`, `variables.tf`,
`locals.tf`, `main.tf`, `outputs.tf`, `lab.tfvars` and `prod.tfvars`.

## 1. Prerequisites

* Azure CLI signed in (`az login`) to the target subscription. The deploying identity needs **Owner**, or
  **Contributor + Role Based Access Control Administrator**, on the subscription (the stacks create role assignments).
* `scripts/preflight.sh` — registers the resource providers. **AzureRM 5.x registers none by default**
  (`resource_provider_registrations = "none"`), so a fresh subscription fails at apply time without it.
* Per-user values are **never** stored in files; export them as `TF_VAR_*`:

| Variable | Stack | Purpose |
|---|---|---|
| `TF_VAR_subscription_id` | all | target subscription (also seeds the name suffix) — **required** |
| `TF_VAR_workload_team_principal_id` | platform | optional: Contributor on the vended RGs |
| `TF_VAR_ops_ssh_public_key` | workload | optional: without it no ops VM is created (`opsVmName` = `""`) |
| `TF_VAR_alert_email` | workload | optional: action group e-mail receiver |
| `TF_VAR_tls_certificate_secret_id` | workload | optional: Key Vault secret ID → HTTPS listener + 80→443 redirect |
| `TF_VAR_cluster_admin_object_ids` | aks | optional JSON list, e.g. `'["<object-id>"]'` |
| `TF_VAR_deploy_principal_id` | aks | optional: GitHub deploy identity (AcrPush, Cluster User, RBAC Writer on the namespace) |

```bash
export TF_VAR_subscription_id="$(az account show --query id -o tsv)"
export TF_VAR_ops_ssh_public_key="$(cat ~/.ssh/id_ed25519.pub)"
export TF_VAR_cluster_admin_object_ids="[\"$(az ad signed-in-user show --query id -o tsv)\"]"
```

## 2. Bootstrap the remote state (once per subscription)

```bash
# run scripts/bootstrap-github-oidc.sh <owner/repo> <env> first, so id-ch-github-<env> exists
scripts/bootstrap-tfstate.sh lab  [owner/repo]   # storage account + container, Entra-only (shared keys disabled), RBAC for you/CI
scripts/bootstrap-tfstate.sh prod [owner/repo]   # same account; grants id-ch-github-prod and writes the prod files
```

The script writes `backend-<env>.hcl` into `platform/`, `workload/` and `aks/` with the real storage account
name. Do **not** copy the `backend-<env>.hcl.example` files afterwards: they hold the placeholder
`stchtfstate000000` and would overwrite the generated files. Use the examples only if you create the state
storage some other way.

The `backend-*.hcl` files hold no secrets (resource group, storage account, container, key). Authentication is
always Entra ID: your `az login` session locally, the GitHub OIDC token in CI (`ARM_USE_OIDC=true`).

## 3. Deploy — init / plan / apply per stack and environment

Order: **platform → workload → database bootstrap (ops VM) → aks → `scripts/aks-postprovision.sh`**.

```bash
cd infra/terraform

# 1) platform (singleton per subscription: hub names carry no environment)
terraform -chdir=platform init -backend-config=backend-lab.hcl
terraform -chdir=platform plan -var-file=lab.tfvars -out=tfplan
terraform -chdir=platform apply tfplan

# 2) workload (lab)
terraform -chdir=workload init -backend-config=backend-lab.hcl
terraform -chdir=workload plan -var-file=lab.tfvars -out=tfplan
terraform -chdir=workload apply tfplan

# 3) aks (lab)
terraform -chdir=aks init -backend-config=backend-lab.hcl
terraform -chdir=aks plan -var-file=lab.tfvars -out=tfplan
terraform -chdir=aks apply tfplan
```

**prod** in the same subscription:

```bash
# platform: SAME backend (backend-lab.hcl), prod profile = superset (vends lab + prod, adds Firewall/Bastion/Defender)
terraform -chdir=platform plan -var-file=prod.tfvars -out=tfplan && terraform -chdir=platform apply tfplan

# workload / aks: separate state per environment
terraform -chdir=workload init -reconfigure -backend-config=backend-prod.hcl
terraform -chdir=workload plan -var-file=prod.tfvars -out=tfplan && terraform -chdir=workload apply tfplan
terraform -chdir=aks init -reconfigure -backend-config=backend-prod.hcl
terraform -chdir=aks plan -var-file=prod.tfvars -out=tfplan && terraform -chdir=aks apply tfplan
```

Use `backend-prod.hcl` for the platform only when production has its own subscription (then set
`environments = ["prod"]` in `prod.tfvars`). prod requires the platform firewall (`egress_mode = "firewall"`),
and a self-hosted runner inside the VNet (SCM site `Deny`, private API server, private registry).

Outputs (same names as Bicep): `terraform -chdir=workload output -json`, e.g. `webAppName`, `postgresFqdn`,
`aksIngressPrivateIp`, `natGatewayId`; `terraform -chdir=aks output -raw oidcIssuerUrl`.

### Web Application Firewall

WAF policy `waf-ch-<env>-idc` (`modules/app_gateway`) is attached to the whole gateway, so the `:80`/`:443` and `:8080`
listeners share it. Workload variables:

| Variable | lab | prod | Purpose |
|---|---|---|---|
| `waf_mode` | `"Prevention"` | `"Prevention"` | Policy mode (validated: `Prevention` or `Detection`). Tune false positives with exclusions, not with Detection. |
| `waf_claims_rate_limit_per_minute` | `60` | `300` | Custom rule `RateLimitClaimSubmissions`: POSTs to `/api/claims` per client IP and minute (whole number >= 1). |
| `waf_block_ops_api` | `false` | `true` | Adds custom rule `BlockOpsApiFromInternet` (a `dynamic` block): `/api/ops/*` blocked at the edge. |
| `waf_allowed_country_codes` | `["ID"]` | `["ID"]` | Custom rule `LogOutsideAllowedCountries`: requests from other countries are logged, not blocked (at least one code). |

* **Managed rule sets**: `Microsoft_DefaultRuleSet` 2.2 and `Microsoft_BotManagerRuleSet` 1.1 in `waf_mode`. There are no
  exclusions on purpose: adding a per-rule exclusion is a workshop exercise.
* **Request limits**: body inspection on, inspection limit and maximum body size 128 KB, file uploads 100 MB, all enforced. The
  portal and API only accept small JSON bodies.
* **Custom rules** run before the managed rules, lowest priority first. A block returns HTTP 403.

  | Priority | Rule | Matches | Action |
  |---|---|---|---|
  | 10 | `RateLimitClaimSubmissions` | `POST` to a URI that begins with `/api/claims` (lowercased), counted per client IP (`ClientAddr`) over one minute | Block above `waf_claims_rate_limit_per_minute` |
  | 20 | `BlockUnexpectedMethods` | any method except `GET`, `HEAD` and `POST` | Block |
  | 30 | `BlockOpsApiFromInternet` (only when `waf_block_ops_api`) | URI begins with `/api/ops/` (lowercased) | Block |
  | 40 | `LogOutsideAllowedCountries` | client IP (`RemoteAddr`, GeoMatch) outside `waf_allowed_country_codes` | Log |

  The rate limit is defence in depth: the API still allows each member 5 claims a minute (HTTP 429). It counts per client IP in a
  sliding window, so participants behind one venue NAT share it; raise the lab value if the burst exercise gets HTTP 403 instead
  of 429. Blocking by country is a business and legal decision, so the geo rule only logs. Learn recommends adding `ZZ`
  (addresses not yet mapped to a country) to the list before a geo rule ever blocks.
* **Log scrubbing**: the JSON argument `note` (the free-text claim note, which is health information) is masked in the WAF logs
  (`RequestJSONArgNames`, `Equals`; the selector is case-sensitive). Scrubbing needs a matching `Content-Type`, and the API only
  accepts `application/json`.
* **Diagnostics**: `log_analytics_destination_type = "Dedicated"` (passed through `modules/diagnostic_setting`, whose default
  `null` leaves every other resource unchanged) sends the logs to the resource-specific tables `AGWAccessLogs`, `AGWFirewallLogs`
  and `AGWPerformanceLogs` instead of `AzureDiagnostics`. The performance log exists only for the v1 SKU; on WAF_v2 use the metrics.
* **Policy** (platform `guardrails` local, workload RG, Audit): `pa-ch-appgw-waf` (WAF enabled), `pa-ch-appgw-waf-mode` (WAF
  mode, with `modeRequirement = "Prevention"` because the definition defaults to Detection), `pa-ch-appgw-waf-bots` (Bot Manager
  rule set present) and `pa-ch-appgw-waf-body` (request body inspection on).
* **Check**: with `AGW_IP=$(terraform -chdir=workload output -raw appGatewayPublicIp)`, `scripts/waf-test.sh "http://$AGW_IP"`
  (and `:8080`; the deploy workflows run it too) expects HTTP 403 from the gateway for its attack probes and for `DELETE`
  (`BlockUnexpectedMethods`). Add `WAF_RATE_LIMIT=true WAF_RATE_LIMIT_PER_MINUTE=<waf_claims_rate_limit_per_minute>` to test
  the rate limit. Its SQL-injection probe sends the payload in `note`, so search `AGWFirewallLogs` for `******` to see the
  scrubbing; `AGWFirewallLogs | where TimeGenerated > ago(1h) | summarize count() by RuleId, Action` summarises the matches.

## 4. How the stacks find each other (no remote-state coupling)

Stacks never read each other's state. Every cross-stack reference is a **data source looked up by a
deterministic name** built from `env` with the same naming rules as Bicep:

| Consumer | Looks up (data source) | Name |
|---|---|---|
| workload | resource group | `rg-ch-<env>-idc` (vended by platform) |
| workload | hub VNet, `AzureBastionSubnet` | `vnet-ch-hub-idc` in `rg-ch-hub-idc` |
| workload | Log Analytics workspace | `log-ch-idc` in `rg-ch-mgmt-idc` |
| workload | private DNS zones | `privatelink.*` in `rg-ch-hub-idc` |
| workload | firewall (firewall mode) / DDoS plan (optional) | `afw-ch-hub-idc` / `ddos-ch-hub-idc` |
| aks | resource group | `rg-ch-aks-<env>-idc` |
| aks | spoke VNet + subnets | `vnet-ch-<env>-idc` / `snet-aks-nodes`, `snet-aks-apiserver`, `snet-private-endpoints` |
| aks | workload identities | `id-ch-api-<env>`, `id-ch-web-<env>` in `rg-ch-<env>-idc` |
| aks | ACR private DNS zone, Log Analytics | `privatelink.azurecr.io`, `log-ch-idc` |

Why: each pipeline identity needs read access to Azure only, not to another team's state file; plans stay
independent; and a stack can consume resources deployed by the other IaC flavour (the looked-up names carry no
suffix). Writes into another stack's resource group are deliberate and few: the hub→spoke peering and the
spoke's private DNS zone links (hub RG), the Network Contributor assignment on the spoke VNet and the federated
credentials on the workload identities (workload RG).

The globally-unique suffix is `substr(sha1("<subscription_id>-ch-<env>"), 0, 6)` (Bicep:
`take(uniqueString(subscription().id, 'ch', env), 6)`), so **the two flavours produce different `kv-`, `app-`,
`psql-`, `redis-` and `crch` names** — deploy one flavour per environment.

## 5. CI (GitHub Actions, OIDC — no secrets)

```yaml
permissions:
  id-token: write
  contents: read
env:
  ARM_CLIENT_ID: ${{ vars.AZURE_CLIENT_ID }}           # environment variable (lab/prod)
  ARM_TENANT_ID: ${{ vars.AZURE_TENANT_ID }}
  ARM_SUBSCRIPTION_ID: ${{ vars.AZURE_SUBSCRIPTION_ID }}
  ARM_USE_OIDC: "true"                                  # provider AND backend sign in with the GitHub OIDC token
  ARM_USE_AZUREAD: "true"                               # backend: Entra ID for blob access (no storage keys)
  TF_VAR_subscription_id: ${{ vars.AZURE_SUBSCRIPTION_ID }}
steps:
  - uses: actions/checkout@v7
  - uses: hashicorp/setup-terraform@v4
    with:
      terraform_wrapper: false
  - run: |
      terraform -chdir=infra/terraform/workload init -input=false \
        -backend-config="resource_group_name=${{ vars.TFSTATE_RESOURCE_GROUP }}" \
        -backend-config="storage_account_name=${{ vars.TFSTATE_STORAGE_ACCOUNT }}" \
        -backend-config="container_name=${{ vars.TFSTATE_CONTAINER }}" \
        -backend-config="key=ch/workload/lab.tfstate"
      terraform -chdir=infra/terraform/workload plan -input=false -var-file=lab.tfvars -out=tfplan
```

The federated credential subject must match the job (e.g. `...:environment:lab`). The CI identity needs
**Storage Blob Data Contributor** on the state container (granted by `scripts/bootstrap-tfstate.sh`).

## 6. Static checks

```bash
terraform fmt -check -recursive infra/terraform
for s in platform workload aks; do
  terraform -chdir=infra/terraform/$s init -backend=false -input=false && terraform -chdir=infra/terraform/$s validate
done
```

Commit each stack's `.terraform.lock.hcl` after the first `init` (add other platforms with
`terraform providers lock -platform=linux_amd64 -platform=darwin_arm64 -platform=windows_amd64`).

## 7. AzureRM 5.x specifics and differences from the Bicep twin

| Topic | Terraform | Bicep |
|---|---|---|
| App Service "route all" egress | `site_config.vnet_route_all_enabled` (AzureRM 5.x has no `outboundVnetRouting.allTraffic` argument; same effect) | `outboundVnetRouting.allTraffic` |
| Basic publishing credentials | `ftp_/webdeploy_publish_basic_authentication_enabled = false` | `basicPublishingCredentialsPolicies` `ftp`/`scm` |
| Health check | `health_check_path = "/readyz"` (readiness: 5xx when a required dependency is down) + `health_check_eviction_time_in_min = 10` (provider requires both) | `healthCheckPath` |
| AKS maintenance configurations | `maintenance_window_auto_upgrade` / `maintenance_window_node_os` blocks (= `aksManagedAutoUpgradeSchedule` / `aksManagedNodeOSUpgradeSchedule`) | child resources |
| AKS Gateway API | `azapi_update_resource` on `managedClusters@2026-08-01`, only when `enable_gateway_api = true` | `ingressProfile` |
| AKS node auto-provisioning | `node_provisioning_profile { mode = "Manual" }` (required block since 5.0) | omitted |
| Monitoring add-ons | not managed; `lifecycle.ignore_changes = [monitor_metrics, oms_agent]` because `scripts/aks-postprovision.sh` enables them | same split |
| Managed Redis min TLS | no `minimum_tls_version` argument in AzureRM 5.x (service default) | `minimumTlsVersion: '1.2'` |
| Private DNS zone links | `private_dns_zone_id` (5.x removed `private_dns_zone_name` / `resource_group_name`) | child of the zone |
| Diagnostic settings | `enabled_log { category_group = "allLogs" }` + `enabled_metric { category = "AllMetrics" }` (5.x) | `logs` / `metrics` arrays |
| WAF policy | `custom_rules` blocks (`dynamic` for the optional ops rule), `enabled`, `group_rate_limit_by = "ClientAddr"`, `negation_condition`, `policy_settings.log_scrubbing.rule`; no custom block response argument, so neither flavour sets one | `customRules` array (`concat()` for the optional rule), `state`, `groupByUserSession[].groupByVariables[]`, `negationConditon` (sic, ARM spelling), `policySettings.logScrubbing.scrubbingRules` |
| Role assignment names | provider-generated deterministic UUIDv5 (scope, principal, role) | `guid(scope, principalId, roleId)` |

## 8. Troubleshooting

* **aks apply fails with a permission error on `snet-aks-nodes` / `snet-aks-apiserver`**: the Network
  Contributor assignment of `id-ch-aks-<env>` was created seconds earlier and Entra/RBAC had not propagated yet.
  Re-run `terraform apply`; nothing else changes.
* **workload plan fails on `data.azurerm_firewall.hub`** with `egress_mode = "firewall"`: apply the platform with
  `deploy_firewall = true` (prod.tfvars) first.
* **`kv-ch-<env>-<sfx>` already exists (soft-deleted)** after a destroy: recover it (`az keyvault recover`) or wait
  out the 90-day retention — purge protection forbids purging.
* **App Gateway `UnhealthyHostCount` alert in lab** before the aks stack exists: expected, the `:8080` pool points
  at the AKS internal load balancer IP that the `web` Service claims later.

## 9. Destroy

Reverse order: **aks → workload → platform**. Notes:

* Key Vault has purge protection: after a destroy the name `kv-ch-<env>-<sfx>` stays reserved for 90 days
  (recover it with `az keyvault recover --name <name>` before re-applying).
* The platform refuses to delete a vended resource group that still contains resources (AzureRM default).
* Defender plans are subscription-wide: destroying the platform sets them back to Free.
