#!/usr/bin/env bash
# Runs once when the codespace is created.
set -euo pipefail
echo "==> Installing API dependencies"
( cd app/api && if [ -f package-lock.json ]; then npm ci; else npm install --no-audit --no-fund; fi )
echo "==> Installing portal dependencies (React, Vite, TypeScript, Playwright)"
( cd app/web && if [ -f package-lock.json ]; then npm ci; else npm install --no-audit --no-fund; fi )
echo "==> Installing Chromium for the browser tests"
( cd app/web && npx playwright install --with-deps chromium ) || echo "Chromium install skipped: run 'cd app/web && npm run e2e:install' later"
echo "==> Installing GitHub Copilot CLI (npm package @github/copilot)"
npm install -g @github/copilot || echo "Copilot CLI install skipped"
echo "==> Installing the GitHub Agentic Workflows extension (gh aw)"
gh extension install github/gh-aw 2>/dev/null || echo "gh-aw: run 'gh auth login' then 'gh extension install github/gh-aw'"
echo "==> Tool versions"
node --version; az version --query '"azure-cli"' -o tsv || true; az bicep version || true; terraform version | head -1 || true; kubectl version --client=true 2>/dev/null | head -1 || true
cat <<'MSG'

Ready. Next steps:
  cd app/api && npm run dev        # API on :3000 (PostgreSQL + Redis already running)
  cd app/web && npm run dev        # React portal with hot reload on :5173 (BFF on :8080)
  npm test (in app/api or app/web) # unit tests
  npm run test:integration         # API against the sibling PostgreSQL + Redis
  npm run build && npm start       # production build of the portal on :8080 (in app/web)
  npm run e2e                      # browser tests against http://localhost:8080 (in app/web)
MSG
