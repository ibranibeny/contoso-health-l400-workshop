# AGENTS.md

Guidance for AI coding agents (GitHub Copilot and others) working in this repository.

## Start here
- **Rules and architecture**: [.github/copilot-instructions.md](.github/copilot-instructions.md).
  Its guardrails are non-negotiable: `indonesiacentral` only, no secrets, Microsoft Entra ID only,
  private endpoints, Bicep and Terraform kept in sync, never weaken a Well-Architected control.
- **Path-specific rules**: [.github/instructions/](.github/instructions/) (Bicep, Terraform,
  Kubernetes, GitHub Actions, containers, Node.js app, React portal).

## Specialised agents and skills
- Agents in [.github/agents/](.github/agents/): `platform-engineer` (implements infra changes),
  `waf-reviewer` (read-only review), `sre-investigator` (read-only incident analysis).
- Skills in [.github/skills/](.github/skills/): `iac-validate`, `containerize-node-service`,
  `add-azure-monitor-alert`, `waf-review`.

## Build and test
```bash
cd app/api && npm ci && npm run check && npm test     # npm install when no lockfile exists
cd app/web && npm run typecheck && npm test && npm run build   # React portal + BFF
cd app/web && BASE_URL=http://localhost:8080 npm run e2e        # browser tests, stack running
```
Infrastructure, manifests and workflows: follow the `iac-validate` skill. Integration tests need
PostgreSQL and Redis (`docker compose up -d postgres redis`, or the Copilot setup service containers).

## Working agreements
- Small PRs that follow [.github/pull_request_template.md](.github/pull_request_template.md),
  including the WAF checklist and evidence links.
- Never deploy from an agent session: deployments run through the GitHub Actions workflows with
  environment protection.
