# Migrating from GitLab CI, Harbor and Rancher to GitHub Actions, ACR and AKS

Many teams joining the workshop run GitLab CI pipelines that push to Harbor and deploy to
Rancher-managed clusters with long-lived kubeconfig tokens. This guide maps each concept to the
Contoso Health setup: GitHub Actions with OIDC, Azure Container Registry and AKS with Microsoft
Entra ID. The goal is not a one-to-one copy: it is to drop every stored credential on the way.

## 1. GitLab CI -> GitHub Actions

| GitLab CI | GitHub Actions | Notes for this kit |
|-----------|----------------|--------------------|
| `.gitlab-ci.yml` (one file) | `.github/workflows/*.yml` (one file per concern) | `ci.yml`, `iac-validate.yml`, `container-build.yml`, `aks-deploy.yml`, ... |
| `stages:` | jobs + `needs:` | Stages become an explicit dependency graph; jobs without `needs` run in parallel |
| job | `jobs.<id>` with `runs-on` | `runs-on: ubuntu-latest` or a self-hosted/ARC label (prod: in-VNet runner) |
| `image:` | `jobs.<id>.container` or setup actions | The kit uses `actions/setup-node`, `hashicorp/setup-terraform` on the runner |
| `rules:` / `only:` / `except:` | `on:` triggers (+ `branches`, `paths`) and `if:` | `rules: changes:` maps to `on.<event>.paths` |
| `when: manual` | `workflow_dispatch` or an environment with required reviewers | `prod` environment gates deployments |
| `variables:` | `env:` + configuration variables (`vars.*`) | Masked/protected CI variables for cloud credentials disappear: OIDC instead |
| `id_tokens:` (GitLab OIDC) | `permissions: id-token: write` | Issuer `https://token.actions.githubusercontent.com`, audience `api://AzureADTokenExchange` |
| `artifacts:` | `actions/upload-artifact@v7` / `actions/download-artifact@v8` | Build once, promote the same zip (`app-deploy-appservice.yml`) |
| `dependencies:` | `actions/download-artifact` in the consuming job | |
| `cache:` | `actions/cache@v6`, `setup-node` `cache:`, BuildKit `type=gha` | |
| `environment:` (+ `url`) | `environment:` (+ `url`), protection rules, environment variables | `lab`, `prod`, `copilot` |
| `needs:` | `needs:` | Outputs flow through `needs.<job>.outputs.*` |
| `include:` (local/project/remote) | reusable workflows (`on: workflow_call`) and composite actions | `aks-deploy.yml` is called by `container-build.yml` |
| templates, `extends:`, hidden jobs | reusable workflows, composite actions, matrix | |
| `services:` | `jobs.<id>.services` | PostgreSQL 17 + Redis 7.4 in `ci.yml` |
| `parallel: matrix:` | `strategy.matrix` | `app-unit` runs api and web |
| `resource_group:` | `concurrency:` | One deployment per stack/environment at a time |
| `interruptible:` | `concurrency.cancel-in-progress` | PR validation cancels; deployments never do |
| `allow_failure:` | `continue-on-error:` | PSRule runs in report mode first |
| `timeout:` | `timeout-minutes:` | |
| `trigger:` (downstream/multi-project) | `workflow_call`, `workflow_run`, `repository_dispatch` | |
| `CI_JOB_TOKEN` | `GITHUB_TOKEN` with `permissions:` | Read-only by default, widened per job |
| runners with tags | `runs-on` labels, larger runners, Actions Runner Controller | |

### Migrate with GitHub Actions Importer
```bash
gh extension install github/gh-actions-importer
gh actions-importer update          # pulls the importer container image
gh actions-importer configure       # GitLab URL + access token, GitHub token (prompted, never committed)

# 1. Inventory and complexity of all pipelines in a group/namespace
gh actions-importer audit gitlab --output-dir tmp/audit --namespace <group>
# 2. Runner usage forecast
gh actions-importer forecast gitlab --output-dir tmp/forecast --namespace <group>
# 3. Convert one project locally and review the YAML
gh actions-importer dry-run gitlab --output-dir tmp/dry-run --namespace <group> --project <project>
# 4. Open a PR with the converted workflow in the target repository
gh actions-importer migrate gitlab --target-url https://github.com/<owner>/<repo> \
  --output-dir tmp/migrate --namespace <group> --project <project>
```
Treat the generated workflows as a starting point: replace stored cloud credentials with
`azure/login` + OIDC, add `permissions:` and `concurrency:`, and adopt the kit's deploy workflows.

### Migrate the repositories (history, PRs) with GitHub Enterprise Importer
GEI supports GitLab -> GitHub Enterprise Cloud (GA since August 2026) through the `gl2gh` CLI:
```bash
gh gl2gh migrate-repo --help        # lists the source/target options and the token variables it expects
```
Run a dry migration of one project first, then the full batch; protected branches become rulesets
(`scripts/github/apply-governance.sh` applies the kit's `main` ruleset).

## 2. Harbor -> Azure Container Registry

| Harbor | Azure Container Registry (Premium) |
|--------|------------------------------------|
| Projects, robot accounts | Registry + Microsoft Entra RBAC (`AcrPush` for the pipeline identity, `AcrPull` for the AKS kubelet identity). No admin user, no anonymous pull |
| Trivy scanning in Harbor | Microsoft Defender for Containers (vulnerability assessment of pushed and imported images; findings in Defender for Cloud). Keep a scanner in CI if you want PR-time feedback |
| Tag retention rules | `acr purge` in a scheduled ACR task (and retention for untagged manifests) |
| Tag immutability | Lock release tags: `az acr repository update --image <repo>:<tag> --write-enabled false` |
| Replication | Not needed: single region (Indonesia Central has no pair); zone redundancy is automatic in Premium |
| Cosign signatures in Harbor | GitHub artifact attestations (`actions/attest-build-provenance`) pushed to ACR as OCI referrers |
| Proxy cache projects | Import base images into ACR (`NODE_BASE_IMAGE` build argument) |

```bash
ACR=crchlab<sfx>
# Copy images that must keep their history (signatures are re-created by the new pipeline).
# Use a Harbor robot account; read the token interactively, never store it in a file or variable file.
read -rsp "Harbor robot token: " HARBOR_TOKEN; echo
az acr import --name "$ACR" \
  --source harbor.contoso.example/health/contoso-health-api:1.4.2 \
  --image contoso-health-api:1.4.2 \
  --username 'robot$health+migration' --password "$HARBOR_TOKEN"
unset HARBOR_TOKEN

# Retention: delete tags older than 30 days (keep the last 10) and untagged manifests, every Sunday
az acr task create --registry "$ACR" --name purge-weekly --context /dev/null \
  --schedule "0 18 * * 6" \
  --cmd "acr purge --filter 'contoso-health-api:.*' --filter 'contoso-health-web:.*' --ago 30d --keep 10 --untagged"
```
The prod registry is private (`publicNetworkAccess: Disabled`): import into it from an in-VNet
runner, or promote from lab with `az acr import --source <lab-acr>.azurecr.io/<image>@<digest>`.

## 3. Rancher kubeconfig tokens -> Microsoft Entra ID + Azure RBAC + kubelogin + OIDC

| Rancher | AKS in this kit |
|---------|-----------------|
| Long-lived kubeconfig tokens per user | `az aks get-credentials` + `kubelogin convert-kubeconfig -l azurecli`: short-lived Entra tokens, MFA and Conditional Access apply |
| Local admin / service-account tokens in CI | GitHub OIDC -> `azure/login` -> `azure/aks-set-context` with `use-kubelogin`; the cluster has `disableLocalAccounts: true`, so no static admin kubeconfig exists |
| Rancher global/cluster roles | Azure RBAC for Kubernetes: `Azure Kubernetes Service RBAC Cluster Admin` (platform team group, ideally just-in-time with PIM) |
| Rancher projects + project roles | Namespaces + Azure role assignments scoped to `<aks id>/namespaces/<ns>` (the pipeline has `AKS RBAC Writer` on `contoso-health` only) |
| Secrets for app credentials | Workload identity (federated credential per ServiceAccount); Key Vault secrets provider if a secret is unavoidable |
| Rancher-managed ingress (NGINX) | Application Gateway WAF_v2 -> internal load balancer; Gateway API (`approuting-istio`) as the evolution |

Migration steps:
1. Inventory who has access today (Rancher users, groups, cluster/project role bindings, CI tokens).
2. Map each group to an Entra group and a role at the narrowest scope (cluster or namespace).
3. Create the role assignments in IaC (aks stack) or, for cluster admins, as a one-off Owner task.
4. Switch CI to OIDC (`scripts/bootstrap-github-oidc.sh`) and the kit's `Deploy to AKS` workflow.
5. Revoke the Rancher kubeconfig tokens and delete the old CI variables that held them.
6. Verify: `kubectl auth can-i --list -n contoso-health` as each persona; check the sign-in logs.
