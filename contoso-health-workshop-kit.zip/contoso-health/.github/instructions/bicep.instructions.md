---
applyTo: "infra/bicep/**/*.bicep,infra/bicep/**/*.bicepparam,infra/bicep/**/bicepconfig.json"
---

# Bicep (infra/bicep)

## Structure
- Three stacks: `platform` (`targetScope = 'subscription'`), `workload` and `aks` (resource group
  scope). Each has `main.bicep`, `lab.bicepparam` and `prod.bicepparam`.
- Reusable modules live in `infra/bicep/modules/<area>/<name>.bicep` (network, identity, data, web,
  security, monitor, containers, compute). A stack wires modules together; it does not repeat them.
- Cross-stack references use `existing` resources looked up by name (same naming rules), never
  hard-coded resource IDs and never outputs copied by hand.

## API versions (verified for this kit; do not change without checking Microsoft Learn)
| Resource | API version |
|----------|-------------|
| `Microsoft.Web/sites`, `serverfarms` | `2024-11-01` |
| `Microsoft.DBforPostgreSQL/flexibleServers` | `2025-08-01` |
| `Microsoft.Cache/redisEnterprise` (Azure Managed Redis) | `2026-09-01` |
| `Microsoft.Network/*` | `2024-05-01` |
| `Microsoft.ContainerService/managedClusters` | `2026-08-01` |
| `Microsoft.ContainerRegistry/registries`, `Microsoft.KeyVault/vaults` | `2023-07-01` |
| `Microsoft.ManagedIdentity/userAssignedIdentities` | `2023-01-31` |
| `Microsoft.Authorization/roleAssignments` / `policyAssignments` | `2022-04-01` / `2023-04-01` |
| `Microsoft.Insights/diagnosticSettings` | `2021-05-01-preview` |
| `Microsoft.Monitor/accounts` | `2023-04-03` |
| `Microsoft.Insights/metricAlerts` | `2018-03-01` |

## Rules
- Every parameter has `@description`; use `@allowed` / `@minLength` where it prevents mistakes.
  There are no secrets, so there are no `@secure()` parameters; `secure-secrets-in-params` is an
  error in `bicepconfig.json`. Never disable a linter rule to make a build pass: fix the finding.
- Deploy-time values live in the `.bicepparam` files; values that differ per person come from
  `readEnvironmentVariable('NAME', '')` (SSH public key, alert e-mail, principal IDs).
- Names are built once in variables at the top of `main.bicep`. The unique suffix
  `take(uniqueString(subscription().id, 'ch', env), 6)` is used only for globally unique names.
- Pass the `tags` object to every module and resource.
- Role assignments: `name: guid(scope, principalId, roleId)`, `principalType: 'ServicePrincipal'`.
  Only assign roles the deploy identity is allowed to delegate (AcrPull, AcrPush, Key Vault Secrets
  User, Monitoring Metrics Publisher, Network Contributor, Website Contributor, AKS RBAC Writer,
  AKS Cluster User Role): anything else is rejected by its ABAC condition.
- Outputs keep their exact names: workflows and scripts depend on them. Never output secrets.
- Data services: `publicNetworkAccess: 'Disabled'` + private endpoint + DNS zone group pointing at the
  hub private DNS zone; Entra-only authentication.
- Diagnostic settings (`categoryGroup: 'allLogs'` + `AllMetrics` where supported) to the platform
  Log Analytics workspace for every resource type that supports them.
- One-line WHY comment with a pillar tag on every non-obvious property.

## Deploy and preview (never from a Copilot session)
```bash
az deployment group what-if --resource-group rg-ch-lab-idc --template-file infra/bicep/workload/main.bicep --parameters infra/bicep/workload/lab.bicepparam
# deployments run through the "Infra deploy" workflow (deployment stacks: az stack sub|group create)
```

## Validate
```bash
az bicep build --file infra/bicep/<stack>/main.bicep --stdout > /dev/null
az bicep lint --file infra/bicep/<stack>/main.bicep
az bicep build-params --file infra/bicep/<stack>/lab.bicepparam --stdout > /dev/null
```

Mirror every change in `infra/terraform/<stack>` (same names, values, tags and outputs).
