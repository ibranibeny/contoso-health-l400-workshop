---
applyTo: "app/**/*.js,app/**/package.json,app/**/*.sql"
---

# Node.js application (app/api, app/web)

## Platform
- Node.js 24, ES modules (`"type": "module"`), no web framework. Tests use `node:test` and
  `node:assert/strict`.
- Keep runtime dependencies minimal: the API uses `pg`, `redis`, `@redis/entraid`, `@azure/identity`
  (+ optional `@azure/monitor-opentelemetry`); the web BFF (`app/web/server.js`) has none, and React
  is compiled into `dist/` at build time. Every new dependency is a supply-chain decision: justify it
  in the PR. React-specific rules: `.github/instructions/react-web.instructions.md`.

## Configuration and identity
- Settings come only from environment variables through `app/api/src/config.js` (same build on a
  laptop, App Service and AKS). Add new settings there with a safe default.
- Azure authentication goes through `app/api/src/azure/credential.js`: workload identity on AKS,
  user-assigned managed identity on App Service, the developer's sign-in locally. PostgreSQL and Redis
  receive Entra tokens. Never add passwords or access keys for Azure services.

## Data and cache
- Parameterised SQL only. Schema changes are new forward-only files in `app/api/db/migrations`
  (`NNN_description.sql`); never edit a migration that has shipped. Migrations run under an advisory
  lock, so several replicas can start at once.
- Cache-aside with keys `ch:v1:*` and TTLs from configuration. The API must keep serving from
  PostgreSQL when Redis is down (the resilient wrapper reports `x-cache: BYPASS`).
- Preserve `Idempotency-Key` semantics (201 then 200 + `idempotent-replay`) and the per-member rate
  limit; both are part of the smoke test.

## HTTP behaviour
- Validate input; throw the helpers from `src/http/errors.js` (`badRequest`, `notFound`, ...); errors
  are JSON with a `requestId`.
- `/healthz` = the process is alive (no dependency checks); `/readyz` = PostgreSQL is reachable
  (Redis is optional). Keep these meanings: Kubernetes, App Service and Application Gateway rely on them.
- Structured JSON logs; never log tokens, connection details or personal data.

## Validate
```bash
cd app/api && npm run check && npm test && npm run test:integration
cd app/web && npm run typecheck && npm test && npm run build
```
