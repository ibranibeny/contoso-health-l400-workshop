---
applyTo: "app/web/src/**,app/web/index.html,app/web/vite.config.ts,app/web/tsconfig*.json,app/web/e2e/**"
---

# React member portal (app/web)

## Stack
- React 19 with function components and hooks, TypeScript in strict mode, built by Vite into `dist/`.
  Mount with `createRoot` (`src/main.tsx`). No UI framework, state library or router package: hash
  routes (`#/coverage`) live in `src/lib/route.ts`. Adding a dependency needs a reason in the PR.
- Versions are pinned to the ones the kit was tested with; upgrades come through Dependabot and CI.

## Talking to the API
- Every call goes through `apiFetch` in `src/lib/api.ts`, with a type from `src/lib/types.ts`. It
  returns the body plus what the platform added (status, latency, `x-cache`, instances, replay,
  `Retry-After`, `x-request-id`); pages show these with `RequestMeta`. Never call `fetch` directly.
- Relative URLs only (`/api/...`): the BFF proxies them. No API base URL, key or token in the bundle.
- A 403 that is not JSON came from the WAF: `apiFetch` turns it into the error code `blocked`.
- Claims: one `Idempotency-Key` per logical submission (`newIdempotencyKey()`); a retry reuses it.

## Security and accessibility
- The BFF sends `Content-Security-Policy: script-src 'self'; style-src 'self'`. No inline `<script>`,
  no inline `style` attributes in `index.html`, no `dangerouslySetInnerHTML`. React's `style` prop is
  fine (it sets styles through the DOM, which CSP allows).
- Every input has a `<label>`; results and errors are announced (`aria-live`, `role="alert"`); every
  action is reachable by keyboard.

## Tests
- Pure logic in `src/lib/*.ts` has unit tests next to it (`*.test.ts`), run by `node --test`: Node 24
  strips the types, so use only erasable TypeScript syntax (no `enum`, no parameter properties) and
  import with the `.ts` extension.
- Browser behaviour is covered by `e2e/portal.e2e.test.js` (Playwright + `node:test`), which also
  verifies every deployment. Select elements by role, label or `data-testid`, never by CSS class.
- Before a PR: `npm run typecheck && npm test && npm run build`; with the stack running, `npm run e2e`.
