---
applyTo: "**/Dockerfile,**/*.dockerfile,**/.dockerignore,docker-compose.yml,.devcontainer/**"
---

# Container images and local stack

## Dockerfiles
- Base image through a build argument: `ARG NODE_IMAGE=node:24-slim` + `FROM ${NODE_IMAGE}`, so CI can
  use a copy imported into ACR (`NODE_BASE_IMAGE` repository variable). Stay on the Node.js 24 LTS line.
- Multi-stage when there are dependencies: `npm ci --omit=dev` in a `deps` stage (needs a committed
  `package-lock.json`); the runtime stage copies only `node_modules`, `package.json` and the source
  folders it runs.
- The web image builds the React app in a `build` stage (dev dependencies, `typecheck`, unit tests,
  `vite build`); the runtime stage copies only `server.js`, `package.json` and `dist/`, with no
  `node_modules` at all.
- Run as the unprivileged `node` user (uid 1000, matching `runAsUser: 1000` in Kubernetes). Code stays
  owned by root, so the process cannot modify itself.
- Exec-form `CMD` so `node` is PID 1 and receives SIGTERM for graceful shutdown.
- The image must work with a read-only root filesystem: write only to `/tmp`.
- OCI labels from the `APP_VERSION` and `GIT_SHA` build arguments; `HEALTHCHECK` on `/healthz` is for
  docker compose (Kubernetes and App Service use their own probes).
- Never put secrets in images, build arguments or layers. `.dockerignore` excludes `node_modules`,
  tests, `.env*`, docs and the Dockerfile itself.
- Provenance (SLSA, `mode=max`), SBOM and GitHub artifact attestations are added by the
  "Container build" workflow: do not disable them.

## docker-compose.yml and the dev container
- Mirror Azure versions: `postgres:17-alpine`, `redis:7.4-alpine`.
- Throw-away passwords are acceptable only for these local containers (and CI service containers);
  Azure uses Microsoft Entra ID everywhere.

## Validate
```bash
docker build -t contoso-health-api:dev app/api
docker build -t contoso-health-web:dev app/web
docker compose up --build -d && scripts/smoke-test.sh http://localhost:8080
```
