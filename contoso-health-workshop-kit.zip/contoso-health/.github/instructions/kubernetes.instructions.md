---
applyTo: "k8s/**/*.yaml,k8s/**/*.yml"
---

# Kubernetes manifests (k8s/)

## Layout
- `k8s/base` is environment-agnostic; `k8s/overlays/lab` and `k8s/overlays/prod` contain patches only.
- Images are referenced as `contoso-health-api` and `contoso-health-web`. The "Deploy to AKS" workflow
  pins the registry and the digest (`kustomize edit set image`) and fills the `REPLACE_ME_*`
  placeholders from the deployed workload. Never hard-code a registry, tag, host name or client ID
  that the workflow resolves.
- Optional Gateway API manifests live in `k8s/optional/gateway-api` (application routing,
  `gatewayClassName: approuting-istio`). Never add NGINX ingress.

## Rules
- Namespace `contoso-health` enforces Pod Security Admission `restricted`. Every pod: `runAsNonRoot`,
  `runAsUser: 1000`, `seccompProfile: RuntimeDefault`; every container: `allowPrivilegeEscalation:
  false`, `readOnlyRootFilesystem: true`, `capabilities.drop: ["ALL"]`. Writable paths only through
  `emptyDir` volumes (for example `/tmp`).
- Probes: liveness `/healthz` (process only, never dependencies), readiness `/readyz` (dependencies),
  a startup probe for the API (migrations on first start).
- Resources: CPU and memory requests, memory limits, no CPU limits (avoid throttling).
- Availability: replicas >= 2 (lab) / 3 (prod), PodDisruptionBudget `maxUnavailable: 1`,
  `topologySpreadConstraints` across `topology.kubernetes.io/zone`, `RollingUpdate` with
  `maxUnavailable: 0`, `preStop` sleep so endpoints drain before SIGTERM.
- Identity: one ServiceAccount per workload with the `azure.workload.identity/client-id`
  annotation and the pod label `azure.workload.identity/use: "true"`. No Kubernetes Secrets for Azure
  access; ConfigMaps hold non-secret settings only.
- Network: default-deny NetworkPolicies plus explicit allows (DNS, web -> api:3000, api -> private
  endpoint subnet on 5432/10000, HTTPS egress). The `web` Service is an INTERNAL LoadBalancer in
  `snet-aks-ilb` with the static IP that Application Gateway targets on `:8080`; the API stays
  `ClusterIP`.
- Namespaced objects only: the GitHub deploy identity has AKS RBAC Writer on the namespace and cannot
  create cluster-scoped objects (`scripts/aks-postprovision.sh` creates the namespace once).

## Validate
```bash
for o in lab prod; do kubectl kustomize k8s/overlays/$o | kubeconform -strict -summary -ignore-missing-schemas -kubernetes-version 1.36.0; done
```
