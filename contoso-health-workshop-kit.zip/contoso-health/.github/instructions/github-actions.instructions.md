---
applyTo: ".github/workflows/**"
---

# GitHub Actions workflows (.github/workflows)

## Security
- Workflow-level `permissions: contents: read`; each job adds only what it needs
  (`id-token: write` for Azure OIDC, `attestations: write`, `security-events: write`, ...).
- Azure: `azure/login@v3` with `client-id`, `tenant-id`, `subscription-id` from `vars.*`. Jobs that
  touch Azure reference a GitHub environment (`lab`, `prod`, `copilot`), which makes the OIDC subject
  `...:environment:<name>`. Never add Azure credentials as secrets, never use publish profiles.
- Untrusted input (PR titles, branch names, issue or comment bodies) reaches `run:` only through
  `env:`, never through inline `${{ }}` (script injection).
- Steps that need GitHub Advanced Security on private repositories are guarded with
  `if: github.event.repository.private == false || vars.GHAS_ENABLED == 'true'`.
- `actions/checkout` with `persist-credentials: false` unless the job pushes.

## Versions
- Use the major tags already used in this repository (checkout@v7, setup-node@v7, upload-artifact@v7,
  download-artifact@v8, docker/*-action@v4/v6/v7, azure/login@v3, azure/webapps-deploy@v3,
  azure/aks-set-context@v5, azure/use-kubelogin@v1, azure/setup-kubectl@v5,
  hashicorp/setup-terraform@v4 with `terraform_wrapper: false`). Pinning third-party actions to a
  full commit SHA is the stricter option.

## Reliability and operations
- Every workflow has `concurrency:`; deployments use `cancel-in-progress: false`.
- Build once, deploy many: promote the same zip or image digest from lab to prod.
- Deploy jobs end with a smoke test through Application Gateway with a retry loop.
- Path filters: a workflow skipped by `paths:` reports no check at all, so do not make its checks
  required in the ruleset (see `scripts/github/apply-governance.sh`).

## Shell in `run:` (actionlint runs shellcheck on it)
- Quote every variable (`"${VAR}"`), group several writes to `$GITHUB_STEP_SUMMARY` or
  `$GITHUB_OUTPUT` as `{ ...; } >> "${GITHUB_STEP_SUMMARY}"`.
- Default shell is `bash -eo pipefail`: avoid `cmd | head` (SIGPIPE fails the step); write to a file
  and `head` the file instead.

## Special files
- `copilot-setup-steps.yml`: the job must be named `copilot-setup-steps`; only `steps`,
  `permissions`, `runs-on`, `services`, `snapshot`, `timeout-minutes` (max 59) and `environment` are
  allowed.
- Agentic workflows (`*.md`): only the frontmatter keys `on`, `permissions`, `engine`, `tools`,
  `safe-outputs`, `network`; the agent job stays read-only and writes happen through safe outputs.
  Compile with `gh aw compile` and commit the generated `.lock.yml` with the `.md`.

## Validate
```bash
actionlint $(ls .github/workflows/*.yml | grep -v '\.lock\.yml$')
```
