---
applyTo: "infra/terraform/**/*.tf,infra/terraform/**/*.tfvars,infra/terraform/**/*.hcl,infra/terraform/**/*.hcl.example"
---

# Terraform (infra/terraform)

## Structure
- Stacks `platform`, `workload`, `aks`, each with `versions.tf`, `providers.tf`, `backend.tf`,
  `variables.tf`, `locals.tf`, `main.tf`, `outputs.tf`, `lab.tfvars`, `prod.tfvars`.
  Shared modules in `infra/terraform/modules/<name>/`.
- Cross-stack lookups by name with `data` sources (same naming rules as Bicep). No
  `terraform_remote_state`.

## Versions and providers
- `required_version = ">= 1.9"`, `azurerm ~> 5.14`; `azapi ~> 2.13` only where azurerm has no
  argument (for example the AKS Gateway API via `azapi_update_resource`).
- Provider block: `features {}`, `subscription_id = var.subscription_id`,
  `storage_use_azuread = true`. AzureRM 5.x does not register resource providers:
  `scripts/preflight.sh` does.
- Azure Managed Redis = `azurerm_managed_redis` (+ `default_database`,
  `access_keys_authentication_enabled = false`) and `azurerm_managed_redis_access_policy_assignment`.
  Never `azurerm_redis_cache`.

## State
- Backend `azurerm` with partial configuration and `use_azuread_auth = true`; values in
  `backend-<env>.hcl` (written by `scripts/bootstrap-tfstate.sh`), key `ch/<stack>/<env>.tfstate`.
- No access keys or SAS tokens: CI authenticates with `ARM_USE_OIDC=true` and `ARM_USE_AZUREAD=true`.
- Never commit `*.tfstate`, `.terraform/` or plan files.

## Rules
- Names in `locals.tf`; unique suffix `substr(sha1("${var.subscription_id}-ch-${var.env}"), 0, 6)` for
  globally unique names only. `local.tags` on every resource.
- Variables: `type`, `description` and `validation` where it prevents mistakes; environment-specific
  values come from `lab.tfvars` / `prod.tfvars`, per-person values from `TF_VAR_*`.
- Prefer `for_each` over `count` for named collections (stable addresses).
- Role assignments only for the roles the deploy identity may delegate (see the Bicep instructions).
- Outputs keep the same names as the Bicep outputs; mark anything sensitive `sensitive = true`
  (there should be nothing sensitive).
- One-line WHY comment with a pillar tag on every non-obvious argument.

## Validate
```bash
terraform fmt -check -recursive infra/terraform        # fix with: terraform fmt -recursive infra/terraform
terraform -chdir=infra/terraform/<stack> init -backend=false -input=false
terraform -chdir=infra/terraform/<stack> validate
```

Mirror every change in `infra/bicep/<stack>` (same names, values, tags and outputs).
