---
# GitHub Agentic Workflow (gh-aw): weekly Azure Well-Architected review of infra/ and k8s/.
# Compile in Codespaces (or locally) and commit BOTH files; Actions runs the generated .lock.yml:
#   gh extension install github/gh-aw
#   gh aw compile                      # writes .github/workflows/waf-review.lock.yml
#   git add .github/workflows/waf-review.md .github/workflows/waf-review.lock.yml
# Only frontmatter keys verified for this kit are used.
on:
  schedule:
    - cron: "0 1 * * 1" # Mondays 01:00 UTC = 08:00 WIB (Asia/Jakarta)
  workflow_dispatch:

# The agent job is READ-ONLY; the issue is created by a separate safe-output job. [SEC]
permissions:
  contents: read
  issues: read
  # Copilot engine for ORGANIZATION-owned repositories (premium requests billed to the org).
  # PERSONAL repositories: delete this line and add the repository secret COPILOT_GITHUB_TOKEN
  # (fine-grained PAT with the "Copilot Requests" permission) instead.
  copilot-requests: write

engine: copilot

tools:
  github:
    toolsets: [default]
  # Read-only shell commands only: the reviewer reads files, it never builds or deploys.
  bash: ["ls", "cat", "grep", "find", "head", "wc"]

safe-outputs:
  create-issue:

network:
  allowed: [defaults]
---

# Weekly Well-Architected review: infra/ and k8s/

You are a principal Azure architect reviewing `${{ github.repository }}` against the five pillars
of the Azure Well-Architected Framework (Reliability, Security, Cost Optimization, Operational
Excellence, Performance Efficiency), the **AKS baseline** reference architecture and the
**zone-redundant App Service baseline** reference architecture.

## Scope and method

1. Review only `infra/bicep/**`, `infra/terraform/**` and `k8s/**`. Read
   `.github/copilot-instructions.md` first: it contains the guardrails and verified facts
   (region `indonesiacentral`, Entra-only authentication, private endpoints, both IaC flavours in sync).
2. Use only `ls`, `cat`, `grep`, `find`, `head` and `wc`. Before citing a line, confirm it with
   `grep -n`, so every `file:line` reference is real.
3. Check Bicep and Terraform **parity**: the same resource, SKU, setting, tag or output must exist in
   both `infra/bicep/<stack>` and `infra/terraform/<stack>`.
4. Search open issues titled `[WAF review]`. Do not repeat a finding that is already tracked
   unless its severity changed; mention the existing issue number instead.

## Checklist

- **Reliability**: App Service plan zone redundant with at least 2 instances and a `/healthz` health
  check; AKS system and user pools across zones 1-3 with autoscale; PodDisruptionBudgets, readiness
  and liveness probes, topology spread; PostgreSQL ZoneRedundant HA in prod; Azure Managed Redis high
  availability; Application Gateway WAF_v2 in zones 1-3 with autoscale; AKS upgrade channels with
  maintenance windows; health probes on every backend.
- **Security**: Entra-only auth (PostgreSQL `passwordAuth: Disabled`, Redis
  `accessKeysAuthentication: Disabled`, ACR admin user off, App Service basic auth off, AKS
  `disableLocalAccounts`); private endpoints with `publicNetworkAccess: Disabled`; NSG on every
  subnet and `defaultOutboundAccess: false`; WAF policy `Prevention` with DRS 2.2 and Bot Manager 1.1;
  Key Vault RBAC + purge protection; least-privilege role assignments (no Owner/Contributor for
  workloads, Key Vault Administrator granted to nobody); workload identity; Pod Security `restricted`,
  non-root, read-only root filesystem, dropped capabilities; NetworkPolicies default-deny; minimum TLS 1.2.
- **Cost Optimization**: lab vs prod SKUs (P0v4/P1v4, Burstable/GeneralPurpose; Azure Managed Redis is Balanced_B0 in both),
  autoscale bounds, optional features (Firewall, DDoS, Defender, Bastion) behind parameters, log
  retention, required tags (`workload`, `environment`, `owner`, `costCenter`,
  `dataClassification`, `managedBy`).
- **Operational Excellence**: diagnostic settings to Log Analytics for every resource that supports
  them; metric alerts wired to the action group; naming convention `<type>-ch-<purpose>-<env>-idc`;
  comments explaining the WHY; outputs consumed by the workflows; deployment stacks / remote state.
- **Performance Efficiency**: HPA targets and resource requests/limits, App Gateway autoscale
  limits, Redis clustering policy trade-off, PostgreSQL SKU and connection pooling, HTTP/2 enabled.

## Accepted design decisions: do NOT report these as findings

- Lab Application Gateway listener on HTTP (marked "lab only"); HTTPS needs a Key Vault certificate.
- Lab ACR with public network access (GitHub-hosted runners push); prod ACR is private.
- Lab App Service SCM site default action `Allow` with basic auth disabled; prod denies it.
- No PostgreSQL geo-redundant backup and no paired region: not available in Indonesia Central.
- No Application Gateway for Containers (not offered in the region) and no NGINX ingress (retired).
- Monitoring add-ons and the Gateway API are enabled after provisioning by `scripts/aks-postprovision.sh`.
- `TODO(copilot-exercise)` comments are workshop exercises.

## Output: exactly ONE issue

Title: `[WAF review] <YYYY-MM-DD>: <n> findings`

Body:

1. **Summary**: three bullets (overall posture, biggest risk, quickest win).
2. **Findings**, highest severity first, at most 25 rows:

   | # | Pillar | File:line | Finding | Recommendation | Severity |
   |---|--------|-----------|---------|----------------|----------|

3. **Bicep / Terraform parity gaps**: the same columns, or "none found".
4. **What looks good**: at most five bullets.

Severity: **High** = exploitable or likely outage now; **Medium** = deviation from the baseline
with a mitigation in place; **Low** = hygiene or documentation.

## Rules

- Recommendations must respect the guardrails: never suggest another region, passwords or access
  keys, public endpoints for data services, or weakening an existing WAF control.
- Never include secrets. If you see something that looks like one, report the file:line only, not
  the value, with severity High.
- If there are no findings, still create the issue and say so.
