## What and why

<!-- One short paragraph: the change and the reason. Link the issue: "Fixes #123". -->

## Type of change

- [ ] Application (`app/`)
- [ ] Infrastructure (`infra/bicep` **and** `infra/terraform`)
- [ ] Kubernetes (`k8s/`)
- [ ] Pipelines / governance (`.github/`, `scripts/`)
- [ ] Copilot customisation / documentation

## Validation

<!-- Tick what you ran. CI runs the same commands; paste links in the Evidence table. -->

- [ ] App: `npm run check && npm test` (api, web) and `npm run test:integration` (api)
- [ ] Bicep: `az bicep build` + `az bicep lint` per stack, `az bicep build-params` per parameter file
- [ ] Terraform: `terraform fmt -check -recursive infra/terraform` + `terraform validate` per stack
- [ ] Kubernetes: `kubectl kustomize k8s/overlays/<env> | kubeconform -strict -summary -ignore-missing-schemas -kubernetes-version 1.36.0`
- [ ] Workflows: `actionlint`
- [ ] What-if / plan reviewed for **lab** (and prod when relevant)
- [ ] Bicep and Terraform changed **together** with the same names, SKUs, tags and outputs (or N/A)

## Well-Architected checklist

<!-- Tick each item that is true, or explain in one line why it does not apply. -->

### Reliability [REL]
- [ ] Zone redundancy unchanged or improved (App Service >= 2 instances, AKS pools in zones 1-3, PostgreSQL HA in prod, Managed Redis HA)
- [ ] Health endpoints keep their meaning: `/healthz` = process alive, `/readyz` = dependencies reachable
- [ ] Rollout is safe: probes, PodDisruptionBudgets, `maxUnavailable: 0`, migrations backward compatible

### Security [SEC]
- [ ] No secrets, keys, passwords, connection strings or tokens anywhere (OIDC + managed/workload identities only)
- [ ] Microsoft Entra ID authentication only; local auth, access keys, admin users and basic auth stay disabled
- [ ] Data services stay private (private endpoints, `publicNetworkAccess: Disabled`); NSGs and network policies unchanged or stricter
- [ ] New role assignments are least privilege and scoped as narrowly as possible

### Cost Optimization [COST]
- [ ] lab keeps cost-aware SKUs; prod sizing is justified
- [ ] Autoscale bounds and log retention reviewed; required tags present on new resources

### Operational Excellence [OPS]
- [ ] Diagnostic settings and alerts cover new resources
- [ ] Naming convention `<type>-ch-<purpose>-<env>-idc` and `managedBy` tag respected
- [ ] Docs / runbooks / Copilot instructions updated when behaviour changes

### Performance Efficiency [PERF]
- [ ] Requests/limits, HPA targets and SKU sizes reviewed for the change
- [ ] Caching and connection pooling behaviour unchanged or measured

## Evidence

| Evidence | Link |
|----------|------|
| CI / IaC validate run | |
| What-if or Terraform plan (job summary) | |
| PSRule for Azure report | |
| Smoke test (`scripts/smoke-test.sh` or deploy job) | |
| Dashboard, metric or log query (if behaviour changed) | |

## Rollback

<!-- How to undo: revert the PR and redeploy, previous image digest, stack redeploy, ... -->
