---
name: waf-review
description: Review Contoso Health infrastructure (infra/bicep, infra/terraform) and Kubernetes manifests (k8s/) against the five Azure Well-Architected pillars and the AKS and App Service baseline architectures, with concrete grep checks, Bicep/Terraform parity checks, a severity rubric and a findings-table output. Use for PR reviews, the weekly WAF review or before a production deployment.
---

# Well-Architected review

Read-only. The output is one findings table (pillar, file:line, finding, recommendation, severity).

## 1. Scope and context
```bash
ls infra/bicep infra/terraform k8s/overlays
cat .github/copilot-instructions.md        # guardrails and verified facts
```
Compare `lab` and `prod` values: `infra/bicep/<stack>/{lab,prod}.bicepparam`,
`infra/terraform/<stack>/{lab,prod}.tfvars`, `k8s/overlays/{lab,prod}`.

## 2. Quick checks (each hit or miss is a lead, verify it in the file)
```bash
# Security
grep -rn "publicNetworkAccess" infra/bicep | grep -v "'Disabled'"
grep -rn "public_network_access" infra/terraform | grep -vi "disabled\|false"
grep -rni "password\|secret\|accesskey\|connectionstring" infra k8s | grep -vi "passwordAuth: 'Disabled'\|password_auth_enabled *= *false\|keyvault\|secretsprovider\|Key Vault Secrets User"
grep -rn "adminUserEnabled\|admin_enabled\|disableLocalAccounts\|local_account_disabled\|accessKeysAuthentication\|access_keys_authentication_enabled" infra
grep -rn "minTlsVersion\|min_tls_version\|minimumTlsVersion\|ftpsState" infra
# Reliability
grep -rn "zoneRedundant\|zone_balancing_enabled\|zones\|highAvailability\|high_availability" infra
grep -rn "healthCheckPath\|health_check_path\|readinessProbe\|livenessProbe\|PodDisruptionBudget" infra k8s
# Operations
grep -rLn "diagnosticSettings\|azurerm_monitor_diagnostic_setting" infra/bicep/modules infra/terraform/modules
grep -rn "metricAlerts\|azurerm_monitor_metric_alert" infra
# Network
grep -rn "defaultOutboundAccess\|default_outbound_access_enabled\|networkSecurityGroup\|network_security_group" infra
```

## 3. Checklist per pillar
- **Reliability [REL]**: App Service plan zone redundant with >= 2 instances and health check
  `/healthz`; AKS system pool (3 nodes) and user pool across zones 1-3 with autoscale; PDBs, probes,
  topology spread, `maxUnavailable: 0`; PostgreSQL `ZoneRedundant` HA in prod (Burstable lab cannot);
  Azure Managed Redis high availability; Application Gateway zones 1-3 with autoscale min >= 2 in
  prod; AKS upgrade channels + maintenance windows; backup retention.
- **Security [SEC]**: Entra-only auth everywhere; private endpoints + DNS zone groups; NSG per subnet,
  `defaultOutboundAccess: false`; WAF policy `Prevention`, DRS 2.2, Bot Manager 1.1; Key Vault RBAC +
  purge protection; least privilege (no Owner/Contributor for workloads, nobody holds Key Vault
  Administrator); workload identity; Pod Security `restricted`; default-deny NetworkPolicies; TLS 1.2;
  ACR admin off, anonymous pull off; Defender plans available behind a parameter.
- **Cost Optimization [COST]**: lab vs prod SKUs (P0v4/P1v4, B1ms/D2ds_v5; Azure Managed Redis Balanced_B0 in both); autoscale
  bounds; optional Firewall/DDoS/Bastion/Defender behind parameters; log retention; all six tags.
- **Operational Excellence [OPS]**: diagnostic settings for every resource that supports them;
  alerts wired to `ag-ch-<env>`; naming convention; WHY comments; outputs used by workflows exist in
  both flavours; deployment stacks / remote state; Bicep/Terraform parity.
- **Performance Efficiency [PERF]**: HPA targets and requests/limits; App Gateway autoscale max;
  Redis clustering policy trade-off (`EnterpriseCluster` vs `OSSCluster`); PostgreSQL SKU and pool
  size; HTTP/2 on App Service.
- **AKS baseline extras**: Azure CNI Overlay + Cilium, network policy enabled, private API server in
  prod, `azurepolicy` add-on, Key Vault secrets provider with rotation, Image Cleaner, monitoring
  (Managed Prometheus + Container insights after `scripts/aks-postprovision.sh`), system pool taint
  `CriticalAddonsOnly`.
- **App Service baseline extras**: VNet integration with `outboundVnetRouting.allTraffic`, access
  restrictions default `Deny` (traffic only from Application Gateway), basic auth disabled,
  `alwaysOn`, `httpsOnly`, `ftpsState: Disabled`, Key Vault references through the user identity.

## 4. Accepted design decisions (never report)
Lab HTTP listener (marked "lab only"); lab ACR public network access; lab SCM site default `Allow`
with basic auth off; no PostgreSQL geo-redundant backup and no paired region (not available in
Indonesia Central); no Application Gateway for Containers (not in the region); no NGINX ingress
(retired); monitoring add-ons enabled by `scripts/aks-postprovision.sh`; `TODO(copilot-exercise)`.

## 5. Severity
- **High**: exploitable or likely outage now (public data plane, secret in code, single zone in prod).
- **Medium**: baseline deviation with a mitigation in place.
- **Low**: hygiene, naming, documentation, missing comment.

## 6. Output
```markdown
| # | Pillar | File:line | Finding | Recommendation | Severity |
|---|--------|-----------|---------|----------------|----------|
| 1 | Security | infra/terraform/workload/main.tf:123 | ... | ... | High |
```
Then "Bicep / Terraform parity gaps" (same columns) and "What looks good" (max 5 bullets).
Confirm every `file:line` with `grep -n` before reporting it.
