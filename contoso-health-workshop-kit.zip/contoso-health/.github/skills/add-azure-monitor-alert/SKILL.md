---
name: add-azure-monitor-alert
description: Add an Azure Monitor metric alert to the Contoso Health workload in BOTH Bicep and Terraform, wired to the ag-ch-<env> action group, with the metric name discovered from Azure instead of guessed. Use for alerting requests such as the Azure Managed Redis server load alert (TODO(copilot-exercise)).
---

# Add an Azure Monitor metric alert

Existing alerts to copy: `infra/bicep/modules/monitor/alerts.bicep` (Application Gateway
`UnhealthyHostCount`, PostgreSQL `cpu_percent`) and the matching `azurerm_monitor_metric_alert`
resources in `infra/terraform/workload/main.tf`. The workshop exercise is marked
`TODO(copilot-exercise): Redis server load alert` in both files.

## 1. Decide the signal (write it in the PR)
| Field | Example (Redis server load) |
|-------|-----------------------------|
| Resource type / namespace | `Microsoft.Cache/redisEnterprise` |
| Metric | discovered in step 2, never guessed |
| Aggregation, operator, threshold | `Average`, `GreaterThan`, `80` |
| Window / frequency | `PT15M` / `PT5M` (sustained load, not spikes) |
| Severity | `2` (warning: degraded performance) |
| Why it matters | cache saturation raises API latency before anything fails [PERF][REL] |

## 2. Discover the exact metric name
```bash
id=$(az resource list -g rg-ch-lab-idc --resource-type Microsoft.Cache/redisEnterprise --query "[0].id" -o tsv)
az monitor metrics list-definitions --resource "$id" \
  --query "[].{name:name.value, display:name.localizedValue, unit:unit, aggregation:primaryAggregationType}" -o table
```
Use the `name` column value. Without access to a deployed resource, take it from the Microsoft Learn
page "Supported metrics for Microsoft.Cache/redisEnterprise" and say so in the PR.

## 3. Bicep (`infra/bicep/modules/monitor/alerts.bicep` + wiring in `infra/bicep/workload/main.bicep`)
- Add a parameter for the target name (for example `redisName`) and an `existing` resource
  (`Microsoft.Cache/redisEnterprise@2026-09-01`).
- Add the alert next to the others, replacing the TODO line:
```bicep
// [PERF][REL] Sustained server load above 80 % means the cache is saturated: scale the SKU or review hot keys.
resource redisServerLoad 'Microsoft.Insights/metricAlerts@2018-03-01' = {
  name: 'alert-${redisName}-server-load'
  location: 'global'
  tags: tags
  properties: {
    description: 'Azure Managed Redis server load above 80 percent (15 minute average).'
    severity: 2
    enabled: true
    scopes: [
      redis.id
    ]
    evaluationFrequency: 'PT5M'
    windowSize: 'PT15M'
    autoMitigate: true
    criteria: {
      'odata.type': 'Microsoft.Azure.Monitor.SingleResourceMultipleMetricCriteria'
      allOf: [
        {
          criterionType: 'StaticThresholdCriterion'
          name: 'server-load'
          metricNamespace: 'Microsoft.Cache/redisEnterprise'
          metricName: '<name from step 2>'
          operator: 'GreaterThan'
          threshold: 80
          timeAggregation: 'Average'
        }
      ]
    }
    actions: [
      {
        actionGroupId: actionGroup.id
      }
    ]
  }
}
```
- Pass the new parameter from `module alerts` in `infra/bicep/workload/main.bicep`.

## 4. Terraform (`infra/terraform/workload/main.tf`, replacing the TODO line)
```hcl
# [PERF][REL] Sustained server load above 80 % means the cache is saturated: scale the SKU or review hot keys.
resource "azurerm_monitor_metric_alert" "redis_server_load" {
  name                = "alert-${local.names.redis}-server-load"
  resource_group_name = data.azurerm_resource_group.workload.name
  scopes              = [module.redis.id]
  description         = "Azure Managed Redis server load above 80 percent (15 minute average)."
  severity            = 2
  frequency           = "PT5M"
  window_size         = "PT15M"
  tags                = local.tags

  criteria {
    metric_namespace = "Microsoft.Cache/redisEnterprise"
    metric_name      = "<name from step 2>"
    aggregation      = "Average"
    operator         = "GreaterThan"
    threshold        = 80
  }

  action {
    action_group_id = azurerm_monitor_action_group.this.id
  }
}
```
Check the real local and module names first (`grep -n "names\.\|module \"" infra/terraform/workload/*.tf`);
the identifiers above follow the existing alerts but must match the stack.

## 5. Validate and preview
Run the `iac-validate` skill (Bicep build/lint/build-params, `terraform fmt` + `validate`). Optional:
`az deployment group what-if` / `terraform plan` against lab must show exactly one new alert.

## Done when
- [ ] Same alert name, metric, threshold, window, frequency, severity and tags in Bicep and Terraform.
- [ ] The metric name comes from `list-definitions` or Learn (stated in the PR).
- [ ] The TODO line is gone in both flavours; validation passes; WHY comment with pillar tags present.
