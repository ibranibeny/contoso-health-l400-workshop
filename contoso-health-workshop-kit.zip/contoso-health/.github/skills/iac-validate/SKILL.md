---
name: iac-validate
description: Validate Contoso Health infrastructure and pipeline code exactly like the "IaC validate" workflow (Bicep build, lint and build-params; PSRule for Azure; Terraform fmt and validate; kustomize + kubeconform; actionlint) and optionally preview a lab deployment with what-if or plan. Use before committing changes under infra/, k8s/ or .github/workflows/.
---

# Validate IaC, manifests and workflows

Run the sections that match the files you changed, from the repository root. Every command here
is read-only; none of them deploys anything.

## 1. Bicep
```bash
az bicep version || az bicep install
for f in infra/bicep/*/main.bicep; do
  echo "== $f"
  az bicep build --file "$f" --stdout > /dev/null   # compiles the stack and all modules
  az bicep lint --file "$f"                         # rules from infra/bicep/bicepconfig.json
done
for p in infra/bicep/*/*.bicepparam; do
  echo "== $p"
  az bicep build-params --file "$p" --stdout > /dev/null
done
```
`readEnvironmentVariable()` inputs have defaults, so `build-params` works without exports.

## 2. PSRule for Azure (CI runs it in report mode)
```bash
pwsh -NoProfile -Command "Install-Module PSRule.Rules.Azure -Scope CurrentUser -Force; Assert-PSRule -Format File -InputPath 'infra/bicep/' -Option 'ps-rule.yaml' -Module 'PSRule.Rules.Azure' -Outcome Fail,Error"
```
`ps-rule.yaml` expands `.bicepparam` files, so each lab/prod parameter file is analysed with its
real values. A failing rule that matches a documented lab exception is acceptable: mention it in
the PR; never delete the rule.

## 3. Terraform
```bash
terraform fmt -check -recursive -diff infra/terraform   # fix: terraform fmt -recursive infra/terraform
for s in platform workload aks; do
  echo "== $s"
  terraform -chdir=infra/terraform/$s init -backend=false -input=false > /dev/null
  terraform -chdir=infra/terraform/$s validate
done
```

## 4. Kubernetes
```bash
for o in lab prod; do
  echo "== k8s/overlays/$o"
  kubectl kustomize k8s/overlays/$o | kubeconform -strict -summary -ignore-missing-schemas -kubernetes-version 1.36.0
done
```

## 5. Workflows
```bash
actionlint $(ls .github/workflows/*.yml | grep -v '\.lock\.yml$')
```
Agentic workflows (`.github/workflows/*.md`) are validated by `gh aw compile`.

## 6. Bicep / Terraform parity (manual, 2 minutes)
For every resource, property, tag or output you changed:
```bash
grep -rn "<name or property>" infra/bicep infra/terraform
```
Both flavours must show the same value. Note the result in the PR ("parity: checked").

## 7. Optional preview against lab (needs `az login` with access to the lab subscription)
```bash
az deployment group what-if --resource-group rg-ch-lab-idc \
  --template-file infra/bicep/workload/main.bicep --parameters infra/bicep/workload/lab.bicepparam
terraform -chdir=infra/terraform/workload init -backend-config=backend-lab.hcl
terraform -chdir=infra/terraform/workload plan -var-file=lab.tfvars -lock=false
```
On a pull request the "plan" job of "IaC validate" does the same when `AZURE_CLIENT_ID_PLAN` is set.

## Common failures
| Symptom | Likely cause and fix |
|---------|----------------------|
| `BCP081` / `use-recent-api-versions` warning | API version not in the verified list: use the version from `bicep.instructions.md` |
| `secure-secrets-in-params` error | a parameter looks like a secret: remove it (Entra ID, no secrets) |
| `terraform fmt` diff | run `terraform fmt -recursive infra/terraform` and commit |
| `Unsupported argument` in validate | argument not in azurerm 5.x: check the provider docs; prefer omission |
| kubeconform `additional properties not allowed` | typo or wrong indentation in a manifest (`-strict`) |
| actionlint `SC2086` / `SC2129` | quote the variable / group redirects into one `{ ...; } >> file` |

## Done when
All relevant sections pass, and the output (or "all passed") is pasted into the PR's Validation section.
