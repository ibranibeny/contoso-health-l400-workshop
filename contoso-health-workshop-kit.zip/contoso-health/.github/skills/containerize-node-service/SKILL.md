---
name: containerize-node-service
description: Containerize a Node.js 24 service the Contoso Health way and wire it end to end - hardened multi-stage Dockerfile, .dockerignore, docker compose service, Kubernetes base manifests with workload identity and network policies, CI build, Container build and Deploy to AKS workflows. Use when adding a new service or fixing an existing image.
---

# Containerize a Node.js service

Reference implementations: `app/api/Dockerfile` (runtime dependencies) and `app/web/Dockerfile`
(a build stage that compiles the React app with Vite; the runtime stage has no `node_modules`). Copy
their structure; do not invent a new one. Below, `<svc>` is the service
folder name under `app/` and `<port>` its HTTP port.

## 1. Prerequisites in the service
- `package.json` with `"type": "module"`, `"engines": { "node": ">=24" }`, a `start` script, and a
  committed `package-lock.json` (needed by `npm ci`).
- `GET /healthz` (process alive) and `GET /readyz` (dependencies reachable); graceful shutdown on
  SIGTERM; all settings from environment variables; logs as JSON lines on stdout.

## 2. Dockerfile (`app/<svc>/Dockerfile`)
```dockerfile
# syntax=docker/dockerfile:1
ARG NODE_IMAGE=node:24-slim

FROM ${NODE_IMAGE} AS deps
WORKDIR /app
ENV NODE_ENV=production
COPY package.json package-lock.json ./
RUN npm ci --omit=dev --no-audit --no-fund && npm cache clean --force

FROM ${NODE_IMAGE} AS runtime
ARG APP_VERSION=dev
ARG GIT_SHA=unknown
LABEL org.opencontainers.image.title="contoso-health-<svc>" \
      org.opencontainers.image.revision="${GIT_SHA}" \
      org.opencontainers.image.version="${APP_VERSION}"
WORKDIR /app
ENV NODE_ENV=production PORT=<port> APP_VERSION=${APP_VERSION}
COPY --from=deps /app/node_modules ./node_modules
COPY package.json ./
COPY src ./src
USER node
EXPOSE <port>
HEALTHCHECK --interval=30s --timeout=3s --start-period=20s --retries=3 \
  CMD ["node", "-e", "fetch('http://127.0.0.1:'+(process.env.PORT||<port>)+'/healthz').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))"]
CMD ["node", "src/index.js"]
```
Rules: non-root `node` user (uid 1000), exec-form `CMD`, no secrets in `ARG`/`ENV`/layers, writes
only to `/tmp` (the pod runs with a read-only root filesystem).

## 3. `.dockerignore`
```
node_modules
test
coverage
*.md
.env*
Dockerfile
.dockerignore
```

## 4. Build and run locally
```bash
docker build -t contoso-health-<svc>:dev app/<svc>
docker run --rm -d --name <svc> -p <port>:<port> contoso-health-<svc>:dev
curl -fsS http://127.0.0.1:<port>/healthz && docker rm -f <svc>
```
Add a service to `docker-compose.yml` (`build: ./app/<svc>`, `depends_on` with
`condition: service_healthy`).

## 5. Kubernetes (`k8s/base/<svc>.yaml`, add it to `k8s/base/kustomization.yaml`)
Copy `k8s/base/api.yaml` and adapt:
- Deployment: image `contoso-health-<svc>:placeholder`, pod label `azure.workload.identity/use: "true"`,
  `serviceAccountName: contoso-health-<svc>`, the restricted security context, requests + memory limit,
  liveness `/healthz`, readiness `/readyz`, `topologySpreadConstraints` on zones, `preStop` sleep,
  `emptyDir` for `/tmp`.
- Service `ClusterIP`, PodDisruptionBudget `maxUnavailable: 1`, HorizontalPodAutoscaler.
- ServiceAccount in `serviceaccounts.yaml` with `azure.workload.identity/client-id` (overlays set the
  real client ID); a user-assigned identity `id-ch-<svc>-<env>` plus its federated credential
  (`system:serviceaccount:contoso-health:contoso-health-<svc>`) in BOTH IaC flavours.
- NetworkPolicy: explicit ingress from its callers and egress to its dependencies only.
- `images:` entry for `contoso-health-<svc>` in the kustomizations; validate with kubeconform.

## 6. Pipelines
- `.github/workflows/ci.yml`: add `<svc>` to the `app-unit` matrix and the `container-build` matrix
  (with its port).
- `.github/workflows/container-build.yml`: metadata, build-push (provenance + SBOM) and attestation
  steps for the new image; output its digest.
- `.github/workflows/aks-deploy.yml`: pin the new image (`kustomize edit set image`), verify it in the
  rendered output and wait for its rollout.
- `.github/dependabot.yml`: add `/app/<svc>` to the npm and docker `directories`.

## Done when
- [ ] Image builds, starts as uid 1000 and answers `/healthz`.
- [ ] `kubectl kustomize k8s/overlays/lab | kubeconform ...` passes.
- [ ] CI builds the image; the identity and federated credential exist in Bicep AND Terraform.
