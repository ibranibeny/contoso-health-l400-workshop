# Contoso Health: instructions for GitHub Copilot

Contoso Health (a fictional insurer) runs a member portal and a claims API on Azure in
**Indonesia Central**. This repository holds the application, two equivalent IaC flavours (Bicep and
Terraform), Kubernetes manifests, GitHub Actions pipelines and operational scripts.
The guardrails come first on purpose: they override every other suggestion.

## Guardrails (non-negotiable)

1. **Region `indonesiacentral` only.** No other region, paired region or geo-replication (the region
   has no pair; PostgreSQL geo-redundant backup is not available there).
2. **No secrets anywhere.** No passwords, keys, connection strings, SAS tokens, PATs or kubeconfigs in
   code, parameters, tfvars, workflows, issues or PRs. GitHub reaches Azure with OIDC federated
   credentials; workloads use managed identities (App Service) or workload identity (AKS).
   Workflows read `vars.*`, never `secrets.*`, for Azure. Throw-away passwords exist only for local
   and CI service containers.
3. **Microsoft Entra ID only.** PostgreSQL `passwordAuth: Disabled`; Azure Managed Redis
   `accessKeysAuthentication: Disabled`; ACR admin user off; App Service basic auth (FTP/SCM) off;
   AKS `disableLocalAccounts: true` with Azure RBAC; Key Vault in RBAC mode.
4. **Private endpoints** for every PaaS data plane (PostgreSQL, Redis, Key Vault, ACR, App Service)
   with public network access disabled. Only documented lab exceptions: ACR public in lab (GitHub-hosted
   runners push), App Service SCM site reachable in lab (basic auth still off).
5. **Bicep and Terraform stay in sync.** Every infrastructure change lands in `infra/bicep/<stack>`
   AND `infra/terraform/<stack>` in the same PR, with the same names, SKUs, settings, tags and outputs.
6. **Never weaken a Well-Architected control**: zone redundancy, HA, WAF policy in Prevention with
   DRS 2.2, NSGs and `defaultOutboundAccess: false`, diagnostic settings, TLS 1.2, Pod Security
   `restricted`, network policies, probes, PodDisruptionBudgets. If a request needs that, stop and
   explain the trade-off instead of doing it.
7. **Never use**: Azure Cache for Redis (retiring; use Azure Managed Redis Balanced_B0), NGINX ingress (retired),
   Application Gateway for Containers (not offered in the region), PostgreSQL VNet integration (the kit
   uses private endpoints; the conversion is one-way).

## Architecture

- **Edge**: Application Gateway WAF_v2 (zones 1-3) in the workload spoke. Listener `:80` goes to the
  App Service web app; listener `:8080` goes to the AKS internal load balancer (static IP in
  `snet-aks-ilb`) in front of the `web` Service.
- **Web** (`app/web`): React 19 single-page app (TypeScript, built with Vite into `dist/`) served by a
  Node.js backend-for-frontend (`server.js`) that proxies `/api/*` to the API, so the API is never
  public and needs no CORS. The BFF has no runtime dependencies: React is compiled into `dist/`.
- **API** (`app/api`): Node.js 24 (ESM, no framework). PostgreSQL 17 flexible server with Entra tokens,
  Azure Managed Redis for cache-aside, idempotency keys and rate limiting, OpenTelemetry to
  Application Insights.
- **Hosting**: the same code runs on App Service (Premium v4, zone redundant, VNet integration) and on
  AKS (Kubernetes 1.36, Azure CNI Overlay + Cilium, workload identity, Azure RBAC).
- **Network**: hub-spoke; private DNS zones in the hub; egress through a NAT gateway (lab) or Azure
  Firewall (prod); every subnet has an NSG and no default outbound access.
- **IaC stacks** (deployed in this order): `platform` (subscription scope: hub, DNS zones, Log
  Analytics, policy, vended resource groups) -> `workload` (`rg-ch-<env>-idc`) -> `aks`
  (`rg-ch-aks-<env>-idc`). Environments: `lab` (cost-aware, same topology) and `prod`.

## Repository map

| Path | Content |
|------|---------|
| `app/api`, `app/web` | Application code, unit and integration tests, Dockerfiles |
| `infra/bicep/<stack>` | `main.bicep`, `lab.bicepparam`, `prod.bicepparam`; shared modules in `infra/bicep/modules` |
| `infra/terraform/<stack>` | Same design in Terraform; shared modules in `infra/terraform/modules` |
| `k8s/base`, `k8s/overlays/{lab,prod}` | Kustomize manifests (namespace `contoso-health`) |
| `.github/workflows` | CI, IaC validate, deployments, Copilot setup, agentic workflows (`*.md`) |
| `scripts/` | preflight, OIDC/state bootstrap, database bootstrap, AKS post-provisioning, smoke test, WAF test (`waf-test.sh`), governance |
| `docs/` | Workshop documentation (for example the GitLab migration guide) |

## Conventions

- Names: `<type>-ch-<purpose>-<env>-idc`. Globally unique names add a 6-character suffix
  (`kv-ch-<env>-<sfx>`, `crch<env><sfx>`, `psql-ch-<env>-<sfx>`).
- Tags on every resource and resource group: `workload`, `environment`, `owner`, `costCenter`,
  `dataClassification`, `managedBy`.
- Every non-obvious line gets a one-line comment that explains WHY, tagged with its pillar:
  `[REL]` `[SEC]` `[COST]` `[OPS]` `[PERF]`.
- Use only properties and arguments you are sure exist for the pinned API/provider versions; prefer
  leaving something out over inventing it. Verify with Microsoft Learn when unsure.
- Application settings come from environment variables only (`app/api/src/config.js`).
- Workflows: least-privilege `permissions:` per job, OIDC, `concurrency:`, actions pinned to the major
  tags already used in the repository.

## How to validate (run the relevant block before opening a PR)

```bash
# Application (use npm install when no package-lock.json exists)
cd app/api && npm ci && npm run check && npm test && cd ../..
cd app/web && npm run typecheck && npm test && npm run build && cd ../..   # React portal + BFF
# Integration tests need PostgreSQL + Redis (docker compose up -d postgres redis, Codespaces, or the
# Copilot cloud agent service containers; see .github/workflows/copilot-setup-steps.yml for the env vars)
cd app/api && npm run test:integration && cd ../..

# Bicep
for f in infra/bicep/*/main.bicep; do az bicep build --file "$f" --stdout > /dev/null && az bicep lint --file "$f"; done
for p in infra/bicep/*/*.bicepparam; do az bicep build-params --file "$p" --stdout > /dev/null; done

# Terraform
terraform fmt -check -recursive infra/terraform
for s in platform workload aks; do terraform -chdir=infra/terraform/$s init -backend=false -input=false && terraform -chdir=infra/terraform/$s validate; done

# Kubernetes
for o in lab prod; do kubectl kustomize k8s/overlays/$o | kubeconform -strict -summary -ignore-missing-schemas -kubernetes-version 1.36.0; done

# Workflows
actionlint
```

## Pull requests

- Use `.github/pull_request_template.md`: WAF checklist, Bicep/Terraform parity, evidence links.
- Stay inside the "Files in scope" of the issue; explain any other file you touch.
- Never deploy from a Copilot session: deployments run through the `Infra deploy`,
  `Deploy to App Service` and `Deploy to AKS` workflows with environment protection.

## More guidance

- Path-specific rules: `.github/instructions/*.instructions.md` (Bicep, Terraform, Kubernetes,
  GitHub Actions, containers, Node.js app, React portal).
- Custom agents: `.github/agents/` (`platform-engineer`, `waf-reviewer`, `sre-investigator`).
- Skills: `.github/skills/` (`iac-validate`, `containerize-node-service`, `add-azure-monitor-alert`,
  `waf-review`).
