# Contoso Health: workshop kit

The code for the Contoso Health L400 workshop: a React member portal and a Node.js claims API, the
Azure platform that runs them in Indonesia Central (Bicep **or** Terraform), the containers and
Kubernetes manifests for AKS, and the GitHub workflows, Copilot agents and tests that ship it.
The workshop guide (`contoso-health-l400-workshop.html`) explains every file; its Appendix C is the
full deploy and test runbook.

```
browser ─► Application Gateway WAF_v2 ─► web (React SPA + BFF, App Service or AKS) ─► API ─► PostgreSQL 17
             DRS 2.2 · Bot Manager 1.1      private endpoint                          └─► Azure Managed Redis B0
             custom rules · rate limit
```

| Folder | What it holds |
|---|---|
| `app/api` | Claims and eligibility API (Node.js 24, no framework): cache-aside, idempotency, rate limit, Entra auth |
| `app/web` | Member portal: React 19 + TypeScript (Vite) served by a backend-for-frontend (`server.js`); browser tests in `e2e/` |
| `infra/bicep`, `infra/terraform` | The same three stacks in both languages: `platform` (hub, DNS, policy), `workload` (spoke, PaaS, WAF), `aks` |
| `k8s` | Kustomize base and lab/prod overlays for AKS |
| `scripts` | Bootstrap (OIDC, Terraform state, database), `smoke-test.sh`, `waf-test.sh`, AKS post-provisioning |
| `.github` | CI, IaC validation, deploy workflows with deployment tests, Copilot instructions, agents and skills |
| `.devcontainer` | Codespaces / dev container with every CLI, Node.js 24 and Chromium |

## Run it locally

```bash
docker compose up --build --wait          # PostgreSQL, Redis, API and portal -> http://localhost:8080
scripts/smoke-test.sh http://localhost:8080
cd app/web && npm install && npm run e2e:install && npm run e2e
```

Hot reload for the portal: start the API (`cd app/api && npm install && npm run dev`), then
`cd app/web && npm run dev` and open http://localhost:5173.

## Deploy to Azure (order)

1. `scripts/preflight.sh`: tools, sign-in, providers and region checks.
2. `platform` stack, then `workload` stack (see `infra/bicep/README.md` or `infra/terraform/README.md`).
3. `scripts/db-bootstrap.sh lab`: creates the API's passwordless database role from the ops VM.
4. App Service: build the portal (`cd app/web && npm ci && npm run build`), zip `server.js`,
   `package.json` and `dist/`, zip-deploy the API first, then the web app. Or let
   `.github/workflows/app-deploy-appservice.yml` do it.
5. AKS (optional): `aks` stack, `scripts/aks-postprovision.sh lab`, the `Container build` and
   `Deploy to AKS` workflows.

## Test every deployment

```bash
BASE="http://${APPGW_PUBLIC_IP}"                                  # App Service listener (:8080 = AKS)
curl -fsS "${BASE}/readyz"                                        # web ready and the API reachable
scripts/smoke-test.sh "${BASE}"                                   # health, cache MISS -> HIT, idempotent claims
scripts/waf-test.sh "${BASE}"                                     # attacks blocked by the WAF with 403
(cd app/web && BASE_URL="${BASE}" E2E_EXPECT_WAF=true npm run e2e)   # the React portal in a real browser
WAF_RATE_LIMIT=true scripts/waf-test.sh "${BASE}"                 # last: the claim rate limit
```

Production has no demo data and must not be written to: use `SMOKE_WRITE=false SMOKE_DATA=false`
and `E2E_READONLY=true`. The deploy workflows run all of this automatically after each deployment.

Nothing in this kit has been deployed to Azure by its authors: the application and the test
scripts were run locally, and the IaC is checked by the `IaC validate` workflow on your first push.
