import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApi, daysAgo } from '../helpers.js';

describe('Contoso Health API (in-memory adapters)', () => {
  let api;
  before(async () => { api = await startApi(); });
  after(async () => { await api.stop(); });

  test('liveness and readiness', async () => {
    assert.equal((await api.call('/healthz')).status, 200);
    const ready = await api.call('/readyz');
    assert.equal(ready.status, 200);
    assert.deepEqual(ready.body.checks, { postgres: 'ok', cache: 'ok' });
  });

  test('info reports where the request was served', async () => {
    const r = await api.call('/api/info');
    assert.equal(r.status, 200);
    assert.equal(r.body.storage, 'memory');
    assert.equal(r.body.cache, 'memory');
    assert.ok(r.headers.get('x-request-id'));
    assert.ok(r.headers.get('x-served-by'));
    assert.match(r.headers.get('server-timing'), /total;dur=/);
  });

  test('eligibility: active member is covered, cache MISS then HIT', async () => {
    const first = await api.call('/api/members/CH-100001/eligibility');
    assert.equal(first.status, 200);
    assert.equal(first.body.fullName, 'Ayu Lestari');
    assert.equal(first.body.eligible, true);
    assert.equal(first.headers.get('x-cache'), 'MISS');
    const second = await api.call('/api/members/CH-100001/eligibility');
    assert.equal(second.headers.get('x-cache'), 'HIT');
    assert.equal(second.body.remainingIdr, first.body.remainingIdr);
  });

  test('eligibility: grace and suspended members are not covered', async () => {
    const grace = await api.call('/api/members/CH-100002/eligibility');
    assert.equal(grace.body.eligible, false);
    assert.match(grace.body.reason, /grace/);
    const suspended = await api.call('/api/members/CH-100003/eligibility');
    assert.equal(suspended.body.eligible, false);
    assert.match(suspended.body.reason, /suspended/);
  });

  test('eligibility: validation and not found', async () => {
    assert.equal((await api.call('/api/members/nope/eligibility')).status, 400);
    assert.equal((await api.call('/api/members/CH-999999/eligibility')).status, 404);
  });

  test('provider directory filters and caches', async () => {
    const cities = await api.call('/api/providers/cities');
    assert.equal(cities.body.length, 8);
    const r1 = await api.call('/api/providers?city=Jakarta&type=hospital');
    assert.equal(r1.status, 200);
    assert.ok(r1.body.length >= 3);
    assert.ok(r1.body.every((p) => p.city === 'Jakarta' && p.type === 'hospital'));
    assert.equal(r1.headers.get('x-cache'), 'MISS');
    assert.equal((await api.call('/api/providers?city=Jakarta&type=hospital')).headers.get('x-cache'), 'HIT');
    assert.equal((await api.call('/api/providers?type=spa')).status, 400);
  });

  test('member claims list', async () => {
    const r = await api.call('/api/members/CH-100001/claims');
    assert.equal(r.status, 200);
    assert.ok(Array.isArray(r.body));
  });

  test('routing errors: 404, 405, invalid JSON, wrong media type, body too large', async () => {
    assert.equal((await api.call('/api/nothing')).status, 404);
    assert.equal((await api.call('/api/claims', { method: 'GET' })).status, 405);
    assert.equal((await api.call('/api/claims', { method: 'POST', body: '{bad json', headers: { 'content-type': 'application/json' } })).status, 400);
    assert.equal((await api.call('/api/claims', { method: 'POST', body: 'x=1', headers: { 'content-type': 'text/plain' } })).status, 415);
    const big = JSON.stringify({ note: 'x'.repeat(70 * 1024) });
    assert.equal((await api.call('/api/claims', { method: 'POST', body: big, headers: { 'content-type': 'application/json' } })).status, 413);
  });
});

describe('claims: idempotency, rate limit, decisions, cache invalidation', () => {
  let api;
  before(async () => { api = await startApi({ cfg: { rateLimit: { claimsPerMinute: 5 } } }); });
  after(async () => { await api.stop(); });

  const claim = (over = {}) => ({ memberId: 'CH-100001', providerId: 'PRV-JAK-001', claimType: 'outpatient', serviceDate: daysAgo(2), amountIdr: 350000, note: 'Test visit', ...over });

  test('validation returns every problem at once', async () => {
    const r = await api.call('/api/claims', { method: 'POST', body: { memberId: 'x', amountIdr: 5, serviceDate: '2999-01-01' } });
    assert.equal(r.status, 400);
    assert.ok(r.body.error.details.length >= 4);
  });

  test('ineligible member and unknown provider are rejected with 422', async () => {
    assert.equal((await api.call('/api/claims', { method: 'POST', body: claim({ memberId: 'CH-100003' }) })).status, 422);
    assert.equal((await api.call('/api/claims', { method: 'POST', body: claim({ providerId: 'PRV-XXX-999' }) })).status, 422);
  });

  test('same Idempotency-Key returns the original claim', async () => {
    const key = 'demo-key-0001';
    const first = await api.call('/api/claims', { method: 'POST', body: claim(), headers: { 'idempotency-key': key } });
    assert.equal(first.status, 201);
    assert.match(first.headers.get('location'), /\/api\/claims\/CLM-\d{4}-\d{6}/);
    const again = await api.call('/api/claims', { method: 'POST', body: claim(), headers: { 'idempotency-key': key } });
    assert.equal(again.status, 200);
    assert.equal(again.headers.get('idempotent-replay'), 'true');
    assert.equal(again.body.claimId, first.body.claimId);
    const fetched = await api.call(`/api/claims/${first.body.claimId}`);
    assert.equal(fetched.body.status, 'submitted');
  });

  test('approving a claim updates the member eligibility (cache invalidated)', async () => {
    const before = await api.call('/api/members/CH-100001/eligibility');
    const created = await api.call('/api/claims', { method: 'POST', body: claim({ amountIdr: 1_000_000, serviceDate: daysAgo(1) }) });
    assert.equal(created.status, 201);
    const queue = await api.call('/api/ops/claims?status=submitted&limit=200');
    assert.ok(queue.body.some((c) => c.claimId === created.body.claimId));
    const decided = await api.call(`/api/ops/claims/${created.body.claimId}/decision`, { method: 'POST', body: { decision: 'approve', approvedIdr: 900_000 } });
    assert.equal(decided.status, 200);
    assert.equal(decided.body.status, 'approved');
    const after = await api.call('/api/members/CH-100001/eligibility');
    assert.equal(after.headers.get('x-cache'), 'MISS');
    const sameYear = new Date(Date.now() - 86400000).getUTCFullYear() === new Date().getUTCFullYear();
    if (sameYear) assert.equal(after.body.usedThisYearIdr, before.body.usedThisYearIdr + 900_000);
    const twice = await api.call(`/api/ops/claims/${created.body.claimId}/decision`, { method: 'POST', body: { decision: 'reject' } });
    assert.equal(twice.status, 409);
  });

  test('decision validation', async () => {
    assert.equal((await api.call('/api/ops/claims/CLM-2026-000001/decision', { method: 'POST', body: { decision: 'maybe' } })).status, 400);
    assert.equal((await api.call('/api/ops/claims/CLM-1999-999999/decision', { method: 'POST', body: { decision: 'approve' } })).status, 404);
  });

  test('stats expose cache hit ratio and data counts', async () => {
    const r = await api.call('/api/stats');
    assert.equal(r.status, 200);
    assert.equal(r.body.data.members, 300);
    assert.ok(r.body.runtime.cache.hits >= 0);
    assert.ok(r.body.runtime.requests > 0);
  });
});

describe('operations API can be switched off per environment', () => {
  test('returns 403 when OPS_API_ENABLED=false', async () => {
    const api = await startApi({ cfg: { opsApiEnabled: false } });
    try {
      assert.equal((await api.call('/api/ops/claims')).status, 403);
    } finally { await api.stop(); }
  });
});

describe('rate limit', () => {
  test('the sixth claim in a minute for the same member gets 429 with Retry-After', async () => {
    const api = await startApi({ cfg: { rateLimit: { claimsPerMinute: 5 } } });
    try {
      const statuses = [];
      let last;
      for (let i = 0; i < 6; i += 1) {
        last = await api.call('/api/claims', { method: 'POST', body: { memberId: 'CH-100001', providerId: 'PRV-JAK-003', claimType: 'pharmacy', serviceDate: daysAgo(1), amountIdr: 60000 + i } });
        statuses.push(last.status);
      }
      assert.deepEqual(statuses, [201, 201, 201, 201, 201, 429]);
      assert.ok(Number(last.headers.get('retry-after')) > 0);
    } finally { await api.stop(); }
  });
});
