import { test } from 'node:test';
import assert from 'node:assert/strict';
import { startApi } from '../helpers.js';
import { createMemoryCache } from '../../src/cache/memory.js';

// A cache whose every call fails, like Redis during a zone outage.
const brokenCache = () => {
  const boom = async () => { const e = new Error('connect ECONNREFUSED'); e.code = 'ECONNREFUSED'; throw e; };
  return { kind: 'redis', ping: async () => false, close: async () => {}, get: boom, set: boom, setIfAbsent: boom, del: boom, incrWithExpiry: boom };
};

test('API keeps serving from the database when Redis is down', async () => {
  const api = await startApi({ cache: brokenCache() });
  try {
    const r = await api.call('/api/members/CH-100001/eligibility');
    assert.equal(r.status, 200);
    assert.equal(r.headers.get('x-cache'), 'BYPASS');
    const ready = await api.call('/readyz');
    assert.equal(ready.status, 200, 'the cache is optional for readiness');
    assert.equal(ready.body.checks.cache, 'degraded');
    const stats = await api.call('/api/stats');
    assert.ok(stats.body.runtime.cache.errors >= 1);
  } finally { await api.stop(); }
});

test('readiness fails when the database is down', async () => {
  const { createMemoryRepository } = await import('../../src/data/memory.js');
  const repo = createMemoryRepository();
  repo.ping = async () => { const e = new Error('timeout'); e.code = 'ETIMEDOUT'; throw e; };
  const api = await startApi({ repo, cache: createMemoryCache() });
  try {
    const ready = await api.call('/readyz');
    assert.equal(ready.status, 503);
    assert.match(ready.body.checks.postgres, /ETIMEDOUT/);
    assert.equal((await api.call('/healthz')).status, 200, 'liveness must not depend on the database');
  } finally { await api.stop(); }
});

test('memory cache honours TTL', async () => {
  let t = 0;
  const c = createMemoryCache({ now: () => t });
  await c.set('k', 'v', 10);
  assert.equal(await c.get('k'), 'v');
  t = 11000;
  assert.equal(await c.get('k'), null);
  assert.equal(await c.setIfAbsent('n', '1', 5), true);
  assert.equal(await c.setIfAbsent('n', '2', 5), false);
  assert.equal(await c.incrWithExpiry('r', 60), 1);
  assert.equal(await c.incrWithExpiry('r', 60), 2);
});
