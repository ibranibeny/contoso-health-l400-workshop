import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateSeed, CITIES } from '../../src/data/seed.js';

test('synthetic data is deterministic and well formed', () => {
  const a = generateSeed({ today: new Date('2026-11-26T00:00:00Z') });
  const b = generateSeed({ today: new Date('2026-11-26T00:00:00Z') });
  assert.deepEqual(a, b);
  assert.equal(a.members.length, 300);
  assert.equal(new Set(a.providers.map((p) => p.city)).size, CITIES.length);
  assert.ok(a.claims.length > 300);
  assert.ok(a.members.every((m) => /^CH-\d{6}$/.test(m.memberId)));
  assert.ok(a.providers.every((p) => /^PRV-[A-Z]{3}-\d{3}$/.test(p.providerId)));
  assert.ok(a.claims.every((c) => /^CLM-\d{4}-\d{6}$/.test(c.claimId)));
  assert.equal(new Set(a.providers.map((p) => p.providerId)).size, a.providers.length, 'provider ids are unique');
  assert.equal(a.members[0].fullName, 'Ayu Lestari');
});
