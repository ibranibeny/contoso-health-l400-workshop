// Runs against real PostgreSQL and Redis (GitHub Actions service containers,
// docker compose or the dev container). Skipped when PGHOST/REDIS_HOST are not set.
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApi, silent, daysAgo } from '../helpers.js';
import { loadConfig } from '../../src/config.js';

const enabled = Boolean(process.env.PGHOST && process.env.REDIS_HOST);

describe('integration: PostgreSQL + Redis', { skip: !enabled && 'PGHOST and REDIS_HOST not set' }, () => {
  let api;
  let pool;
  let redis;
  before(async () => {
    const cfg = loadConfig();
    const { createPgPool, createPostgresRepository } = await import('../../src/data/postgres.js');
    const { migrate } = await import('../../src/db/migrate.js');
    const { createRedisCache } = await import('../../src/cache/redis.js');
    pool = await createPgPool(cfg, silent);
    await pool.query(`DROP SCHEMA IF EXISTS ${cfg.pg.schema} CASCADE`);
    // Two concurrent migrations must not collide (advisory lock).
    await Promise.all([migrate(pool, { schema: cfg.pg.schema, seed: true, log: silent }), migrate(pool, { schema: cfg.pg.schema, seed: true, log: silent })]);
    redis = await createRedisCache(cfg, silent);
    await redis.client.flushDb();
    api = await startApi({ repo: createPostgresRepository(pool), cache: redis });
  });
  after(async () => {
    await api?.stop();
    await redis?.close();
    await pool?.end();
  });

  test('migrations are recorded once and seed data is loaded', async () => {
    const { rows } = await pool.query('SELECT version FROM schema_migrations ORDER BY version');
    assert.deepEqual(rows.map((r) => r.version), ['001_init.sql', '002_audit.sql']);
    const stats = await api.call('/api/stats');
    assert.equal(stats.body.data.members, 300);
    assert.ok(stats.body.data.pool.total >= 1);
  });

  test('readiness checks both dependencies', async () => {
    const r = await api.call('/readyz');
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.checks, { postgres: 'ok', cache: 'ok' });
    assert.equal((await api.call('/api/info')).body.storage, 'postgres');
  });

  test('eligibility is cached in Redis (MISS then HIT)', async () => {
    const a = await api.call('/api/members/CH-100001/eligibility');
    assert.equal(a.status, 200);
    assert.equal(a.headers.get('x-cache'), 'MISS');
    const b = await api.call('/api/members/CH-100001/eligibility');
    assert.equal(b.headers.get('x-cache'), 'HIT');
    assert.ok(await redis.client.ttl('ch:v1:elig:CH-100001') > 0);
  });

  test('providers come from PostgreSQL with text[] specialties', async () => {
    const r = await api.call('/api/providers?city=Bandung');
    assert.equal(r.status, 200);
    assert.ok(r.body.length > 0);
    assert.ok(Array.isArray(r.body[0].specialties));
  });

  test('claim lifecycle with idempotency enforced by the database', async () => {
    const body = { memberId: 'CH-100001', providerId: 'PRV-JAK-001', claimType: 'lab', serviceDate: daysAgo(3), amountIdr: 420000 };
    const key = 'integration-key-1';
    const first = await api.call('/api/claims', { method: 'POST', body, headers: { 'idempotency-key': key } });
    assert.equal(first.status, 201);
    // Simulate Redis losing the idempotency entry: the UNIQUE column still prevents a duplicate.
    await redis.client.del(`ch:v1:idem:${key}`);
    const again = await api.call('/api/claims', { method: 'POST', body, headers: { 'idempotency-key': key } });
    assert.equal(again.status, 200);
    assert.equal(again.body.claimId, first.body.claimId);
    const decided = await api.call(`/api/ops/claims/${first.body.claimId}/decision`, { method: 'POST', body: { decision: 'approve' } });
    assert.equal(decided.body.status, 'approved');
    const audit = await pool.query('SELECT from_status, to_status FROM claim_audit WHERE claim_id = $1', [first.body.claimId]);
    assert.deepEqual(audit.rows, [{ from_status: 'submitted', to_status: 'approved' }]);
  });

  test('rate limit is shared through Redis', async () => {
    const body = (i) => ({ memberId: 'CH-100001', providerId: 'PRV-JAK-002', claimType: 'pharmacy', serviceDate: daysAgo(1), amountIdr: 50000 + i });
    await redis.client.flushDb();
    const statuses = [];
    for (let i = 0; i < 6; i += 1) statuses.push((await api.call('/api/claims', { method: 'POST', body: body(i) })).status);
    assert.deepEqual(statuses.slice(0, 5), [201, 201, 201, 201, 201]);
    assert.equal(statuses[5], 429);
  });
});
