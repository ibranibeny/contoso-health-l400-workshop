import { once } from 'node:events';
import { buildApp } from '../src/app.js';
import { loadConfig } from '../src/config.js';
import { createLogger } from '../src/logger.js';
import { createMemoryRepository } from '../src/data/memory.js';
import { createMemoryCache } from '../src/cache/memory.js';

export const silent = createLogger({ level: 'silent' });

export async function startApi({ repo = createMemoryRepository(), cache = createMemoryCache(), cfg: overrides = {} } = {}) {
  const cfg = loadConfig({ port: 0, ...overrides });
  const app = buildApp({ cfg, log: silent, repo, cache });
  app.server.listen(0, '127.0.0.1');
  await once(app.server, 'listening');
  const base = `http://127.0.0.1:${app.server.address().port}`;
  const call = async (path, { method = 'GET', body, headers = {} } = {}) => {
    const res = await fetch(base + path, {
      method,
      headers: { ...(body !== undefined ? { 'content-type': 'application/json' } : {}), ...headers },
      body: body !== undefined ? (typeof body === 'string' ? body : JSON.stringify(body)) : undefined,
    });
    const text = await res.text();
    return { status: res.status, headers: res.headers, body: text ? JSON.parse(text) : undefined };
  };
  const stop = async () => { app.server.closeAllConnections?.(); await new Promise((r) => app.server.close(r)); };
  return { ...app, base, call, stop, cfg };
}

export const daysAgo = (n) => new Date(Date.now() - n * 86400000).toISOString().slice(0, 10);
