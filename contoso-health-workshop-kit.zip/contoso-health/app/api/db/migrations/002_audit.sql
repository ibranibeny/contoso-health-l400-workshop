-- Every claim decision is recorded: who changed what, and when.
CREATE TABLE IF NOT EXISTS claim_audit (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  claim_id    text NOT NULL REFERENCES claims (claim_id),
  from_status text NOT NULL,
  to_status   text NOT NULL,
  actor       text NOT NULL,
  at          timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_claim_audit_claim ON claim_audit (claim_id, at);
