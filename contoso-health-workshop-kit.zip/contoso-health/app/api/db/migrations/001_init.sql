-- Contoso Health core schema. Runs inside the schema named by PGSCHEMA (default "app").
CREATE TABLE IF NOT EXISTS plans (
  plan_code            text PRIMARY KEY,
  name                 text NOT NULL,
  annual_limit_idr     bigint NOT NULL CHECK (annual_limit_idr > 0),
  outpatient_copay_pct smallint NOT NULL CHECK (outpatient_copay_pct BETWEEN 0 AND 100),
  room_class           text NOT NULL
);

CREATE TABLE IF NOT EXISTS members (
  member_id          text PRIMARY KEY,
  full_name          text NOT NULL,
  date_of_birth      date NOT NULL,
  city               text NOT NULL,
  plan_code          text NOT NULL REFERENCES plans (plan_code),
  status             text NOT NULL CHECK (status IN ('active', 'grace', 'suspended')),
  premium_paid_until date NOT NULL,
  created_at         timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS providers (
  provider_id  text PRIMARY KEY,
  name         text NOT NULL,
  type         text NOT NULL CHECK (type IN ('hospital', 'clinic', 'pharmacy', 'lab')),
  city         text NOT NULL,
  address      text NOT NULL,
  network_tier text NOT NULL CHECK (network_tier IN ('preferred', 'standard')),
  specialties  text[] NOT NULL DEFAULT '{}',
  open_24h     boolean NOT NULL DEFAULT false
);

CREATE SEQUENCE IF NOT EXISTS claim_seq START 1;

CREATE TABLE IF NOT EXISTS claims (
  claim_id        text PRIMARY KEY,
  member_id       text NOT NULL REFERENCES members (member_id),
  provider_id     text NOT NULL REFERENCES providers (provider_id),
  claim_type      text NOT NULL CHECK (claim_type IN ('outpatient', 'inpatient', 'pharmacy', 'lab')),
  service_date    date NOT NULL,
  amount_idr      bigint NOT NULL CHECK (amount_idr > 0),
  approved_idr    bigint CHECK (approved_idr IS NULL OR approved_idr >= 0),
  status          text NOT NULL CHECK (status IN ('submitted', 'in_review', 'approved', 'rejected', 'paid')),
  diagnosis_note  text,
  decision_note   text,
  idempotency_key text UNIQUE,
  submitted_at    timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_claims_member ON claims (member_id, submitted_at DESC);
CREATE INDEX IF NOT EXISTS ix_claims_status ON claims (status, submitted_at);
CREATE INDEX IF NOT EXISTS ix_providers_city_type ON providers (city, type);
