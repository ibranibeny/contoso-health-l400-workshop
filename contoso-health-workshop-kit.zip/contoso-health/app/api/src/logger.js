// Structured JSON logs on stdout. App Service and AKS (Container insights) both
// collect stdout, so no log agent or file is needed inside the container.
const LEVELS = { debug: 10, info: 20, warn: 30, error: 40, silent: 99 };

export function createLogger({ level = 'info', base = {}, sink = (line) => process.stdout.write(line + '\n') } = {}) {
  const min = LEVELS[level] ?? LEVELS.info;
  const write = (lvl, msg, fields) => {
    if (LEVELS[lvl] < min) return;
    const entry = { ts: new Date().toISOString(), level: lvl, msg, ...base, ...fields };
    if (fields?.err instanceof Error) entry.err = { name: fields.err.name, message: fields.err.message, code: fields.err.code };
    sink(JSON.stringify(entry));
  };
  return {
    debug: (msg, f) => write('debug', msg, f),
    info: (msg, f) => write('info', msg, f),
    warn: (msg, f) => write('warn', msg, f),
    error: (msg, f) => write('error', msg, f),
    child: (extra) => createLogger({ level, base: { ...base, ...extra }, sink }),
  };
}
