// PostgreSQL repository (Azure Database for PostgreSQL flexible server in Azure,
// a postgres:17 container locally and in CI). All SQL is parameterised.
import { createCredential, SCOPES } from '../azure/credential.js';
import { conflict, notFound } from '../http/errors.js';

const MEMBER_SQL = `
  SELECT m.member_id, m.full_name, m.date_of_birth, m.city, m.plan_code, m.status, m.premium_paid_until,
         p.name AS plan_name, p.annual_limit_idr, p.outpatient_copay_pct, p.room_class
    FROM members m JOIN plans p ON p.plan_code = m.plan_code
   WHERE m.member_id = $1`;

const CLAIM_COLUMNS = `c.claim_id, c.member_id, c.provider_id, c.claim_type, c.service_date, c.amount_idr, c.approved_idr,
       c.status, c.diagnosis_note, c.decision_note, c.submitted_at, c.updated_at, pr.name AS provider_name`;

const toMember = (r) => ({
  memberId: r.member_id,
  fullName: r.full_name,
  dateOfBirth: r.date_of_birth,
  city: r.city,
  planCode: r.plan_code,
  status: r.status,
  premiumPaidUntil: r.premium_paid_until,
  plan: { planCode: r.plan_code, name: r.plan_name, annualLimitIdr: r.annual_limit_idr, outpatientCopayPct: r.outpatient_copay_pct, roomClass: r.room_class },
});
const toProvider = (r) => ({
  providerId: r.provider_id, name: r.name, type: r.type, city: r.city, address: r.address,
  networkTier: r.network_tier, specialties: r.specialties, open24h: r.open_24h,
});
const toClaim = (r) => ({
  claimId: r.claim_id, memberId: r.member_id, providerId: r.provider_id, providerName: r.provider_name,
  claimType: r.claim_type, serviceDate: r.service_date, amountIdr: r.amount_idr, approvedIdr: r.approved_idr,
  status: r.status, diagnosisNote: r.diagnosis_note, decisionNote: r.decision_note,
  submittedAt: new Date(r.submitted_at).toISOString(), updatedAt: new Date(r.updated_at).toISOString(),
  ...(r.member_name ? { memberName: r.member_name } : {}),
});

export async function createPgPool(cfg, log) {
  const { default: pg } = await import('pg');
  pg.types.setTypeParser(1082, (v) => v); // date   -> 'YYYY-MM-DD' (no timezone shifts)
  pg.types.setTypeParser(20, (v) => Number(v)); // bigint -> number (IDR amounts stay far below 2^53)

  let password = cfg.pg.password;
  if (cfg.pg.auth === 'entra') {
    const credential = await createCredential(cfg);
    // node-postgres calls this for every new physical connection. @azure/identity
    // caches the access token and renews it before it expires, so long-running
    // pools keep working without restarts and nothing secret is stored.
    password = async () => (await credential.getToken(SCOPES.postgres)).token;
  }

  const pool = new pg.Pool({
    host: cfg.pg.host,
    port: cfg.pg.port,
    database: cfg.pg.database,
    user: cfg.pg.user,
    password,
    ssl: cfg.pg.ssl ? { rejectUnauthorized: true, servername: cfg.pg.host } : false,
    max: cfg.pg.poolMax,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 5_000,
    statement_timeout: 10_000,
    application_name: `${cfg.service}/${cfg.instance}`.slice(0, 63),
    options: `-c search_path=${cfg.pg.schema},public`,
  });
  pool.on('error', (err) => log.warn('postgres pool error', { err }));
  return pool;
}

export function createPostgresRepository(pool) {
  const q = (text, params) => pool.query(text, params);
  return {
    kind: 'postgres',
    pool,
    async ping() { await q('SELECT 1'); return true; },
    async close() { await pool.end(); },
    async getMember(id) {
      const { rows } = await q(MEMBER_SQL, [id]);
      return rows[0] ? toMember(rows[0]) : null;
    },
    async approvedTotalForYear(memberId, year = new Date().getUTCFullYear()) {
      const { rows } = await q(
        `SELECT COALESCE(SUM(approved_idr), 0)::bigint AS total FROM claims
          WHERE member_id = $1 AND status IN ('approved', 'paid')
            AND service_date >= make_date($2, 1, 1) AND service_date < make_date($2 + 1, 1, 1)`,
        [memberId, year],
      );
      return rows[0].total;
    },
    async listCities() {
      const { rows } = await q('SELECT DISTINCT city FROM providers ORDER BY city');
      return rows.map((r) => r.city);
    },
    async listProviders({ city, type } = {}) {
      const { rows } = await q(
        `SELECT * FROM providers WHERE ($1::text IS NULL OR city = $1) AND ($2::text IS NULL OR type = $2) ORDER BY name`,
        [city || null, type || null],
      );
      return rows.map(toProvider);
    },
    async getProvider(id) {
      const { rows } = await q('SELECT * FROM providers WHERE provider_id = $1', [id]);
      return rows[0] ? toProvider(rows[0]) : null;
    },
    async listClaimsForMember(memberId, limit = 20) {
      const { rows } = await q(
        `SELECT ${CLAIM_COLUMNS} FROM claims c JOIN providers pr ON pr.provider_id = c.provider_id
          WHERE c.member_id = $1 ORDER BY c.submitted_at DESC LIMIT $2`,
        [memberId, limit],
      );
      return rows.map(toClaim);
    },
    async getClaim(id) {
      const { rows } = await q(
        `SELECT ${CLAIM_COLUMNS} FROM claims c JOIN providers pr ON pr.provider_id = c.provider_id WHERE c.claim_id = $1`,
        [id],
      );
      return rows[0] ? toClaim(rows[0]) : null;
    },
    async getClaimByIdempotencyKey(key) {
      const { rows } = await q(
        `SELECT ${CLAIM_COLUMNS} FROM claims c JOIN providers pr ON pr.provider_id = c.provider_id WHERE c.idempotency_key = $1`,
        [key],
      );
      return rows[0] ? toClaim(rows[0]) : null;
    },
    async createClaim(input) {
      // The UNIQUE idempotency_key makes the database the final guard against
      // duplicate submissions, even if Redis is unavailable.
      const { rows } = await q(
        `INSERT INTO claims (claim_id, member_id, provider_id, claim_type, service_date, amount_idr, status, diagnosis_note, idempotency_key)
         VALUES ('CLM-' || to_char(now() AT TIME ZONE 'UTC', 'YYYY') || '-' || lpad(nextval('claim_seq')::text, 6, '0'),
                 $1, $2, $3, $4, $5, 'submitted', $6, $7)
         ON CONFLICT (idempotency_key) DO NOTHING
         RETURNING claim_id`,
        [input.memberId, input.providerId, input.claimType, input.serviceDate, input.amountIdr, input.note || null, input.idempotencyKey || null],
      );
      if (!rows[0]) return { replay: true, claim: await this.getClaimByIdempotencyKey(input.idempotencyKey) };
      return { replay: false, claim: await this.getClaim(rows[0].claim_id) };
    },
    async listClaimsByStatus(status, limit = 50) {
      const { rows } = await q(
        `SELECT ${CLAIM_COLUMNS}, m.full_name AS member_name
           FROM claims c JOIN providers pr ON pr.provider_id = c.provider_id JOIN members m ON m.member_id = c.member_id
          WHERE c.status = $1 ORDER BY c.submitted_at LIMIT $2`,
        [status, limit],
      );
      return rows.map(toClaim);
    },
    async decideClaim(id, { decision, approvedIdr, note, actor }) {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const { rows } = await client.query('SELECT status, amount_idr FROM claims WHERE claim_id = $1 FOR UPDATE', [id]);
        if (!rows[0]) throw notFound(`Claim ${id} not found`);
        const from = rows[0].status;
        if (from !== 'submitted' && from !== 'in_review') throw conflict(`Claim ${id} is already ${from}`);
        const to = decision === 'approve' ? 'approved' : 'rejected';
        await client.query(
          'UPDATE claims SET status = $2, approved_idr = $3, decision_note = $4, updated_at = now() WHERE claim_id = $1',
          [id, to, to === 'approved' ? approvedIdr ?? rows[0].amount_idr : null, note || null],
        );
        await client.query('INSERT INTO claim_audit (claim_id, from_status, to_status, actor) VALUES ($1, $2, $3, $4)', [id, from, to, actor]);
        await client.query('COMMIT');
      } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        throw err;
      } finally {
        client.release();
      }
      return this.getClaim(id);
    },
    async stats() {
      const [{ rows: counts }, { rows: byStatus }] = await Promise.all([
        q(`SELECT (SELECT count(*) FROM members)::int AS members, (SELECT count(*) FROM providers)::int AS providers,
                  (SELECT count(*) FROM claims)::int AS claims`),
        q('SELECT status, count(*)::int AS n FROM claims GROUP BY status'),
      ]);
      return {
        ...counts[0],
        claimsByStatus: Object.fromEntries(byStatus.map((r) => [r.status, r.n])),
        pool: { total: pool.totalCount, idle: pool.idleCount, waiting: pool.waitingCount },
      };
    },
  };
}
