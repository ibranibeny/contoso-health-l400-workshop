// Deterministic synthetic data. The same generator feeds the in-memory store
// and the PostgreSQL seed, so every environment shows identical numbers.
// All names are fictional; no real member or provider data is used.

export const PLANS = [
  { planCode: 'SILVER', name: 'Contoso Silver', annualLimitIdr: 150_000_000, outpatientCopayPct: 20, roomClass: 'Class 2' },
  { planCode: 'GOLD', name: 'Contoso Gold', annualLimitIdr: 400_000_000, outpatientCopayPct: 10, roomClass: 'Class 1' },
  { planCode: 'PLATINUM', name: 'Contoso Platinum', annualLimitIdr: 1_000_000_000, outpatientCopayPct: 0, roomClass: 'VIP' },
];

export const CITIES = ['Jakarta', 'Surabaya', 'Bandung', 'Medan', 'Makassar', 'Semarang', 'Denpasar', 'Yogyakarta'];

const FIRST = ['Ayu', 'Budi', 'Citra', 'Dimas', 'Eka', 'Fajar', 'Gita', 'Hendra', 'Indah', 'Joko', 'Kartika', 'Lestari', 'Made', 'Nur', 'Putri', 'Rizky', 'Sari', 'Teguh', 'Wahyu', 'Yuni', 'Agus', 'Bayu', 'Dewi', 'Arif'];
const LAST = ['Santoso', 'Wijaya', 'Pratama', 'Hidayat', 'Kusuma', 'Saputra', 'Lubis', 'Siregar', 'Nasution', 'Wibowo', 'Halim', 'Gunawan', 'Setiawan', 'Purnomo', 'Rahman', 'Utami', 'Permana'];
const PROVIDER_KINDS = [
  { type: 'hospital', prefix: 'RS Contoso', suffixes: ['Medika', 'Harapan', 'Sehat Sentosa'], specialties: ['emergency', 'internal medicine', 'surgery', 'pediatrics', 'cardiology'] },
  { type: 'clinic', prefix: 'Klinik Contoso', suffixes: ['Pratama', 'Keluarga'], specialties: ['general practice', 'dental'] },
  { type: 'pharmacy', prefix: 'Apotek Contoso', suffixes: ['24'], specialties: ['pharmacy'] },
  { type: 'lab', prefix: 'Lab Contoso', suffixes: ['Diagnostika'], specialties: ['laboratory', 'radiology'] },
];
const STREETS = ['Jl. Merdeka', 'Jl. Sudirman', 'Jl. Diponegoro', 'Jl. Gatot Subroto', 'Jl. Ahmad Yani', 'Jl. Pahlawan'];
const CLAIM_TYPES = ['outpatient', 'inpatient', 'pharmacy', 'lab'];
const CLAIM_STATUS = ['submitted', 'in_review', 'approved', 'approved', 'paid', 'paid', 'rejected'];
const NOTES = ['Follow-up consultation', 'Acute fever', 'Annual check-up', 'Physiotherapy session', 'Prescription refill', 'Blood panel', 'Day surgery', 'Dental filling'];

// Mulberry32: tiny seeded PRNG so the data set is identical on every run.
function prng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const pad = (n, w) => String(n).padStart(w, '0');
const isoDate = (d) => d.toISOString().slice(0, 10);

export function generateSeed({ members = 300, claimsPerMember = 3, today = new Date() } = {}) {
  const rnd = prng(20261126);
  const pick = (arr) => arr[Math.floor(rnd() * arr.length)];
  const base = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate()));
  const addDays = (days) => new Date(base.getTime() + days * 86400000);

  const providers = [];
  CITIES.forEach((city, ci) => {
    let n = 1;
    for (const kind of PROVIDER_KINDS) {
      for (const suffix of kind.suffixes) {
        providers.push({
          providerId: `PRV-${city.slice(0, 3).toUpperCase()}-${pad(n, 3)}`,
          name: `${kind.prefix} ${suffix} ${city}`,
          type: kind.type,
          city,
          address: `${STREETS[(ci + n) % STREETS.length]} No. ${10 + ((ci * 7 + n * 13) % 180)}, ${city}`,
          networkTier: (ci + n) % 3 === 0 ? 'standard' : 'preferred',
          specialties: kind.specialties.slice(0, 2 + ((ci + n) % (kind.specialties.length - 1 || 1))),
          open24h: kind.type === 'hospital' || suffix === '24',
        });
        n += 1;
      }
    }
  });

  const memberRows = [];
  for (let i = 1; i <= members; i += 1) {
    const r = rnd();
    // About 88 % active, 8 % in the grace period, 4 % suspended.
    const status = r < 0.88 ? 'active' : r < 0.96 ? 'grace' : 'suspended';
    const paidUntil = status === 'active' ? addDays(15 + Math.floor(rnd() * 330)) : addDays(-1 - Math.floor(rnd() * 40));
    const birth = new Date(Date.UTC(1950 + Math.floor(rnd() * 55), Math.floor(rnd() * 12), 1 + Math.floor(rnd() * 27)));
    memberRows.push({
      memberId: `CH-${100000 + i}`,
      fullName: `${pick(FIRST)} ${pick(LAST)}`,
      dateOfBirth: isoDate(birth),
      city: CITIES[i % CITIES.length],
      planCode: PLANS[i % 7 === 0 ? 2 : i % 3 === 0 ? 1 : 0].planCode,
      status,
      premiumPaidUntil: isoDate(paidUntil),
    });
  }
  // A few well-known members for the demo script.
  Object.assign(memberRows[0], { fullName: 'Ayu Lestari', planCode: 'GOLD', status: 'active', premiumPaidUntil: isoDate(addDays(200)), city: 'Jakarta' });
  Object.assign(memberRows[1], { fullName: 'Budi Santoso', planCode: 'SILVER', status: 'grace', premiumPaidUntil: isoDate(addDays(-5)), city: 'Surabaya' });
  Object.assign(memberRows[2], { fullName: 'Citra Wijaya', planCode: 'PLATINUM', status: 'suspended', premiumPaidUntil: isoDate(addDays(-60)), city: 'Bandung' });

  const claims = [];
  let seq = 1;
  for (const m of memberRows) {
    const count = Math.floor(rnd() * (claimsPerMember * 2 + 1));
    for (let c = 0; c < count; c += 1) {
      const type = pick(CLAIM_TYPES);
      const cityProviders = providers.filter((p) => p.city === m.city);
      const provider = pick(cityProviders);
      const amount = type === 'inpatient' ? 5_000_000 + Math.floor(rnd() * 45_000_000) : 150_000 + Math.floor(rnd() * 2_500_000);
      const status = pick(CLAIM_STATUS);
      const serviceDate = addDays(-1 - Math.floor(rnd() * 300));
      const submittedAt = new Date(serviceDate.getTime() + (1 + Math.floor(rnd() * 3)) * 86400000);
      const approved = status === 'approved' || status === 'paid' ? Math.round(amount * (0.8 + rnd() * 0.2)) : null;
      claims.push({
        claimId: `CLM-${base.getUTCFullYear()}-${pad(seq, 6)}`,
        memberId: m.memberId,
        providerId: provider.providerId,
        claimType: type,
        serviceDate: isoDate(serviceDate),
        amountIdr: amount,
        approvedIdr: approved,
        status,
        diagnosisNote: pick(NOTES),
        decisionNote: status === 'rejected' ? 'Service not covered by plan' : null,
        submittedAt: submittedAt.toISOString(),
        updatedAt: submittedAt.toISOString(),
      });
      seq += 1;
    }
  }
  return { plans: PLANS, providers, members: memberRows, claims, nextClaimSeq: seq };
}
