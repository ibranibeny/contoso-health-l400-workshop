// In-memory repository: used by unit tests and by the zero-dependency quick start
// (npm start with no PGHOST). Never used in Azure: the API reports storage=memory
// on /api/info so a misconfigured deployment is obvious.
import { generateSeed } from './seed.js';
import { conflict, notFound } from '../http/errors.js';

export function createMemoryRepository({ seed = generateSeed() } = {}) {
  const plans = new Map(seed.plans.map((p) => [p.planCode, { ...p }]));
  const members = new Map(seed.members.map((m) => [m.memberId, { ...m }]));
  const providers = new Map(seed.providers.map((p) => [p.providerId, { ...p }]));
  const claims = new Map(seed.claims.map((c) => [c.claimId, { ...c }]));
  const audit = [];
  const idempotency = new Map();
  let seq = seed.nextClaimSeq;
  const year = new Date().getUTCFullYear();

  return {
    kind: 'memory',
    async ping() { return true; },
    async close() {},
    async getMember(id) {
      const m = members.get(id);
      return m ? { ...m, plan: { ...plans.get(m.planCode) } } : null;
    },
    async approvedTotalForYear(memberId, y = year) {
      let sum = 0;
      for (const c of claims.values()) {
        if (c.memberId === memberId && (c.status === 'approved' || c.status === 'paid') && c.serviceDate.startsWith(String(y))) sum += c.approvedIdr || 0;
      }
      return sum;
    },
    async listCities() {
      return [...new Set([...providers.values()].map((p) => p.city))].sort();
    },
    async listProviders({ city, type } = {}) {
      return [...providers.values()]
        .filter((p) => (!city || p.city === city) && (!type || p.type === type))
        .sort((a, b) => a.name.localeCompare(b.name));
    },
    async getProvider(id) { return providers.get(id) ? { ...providers.get(id) } : null; },
    async listClaimsForMember(memberId, limit = 20) {
      return [...claims.values()]
        .filter((c) => c.memberId === memberId)
        .sort((a, b) => b.submittedAt.localeCompare(a.submittedAt))
        .slice(0, limit)
        .map((c) => ({ ...c, providerName: providers.get(c.providerId)?.name }));
    },
    async getClaim(id) {
      const c = claims.get(id);
      return c ? { ...c, providerName: providers.get(c.providerId)?.name } : null;
    },
    async createClaim(input) {
      if (input.idempotencyKey && idempotency.has(input.idempotencyKey)) {
        return { replay: true, claim: await this.getClaim(idempotency.get(input.idempotencyKey)) };
      }
      const now = new Date().toISOString();
      const claim = {
        claimId: `CLM-${year}-${String(seq).padStart(6, '0')}`,
        memberId: input.memberId,
        providerId: input.providerId,
        claimType: input.claimType,
        serviceDate: input.serviceDate,
        amountIdr: input.amountIdr,
        approvedIdr: null,
        status: 'submitted',
        diagnosisNote: input.note || null,
        decisionNote: null,
        submittedAt: now,
        updatedAt: now,
      };
      seq += 1;
      claims.set(claim.claimId, claim);
      if (input.idempotencyKey) idempotency.set(input.idempotencyKey, claim.claimId);
      return { replay: false, claim: { ...claim, providerName: providers.get(claim.providerId)?.name } };
    },
    async listClaimsByStatus(status, limit = 50) {
      return [...claims.values()]
        .filter((c) => c.status === status)
        .sort((a, b) => a.submittedAt.localeCompare(b.submittedAt))
        .slice(0, limit)
        .map((c) => ({ ...c, providerName: providers.get(c.providerId)?.name, memberName: members.get(c.memberId)?.fullName }));
    },
    async decideClaim(id, { decision, approvedIdr, note, actor }) {
      const c = claims.get(id);
      if (!c) throw notFound(`Claim ${id} not found`);
      if (c.status !== 'submitted' && c.status !== 'in_review') throw conflict(`Claim ${id} is already ${c.status}`);
      const from = c.status;
      c.status = decision === 'approve' ? 'approved' : 'rejected';
      c.approvedIdr = decision === 'approve' ? approvedIdr ?? c.amountIdr : null;
      c.decisionNote = note || null;
      c.updatedAt = new Date().toISOString();
      audit.push({ claimId: id, fromStatus: from, toStatus: c.status, actor, at: c.updatedAt });
      return { ...c, providerName: providers.get(c.providerId)?.name };
    },
    async stats() {
      const byStatus = {};
      for (const c of claims.values()) byStatus[c.status] = (byStatus[c.status] || 0) + 1;
      return { members: members.size, providers: providers.size, claims: claims.size, claimsByStatus: byStatus };
    },
    _audit: audit,
  };
}
