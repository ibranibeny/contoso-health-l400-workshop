import http from 'node:http';
import { randomUUID } from 'node:crypto';
import { HttpError } from './errors.js';

const REQUEST_ID = /^[A-Za-z0-9._:-]{1,100}$/;

async function readJson(req, maxBytes) {
  if (req.method === 'GET' || req.method === 'HEAD') return undefined;
  const type = req.headers['content-type'] || '';
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maxBytes) throw new HttpError(413, 'payload_too_large', `Body larger than ${maxBytes} bytes`);
    chunks.push(chunk);
  }
  if (size === 0) return {};
  if (!type.includes('application/json')) throw new HttpError(415, 'unsupported_media_type', 'Use Content-Type: application/json');
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new HttpError(400, 'invalid_json', 'Request body is not valid JSON');
  }
}

// Wraps the router in an http.Server with request IDs, timing, JSON errors,
// access logs and connection tracking for graceful shutdown.
export function createHttpServer({ router, log, cfg, metrics }) {
  const server = http.createServer(async (req, res) => {
    const started = process.hrtime.bigint();
    const incoming = req.headers['x-request-id'];
    const reqId = typeof incoming === 'string' && REQUEST_ID.test(incoming) ? incoming : randomUUID();
    const url = new URL(req.url, 'http://localhost');
    const timings = [];
    const ctx = {
      reqId,
      url,
      query: Object.fromEntries(url.searchParams),
      headers: req.headers,
      cacheStatus: undefined,
      timing: (name, ms) => timings.push(`${name};dur=${ms.toFixed(1)}`),
      log: log.child({ reqId }),
    };
    res.setHeader('x-request-id', reqId);
    res.setHeader('x-served-by', cfg.instance);
    res.setHeader('cache-control', 'no-store');

    let status = 500;
    let payload;
    try {
      const { handler, params, pathMatched } = router.match(req.method, url.pathname);
      if (!handler) {
        throw pathMatched
          ? new HttpError(405, 'method_not_allowed', `${req.method} not allowed on ${url.pathname}`)
          : new HttpError(404, 'not_found', `No route for ${url.pathname}`);
      }
      ctx.params = params;
      ctx.body = await readJson(req, cfg.maxBodyBytes);
      const result = await handler(ctx);
      status = result?.status ?? 200;
      payload = result?.body;
      if (result?.headers) for (const [k, v] of Object.entries(result.headers)) res.setHeader(k, v);
    } catch (err) {
      if (err instanceof HttpError) {
        status = err.status;
        payload = { error: { code: err.code, message: err.message, details: err.details }, requestId: reqId };
        if (err.headers) for (const [k, v] of Object.entries(err.headers)) res.setHeader(k, v);
      } else {
        status = err?.code === 'ECONNREFUSED' || err?.code === 'ETIMEDOUT' ? 503 : 500;
        payload = { error: { code: status === 503 ? 'dependency_unavailable' : 'internal_error', message: 'Unexpected error' }, requestId: reqId };
        ctx.log.error('request failed', { err, path: url.pathname });
      }
    }

    const durMs = Number(process.hrtime.bigint() - started) / 1e6;
    timings.push(`total;dur=${durMs.toFixed(1)}`);
    res.setHeader('server-timing', timings.join(', '));
    if (ctx.cacheStatus) res.setHeader('x-cache', ctx.cacheStatus);
    metrics?.record(status, ctx.cacheStatus);

    if (status === 204 || payload === undefined) {
      res.writeHead(status);
      res.end();
    } else {
      const body = JSON.stringify(payload);
      res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(body) });
      res.end(req.method === 'HEAD' ? undefined : body);
    }
    if (url.pathname !== '/healthz' && url.pathname !== '/readyz') {
      ctx.log.info('request', { method: req.method, path: url.pathname, status, durMs: Math.round(durMs * 10) / 10, cache: ctx.cacheStatus });
    }
  });

  // Track sockets so shutdown can close idle keep-alive connections promptly.
  server.keepAliveTimeout = 65000; // longer than the 60 s idle timeout of Azure load balancers / App Gateway
  server.headersTimeout = 66000;
  return server;
}
