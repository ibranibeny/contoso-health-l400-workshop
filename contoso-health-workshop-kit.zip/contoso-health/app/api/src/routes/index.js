import { notFound, HttpError } from '../http/errors.js';

export function registerRoutes(router, { services, repo, cache, cfg, state }) {
  // Liveness: is the process able to serve? No dependency checks here, so a
  // database outage never makes Kubernetes or App Service restart healthy pods.
  router.get('/healthz', async () => ({ body: { status: 'ok' } }));

  // Readiness: can this instance do useful work right now?
  router.get('/readyz', async () => {
    if (state.shuttingDown) return { status: 503, body: { status: 'shutting-down' } };
    const [db, redis] = await Promise.all([
      repo.ping().then(() => 'ok').catch((e) => `error: ${e.code || e.message}`),
      cache.ping().then((ok) => (ok ? 'ok' : 'degraded')).catch(() => 'degraded'),
    ]);
    // PostgreSQL is required; the cache is optional (the API degrades to the database).
    const ready = db === 'ok';
    return { status: ready ? 200 : 503, body: { status: ready ? 'ready' : 'not-ready', checks: { postgres: db, cache: redis } } };
  });

  router.get('/api/info', async () => ({
    body: {
      service: cfg.service,
      version: cfg.version,
      instance: cfg.instance,
      node: cfg.node,
      platform: cfg.platform,
      region: cfg.region,
      storage: repo.kind,
      cache: cache.kind,
      startedAt: state.startedAt,
      uptimeSeconds: Math.round(process.uptime()),
      node_version: process.version,
    },
  }));

  router.get('/api/members/:id/eligibility', async (ctx) => ({ body: await services.eligibility(ctx, ctx.params.id) }));
  router.get('/api/members/:id/claims', async (ctx) => ({ body: await services.memberClaims(ctx, ctx.params.id) }));
  router.get('/api/providers/cities', async (ctx) => ({ body: await services.cities(ctx) }));
  router.get('/api/providers', async (ctx) => ({ body: await services.providers(ctx, ctx.query) }));
  router.get('/api/claims/:id', async (ctx) => ({ body: await services.getClaim(ctx, ctx.params.id) }));
  router.post('/api/claims', async (ctx) => {
    const key = ctx.headers['idempotency-key'];
    const r = await services.submitClaim(ctx, ctx.body, typeof key === 'string' ? key : undefined);
    return {
      status: r.status,
      headers: { location: `/api/claims/${r.claim.claimId}`, ...(r.replay ? { 'idempotent-replay': 'true' } : {}) },
      body: r.claim,
    };
  });

  const ops = (handler) => async (ctx) => {
    if (!cfg.opsApiEnabled) throw new HttpError(403, 'forbidden', 'Operations API is disabled in this environment');
    return handler(ctx);
  };
  router.get('/api/ops/claims', ops(async (ctx) => ({ body: await services.queue(ctx, ctx.query) })));
  router.post('/api/ops/claims/:id/decision', ops(async (ctx) => ({ body: await services.decide(ctx, ctx.params.id, ctx.body) })));
  router.get('/api/stats', async () => ({ body: await services.stats() }));

  router.get('/', async () => { throw notFound('This is the Contoso Health API. Try /api/info'); });
}
