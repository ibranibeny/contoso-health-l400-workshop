import { loadConfig } from './config.js';
import { createLogger } from './logger.js';
import { buildApp } from './app.js';
import { createMemoryRepository } from './data/memory.js';
import { createMemoryCache } from './cache/memory.js';

const cfg = loadConfig();
const log = createLogger({ level: cfg.logLevel, base: { service: cfg.service, version: cfg.version, instance: cfg.instance } });

async function createAdapters() {
  let repo;
  if (cfg.storage === 'postgres') {
    const { createPgPool, createPostgresRepository } = await import('./data/postgres.js');
    const pool = await createPgPool(cfg, log);
    if (cfg.migrateOnStart) {
      const { migrate } = await import('./db/migrate.js');
      await migrate(pool, { schema: cfg.pg.schema, seed: cfg.seedOnStart, log });
    }
    repo = createPostgresRepository(pool);
  } else {
    repo = createMemoryRepository();
  }

  let cache;
  if (cfg.cacheMode === 'redis') {
    const { createRedisCache } = await import('./cache/redis.js');
    try {
      cache = await createRedisCache(cfg, log);
    } catch (err) {
      // Start anyway: the resilient wrapper bypasses the cache until Redis is back.
      log.error('redis connection failed at startup; serving without cache', { err });
      cache = { kind: 'redis', ping: async () => false, close: async () => {}, get: async () => { throw err; }, set: async () => { throw err; }, setIfAbsent: async () => { throw err; }, del: async () => { throw err; }, incrWithExpiry: async () => { throw err; } };
    }
  } else if (cfg.cacheMode === 'none') {
    cache = { kind: 'none', ping: async () => true, close: async () => {}, get: async () => undefined, set: async () => {}, setIfAbsent: async () => true, del: async () => {}, incrWithExpiry: async () => undefined };
  } else {
    cache = createMemoryCache();
  }
  return { repo, cache };
}

const { repo, cache } = await createAdapters();
const { server, state } = buildApp({ cfg, log, repo, cache });

server.listen(cfg.port, () => {
  log.info('listening', { port: cfg.port, storage: repo.kind, cache: cache.kind, platform: cfg.platform, region: cfg.region });
});

// Graceful shutdown: Kubernetes sends SIGTERM and App Service stops the container
// the same way. Stop accepting work, finish in-flight requests, close pools.
let stopping = false;
async function shutdown(signal) {
  if (stopping) return;
  stopping = true;
  state.shuttingDown = true;
  log.info('shutting down', { signal });
  const timer = setTimeout(() => { log.warn('forced exit after timeout'); process.exit(1); }, cfg.shutdownTimeoutMs);
  timer.unref();
  server.close(async () => {
    await Promise.allSettled([repo.close(), cache.close()]);
    log.info('shutdown complete');
    process.exit(0);
  });
  server.closeIdleConnections?.();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
