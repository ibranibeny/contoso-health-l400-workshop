// The cache is an optimisation, never a hard dependency (WAF Reliability:
// graceful degradation). When Redis errors, this wrapper opens a short circuit,
// serves straight from PostgreSQL and retries Redis after the cool-down.
export function createResilientCache(inner, { log, metrics, coolDownMs = 15000, now = () => Date.now() }) {
  let openUntil = 0;
  let lastWarn = 0;
  const isOpen = () => openUntil > now();
  const fail = (op, err) => {
    metrics?.cacheError();
    openUntil = now() + coolDownMs;
    if (now() - lastWarn > 5000) {
      lastWarn = now();
      log.warn('cache unavailable, bypassing', { op, err, coolDownMs });
    }
  };
  const guard = (op, fallback) => async (...args) => {
    if (isOpen()) return fallback;
    try {
      return await inner[op](...args);
    } catch (err) {
      fail(op, err);
      return fallback;
    }
  };
  return {
    kind: inner.kind,
    isBypassed: isOpen,
    async ping() { try { return await inner.ping(); } catch { return false; } },
    close: () => inner.close(),
    get: guard('get', undefined),
    set: guard('set', undefined),
    setIfAbsent: guard('setIfAbsent', undefined),
    del: guard('del', undefined),
    incrWithExpiry: guard('incrWithExpiry', undefined),
  };
}
