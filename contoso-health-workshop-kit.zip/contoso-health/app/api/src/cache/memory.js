// In-memory cache with the same contract as the Redis cache. Used for unit tests
// and the zero-dependency quick start. Not shared between replicas.
export function createMemoryCache({ now = () => Date.now() } = {}) {
  const store = new Map();
  const alive = (key) => {
    const e = store.get(key);
    if (!e) return undefined;
    if (e.exp && e.exp <= now()) { store.delete(key); return undefined; }
    return e;
  };
  return {
    kind: 'memory',
    async ping() { return true; },
    async close() { store.clear(); },
    async get(key) { return alive(key)?.v ?? null; },
    async set(key, value, ttlSeconds) { store.set(key, { v: value, exp: ttlSeconds ? now() + ttlSeconds * 1000 : 0 }); },
    async setIfAbsent(key, value, ttlSeconds) {
      if (alive(key)) return false;
      store.set(key, { v: value, exp: ttlSeconds ? now() + ttlSeconds * 1000 : 0 });
      return true;
    },
    async del(...keys) { keys.forEach((k) => store.delete(k)); },
    async incrWithExpiry(key, ttlSeconds) {
      const e = alive(key);
      const n = (e ? Number(e.v) : 0) + 1;
      store.set(key, { v: String(n), exp: e?.exp || now() + ttlSeconds * 1000 });
      return n;
    },
    _size: () => store.size,
  };
}
