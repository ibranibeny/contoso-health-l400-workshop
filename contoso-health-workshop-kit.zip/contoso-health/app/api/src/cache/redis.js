// Azure Managed Redis (TLS on port 10000, Microsoft Entra ID auth) in Azure;
// a redis container with a password locally and in CI.
import { createCredential } from '../azure/credential.js';

export async function createRedisCache(cfg, log) {
  const { createClient } = await import('redis');
  const options = {
    socket: {
      host: cfg.redis.host,
      port: cfg.redis.port,
      tls: cfg.redis.tls,
      ...(cfg.redis.tls ? { servername: cfg.redis.host } : {}),
      connectTimeout: 5000,
      // Back off up to 5 s between reconnect attempts; the resilient wrapper
      // keeps serving from PostgreSQL while Redis is unreachable.
      reconnectStrategy: (retries) => Math.min(250 * 2 ** Math.min(retries, 5), 5000),
    },
    // Fail fast instead of queueing commands while disconnected.
    disableOfflineQueue: true,
  };

  if (cfg.redis.auth === 'entra') {
    // @redis/entraid acquires a token for https://redis.azure.com/.default, uses the
    // token's object ID as the Redis username, refreshes the token before expiry
    // and re-authenticates open connections (Learn: Azure Managed Redis Node.js quickstart).
    const { EntraIdCredentialsProviderFactory, REDIS_SCOPE_DEFAULT } = await import('@redis/entraid');
    const credential = await createCredential(cfg);
    options.credentialsProvider = EntraIdCredentialsProviderFactory.createForDefaultAzureCredential({
      credential,
      scopes: REDIS_SCOPE_DEFAULT,
      options: {},
      tokenManagerConfig: { expirationRefreshRatio: 0.8 },
    });
  } else if (cfg.redis.auth === 'password') {
    options.password = cfg.redis.password;
  }

  const client = createClient(options);
  client.on('error', (err) => log.warn('redis client error', { err }));
  client.on('reconnecting', () => log.debug('redis reconnecting'));
  await client.connect();

  return {
    kind: 'redis',
    client,
    async ping() { return (await client.ping()) === 'PONG'; },
    async close() {
      if (typeof client.close === 'function') await client.close();
      else await client.quit();
    },
    async get(key) { return client.get(key); },
    async set(key, value, ttlSeconds) {
      await client.set(key, value, ttlSeconds ? { EX: ttlSeconds } : undefined);
    },
    async setIfAbsent(key, value, ttlSeconds) {
      return (await client.set(key, value, { NX: true, EX: ttlSeconds })) === 'OK';
    },
    async del(...keys) { if (keys.length) await Promise.all(keys.map((k) => client.del(k))); },
    async incrWithExpiry(key, ttlSeconds) {
      const n = await client.incr(key);
      if (n === 1) await client.expire(key, ttlSeconds);
      return n;
    },
  };
}
