// One place decides how the API proves its identity to Azure services.
// No connection strings, passwords or access keys are stored anywhere.
//   AKS          -> workload identity (federated token projected into the pod)
//   App Service  -> user-assigned managed identity (AZURE_CLIENT_ID app setting)
//   Laptop       -> the developer's own sign-in (az login / VS Code)
export async function createCredential(cfg) {
  const identity = await import('@azure/identity');
  if (process.env.AZURE_FEDERATED_TOKEN_FILE) {
    // The AKS workload identity webhook injects AZURE_CLIENT_ID, AZURE_TENANT_ID
    // and AZURE_FEDERATED_TOKEN_FILE into pods labelled azure.workload.identity/use=true.
    return new identity.WorkloadIdentityCredential({ clientId: cfg.azure.clientId || undefined });
  }
  if (cfg.azure.clientId) {
    return new identity.ManagedIdentityCredential({ clientId: cfg.azure.clientId });
  }
  return new identity.DefaultAzureCredential();
}

export const SCOPES = {
  // Audience for Azure Database for PostgreSQL flexible server tokens.
  postgres: 'https://ossrdbms-aad.database.windows.net/.default',
  // Audience for Azure Managed Redis Entra tokens.
  redis: 'https://redis.azure.com/.default',
};
