import { badRequest, notFound, unprocessable, HttpError } from '../http/errors.js';

const MEMBER_ID = /^CH-\d{6}$/;
const PROVIDER_ID = /^PRV-[A-Z]{3}-\d{3}$/;
const CLAIM_ID = /^CLM-\d{4}-\d{6}$/;
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const IDEMPOTENCY_KEY = /^[A-Za-z0-9-]{8,64}$/;
export const CLAIM_TYPES = ['outpatient', 'inpatient', 'pharmacy', 'lab'];
export const PROVIDER_TYPES = ['hospital', 'clinic', 'pharmacy', 'lab'];
const KEY = {
  eligibility: (id) => `ch:v1:elig:${id}`,
  providers: (city, type) => `ch:v1:prov:${city || '*'}:${type || '*'}`,
  cities: () => 'ch:v1:cities',
  claims: (id) => `ch:v1:claims:${id}`,
  idempotency: (k) => `ch:v1:idem:${k}`,
  rate: (id, bucket) => `ch:v1:rl:claims:${id}:${bucket}`,
};

const todayUtc = () => new Date().toISOString().slice(0, 10);

export function createServices({ repo, cache, cfg, metrics }) {
  // Cache-aside: read the cache, fall back to PostgreSQL, populate the cache.
  async function cached(ctx, key, ttl, loader) {
    const t0 = performance.now();
    const raw = await cache.get(key);
    ctx.timing('cache', performance.now() - t0);
    if (raw) {
      ctx.cacheStatus = 'HIT';
      return JSON.parse(raw);
    }
    const t1 = performance.now();
    const value = await loader();
    ctx.timing('db', performance.now() - t1);
    ctx.cacheStatus = cache.isBypassed?.() || raw === undefined ? 'BYPASS' : 'MISS';
    if (value !== null && value !== undefined) await cache.set(key, JSON.stringify(value), ttl);
    return value;
  }

  const requireMemberId = (id) => {
    if (!MEMBER_ID.test(id || '')) throw badRequest('memberId must look like CH-100001');
  };

  return {
    async eligibility(ctx, memberId) {
      requireMemberId(memberId);
      const result = await cached(ctx, KEY.eligibility(memberId), cfg.ttl.eligibility, async () => {
        const m = await repo.getMember(memberId);
        if (!m) return null;
        const used = await repo.approvedTotalForYear(memberId, new Date().getUTCFullYear());
        const paidUp = m.premiumPaidUntil >= todayUtc();
        const eligible = m.status === 'active' && paidUp;
        const reason = eligible ? 'Coverage active'
          : m.status === 'suspended' ? 'Membership suspended'
          : m.status === 'grace' ? 'Premium overdue (grace period)'
          : 'Premium not paid';
        return {
          memberId: m.memberId,
          fullName: m.fullName,
          city: m.city,
          status: m.status,
          eligible,
          reason,
          premiumPaidUntil: m.premiumPaidUntil,
          plan: m.plan,
          annualLimitIdr: m.plan.annualLimitIdr,
          usedThisYearIdr: used,
          remainingIdr: Math.max(m.plan.annualLimitIdr - used, 0),
          computedAt: new Date().toISOString(),
        };
      });
      if (!result) throw notFound(`Member ${memberId} not found`);
      return result;
    },

    async cities(ctx) {
      return cached(ctx, KEY.cities(), cfg.ttl.providers, () => repo.listCities());
    },

    async providers(ctx, { city, type }) {
      if (type && !PROVIDER_TYPES.includes(type)) throw badRequest(`type must be one of ${PROVIDER_TYPES.join(', ')}`);
      if (city && !/^[A-Za-z ]{2,40}$/.test(city)) throw badRequest('city is invalid');
      return cached(ctx, KEY.providers(city, type), cfg.ttl.providers, () => repo.listProviders({ city, type }));
    },

    async memberClaims(ctx, memberId) {
      requireMemberId(memberId);
      const member = await repo.getMember(memberId);
      if (!member) throw notFound(`Member ${memberId} not found`);
      return cached(ctx, KEY.claims(memberId), cfg.ttl.claims, () => repo.listClaimsForMember(memberId, 20));
    },

    async getClaim(ctx, claimId) {
      if (!CLAIM_ID.test(claimId || '')) throw badRequest('claimId must look like CLM-2026-000123');
      const claim = await repo.getClaim(claimId);
      if (!claim) throw notFound(`Claim ${claimId} not found`);
      return claim;
    },

    async submitClaim(ctx, body, idempotencyKey) {
      const input = validateClaim(body);
      if (idempotencyKey !== undefined && !IDEMPOTENCY_KEY.test(idempotencyKey)) {
        throw badRequest('Idempotency-Key must be 8-64 characters [A-Za-z0-9-]');
      }

      // 1. Fast replay path: the same Idempotency-Key returns the original claim.
      if (idempotencyKey) {
        const known = await cache.get(KEY.idempotency(idempotencyKey));
        if (known) {
          const claim = await repo.getClaim(known);
          if (claim) return { status: 200, replay: true, claim };
        }
      }

      // 2. Per-member rate limit (fixed one-minute window in Redis).
      const bucket = Math.floor(Date.now() / 60000);
      const count = await cache.incrWithExpiry(KEY.rate(input.memberId, bucket), 60);
      if (count !== undefined && count > cfg.rateLimit.claimsPerMinute) {
        const err = new HttpError(429, 'rate_limited', `More than ${cfg.rateLimit.claimsPerMinute} claims per minute for ${input.memberId}`);
        err.headers = { 'retry-after': String(60 - Math.floor((Date.now() / 1000) % 60)) };
        throw err;
      }

      // 3. Business rules.
      const member = await repo.getMember(input.memberId);
      if (!member) throw unprocessable(`Member ${input.memberId} not found`);
      if (member.status !== 'active' || member.premiumPaidUntil < todayUtc()) {
        throw unprocessable(`Member ${input.memberId} is not eligible: ${member.status}`);
      }
      const provider = await repo.getProvider(input.providerId);
      if (!provider) throw unprocessable(`Provider ${input.providerId} not found`);

      // 4. Insert. The database enforces idempotency even if Redis was skipped.
      const result = await repo.createClaim({ ...input, idempotencyKey });
      const { claim } = result;
      if (idempotencyKey) await cache.set(KEY.idempotency(idempotencyKey), claim.claimId, cfg.ttl.idempotency);
      await cache.del(KEY.claims(input.memberId), KEY.eligibility(input.memberId));
      return { status: result.replay ? 200 : 201, replay: Boolean(result.replay), claim };
    },

    async queue(ctx, { status = 'submitted', limit = '50' }) {
      if (!['submitted', 'in_review'].includes(status)) throw badRequest('status must be submitted or in_review');
      const n = Math.min(Math.max(Number.parseInt(limit, 10) || 50, 1), 200);
      return repo.listClaimsByStatus(status, n);
    },

    async decide(ctx, claimId, body) {
      if (!CLAIM_ID.test(claimId || '')) throw badRequest('claimId must look like CLM-2026-000123');
      const decision = body?.decision;
      if (!['approve', 'reject'].includes(decision)) throw badRequest('decision must be approve or reject');
      let approvedIdr;
      if (body.approvedIdr !== undefined && body.approvedIdr !== null) {
        if (!Number.isInteger(body.approvedIdr) || body.approvedIdr < 0) throw badRequest('approvedIdr must be a non-negative integer');
        approvedIdr = body.approvedIdr;
      }
      const note = typeof body.note === 'string' ? body.note.slice(0, 200) : undefined;
      const existing = await repo.getClaim(claimId);
      if (!existing) throw notFound(`Claim ${claimId} not found`);
      if (approvedIdr !== undefined && approvedIdr > existing.amountIdr) throw unprocessable('approvedIdr cannot exceed the claimed amount');
      const claim = await repo.decideClaim(claimId, { decision, approvedIdr, note, actor: 'claims-officer-demo' });
      await cache.del(KEY.claims(claim.memberId), KEY.eligibility(claim.memberId));
      return claim;
    },

    async stats() {
      return { data: await repo.stats(), runtime: metrics.snapshot() };
    },
  };
}

function validateClaim(body) {
  if (!body || typeof body !== 'object') throw badRequest('JSON body required');
  const errors = [];
  const { memberId, providerId, claimType, serviceDate, amountIdr, note } = body;
  if (!MEMBER_ID.test(memberId || '')) errors.push('memberId must look like CH-100001');
  if (!PROVIDER_ID.test(providerId || '')) errors.push('providerId must look like PRV-JAK-001');
  if (!CLAIM_TYPES.includes(claimType)) errors.push(`claimType must be one of ${CLAIM_TYPES.join(', ')}`);
  if (!DATE.test(serviceDate || '') || Number.isNaN(Date.parse(serviceDate))) {
    errors.push('serviceDate must be YYYY-MM-DD');
  } else {
    const days = (Date.parse(todayUtc()) - Date.parse(serviceDate)) / 86400000;
    if (days < 0) errors.push('serviceDate cannot be in the future');
    if (days > 90) errors.push('serviceDate must be within the last 90 days');
  }
  if (!Number.isInteger(amountIdr) || amountIdr < 10_000 || amountIdr > 500_000_000) {
    errors.push('amountIdr must be an integer between 10,000 and 500,000,000');
  }
  if (note !== undefined && (typeof note !== 'string' || note.length > 200)) errors.push('note must be a string of at most 200 characters');
  if (errors.length) throw badRequest('Claim is invalid', errors);
  return { memberId, providerId, claimType, serviceDate, amountIdr, note };
}
