// Composition root: wires configuration, adapters, services and routes.
// Tests call buildApp() with in-memory adapters; index.js adds real adapters.
import { createRouter } from './http/router.js';
import { createHttpServer } from './http/server.js';
import { registerRoutes } from './routes/index.js';
import { createServices } from './services/index.js';
import { createMetrics } from './metrics.js';
import { createResilientCache } from './cache/resilient.js';

export function buildApp({ cfg, log, repo, cache }) {
  const metrics = createMetrics();
  const safeCache = createResilientCache(cache, { log, metrics });
  const state = { startedAt: new Date().toISOString(), shuttingDown: false };
  const services = createServices({ repo, cache: safeCache, cfg, metrics });
  const router = createRouter();
  registerRoutes(router, { services, repo, cache: safeCache, cfg, state });
  const server = createHttpServer({ router, log, cfg, metrics });
  return { server, state, metrics, cache: safeCache, repo };
}
