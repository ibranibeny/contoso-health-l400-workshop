// Preloaded with `node --import ./src/telemetry.js src/index.js` so OpenTelemetry
// can instrument http, pg and redis before the application imports them.
// Does nothing unless APPLICATIONINSIGHTS_CONNECTION_STRING is set.
const connectionString = process.env.APPLICATIONINSIGHTS_CONNECTION_STRING;

if (connectionString) {
  try {
    // ES module instrumentation hooks, then the Azure Monitor distro (npm README).
    await import('@azure/monitor-opentelemetry/loader');
    const { useAzureMonitor } = await import('@azure/monitor-opentelemetry');
    const exporter = { connectionString };
    if (process.env.APPLICATIONINSIGHTS_AUTHENTICATION_STRING || process.env.APPLICATIONINSIGHTS_AUTH === 'entra') {
      // Microsoft Entra ingestion: the identity needs "Monitoring Metrics Publisher"
      // on the Application Insights resource; local (key) auth can then be disabled.
      const identity = await import('@azure/identity');
      exporter.credential = process.env.AZURE_FEDERATED_TOKEN_FILE
        ? new identity.WorkloadIdentityCredential()
        : new identity.ManagedIdentityCredential({ clientId: process.env.AZURE_CLIENT_ID });
    }
    useAzureMonitor({ azureMonitorExporterOptions: exporter });
  } catch (err) {
    process.stdout.write(JSON.stringify({ ts: new Date().toISOString(), level: 'warn', msg: 'telemetry disabled', err: { message: err.message } }) + '\n');
  }
}
