// Forward-only SQL migrations with an advisory lock, so several replicas that
// start at the same time (App Service scale-out, AKS rollout) never race.
// Usage: node src/db/migrate.js [--seed]
import { readdir, readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { generateSeed } from '../data/seed.js';

const LOCK_ID = 727274; // arbitrary, constant for this application
const here = path.dirname(fileURLToPath(import.meta.url));
const MIGRATIONS_DIR = path.resolve(here, '../../db/migrations');
const ident = (s) => {
  if (!/^[a-z_][a-z0-9_]*$/.test(s)) throw new Error(`Unsafe schema name: ${s}`);
  return s;
};

export async function migrate(pool, { schema = 'app', seed = false, log = console } = {}) {
  const client = await pool.connect();
  try {
    await client.query('SELECT pg_advisory_lock($1)', [LOCK_ID]);
    const exists = await client.query('SELECT 1 FROM information_schema.schemata WHERE schema_name = $1', [schema]);
    // In Azure the bootstrap step creates the schema and makes the API identity its owner,
    // so the API never needs CREATE on the database itself.
    if (!exists.rowCount) await client.query(`CREATE SCHEMA ${ident(schema)}`);
    await client.query(`SET search_path TO ${ident(schema)}, public`);
    await client.query('CREATE TABLE IF NOT EXISTS schema_migrations (version text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())');
    const done = new Set((await client.query('SELECT version FROM schema_migrations')).rows.map((r) => r.version));
    const files = (await readdir(MIGRATIONS_DIR)).filter((f) => f.endsWith('.sql')).sort();
    for (const file of files) {
      if (done.has(file)) continue;
      const sql = await readFile(path.join(MIGRATIONS_DIR, file), 'utf8');
      await client.query('BEGIN');
      try {
        await client.query(sql);
        await client.query('INSERT INTO schema_migrations (version) VALUES ($1)', [file]);
        await client.query('COMMIT');
        log.info?.('migration applied', { file });
      } catch (err) {
        await client.query('ROLLBACK');
        throw err;
      }
    }
    if (seed) await seedIfEmpty(client, log);
  } finally {
    await client.query('SELECT pg_advisory_unlock($1)', [LOCK_ID]).catch(() => {});
    client.release();
  }
}

async function seedIfEmpty(client, log) {
  const { rows } = await client.query('SELECT count(*)::int AS n FROM members');
  if (rows[0].n > 0) return;
  const data = generateSeed();
  const json = (arr) => JSON.stringify(arr);
  await client.query('BEGIN');
  try {
    await client.query(
      `INSERT INTO plans SELECT x.* FROM jsonb_to_recordset($1::jsonb)
         AS x(plan_code text, name text, annual_limit_idr bigint, outpatient_copay_pct smallint, room_class text)`,
      [json(data.plans.map((p) => ({ plan_code: p.planCode, name: p.name, annual_limit_idr: p.annualLimitIdr, outpatient_copay_pct: p.outpatientCopayPct, room_class: p.roomClass })))],
    );
    await client.query(
      `INSERT INTO providers (provider_id, name, type, city, address, network_tier, specialties, open_24h)
       SELECT x.provider_id, x.name, x.type, x.city, x.address, x.network_tier,
              ARRAY(SELECT jsonb_array_elements_text(x.specialties)), x.open_24h
         FROM jsonb_to_recordset($1::jsonb)
           AS x(provider_id text, name text, type text, city text, address text, network_tier text, specialties jsonb, open_24h boolean)`,
      [json(data.providers.map((p) => ({ provider_id: p.providerId, name: p.name, type: p.type, city: p.city, address: p.address, network_tier: p.networkTier, specialties: p.specialties, open_24h: p.open24h })))],
    );
    await client.query(
      `INSERT INTO members (member_id, full_name, date_of_birth, city, plan_code, status, premium_paid_until)
       SELECT x.* FROM jsonb_to_recordset($1::jsonb)
           AS x(member_id text, full_name text, date_of_birth date, city text, plan_code text, status text, premium_paid_until date)`,
      [json(data.members.map((m) => ({ member_id: m.memberId, full_name: m.fullName, date_of_birth: m.dateOfBirth, city: m.city, plan_code: m.planCode, status: m.status, premium_paid_until: m.premiumPaidUntil })))],
    );
    await client.query(
      `INSERT INTO claims (claim_id, member_id, provider_id, claim_type, service_date, amount_idr, approved_idr, status,
                           diagnosis_note, decision_note, submitted_at, updated_at)
       SELECT x.* FROM jsonb_to_recordset($1::jsonb)
           AS x(claim_id text, member_id text, provider_id text, claim_type text, service_date date, amount_idr bigint,
                approved_idr bigint, status text, diagnosis_note text, decision_note text, submitted_at timestamptz, updated_at timestamptz)`,
      [json(data.claims.map((c) => ({ claim_id: c.claimId, member_id: c.memberId, provider_id: c.providerId, claim_type: c.claimType, service_date: c.serviceDate, amount_idr: c.amountIdr, approved_idr: c.approvedIdr, status: c.status, diagnosis_note: c.diagnosisNote, decision_note: c.decisionNote, submitted_at: c.submittedAt, updated_at: c.updatedAt })))],
    );
    await client.query('SELECT setval($1::regclass, $2, false)', ['claim_seq', data.nextClaimSeq]);
    await client.query('COMMIT');
    log.info?.('seed loaded', { members: data.members.length, providers: data.providers.length, claims: data.claims.length });
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  }
}

// CLI entry point (used by the Kubernetes migration Job and by developers).
if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  const { loadConfig } = await import('../config.js');
  const { createLogger } = await import('../logger.js');
  const { createPgPool } = await import('../data/postgres.js');
  const cfg = loadConfig();
  const log = createLogger({ level: cfg.logLevel, base: { service: cfg.service, component: 'migrate' } });
  const pool = await createPgPool(cfg, log);
  try {
    await migrate(pool, { schema: cfg.pg.schema, seed: process.argv.includes('--seed'), log });
    log.info('migrations complete');
  } catch (err) {
    log.error('migration failed', { err });
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
}
