// In-process counters exposed on /api/stats. Production telemetry goes to
// Application Insights through OpenTelemetry (see telemetry.js); these counters
// make the cache effect visible in the demo UI without any extra tooling.
export function createMetrics() {
  const m = {
    startedAt: new Date().toISOString(),
    requests: 0,
    byStatus: {},
    cache: { hits: 0, misses: 0, errors: 0, bypass: 0 },
  };
  return {
    record(status, cacheStatus) {
      m.requests += 1;
      const bucket = `${Math.floor(status / 100)}xx`;
      m.byStatus[bucket] = (m.byStatus[bucket] || 0) + 1;
      if (cacheStatus === 'HIT') m.cache.hits += 1;
      else if (cacheStatus === 'MISS') m.cache.misses += 1;
      else if (cacheStatus === 'BYPASS') m.cache.bypass += 1;
    },
    cacheError() { m.cache.errors += 1; },
    snapshot() {
      const lookups = m.cache.hits + m.cache.misses;
      return { ...m, cache: { ...m.cache, hitRatio: lookups ? Math.round((m.cache.hits / lookups) * 1000) / 1000 : 0 } };
    },
  };
}
