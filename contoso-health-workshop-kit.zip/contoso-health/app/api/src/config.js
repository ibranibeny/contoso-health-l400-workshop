// Central configuration. Every setting comes from the environment (12-factor),
// so the same build runs unchanged on a laptop, in App Service and in AKS.
import os from 'node:os';

const env = process.env;

const bool = (v, d = false) => (v === undefined || v === '' ? d : ['1', 'true', 'yes', 'on'].includes(String(v).toLowerCase()));
const int = (v, d) => (v === undefined || v === '' || Number.isNaN(Number(v)) ? d : Number.parseInt(v, 10));

export function loadConfig(overrides = {}) {
  const storage = env.STORAGE_MODE || (env.PGHOST ? 'postgres' : 'memory');
  const cache = env.CACHE_MODE || (env.REDIS_HOST ? 'redis' : 'memory');

  const cfg = {
    service: 'contoso-health-api',
    version: env.APP_VERSION || '1.0.0-local',
    port: int(env.PORT, 3000),
    logLevel: env.LOG_LEVEL || 'info',
    // Where the instance runs: App Service sets WEBSITE_INSTANCE_ID and REGION_NAME,
    // the Kubernetes manifests inject POD_NAME / NODE_NAME through the downward API.
    instance: env.POD_NAME || (env.WEBSITE_INSTANCE_ID ? env.WEBSITE_INSTANCE_ID.slice(0, 12) : os.hostname()),
    node: env.NODE_NAME || env.COMPUTERNAME || os.hostname(),
    region: env.AZURE_REGION || env.REGION_NAME || 'local',
    platform: env.WEBSITE_SITE_NAME ? 'app-service' : env.KUBERNETES_SERVICE_HOST ? 'aks' : 'local',
    storage,
    cacheMode: cache,
    opsApiEnabled: bool(env.OPS_API_ENABLED, true),
    migrateOnStart: bool(env.MIGRATE_ON_START, storage === 'postgres'),
    seedOnStart: bool(env.SEED_ON_START, false),
    shutdownTimeoutMs: int(env.SHUTDOWN_TIMEOUT_MS, 20000),
    maxBodyBytes: int(env.MAX_BODY_BYTES, 64 * 1024),
    ttl: {
      eligibility: int(env.CACHE_TTL_ELIGIBILITY_SECONDS, 60),
      providers: int(env.CACHE_TTL_PROVIDERS_SECONDS, 300),
      claims: int(env.CACHE_TTL_CLAIMS_SECONDS, 30),
      idempotency: int(env.IDEMPOTENCY_TTL_SECONDS, 24 * 3600),
    },
    rateLimit: {
      claimsPerMinute: int(env.RATE_LIMIT_CLAIMS_PER_MINUTE, 5),
    },
    azure: {
      // Client ID of the user-assigned managed identity (App Service) or of the
      // workload identity (AKS). Empty locally, where az login / password auth is used.
      clientId: env.AZURE_CLIENT_ID || '',
    },
    pg: {
      host: env.PGHOST || 'localhost',
      port: int(env.PGPORT, 5432),
      database: env.PGDATABASE || 'contoso_health',
      user: env.PGUSER || 'postgres',
      password: env.PGPASSWORD || '',
      schema: env.PGSCHEMA || 'app',
      // 'entra' = Microsoft Entra token as password (Azure); 'password' = local container.
      auth: env.PG_AUTH || (env.PGPASSWORD ? 'password' : 'entra'),
      ssl: bool(env.PGSSL, env.PG_AUTH === 'entra' || !env.PGPASSWORD),
      poolMax: int(env.PG_POOL_MAX, 10),
    },
    redis: {
      host: env.REDIS_HOST || 'localhost',
      // Azure Managed Redis listens on 10000 (TLS). A local container uses 6379.
      port: int(env.REDIS_PORT, 10000),
      tls: bool(env.REDIS_TLS, true),
      password: env.REDIS_PASSWORD || '',
      auth: env.REDIS_AUTH || (env.REDIS_PASSWORD ? 'password' : 'entra'),
    },
    ...overrides,
  };
  return cfg;
}
