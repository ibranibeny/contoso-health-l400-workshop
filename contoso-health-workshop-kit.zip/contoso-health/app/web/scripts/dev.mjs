// Local development loop: the backend-for-frontend on :8080 (it proxies /api to the API on :3000)
// and the Vite dev server on :5173 with hot reload (it proxies /api, /web and /readyz to :8080).
//   cd app/web && npm run dev       -> open http://localhost:5173
// Start the API first (cd app/api && npm run dev), or set API_BASE_URL.
import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';
import path from 'node:path';

const require = createRequire(import.meta.url);
const viteBin = path.join(path.dirname(require.resolve('vite/package.json')), 'bin', 'vite.js');
const children = [
  spawn(process.execPath, ['--watch', 'server.js'], { stdio: 'inherit', env: { ...process.env, PORT: process.env.BFF_PORT ?? '8080' } }),
  spawn(process.execPath, [viteBin, '--host'], { stdio: 'inherit', env: process.env }),
];
const stop = () => children.forEach((c) => c.exitCode === null && c.kill('SIGTERM'));
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
children.forEach((c) => c.on('exit', (code) => {
  if (code) process.exitCode = code;
  stop();
}));
