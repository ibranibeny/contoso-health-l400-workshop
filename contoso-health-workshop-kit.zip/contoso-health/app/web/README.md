# Contoso Health member portal (app/web)

A React 19 single-page app (TypeScript, built with Vite) plus a small Node.js
backend-for-frontend, `server.js`. The browser only talks to the web tier: the BFF serves the
compiled app from `dist/` and forwards `/api/*` to the private API, so the API needs no public
endpoint and no CORS, and both sit behind the same Application Gateway WAF.

```
browser ──► Application Gateway (WAF) ──► web: server.js ──► /api/* ──► API (private endpoint)
                                            └─ dist/ (React build: index.html + fingerprinted /assets)
```

| Command | What it does |
|---|---|
| `npm install` | Installs React, Vite, TypeScript and Playwright. Commit the generated `package-lock.json`. |
| `npm run dev` | BFF on :8080 + Vite on :5173 with hot reload (start the API on :3000 first). Open http://localhost:5173. |
| `npm run typecheck` | Type-checks the app (`tsconfig.app.json`) and the Node-side code (`tsconfig.node.json`). |
| `npm test` | Unit tests (`src/**/*.test.ts`, run by Node 24 directly) and BFF tests (`test/`). |
| `npm run build` | Production build into `dist/`. |
| `npm start` | Serves `dist/` and proxies `/api` (what App Service and the container run). |
| `npm run e2e:install` | Downloads Chromium for the browser tests (once per machine or runner). |
| `npm run e2e` | Browser tests against `BASE_URL` (default http://localhost:8080). |

The end-to-end tests are also the deployment tests: run them against any environment.

```bash
BASE_URL=http://localhost:8080 npm run e2e                                        # docker compose
BASE_URL="http://${APPGW_PUBLIC_IP}" E2E_EXPECT_WAF=true npm run e2e               # App Service via the WAF
BASE_URL="http://${APPGW_PUBLIC_IP}:8080" E2E_EXPECT_WAF=true npm run e2e          # AKS via the WAF
BASE_URL="https://portal.example" E2E_READONLY=true npm run e2e                    # production: no writes
```

Versions are pinned to the ones this kit was built and tested with (React 19.2.5, Vite 7.3.5,
@vitejs/plugin-react 5.2.0, TypeScript 5.8.3, Playwright 1.58.2). Newer majors exist (Vite 8,
TypeScript 7): take them through Dependabot pull requests, with CI as the gate.

Configuration (environment variables of `server.js`): `PORT` (8080), `API_BASE_URL`
(http://localhost:3000), `API_TIMEOUT_MS` (10000), `STATIC_DIR` (./dist), `APP_VERSION`
(otherwise `dist/version.json`, written by the pipeline).
