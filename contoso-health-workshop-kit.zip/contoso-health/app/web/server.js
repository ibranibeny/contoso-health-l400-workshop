// Contoso Health member portal: the backend-for-frontend (BFF).
// Serves the React single-page app that Vite builds into dist/ and forwards /api/* to the private
// API. The browser only ever talks to this origin, so the API needs no public endpoint, no CORS and
// sits behind the same Web Application Firewall. No npm dependencies at runtime: React is compiled
// into dist/ at build time, so the image and the App Service package carry no node_modules.
import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.json': 'application/json', '.png': 'image/png', '.webp': 'image/webp',
  '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8', '.webmanifest': 'application/manifest+json',
};

// The build pipeline writes dist/version.json (the commit it was built from); APP_VERSION wins when set.
function builtVersion(staticDir) {
  try {
    return JSON.parse(readFileSync(path.join(staticDir, 'version.json'), 'utf8')).version || null;
  } catch {
    return null;
  }
}
const HOP_BY_HOP = new Set(['connection', 'keep-alive', 'transfer-encoding', 'upgrade', 'proxy-connection', 'te', 'trailer', 'host', 'content-length']);

export function loadWebConfig(env = process.env) {
  const staticDir = path.resolve(env.STATIC_DIR || path.join(here, 'dist'));
  return {
    port: Number.parseInt(env.PORT || '8080', 10),
    apiBaseUrl: (env.API_BASE_URL || 'http://localhost:3000').replace(/\/$/, ''),
    apiTimeoutMs: Number.parseInt(env.API_TIMEOUT_MS || '10000', 10),
    instance: env.POD_NAME || (env.WEBSITE_INSTANCE_ID ? env.WEBSITE_INSTANCE_ID.slice(0, 12) : os.hostname()),
    version: env.APP_VERSION || builtVersion(staticDir) || '2.0.0-local',
    staticDir,
  };
}

// Vite fingerprints everything under /assets (index-3f9c2a.js), so those files never change and can
// be cached for a year. index.html names the current bundles, so it is always revalidated. [PERF]
export function cacheControl(rel) {
  if (rel === '/index.html') return 'no-cache';
  if (rel.startsWith('/assets/')) return 'public, max-age=31536000, immutable';
  return 'public, max-age=3600';
}

const log = (level, msg, fields = {}) => process.stdout.write(JSON.stringify({ ts: new Date().toISOString(), level, msg, service: 'contoso-health-web', ...fields }) + '\n');

function securityHeaders(req) {
  const h = {
    'content-security-policy': "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
    'x-content-type-options': 'nosniff',
    'referrer-policy': 'no-referrer',
    'permissions-policy': 'geolocation=(), camera=(), microphone=()',
    'cross-origin-opener-policy': 'same-origin',
  };
  // Application Gateway terminates TLS and sets X-Forwarded-Proto.
  if ((req.headers['x-forwarded-proto'] || '').includes('https')) h['strict-transport-security'] = 'max-age=31536000; includeSubDomains';
  return h;
}

async function serveStatic(req, res, cfg) {
  const root = cfg.staticDir || path.join(here, 'dist');
  const url = new URL(req.url, 'http://localhost');
  let rel;
  try { rel = decodeURIComponent(url.pathname); } catch { rel = '\0'; }
  if (rel.includes('\0') || rel.split(/[\\/]/).includes('..')) {
    res.writeHead(400, { ...securityHeaders(req), 'content-type': 'text/plain' }).end('Bad path');
    return 400;
  }
  if (rel === '/' || !path.extname(rel)) rel = '/index.html'; // single-page app fallback
  const file = path.normalize(path.join(root, rel));
  if (!file.startsWith(root + path.sep)) {
    res.writeHead(400, securityHeaders(req)).end('Bad path');
    return 400;
  }
  try {
    const info = await stat(file);
    if (!info.isFile()) throw new Error('not a file');
    const lastModified = info.mtime.toUTCString();
    const headers = {
      ...securityHeaders(req),
      'content-type': TYPES[path.extname(file)] || 'application/octet-stream',
      'cache-control': cacheControl(rel),
      'last-modified': lastModified,
      'x-served-by': cfg.instance,
    };
    // Revalidation of index.html costs a 304, not the whole file. [PERF]
    if (req.headers['if-modified-since'] === lastModified) {
      res.writeHead(304, headers).end();
      return 304;
    }
    const body = await readFile(file);
    res.writeHead(200, { ...headers, 'content-length': body.length });
    res.end(req.method === 'HEAD' ? undefined : body);
    return 200;
  } catch {
    res.writeHead(404, { ...securityHeaders(req), 'content-type': 'text/plain' }).end('Not found');
    return 404;
  }
}

async function proxy(req, res, cfg, reqId) {
  const target = cfg.apiBaseUrl + req.url;
  const headers = {};
  for (const [k, v] of Object.entries(req.headers)) if (!HOP_BY_HOP.has(k)) headers[k] = v;
  headers['x-request-id'] = reqId;
  headers['x-forwarded-for'] = [req.headers['x-forwarded-for'], req.socket.remoteAddress].filter(Boolean).join(', ');
  const hasBody = !['GET', 'HEAD'].includes(req.method);
  try {
    const upstream = await fetch(target, {
      method: req.method,
      headers,
      body: hasBody ? req : undefined,
      duplex: hasBody ? 'half' : undefined,
      signal: AbortSignal.timeout(cfg.apiTimeoutMs),
      redirect: 'manual',
    });
    const out = { ...securityHeaders(req), 'x-web-instance': cfg.instance };
    upstream.headers.forEach((v, k) => { if (!HOP_BY_HOP.has(k)) out[k] = v; });
    const body = Buffer.from(await upstream.arrayBuffer());
    out['content-length'] = body.length;
    res.writeHead(upstream.status, out);
    res.end(req.method === 'HEAD' ? undefined : body);
    return upstream.status;
  } catch (err) {
    const timeout = err?.name === 'TimeoutError';
    const status = timeout ? 504 : 502;
    log('warn', 'api proxy failed', { reqId, target: cfg.apiBaseUrl, err: err?.cause?.code || err?.name });
    const body = JSON.stringify({ error: { code: timeout ? 'upstream_timeout' : 'upstream_unavailable', message: 'The Contoso Health API is not reachable from the web tier' }, requestId: reqId });
    res.writeHead(status, { ...securityHeaders(req), 'content-type': 'application/json' }).end(body);
    return status;
  }
}

export function createWebServer(cfg = loadWebConfig()) {
  const state = { shuttingDown: false };
  const server = http.createServer(async (req, res) => {
    const started = performance.now();
    const incoming = req.headers['x-request-id'];
    const reqId = typeof incoming === 'string' && /^[A-Za-z0-9._:-]{1,100}$/.test(incoming) ? incoming : randomUUID();
    res.setHeader('x-request-id', reqId);
    let status;
    const { pathname } = new URL(req.url, 'http://localhost');
    if (pathname === '/healthz') {
      status = 200;
      res.writeHead(200, { 'content-type': 'application/json' }).end(JSON.stringify({ status: 'ok' }));
    } else if (pathname === '/readyz') {
      // Ready only if the API answers: App Service Health check and the Kubernetes readiness probe take a
      // web instance that has lost its path to the API out of rotation. (Application Gateway probes /healthz.)
      let api = 'unreachable';
      try {
        const r = await fetch(cfg.apiBaseUrl + '/healthz', { signal: AbortSignal.timeout(2000) });
        api = r.ok ? 'ok' : `http ${r.status}`;
      } catch { /* keep unreachable */ }
      const ready = api === 'ok' && !state.shuttingDown;
      status = ready ? 200 : 503;
      res.writeHead(status, { 'content-type': 'application/json' }).end(JSON.stringify({ status: ready ? 'ready' : 'not-ready', checks: { api } }));
    } else if (pathname === '/web/info') {
      status = 200;
      res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' })
        .end(JSON.stringify({ service: 'contoso-health-web', version: cfg.version, instance: cfg.instance, apiBaseUrl: new URL(cfg.apiBaseUrl).host }));
    } else if (pathname.startsWith('/api/')) {
      status = await proxy(req, res, cfg, reqId);
    } else if (req.method === 'GET' || req.method === 'HEAD') {
      status = await serveStatic(req, res, cfg);
    } else {
      status = 405;
      res.writeHead(405, securityHeaders(req)).end();
    }
    if (pathname !== '/healthz' && pathname !== '/readyz') {
      log('info', 'request', { reqId, method: req.method, path: pathname, status, durMs: Math.round((performance.now() - started) * 10) / 10 });
    }
  });
  server.keepAliveTimeout = 65000;
  server.headersTimeout = 66000;
  return { server, state };
}

// Start when executed directly (not when imported by tests).
if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  const cfg = loadWebConfig();
  const { server, state } = createWebServer(cfg);
  try {
    readFileSync(path.join(cfg.staticDir, 'index.html'));
  } catch {
    log('warn', 'no built portal found: run "npm run build" (or use "npm run dev" for hot reload)', { staticDir: cfg.staticDir });
  }
  server.listen(cfg.port, () => log('info', 'listening', { port: cfg.port, api: cfg.apiBaseUrl, version: cfg.version }));
  const shutdown = (signal) => {
    if (state.shuttingDown) return;
    state.shuttingDown = true;
    log('info', 'shutting down', { signal });
    setTimeout(() => process.exit(1), 20000).unref();
    server.close(() => process.exit(0));
    server.closeIdleConnections?.();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}
