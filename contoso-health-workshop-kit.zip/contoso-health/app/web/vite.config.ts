import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The browser only ever talks to its own origin. In development Vite (:5173) forwards API calls to
// the backend-for-frontend (:8080), which forwards them to the API (:3000): the same path as in Azure.
const bff = process.env.BFF_URL ?? 'http://localhost:8080';

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    target: 'es2022',
    // No source maps in the deployed bundle: smaller and nothing extra to protect. [SEC][PERF]
    sourcemap: false,
  },
  server: {
    port: 5173,
    strictPort: true,
    proxy: { '/api': bff, '/web': bff, '/readyz': bff },
  },
});
