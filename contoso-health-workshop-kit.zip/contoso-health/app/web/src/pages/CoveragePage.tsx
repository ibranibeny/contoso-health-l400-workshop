import { useId, useState, type FormEvent } from 'react';
import { apiFetch, type ApiResult } from '../lib/api.ts';
import type { Eligibility } from '../lib/types.ts';
import { coverageTone, formatDate, formatIdr, isMemberId, percentUsed } from '../lib/format.ts';
import { Badge } from '../components/Badge.tsx';
import { ErrorNotice } from '../components/ErrorNotice.tsx';
import { PageHeader } from '../components/PageHeader.tsx';
import { RequestMeta } from '../components/RequestMeta.tsx';
import { UsageBar } from '../components/UsageBar.tsx';

const PERSONAS = [
  { memberId: 'CH-100001', name: 'Ayu', note: 'active' },
  { memberId: 'CH-100002', name: 'Budi', note: 'grace period' },
  { memberId: 'CH-100003', name: 'Citra', note: 'suspended' },
];

export function CoveragePage() {
  const inputId = useId();
  const [memberId, setMemberId] = useState('CH-100001');
  const [invalid, setInvalid] = useState(false);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<ApiResult<Eligibility> | null>(null);

  async function check(id: string) {
    const value = id.trim().toUpperCase();
    setMemberId(value);
    if (!isMemberId(value)) {
      setInvalid(true);
      return;
    }
    setInvalid(false);
    setBusy(true);
    try {
      setResult(await apiFetch<Eligibility>(`/api/members/${encodeURIComponent(value)}/eligibility`));
    } finally {
      setBusy(false);
    }
  }

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    void check(memberId);
  }

  return (
    <section className="page" aria-labelledby={`${inputId}-title`}>
      <PageHeader title="Am I covered today?">
        Members check their eligibility before every hospital visit. The answer is cached in Azure Managed Redis for 60 seconds:
        check the same member twice and watch the cache chip turn from MISS to HIT.
      </PageHeader>

      <form className="toolbar" onSubmit={onSubmit} noValidate>
        <label htmlFor={inputId}>
          Member ID
          <input
            id={inputId}
            name="memberId"
            value={memberId}
            onChange={(e) => setMemberId(e.target.value)}
            aria-invalid={invalid}
            aria-describedby={invalid ? `${inputId}-error` : undefined}
            autoComplete="off"
            spellCheck={false}
          />
        </label>
        <button type="submit" className="primary" disabled={busy}>
          {busy ? 'Checking…' : 'Check eligibility'}
        </button>
        <div className="quick" role="group" aria-label="Demo members">
          <span>Try:</span>
          {PERSONAS.map((p) => (
            <button key={p.memberId} type="button" className="link" onClick={() => void check(p.memberId)}>
              {p.name} ({p.note})
            </button>
          ))}
        </div>
      </form>
      {invalid && (
        <p id={`${inputId}-error`} className="field-error" role="alert">
          A member ID looks like CH-100001.
        </p>
      )}

      <div aria-live="polite">
        {result?.ok && <EligibilityCards eligibility={result.data} />}
        {result && !result.ok && <ErrorNotice result={result} title={result.status === 404 ? 'Member not found' : undefined} />}
      </div>
      <RequestMeta meta={result} />
    </section>
  );
}

function EligibilityCards({ eligibility: e }: { eligibility: Eligibility }) {
  // Show a sliver for any usage at all, so 0.4% does not look like an empty bar.
  const used = Math.max(e.usedThisYearIdr > 0 ? 1 : 0, percentUsed(e.usedThisYearIdr, e.annualLimitIdr));
  const tone = coverageTone(e.eligible, e.status);
  return (
    <div className="cards three">
      <article className="card">
        <h2>Member</h2>
        <p className="big" data-testid="member-name">{e.fullName}</p>
        <p className="hint">
          {e.memberId} · {e.city}
        </p>
      </article>
      <article className={`card accent-${tone}`}>
        <h2>Coverage</h2>
        <p>
          <Badge tone={tone} testId="eligibility-status">
            {e.eligible ? 'Covered' : e.status === 'grace' ? 'Not covered · grace period' : 'Not covered'}
          </Badge>
        </p>
        <p data-testid="eligibility-reason">{e.reason}</p>
        <p className="hint">Premium paid until {formatDate(e.premiumPaidUntil)}</p>
      </article>
      <article className="card">
        <h2>{e.plan.name}</h2>
        <p>
          Room {e.plan.roomClass} · outpatient co-pay {e.plan.outpatientCopayPct}%
        </p>
        <UsageBar percent={used} label="Annual limit used" />
        <p className="hint">
          {formatIdr(e.usedThisYearIdr)} used of {formatIdr(e.annualLimitIdr)} · {formatIdr(e.remainingIdr)} left
        </p>
      </article>
    </div>
  );
}
