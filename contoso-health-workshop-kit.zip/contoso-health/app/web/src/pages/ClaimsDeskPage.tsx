import { useCallback, useEffect, useState } from 'react';
import { apiFetch, type ApiResult } from '../lib/api.ts';
import type { Claim } from '../lib/types.ts';
import { formatDate, formatIdr } from '../lib/format.ts';
import { ErrorNotice } from '../components/ErrorNotice.tsx';
import { PageHeader } from '../components/PageHeader.tsx';
import { RequestMeta } from '../components/RequestMeta.tsx';
import { Icon } from '../components/Icon.tsx';

export function ClaimsDeskPage() {
  const [queue, setQueue] = useState<ApiResult<Claim[]> | null>(null);
  const [decision, setDecision] = useState<ApiResult<Claim> | null>(null);
  const [pending, setPending] = useState<string | null>(null);

  const load = useCallback(async () => {
    setQueue(await apiFetch<Claim[]>('/api/ops/claims?status=submitted&limit=25'));
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function decide(claimId: string, choice: 'approve' | 'reject') {
    setPending(claimId);
    try {
      const r = await apiFetch<Claim>(`/api/ops/claims/${encodeURIComponent(claimId)}/decision`, {
        method: 'POST',
        body: { decision: choice, note: 'Decided in the claims desk demo' },
      });
      setDecision(r);
      await load();
    } finally {
      setPending(null);
    }
  }

  // Production turns the desk off twice: the API answers 403 forbidden (OPS_API_ENABLED=false) and the WAF
  // custom rule BlockOpsApiFromInternet answers its own 403 before the request reaches the API.
  const code = queue && !queue.ok ? queue.data?.error?.code : undefined;
  const disabled = queue !== null && !queue.ok && queue.status === 403 && (code === 'forbidden' || code === 'blocked');
  return (
    <section className="page">
      <PageHeader title="Claims desk">
        Claims officers approve or reject submitted claims. Every decision is written to an audit table and clears the member&apos;s cached
        eligibility, so the next lookup is fresh.
      </PageHeader>
      <div className="toolbar">
        <button type="button" className="primary" onClick={() => void load()}>
          <Icon name="refresh" /> Refresh queue
        </button>
      </div>
      <RequestMeta meta={queue} />
      {disabled && (
        <p className="notice info" data-testid="desk-disabled">
          {code === 'blocked'
            ? 'The claims desk is not reachable from the internet here: the Web Application Firewall blocks /api/ops (custom rule BlockOpsApiFromInternet), as in production.'
            : 'The claims desk API is turned off in this environment (OPS_API_ENABLED=false), as it is in production.'}
        </p>
      )}
      {queue && !queue.ok && !disabled && <ErrorNotice result={queue} />}
      {decision?.ok && (
        <p className="notice ok" data-testid="decision-result">
          {decision.data.claimId} is now {decision.data.status}.
        </p>
      )}
      {decision && !decision.ok && <ErrorNotice result={decision} />}
      {queue?.ok &&
        (queue.data.length === 0 ? (
          <p className="notice info" data-testid="desk-empty">
            The queue is empty.
          </p>
        ) : (
          <div className="table-wrap">
            <table data-testid="desk-table">
              <thead>
                <tr>
                  <th scope="col">Claim</th>
                  <th scope="col">Member</th>
                  <th scope="col">Provider</th>
                  <th scope="col" className="num">
                    Amount
                  </th>
                  <th scope="col">Submitted</th>
                  <th scope="col">Decision</th>
                </tr>
              </thead>
              <tbody>
                {queue.data.map((c) => (
                  <tr key={c.claimId}>
                    <td>
                      {c.claimId}
                      <div className="hint">
                        {c.claimType}
                        {c.diagnosisNote ? ` · ${c.diagnosisNote}` : ''}
                      </div>
                    </td>
                    <td>
                      {c.memberName ?? c.memberId}
                      <div className="hint">{c.memberId}</div>
                    </td>
                    <td>{c.providerName ?? c.providerId}</td>
                    <td className="num">{formatIdr(c.amountIdr)}</td>
                    <td>{formatDate(c.submittedAt)}</td>
                    <td className="row-actions">
                      <button type="button" className="small primary" disabled={pending === c.claimId} onClick={() => void decide(c.claimId, 'approve')}>
                        Approve
                      </button>
                      <button type="button" className="small" disabled={pending === c.claimId} onClick={() => void decide(c.claimId, 'reject')}>
                        Reject
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))}
    </section>
  );
}
