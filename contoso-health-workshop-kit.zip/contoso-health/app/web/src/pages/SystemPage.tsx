import { useCallback, useEffect, useState } from 'react';
import { apiFetch, type ApiResult } from '../lib/api.ts';
import type { ApiInfo, Readiness, Stats, WebInfo } from '../lib/types.ts';
import { formatUptime } from '../lib/format.ts';
import { Badge } from '../components/Badge.tsx';
import { ErrorNotice } from '../components/ErrorNotice.tsx';
import { PageHeader } from '../components/PageHeader.tsx';
import { Icon } from '../components/Icon.tsx';

interface Snapshot {
  web: ApiResult<WebInfo>;
  ready: ApiResult<Readiness>;
  info: ApiResult<ApiInfo>;
  stats: ApiResult<Stats>;
}

const PLATFORM: Record<string, string> = { 'app-service': 'Azure App Service', aks: 'Azure Kubernetes Service', local: 'Local machine' };

export function SystemPage() {
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [load, setLoad] = useState<{ hits: number; total: number; ms: number } | null>(null);
  const [running, setRunning] = useState(false);

  const refresh = useCallback(async () => {
    const [web, ready, info, stats] = await Promise.all([
      apiFetch<WebInfo>('/web/info'),
      apiFetch<Readiness>('/readyz'),
      apiFetch<ApiInfo>('/api/info'),
      apiFetch<Stats>('/api/stats'),
    ]);
    setSnap({ web, ready, info, stats });
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  async function runLoad() {
    setRunning(true);
    const started = performance.now();
    const ids = Array.from({ length: 100 }, (_, i) => `CH-${100001 + (i % 20)}`);
    let hits = 0;
    try {
      for (let i = 0; i < ids.length; i += 10) {
        const batch = await Promise.all(ids.slice(i, i + 10).map((member) => apiFetch(`/api/members/${member}/eligibility`)));
        hits += batch.filter((r) => r.cache === 'HIT').length;
      }
      setLoad({ hits, total: ids.length, ms: Math.round(performance.now() - started) });
      await refresh();
    } finally {
      setRunning(false);
    }
  }

  return (
    <section className="page">
      <PageHeader title="System">Which instance served you, whether every dependency is healthy, and how well the cache works.</PageHeader>
      <div className="toolbar">
        <button type="button" className="primary" onClick={() => void refresh()}>
          <Icon name="refresh" /> Refresh
        </button>
        <button type="button" onClick={() => void runLoad()} disabled={running}>
          <Icon name="bolt" /> {running ? 'Running…' : 'Run 100 eligibility lookups'}
        </button>
      </div>
      {snap && !snap.info.ok && <ErrorNotice result={snap.info} title="The API is not reachable from the web tier" />}
      <div className="cards">
        {load && (
          <article className="card accent-ok">
            <h2>Load run</h2>
            <p className="big">
              {load.hits}/{load.total}
            </p>
            <p className="hint">
              lookups answered from Redis in {load.ms} ms (20 members, 60 s TTL)
            </p>
          </article>
        )}
        {snap?.web.ok && (
          <article className="card" data-testid="web-tier">
            <h2>Web tier</h2>
            <p className="instance">{snap.web.data.instance}</p>
            <p className="hint">
              version {snap.web.data.version} · API at {snap.web.data.apiBaseUrl}
            </p>
            <p>
              Readiness <Badge tone={snap.ready.ok ? 'ok' : 'bad'}>{snap.ready.ok ? 'ready' : 'not ready'}</Badge>
            </p>
          </article>
        )}
        {snap?.info.ok && (
          <>
            <article className="card" data-testid="api-tier">
              <h2>API tier</h2>
              <p className="instance">{snap.info.data.instance}</p>
              <p className="hint">
                {PLATFORM[snap.info.data.platform] ?? snap.info.data.platform} · {snap.info.data.region} · Node {snap.info.data.node_version} · up{' '}
                {formatUptime(snap.info.data.uptimeSeconds)}
              </p>
            </article>
            <article className="card">
              <h2>Dependencies</h2>
              <p>
                Storage <strong>{snap.info.data.storage}</strong> · Cache <strong>{snap.info.data.cache}</strong>
              </p>
              {snap.info.data.storage === 'memory' && <p className="hint">In-memory mode is for laptops only.</p>}
            </article>
          </>
        )}
        {snap?.stats.ok && (
          <>
            <article className="card">
              <h2>Cache hit ratio (this API instance)</h2>
              <p className="big">{Math.round(snap.stats.data.runtime.cache.hitRatio * 100)}%</p>
              <p className="hint">
                {snap.stats.data.runtime.cache.hits} hits · {snap.stats.data.runtime.cache.misses} misses · {snap.stats.data.runtime.cache.bypass} bypassed ·{' '}
                {snap.stats.data.runtime.cache.errors} errors
              </p>
            </article>
            <article className="card">
              <h2>Requests (this API instance)</h2>
              <p className="big">{snap.stats.data.runtime.requests}</p>
              <p className="hint">
                {Object.entries(snap.stats.data.runtime.byStatus)
                  .map(([status, n]) => `${status}: ${n}`)
                  .join(' · ')}
              </p>
            </article>
            <article className="card">
              <h2>Data</h2>
              <p>
                {snap.stats.data.data.members} members · {snap.stats.data.data.providers} providers · {snap.stats.data.data.claims} claims
              </p>
              {snap.stats.data.data.pool && (
                <p className="hint">
                  PostgreSQL pool: {snap.stats.data.data.pool.total} open · {snap.stats.data.data.pool.idle} idle · {snap.stats.data.data.pool.waiting}{' '}
                  waiting
                </p>
              )}
            </article>
          </>
        )}
      </div>
    </section>
  );
}
