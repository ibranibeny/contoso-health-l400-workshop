import { useEffect, useId, useState, type FormEvent } from 'react';
import { apiFetch, type ApiResult } from '../lib/api.ts';
import { PROVIDER_TYPES, type Provider } from '../lib/types.ts';
import { ErrorNotice } from '../components/ErrorNotice.tsx';
import { PageHeader } from '../components/PageHeader.tsx';
import { RequestMeta } from '../components/RequestMeta.tsx';
import { Badge } from '../components/Badge.tsx';

export function FindCarePage() {
  const id = useId();
  const [cities, setCities] = useState<string[]>([]);
  const [city, setCity] = useState('');
  const [type, setType] = useState('');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<ApiResult<Provider[]> | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    apiFetch<string[]>('/api/providers/cities', { signal: controller.signal })
      .then((r) => {
        if (r.ok) setCities(r.data);
      })
      .catch(() => undefined); // aborted on unmount
    return () => controller.abort();
  }, []);

  async function search(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const qs = new URLSearchParams();
    if (city) qs.set('city', city);
    if (type) qs.set('type', type);
    setBusy(true);
    try {
      setResult(await apiFetch<Provider[]>(`/api/providers${qs.size ? `?${qs}` : ''}`));
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="page">
      <PageHeader title="Find a hospital, clinic, pharmacy or lab">
        The provider directory changes rarely, so the API caches it for 5 minutes. Run the same search twice and the second answer
        comes from Redis.
      </PageHeader>
      <form className="toolbar" onSubmit={search}>
        <label htmlFor={`${id}-city`}>
          City
          <select id={`${id}-city`} value={city} onChange={(e) => setCity(e.target.value)} data-testid="city-select">
            <option value="">All cities</option>
            {cities.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </label>
        <label htmlFor={`${id}-type`}>
          Type
          <select id={`${id}-type`} value={type} onChange={(e) => setType(e.target.value)}>
            <option value="">All types</option>
            {PROVIDER_TYPES.map((t) => (
              <option key={t} value={t}>
                {t[0]?.toUpperCase()}
                {t.slice(1)}
              </option>
            ))}
          </select>
        </label>
        <button type="submit" className="primary" disabled={busy}>
          {busy ? 'Searching…' : 'Search'}
        </button>
      </form>
      <RequestMeta meta={result} />
      {result && !result.ok && <ErrorNotice result={result} />}
      {result?.ok && (
        <>
          <p className="hint" data-testid="providers-count">
            {result.data.length} providers
          </p>
          <div className="table-wrap">
            <table data-testid="providers-table">
              <thead>
                <tr>
                  <th scope="col">Provider</th>
                  <th scope="col">Type</th>
                  <th scope="col">City</th>
                  <th scope="col">Address</th>
                  <th scope="col">Network</th>
                  <th scope="col">24 h</th>
                </tr>
              </thead>
              <tbody>
                {result.data.map((p) => (
                  <tr key={p.providerId}>
                    <td>
                      <strong>{p.name}</strong>
                      <div className="hint">
                        {p.providerId} · {p.specialties.join(', ')}
                      </div>
                    </td>
                    <td>{p.type}</td>
                    <td>{p.city}</td>
                    <td>{p.address}</td>
                    <td>
                      <Badge tone={p.networkTier === 'preferred' ? 'ok' : 'neutral'}>{p.networkTier}</Badge>
                    </td>
                    <td>{p.open24h ? 'Yes' : 'No'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </section>
  );
}
