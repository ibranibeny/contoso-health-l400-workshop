import { useCallback, useEffect, useId, useState, type FormEvent } from 'react';
import { apiFetch, newIdempotencyKey, type ApiResult } from '../lib/api.ts';
import { CLAIM_TYPES, type Claim, type ClaimType, type Eligibility, type NewClaim, type Provider } from '../lib/types.ts';
import { claimTone, formatDate, formatIdr, isMemberId, isoDateDaysAgo, statusLabel } from '../lib/format.ts';
import { Badge } from '../components/Badge.tsx';
import { ErrorNotice } from '../components/ErrorNotice.tsx';
import { PageHeader } from '../components/PageHeader.tsx';
import { RequestMeta } from '../components/RequestMeta.tsx';

interface Submission {
  body: NewClaim;
  key: string;
}

export function ClaimsPage() {
  const id = useId();
  const [memberId, setMemberId] = useState('CH-100001');
  const [claims, setClaims] = useState<ApiResult<Claim[]> | null>(null);
  const [providers, setProviders] = useState<Provider[]>([]);
  const [providerId, setProviderId] = useState('');
  const [claimType, setClaimType] = useState<ClaimType>('outpatient');
  const [serviceDate, setServiceDate] = useState(() => isoDateDaysAgo(3));
  const [amountIdr, setAmountIdr] = useState(350000);
  const [note, setNote] = useState('Follow-up consultation');
  const [busy, setBusy] = useState(false);
  const [last, setLast] = useState<Submission | null>(null);
  const [submitted, setSubmitted] = useState<ApiResult<Claim> | null>(null);
  const [burst, setBurst] = useState<number[] | null>(null);
  const [burstRun, setBurstRun] = useState(0);
  const [countdown, setCountdown] = useState(0);

  const loadClaims = useCallback(async (member: string) => {
    if (!isMemberId(member)) return;
    setClaims(await apiFetch<Claim[]>(`/api/members/${encodeURIComponent(member)}/claims`));
    // Offer the providers in the member's city.
    const eligibility = await apiFetch<Eligibility>(`/api/members/${encodeURIComponent(member)}/eligibility`);
    const city = eligibility.ok ? eligibility.data.city : '';
    const list = await apiFetch<Provider[]>(`/api/providers${city ? `?city=${encodeURIComponent(city)}` : ''}`);
    if (list.ok) {
      setProviders(list.data);
      setProviderId((current) => (list.data.some((p) => p.providerId === current) ? current : (list.data[0]?.providerId ?? '')));
    }
  }, []);

  useEffect(() => {
    void loadClaims('CH-100001');
  }, [loadClaims]);

  // Count down a Retry-After from the rate limiter.
  useEffect(() => {
    if (countdown <= 0) return undefined;
    const timer = window.setTimeout(() => setCountdown((s) => s - 1), 1000);
    return () => window.clearTimeout(timer);
  }, [countdown]);

  function claimBody(): NewClaim {
    return { memberId: memberId.trim(), providerId, claimType, serviceDate, amountIdr, note: note || undefined };
  }

  async function send(submission: Submission) {
    setBusy(true);
    try {
      const r = await apiFetch<Claim>('/api/claims', { method: 'POST', body: submission.body, headers: { 'idempotency-key': submission.key } });
      setSubmitted(r);
      setBurst(null);
      if (!r.ok && r.status === 429) setCountdown(r.retryAfter ?? 60);
      await loadClaims(submission.body.memberId);
    } finally {
      setBusy(false);
    }
  }

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const submission = { body: claimBody(), key: newIdempotencyKey() };
    setLast(submission);
    await send(submission);
  }

  async function sendBurst() {
    setBusy(true);
    const statuses: number[] = [];
    try {
      for (let i = 0; i < 7; i += 1) {
        const r = await apiFetch<Claim>('/api/claims', { method: 'POST', body: claimBody(), headers: { 'idempotency-key': newIdempotencyKey() } });
        statuses.push(r.status);
      }
      setBurst(statuses);
      setBurstRun((n) => n + 1);
      setSubmitted(null);
      await loadClaims(memberId.trim());
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="page">
      <PageHeader title="My claims">
        Every submission carries an <code>Idempotency-Key</code>: sending the same request again never creates a second claim. Each member
        may submit five claims per minute, counted in Redis across every API instance.
      </PageHeader>

      <form
        className="toolbar"
        onSubmit={(e) => {
          e.preventDefault();
          void loadClaims(memberId.trim());
        }}
      >
        <label htmlFor={`${id}-member`}>
          Member ID
          <input id={`${id}-member`} value={memberId} onChange={(e) => setMemberId(e.target.value)} autoComplete="off" spellCheck={false} />
        </label>
        <button type="submit">Show claims</button>
      </form>
      <RequestMeta meta={claims} />
      {claims && !claims.ok && <ErrorNotice result={claims} />}
      {claims?.ok && <ClaimsTable claims={claims.data} />}

      <h2 className="section-title">Submit a claim</h2>
      <form className="form-grid" onSubmit={onSubmit}>
        <label htmlFor={`${id}-provider`}>
          Provider
          <select id={`${id}-provider`} value={providerId} onChange={(e) => setProviderId(e.target.value)} required data-testid="provider-select">
            {providers.map((p) => (
              <option key={p.providerId} value={p.providerId}>
                {p.name}
              </option>
            ))}
          </select>
        </label>
        <label htmlFor={`${id}-type`}>
          Type
          <select id={`${id}-type`} value={claimType} onChange={(e) => setClaimType(e.target.value as ClaimType)}>
            {CLAIM_TYPES.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </label>
        <label htmlFor={`${id}-date`}>
          Service date
          <input id={`${id}-date`} type="date" value={serviceDate} onChange={(e) => setServiceDate(e.target.value)} required />
        </label>
        <label htmlFor={`${id}-amount`}>
          Amount (IDR)
          <input
            id={`${id}-amount`}
            type="number"
            min={10000}
            max={500000000}
            step={1000}
            value={amountIdr}
            onChange={(e) => setAmountIdr(Number.parseInt(e.target.value || '0', 10))}
            required
          />
        </label>
        <label htmlFor={`${id}-note`} className="wide">
          Note
          <input id={`${id}-note`} value={note} maxLength={200} onChange={(e) => setNote(e.target.value)} />
        </label>
        <div className="actions wide">
          <button type="submit" className="primary" disabled={busy || !providerId}>
            Submit claim
          </button>
          <button type="button" disabled={busy || !last} onClick={() => last && void send(last)}>
            Send the same request again
          </button>
          <button type="button" disabled={busy || !providerId} onClick={() => void sendBurst()}>
            Submit 7 claims quickly
          </button>
        </div>
      </form>

      <div aria-live="polite">
        {submitted?.ok && (
          <div className="notice ok" data-testid="claim-result">
            <div>
              <p className="notice-title">{submitted.replay ? 'Replay detected: the API returned the original claim' : 'Claim created'}</p>
              <p>
                <strong data-testid="claim-id">{submitted.data.claimId}</strong> · {formatIdr(submitted.data.amountIdr)} · status{' '}
                <Badge tone={claimTone(submitted.data.status)}>{statusLabel(submitted.data.status)}</Badge>
              </p>
            </div>
          </div>
        )}
        {submitted && !submitted.ok && (
          <>
            <ErrorNotice result={submitted} title={submitted.status === 429 ? 'Too many claims' : 'The claim was not accepted'} />
            {countdown > 0 && <p className="hint">You can submit again in {countdown} s.</p>}
          </>
        )}
        {burst && (
          <div className="notice info" data-testid="burst-result" data-run={burstRun}>
            <div>
              <p className="notice-title">Seven submissions returned</p>
              <ul className="meta">
                {burst.map((s, i) => (
                  <li key={i} className={`chip ${s === 429 ? 'bad' : s >= 200 && s < 300 ? 'ok' : 'warn'}`}>
                    {s}
                  </li>
                ))}
              </ul>
              <p className="hint">The limit lives in Redis, so it holds across every API instance and both hosting platforms.</p>
            </div>
          </div>
        )}
      </div>
      <RequestMeta meta={submitted} />
    </section>
  );
}

function ClaimsTable({ claims }: { claims: Claim[] }) {
  if (claims.length === 0) return <p className="notice info">No claims yet for this member.</p>;
  return (
    <div className="table-wrap">
      <table data-testid="claims-table">
        <thead>
          <tr>
            <th scope="col">Claim</th>
            <th scope="col">Provider</th>
            <th scope="col">Type</th>
            <th scope="col">Service date</th>
            <th scope="col" className="num">
              Amount
            </th>
            <th scope="col">Status</th>
          </tr>
        </thead>
        <tbody>
          {claims.map((c) => (
            <tr key={c.claimId}>
              <td>{c.claimId}</td>
              <td>{c.providerName ?? c.providerId}</td>
              <td>{c.claimType}</td>
              <td>{formatDate(c.serviceDate)}</td>
              <td className="num">{formatIdr(c.amountIdr)}</td>
              <td>
                <Badge tone={claimTone(c.status)}>{statusLabel(c.status)}</Badge>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
