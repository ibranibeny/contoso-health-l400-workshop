// Hash routes (#/coverage, #/claims, ...): deep links work behind any gateway or path rule,
// and the server never needs to know the client-side routes.
export const ROUTES = [
  { id: 'coverage', label: 'My coverage', title: 'Am I covered today?' },
  { id: 'care', label: 'Find care', title: 'Find a hospital, clinic, pharmacy or lab' },
  { id: 'claims', label: 'My claims', title: 'My claims' },
  { id: 'desk', label: 'Claims desk', title: 'Claims desk' },
  { id: 'system', label: 'System', title: 'System' },
] as const;

export type RouteId = (typeof ROUTES)[number]['id'];

export const DEFAULT_ROUTE: RouteId = 'coverage';

export function parseHash(hash: string): RouteId | null {
  const match = /^#\/([a-z]+)\/?$/.exec(hash);
  if (!match) return null;
  const found = ROUTES.find((r) => r.id === match[1]);
  return found ? found.id : null;
}

export function hrefFor(id: RouteId): string {
  return `#/${id}`;
}

export function routeLabel(id: RouteId): string {
  return ROUTES.find((r) => r.id === id)?.label ?? id;
}
