// Formatting and small pure helpers (unit-tested with node --test).
const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });
const day = new Intl.DateTimeFormat('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' });

export const MEMBER_ID = /^CH-\d{6}$/;

export function isMemberId(value: string): boolean {
  return MEMBER_ID.test(value.trim());
}

export function formatIdr(amount: number): string {
  return idr.format(amount);
}

export function formatDate(iso: string | null | undefined): string {
  if (!iso) return '–';
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? '–' : day.format(d);
}

export function percentUsed(used: number, limit: number): number {
  if (!(limit > 0)) return 0;
  return Math.min(100, Math.max(0, Math.round((used / limit) * 100)));
}

export type Tone = 'ok' | 'warn' | 'bad' | 'neutral';

export function claimTone(status: string): Tone {
  if (status === 'approved' || status === 'paid') return 'ok';
  if (status === 'submitted' || status === 'in_review') return 'warn';
  if (status === 'rejected') return 'bad';
  return 'neutral';
}

export function coverageTone(eligible: boolean, status: string): Tone {
  if (eligible) return 'ok';
  return status === 'grace' ? 'warn' : 'bad';
}

export function statusLabel(status: string): string {
  return status.replaceAll('_', ' ');
}

export function isoDateDaysAgo(days: number, now: Date = new Date()): string {
  return new Date(now.getTime() - days * 86_400_000).toISOString().slice(0, 10);
}

export function formatUptime(seconds: number): string {
  if (seconds < 60) return `${seconds} s`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  return `${hours} h ${minutes % 60} min`;
}

export function cacheTone(cache: string | null): Tone {
  if (cache === 'HIT') return 'ok';
  if (cache === 'MISS') return 'warn';
  if (cache === 'BYPASS') return 'bad';
  return 'neutral';
}
