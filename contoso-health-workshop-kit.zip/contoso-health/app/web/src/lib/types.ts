// Shapes returned by the Contoso Health API (app/api). Kept in one place so a contract change
// shows up as a type error in every page that uses it.

export interface ApiErrorBody {
  error?: { code?: string; message?: string; details?: string[] };
  requestId?: string;
}

export interface Plan {
  planCode?: string;
  name: string;
  roomClass: string;
  outpatientCopayPct: number;
  annualLimitIdr: number;
}

export interface Eligibility {
  memberId: string;
  fullName: string;
  city: string;
  status: string; // active | grace | suspended
  eligible: boolean;
  reason: string;
  premiumPaidUntil: string;
  plan: Plan;
  annualLimitIdr: number;
  usedThisYearIdr: number;
  remainingIdr: number;
  computedAt?: string;
}

export const PROVIDER_TYPES = ['hospital', 'clinic', 'pharmacy', 'lab'] as const;

export interface Provider {
  providerId: string;
  name: string;
  type: string;
  city: string;
  address: string;
  networkTier: string;
  open24h: boolean;
  specialties: string[];
}

export const CLAIM_TYPES = ['outpatient', 'inpatient', 'pharmacy', 'lab'] as const;
export type ClaimType = (typeof CLAIM_TYPES)[number];

export interface Claim {
  claimId: string;
  memberId: string;
  providerId: string;
  providerName?: string;
  claimType: string;
  serviceDate: string;
  amountIdr: number;
  approvedIdr?: number | null;
  status: string; // submitted | in_review | approved | rejected | paid
  diagnosisNote?: string | null;
  decisionNote?: string | null;
  submittedAt: string;
  updatedAt?: string;
  memberName?: string;
}

export interface NewClaim {
  memberId: string;
  providerId: string;
  claimType: ClaimType;
  serviceDate: string;
  amountIdr: number;
  note?: string;
}

export interface ApiInfo {
  service: string;
  version: string;
  instance: string;
  platform: string; // app-service | aks | local
  region: string;
  storage: string; // postgres | memory
  cache: string; // redis | memory
  startedAt?: string;
  uptimeSeconds: number;
  node_version: string;
}

export interface Stats {
  data: {
    members: number;
    providers: number;
    claims: number;
    claimsByStatus: Record<string, number>;
    pool?: { total: number; idle: number; waiting: number };
  };
  runtime: {
    requests: number;
    byStatus: Record<string, number>;
    cache: { hits: number; misses: number; bypass: number; errors: number; hitRatio: number };
  };
}

export interface WebInfo {
  service: string;
  version: string;
  instance: string;
  apiBaseUrl: string;
}

export interface Readiness {
  status: string;
  checks: Record<string, string>;
}
