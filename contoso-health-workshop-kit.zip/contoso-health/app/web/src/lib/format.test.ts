import { test } from 'node:test';
import assert from 'node:assert/strict';
import { cacheTone, claimTone, coverageTone, formatDate, formatIdr, formatUptime, isMemberId, isoDateDaysAgo, percentUsed, statusLabel } from './format.ts';

test('formats rupiah without decimals', () => {
  // Intl inserts a no-break space after "Rp": normalise it for the comparison.
  assert.equal(formatIdr(350000).replace(/\s/g, ' '), 'Rp 350.000');
});

test('formats dates in UTC so a date-only value never shifts a day', () => {
  assert.equal(formatDate('2026-11-30'), '30 Nov 2026');
  assert.equal(formatDate(null), '–');
  assert.equal(formatDate('not a date'), '–');
});

test('validates member ids', () => {
  assert.equal(isMemberId('CH-100001'), true);
  assert.equal(isMemberId(' CH-100001 '), true);
  assert.equal(isMemberId('CH-1'), false);
  assert.equal(isMemberId("CH-100001' OR 1=1"), false);
});

test('clamps the annual-limit usage bar', () => {
  assert.equal(percentUsed(50, 200), 25);
  assert.equal(percentUsed(500, 200), 100);
  assert.equal(percentUsed(10, 0), 0);
});

test('maps statuses to colours', () => {
  assert.equal(claimTone('approved'), 'ok');
  assert.equal(claimTone('in_review'), 'warn');
  assert.equal(claimTone('rejected'), 'bad');
  assert.equal(coverageTone(true, 'active'), 'ok');
  assert.equal(coverageTone(false, 'grace'), 'warn');
  assert.equal(coverageTone(false, 'suspended'), 'bad');
  assert.equal(cacheTone('HIT'), 'ok');
  assert.equal(cacheTone('BYPASS'), 'bad');
  assert.equal(statusLabel('in_review'), 'in review');
});

test('computes a service date in the past', () => {
  assert.equal(isoDateDaysAgo(3, new Date('2026-11-27T10:00:00Z')), '2026-11-24');
});

test('formats uptime', () => {
  assert.equal(formatUptime(42), '42 s');
  assert.equal(formatUptime(600), '10 min');
  assert.equal(formatUptime(7260), '2 h 1 min');
});
