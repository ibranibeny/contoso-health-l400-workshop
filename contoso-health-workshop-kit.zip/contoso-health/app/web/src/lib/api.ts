// A small typed wrapper around fetch(). Every call returns the parsed body AND what the platform
// added on the way: the HTTP status, the round trip, which API and web instance answered, whether
// Redis served it (x-cache) and whether it was an idempotent replay. The pages show these values,
// so the architecture is visible while you click.
import type { ApiErrorBody } from './types.ts';

export interface ApiMeta {
  status: number; // 0 = no HTTP response at all (network error)
  ms: number;
  cache: string | null; // x-cache: HIT | MISS | BYPASS
  servedBy: string | null; // x-served-by: API instance
  web: string | null; // x-web-instance: web tier instance
  replay: boolean; // idempotent-replay: true
  retryAfter: number | null; // Retry-After, in seconds
  requestId: string | null; // x-request-id, the same id in every tier's logs
}

export type ApiSuccess<T> = ApiMeta & { ok: true; data: T };
export type ApiFailure = ApiMeta & { ok: false; data: ApiErrorBody | null };
export type ApiResult<T> = ApiSuccess<T> | ApiFailure;

export interface ApiOptions {
  method?: 'GET' | 'POST';
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
  fetchImpl?: typeof fetch;
  now?: () => number;
}

export function parseRetryAfter(value: string | null): number | null {
  if (!value) return null;
  const seconds = Number.parseInt(value, 10);
  return Number.isFinite(seconds) && seconds >= 0 ? seconds : null;
}

export function readMeta(headers: Headers, status: number, ms: number): ApiMeta {
  return {
    status,
    ms,
    cache: headers.get('x-cache'),
    servedBy: headers.get('x-served-by'),
    web: headers.get('x-web-instance'),
    replay: headers.get('idempotent-replay') === 'true',
    retryAfter: parseRetryAfter(headers.get('retry-after')),
    requestId: headers.get('x-request-id'),
  };
}

// Application Gateway answers a blocked request with its own 403 page (HTML, not JSON). Describe
// non-JSON failures so the portal can say what happened instead of showing a parse error.
export function describeNonJson(status: number): ApiErrorBody {
  if (status === 403) {
    return { error: { code: 'blocked', message: 'The request was blocked before it reached the application, for example by the Web Application Firewall.' } };
  }
  if (status === 502 || status === 503 || status === 504) {
    return { error: { code: `http_${status}`, message: 'The gateway could not reach a healthy instance of the portal.' } };
  }
  return { error: { code: `http_${status}`, message: `The server answered HTTP ${status}.` } };
}

export async function apiFetch<T>(path: string, options: ApiOptions = {}): Promise<ApiResult<T>> {
  const { method = 'GET', body, headers = {}, signal } = options;
  const fetchImpl = options.fetchImpl ?? globalThis.fetch.bind(globalThis);
  const now = options.now ?? (() => performance.now());
  const started = now();
  let response: Response;
  try {
    response = await fetchImpl(path, {
      method,
      signal,
      headers: {
        accept: 'application/json',
        ...(body === undefined ? {} : { 'content-type': 'application/json' }),
        ...headers,
      },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch (err) {
    if (signal?.aborted) throw err; // the caller cancelled: nothing to show
    return {
      ok: false,
      status: 0,
      ms: Math.round(now() - started),
      cache: null,
      servedBy: null,
      web: null,
      replay: false,
      retryAfter: null,
      requestId: null,
      data: { error: { code: 'network_error', message: err instanceof Error ? err.message : 'The request did not reach the server.' } },
    };
  }
  const meta = readMeta(response.headers, response.status, Math.round(now() - started));
  const text = await response.text();
  let parsed: unknown = null;
  if (text) {
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = null;
    }
  }
  if (response.ok) return { ...meta, ok: true, data: parsed as T };
  const failure = parsed !== null && typeof parsed === 'object' ? (parsed as ApiErrorBody) : describeNonJson(response.status);
  return { ...meta, ok: false, data: failure };
}

// One key per logical submission: a retry with the same key returns the original claim.
export function newIdempotencyKey(): string {
  return crypto.randomUUID();
}
