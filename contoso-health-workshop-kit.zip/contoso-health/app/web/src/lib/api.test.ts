import { test } from 'node:test';
import assert from 'node:assert/strict';
import { apiFetch, describeNonJson, parseRetryAfter, readMeta } from './api.ts';

const fakeFetch = (response: Response | Error): typeof fetch =>
  (async () => {
    if (response instanceof Error) throw response;
    return response;
  }) as typeof fetch;

test('reads the platform headers the portal displays', () => {
  const headers = new Headers({ 'x-cache': 'HIT', 'x-served-by': 'api-1', 'x-web-instance': 'web-2', 'idempotent-replay': 'true', 'retry-after': '42', 'x-request-id': 'req-1' });
  assert.deepEqual(readMeta(headers, 200, 12), { status: 200, ms: 12, cache: 'HIT', servedBy: 'api-1', web: 'web-2', replay: true, retryAfter: 42, requestId: 'req-1' });
});

test('parses Retry-After seconds and ignores junk', () => {
  assert.equal(parseRetryAfter('17'), 17);
  assert.equal(parseRetryAfter(null), null);
  assert.equal(parseRetryAfter('soon'), null);
  assert.equal(parseRetryAfter('-3'), null);
});

test('returns typed data and metadata on success', async () => {
  const res = new Response(JSON.stringify({ memberId: 'CH-100001' }), { status: 200, headers: { 'content-type': 'application/json', 'x-cache': 'MISS' } });
  const r = await apiFetch<{ memberId: string }>('/api/members/CH-100001/eligibility', { fetchImpl: fakeFetch(res) });
  assert.equal(r.ok, true);
  assert.equal(r.status, 200);
  assert.equal(r.cache, 'MISS');
  if (r.ok) assert.equal(r.data.memberId, 'CH-100001');
});

test('sends JSON bodies and the Idempotency-Key header', async () => {
  let seen: RequestInit | undefined;
  const capture = (async (_url: string | URL | Request, init?: RequestInit) => {
    seen = init;
    return new Response('{}', { status: 201 });
  }) as typeof fetch;
  await apiFetch('/api/claims', { method: 'POST', body: { a: 1 }, headers: { 'idempotency-key': 'k-12345678' }, fetchImpl: capture });
  assert.equal(seen?.method, 'POST');
  assert.equal(seen?.body, '{"a":1}');
  const h = seen?.headers as Record<string, string>;
  assert.equal(h['content-type'], 'application/json');
  assert.equal(h['idempotency-key'], 'k-12345678');
});

test('keeps the API error body (code, message, details) on failure', async () => {
  const body = { error: { code: 'bad_request', message: 'Claim is invalid', details: ['amountIdr must be an integer'] }, requestId: 'r-9' };
  const r = await apiFetch('/api/claims', { method: 'POST', body: {}, fetchImpl: fakeFetch(new Response(JSON.stringify(body), { status: 400 })) });
  assert.equal(r.ok, false);
  if (!r.ok) {
    assert.equal(r.data?.error?.code, 'bad_request');
    assert.deepEqual(r.data?.error?.details, ['amountIdr must be an integer']);
  }
});

test('explains a WAF block (403 HTML page) instead of failing to parse it', async () => {
  const r = await apiFetch('/api/providers', { fetchImpl: fakeFetch(new Response('<html>403 Forbidden</html>', { status: 403 })) });
  assert.equal(r.ok, false);
  if (!r.ok) assert.equal(r.data?.error?.code, 'blocked');
  assert.equal(describeNonJson(502).error?.code, 'http_502');
});

test('turns a network error into status 0 instead of throwing', async () => {
  const r = await apiFetch('/api/info', { fetchImpl: fakeFetch(new TypeError('fetch failed')) });
  assert.equal(r.ok, false);
  assert.equal(r.status, 0);
  if (!r.ok) assert.equal(r.data?.error?.code, 'network_error');
});

test('rethrows when the caller aborted the request', async () => {
  const controller = new AbortController();
  controller.abort();
  await assert.rejects(apiFetch('/api/info', { signal: controller.signal, fetchImpl: fakeFetch(new DOMException('aborted', 'AbortError')) }));
});
