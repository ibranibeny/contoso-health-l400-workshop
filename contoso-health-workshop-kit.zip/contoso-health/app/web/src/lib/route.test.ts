import { test } from 'node:test';
import assert from 'node:assert/strict';
import { hrefFor, parseHash, routeLabel } from './route.ts';

test('parses known hash routes', () => {
  assert.equal(parseHash('#/claims'), 'claims');
  assert.equal(parseHash('#/system/'), 'system');
});

test('ignores anything that is not a route (skip links, unknown pages)', () => {
  assert.equal(parseHash('#main'), null);
  assert.equal(parseHash('#/admin'), null);
  assert.equal(parseHash(''), null);
});

test('builds links and labels', () => {
  assert.equal(hrefFor('care'), '#/care');
  assert.equal(routeLabel('desk'), 'Claims desk');
});
