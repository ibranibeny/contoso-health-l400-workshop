import type { ApiFailure } from '../lib/api.ts';
import { Icon } from './Icon.tsx';

export function ErrorNotice({ result, title }: { result: ApiFailure; title?: string }) {
  const err = result.data?.error;
  const requestId = result.requestId ?? result.data?.requestId ?? null;
  return (
    <div className="notice bad" role="alert" data-testid="error-notice">
      <Icon name="alert" />
      <div>
        <p className="notice-title">
          {title ?? 'Something went wrong'} <code>{err?.code ?? `http_${result.status}`}</code>
        </p>
        <p>{err?.message ?? 'The request failed.'}</p>
        {err?.details && err.details.length > 0 && (
          <ul>
            {err.details.map((d) => (
              <li key={d}>{d}</li>
            ))}
          </ul>
        )}
        {requestId && <p className="hint">Request id {requestId}: search for it in Application Insights.</p>}
      </div>
    </div>
  );
}
