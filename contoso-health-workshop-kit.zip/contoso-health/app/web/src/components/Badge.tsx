import type { ReactNode } from 'react';
import type { Tone } from '../lib/format.ts';

export function Badge({ tone, children, testId }: { tone: Tone; children: ReactNode; testId?: string }) {
  return (
    <span className={`badge ${tone}`} data-testid={testId}>
      {children}
    </span>
  );
}
