// Inline SVG icons (no icon font, no extra requests, allowed by the strict CSP).
const PATHS = {
  shield: 'M12 2 4 5v6c0 5.2 3.4 9.7 8 11 4.6-1.3 8-5.8 8-11V5l-8-3Zm-1.2 13.6-3.4-3.4 1.4-1.4 2 2 4.6-4.6 1.4 1.4-6 6Z',
  care: 'M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.8 7-13a7 7 0 0 0-7-7Zm1 10h2v-2h-2V8h-2v2H9v2h2v2h2v-2Z',
  claims: 'M6 2h9l5 5v13a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Zm8 1.5V8h4.5L14 3.5ZM7 12h10v-2H7v2Zm0 4h10v-2H7v2Zm0 4h6v-2H7v2Z',
  desk: 'M9 2h6a2 2 0 0 1 2 2h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2a2 2 0 0 1 2-2Zm0 2v2h6V4H9Zm1.5 13.4 6-6-1.4-1.4-4.6 4.6-2-2L7.1 12l3.4 3.4Z',
  system: 'M3 4h18v6H3V4Zm2 2v2h2V6H5Zm-2 8h18v6H3v-6Zm2 2v2h2v-2H5Zm4-10v2h10V6H9Zm0 10v2h10v-2H9Z',
  refresh: 'M17.7 6.3A8 8 0 1 0 20 12h-2a6 6 0 1 1-1.8-4.2L13 11h7V4l-2.3 2.3Z',
  alert: 'M1 21h22L12 2 1 21Zm12-3h-2v-2h2v2Zm0-4h-2v-4h2v4Z',
  check: 'M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2Z',
  bolt: 'M11 21h-1l1-7H7.5c-.9 0-.3-.8-.3-.8L13 3h1l-1 7h3.5c.5 0 .8.2.4.8L11 21Z',
} as const;

export type IconName = keyof typeof PATHS;

export function Icon({ name, size = 18, label }: { name: IconName; size?: number; label?: string }) {
  return (
    <svg
      className="icon"
      viewBox="0 0 24 24"
      width={size}
      height={size}
      role={label ? 'img' : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
      focusable="false"
    >
      <path d={PATHS[name]} fill="currentColor" />
    </svg>
  );
}

export function Logo({ size = 36 }: { size?: number }) {
  return (
    <svg viewBox="0 0 48 48" width={size} height={size} aria-hidden="true" focusable="false" className="logo">
      <path d="M24 4 7 10v12c0 11 7.3 18.7 17 22 9.7-3.3 17-11 17-22V10L24 4Z" className="logo-shield" />
      <path d="M24 33s-9-5.6-9-11.5a5 5 0 0 1 9-3 5 5 0 0 1 9 3C33 27.4 24 33 24 33Z" className="logo-heart" />
    </svg>
  );
}
