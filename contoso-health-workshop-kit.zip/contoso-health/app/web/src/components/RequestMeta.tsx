import type { ApiMeta } from '../lib/api.ts';
import { cacheTone } from '../lib/format.ts';

// What the platform did with the last request: status, latency, cache, instances, replay.
export function RequestMeta({ meta }: { meta: ApiMeta | null }) {
  if (!meta) return null;
  const ok = meta.status >= 200 && meta.status < 400;
  return (
    <ul className="meta" aria-label="Request details" data-testid="request-meta">
      <li className={`chip ${ok ? 'ok' : 'bad'}`}>{meta.status ? `HTTP ${meta.status}` : 'no response'}</li>
      <li className="chip">{meta.ms} ms</li>
      {meta.cache && (
        <li className={`chip ${cacheTone(meta.cache)}`} data-testid="cache-chip" title="x-cache: where the API found the answer">
          cache {meta.cache}
        </li>
      )}
      {meta.servedBy && <li className="chip" title="x-served-by">api {meta.servedBy}</li>}
      {meta.web && <li className="chip" title="x-web-instance">web {meta.web}</li>}
      {meta.replay && <li className="chip ok">idempotent replay</li>}
      {meta.requestId && (
        <li className="chip subtle" title={`x-request-id ${meta.requestId}`}>
          req {meta.requestId.slice(0, 8)}
        </li>
      )}
    </ul>
  );
}
