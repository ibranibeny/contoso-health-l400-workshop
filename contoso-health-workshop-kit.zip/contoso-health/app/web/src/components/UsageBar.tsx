// Width is set through the DOM style property (CSSOM), which the strict CSP allows; no inline
// style attribute ever appears in the served HTML.
export function UsageBar({ percent, label }: { percent: number; label: string }) {
  return (
    <div className="usage" role="meter" aria-valuemin={0} aria-valuemax={100} aria-valuenow={percent} aria-label={label}>
      <span style={{ inlineSize: `${percent}%` }} />
    </div>
  );
}
