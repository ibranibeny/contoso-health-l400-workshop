import { useEffect, useRef, useState } from 'react';
import { apiFetch } from './lib/api.ts';
import type { ApiInfo, WebInfo } from './lib/types.ts';
import { DEFAULT_ROUTE, ROUTES, hrefFor, parseHash, type RouteId } from './lib/route.ts';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { Icon, Logo, type IconName } from './components/Icon.tsx';
import { CoveragePage } from './pages/CoveragePage.tsx';
import { FindCarePage } from './pages/FindCarePage.tsx';
import { ClaimsPage } from './pages/ClaimsPage.tsx';
import { ClaimsDeskPage } from './pages/ClaimsDeskPage.tsx';
import { SystemPage } from './pages/SystemPage.tsx';

const ICONS: Record<RouteId, IconName> = { coverage: 'shield', care: 'care', claims: 'claims', desk: 'desk', system: 'system' };
const PLATFORM: Record<string, string> = { 'app-service': 'App Service', aks: 'AKS', local: 'Local' };

function useHashRoute(): RouteId {
  const [route, setRoute] = useState<RouteId>(() => parseHash(window.location.hash) ?? DEFAULT_ROUTE);
  useEffect(() => {
    const onChange = () => {
      const next = parseHash(window.location.hash);
      if (next) setRoute(next); // ignore non-route hashes such as the skip link
    };
    window.addEventListener('hashchange', onChange);
    return () => window.removeEventListener('hashchange', onChange);
  }, []);
  return route;
}

interface ServerInfo {
  web: WebInfo | null;
  api: ApiInfo | null;
  apiStatus: number;
}

function useServerInfo(): ServerInfo | null {
  const [info, setInfo] = useState<ServerInfo | null>(null);
  useEffect(() => {
    let alive = true;
    const load = async () => {
      const [web, api] = await Promise.all([apiFetch<WebInfo>('/web/info'), apiFetch<ApiInfo>('/api/info')]);
      if (alive) setInfo({ web: web.ok ? web.data : null, api: api.ok ? api.data : null, apiStatus: api.status });
    };
    void load();
    const timer = window.setInterval(() => void load(), 60_000);
    return () => {
      alive = false;
      window.clearInterval(timer);
    };
  }, []);
  return info;
}

export function App() {
  const route = useHashRoute();
  const server = useServerInfo();
  const first = useRef(true);
  const current = ROUTES.find((r) => r.id === route) ?? ROUTES[0];

  // Accessibility: announce the new page by moving focus to its heading (not on first load).
  useEffect(() => {
    document.title = `${current.label} · Contoso Health`;
    if (first.current) {
      first.current = false;
      return;
    }
    document.querySelector<HTMLHeadingElement>('main h1')?.focus();
  }, [current]);

  return (
    <div className="shell">
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <header className="topbar">
        <a className="brand" href={hrefFor(DEFAULT_ROUTE)} aria-label="Contoso Health member portal home">
          <Logo />
          <span>
            <strong>Contoso Health</strong>
            <small>Member Portal</small>
          </span>
        </a>
        <nav aria-label="Sections">
          <ul className="nav">
            {ROUTES.map((r) => (
              <li key={r.id}>
                <a href={hrefFor(r.id)} aria-current={r.id === route ? 'page' : undefined} className={r.id === route ? 'active' : undefined}>
                  <Icon name={ICONS[r.id]} />
                  <span>{r.label}</span>
                </a>
              </li>
            ))}
          </ul>
        </nav>
        {server?.api && (
          <span className="env-pill" title="Where the API that answered you is running">
            {PLATFORM[server.api.platform] ?? server.api.platform} · {server.api.region}
          </span>
        )}
      </header>

      <main id="main" className="content">
        <ErrorBoundary key={route}>
          {route === 'coverage' && <CoveragePage />}
          {route === 'care' && <FindCarePage />}
          {route === 'claims' && <ClaimsPage />}
          {route === 'desk' && <ClaimsDeskPage />}
          {route === 'system' && <SystemPage />}
        </ErrorBoundary>
      </main>

      <footer className="statusbar" data-testid="status-bar" aria-live="polite">
        {!server && 'Connecting…'}
        {server && !server.api && `Web ${server.web?.instance ?? '?'} cannot reach the API (HTTP ${server.apiStatus || 'no response'}).`}
        {server?.api &&
          `Served by web ${server.web?.instance ?? '?'} (v${server.web?.version ?? '?'}) → api ${server.api.instance} · ${PLATFORM[server.api.platform] ?? server.api.platform} · ${server.api.region} · storage ${server.api.storage} · cache ${server.api.cache} · api v${server.api.version}`}
      </footer>
    </div>
  );
}
