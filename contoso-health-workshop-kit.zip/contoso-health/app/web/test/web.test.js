import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { once } from 'node:events';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { cacheControl, createWebServer, loadWebConfig } from '../server.js';

let upstream; let web; let base; let dist;
before(async () => {
  // A stand-in for the Vite build output, so these tests do not need a build first.
  dist = await mkdtemp(path.join(os.tmpdir(), 'ch-web-dist-'));
  await mkdir(path.join(dist, 'assets'));
  await writeFile(path.join(dist, 'index.html'), '<!doctype html><title>Contoso Health</title><div id="root"></div><script type="module" src="/assets/index-abc123.js"></script>');
  await writeFile(path.join(dist, 'assets', 'index-abc123.js'), 'console.log("portal")');
  await writeFile(path.join(dist, 'favicon.svg'), '<svg xmlns="http://www.w3.org/2000/svg"/>');
  await writeFile(path.join(dist, 'version.json'), '{"version":"abc1234"}');
  // A fake API that echoes what it received.
  upstream = http.createServer((req, res) => {
    if (req.url === '/healthz') { res.writeHead(200, { 'content-type': 'application/json' }).end('{"status":"ok"}'); return; }
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => {
      res.writeHead(req.method === 'POST' ? 201 : 200, { 'content-type': 'application/json', 'x-cache': 'HIT', 'x-served-by': 'api-1' });
      res.end(JSON.stringify({ method: req.method, url: req.url, body, reqId: req.headers['x-request-id'], idem: req.headers['idempotency-key'] }));
    });
  });
  upstream.listen(0, '127.0.0.1');
  await once(upstream, 'listening');
  ({ server: web } = createWebServer({ port: 0, apiBaseUrl: `http://127.0.0.1:${upstream.address().port}`, apiTimeoutMs: 2000, instance: 'web-test', version: 'test', staticDir: dist }));
  web.listen(0, '127.0.0.1');
  await once(web, 'listening');
  base = `http://127.0.0.1:${web.address().port}`;
});
after(async () => {
  web.closeAllConnections?.(); upstream.closeAllConnections?.();
  await new Promise((r) => web.close(r)); await new Promise((r) => upstream.close(r));
  await rm(dist, { recursive: true, force: true });
});

test('serves the React shell with strict security headers', async () => {
  const r = await fetch(base + '/');
  assert.equal(r.status, 200);
  assert.match(r.headers.get('content-type'), /text\/html/);
  assert.match(r.headers.get('content-security-policy'), /script-src 'self'/);
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(r.headers.get('cache-control'), 'no-cache');
  assert.match(await r.text(), /id="root"/);
});

test('caches fingerprinted bundles for a year, everything else briefly', async () => {
  const js = await fetch(base + '/assets/index-abc123.js');
  assert.equal(js.status, 200);
  assert.match(js.headers.get('content-type'), /javascript/);
  assert.equal(js.headers.get('cache-control'), 'public, max-age=31536000, immutable');
  assert.equal((await fetch(base + '/favicon.svg')).headers.get('cache-control'), 'public, max-age=3600');
  assert.equal(cacheControl('/index.html'), 'no-cache');
});

test('answers 304 when index.html has not changed', async () => {
  const first = await fetch(base + '/');
  const again = await fetch(base + '/', { headers: { 'if-modified-since': first.headers.get('last-modified') } });
  assert.equal(again.status, 304);
});

test('falls back to index.html for client-side routes but not for missing files', async () => {
  const route = await fetch(base + '/claims');
  assert.equal(route.status, 200);
  assert.match(await route.text(), /id="root"/);
  assert.equal((await fetch(base + '/assets/missing-123.js')).status, 404);
});

test('HSTS only behind TLS (X-Forwarded-Proto https from Application Gateway)', async () => {
  assert.equal((await fetch(base + '/')).headers.get('strict-transport-security'), null);
  const r = await fetch(base + '/', { headers: { 'x-forwarded-proto': 'https' } });
  assert.match(r.headers.get('strict-transport-security'), /max-age=/);
});

test('blocks path traversal', async () => {
  assert.equal((await fetch(base + '/..%2f..%2fetc%2fpasswd')).status, 400);
  assert.equal((await fetch(base + '/assets/..%2f..%2fserver.js')).status, 400);
});

test('proxies GET and POST to the API, forwarding request id and idempotency key', async () => {
  const g = await fetch(base + '/api/info?x=1', { headers: { 'x-request-id': 'req-123' } });
  assert.equal(g.status, 200);
  assert.equal(g.headers.get('x-cache'), 'HIT');
  assert.equal(g.headers.get('x-web-instance'), 'web-test');
  const gb = await g.json();
  assert.equal(gb.url, '/api/info?x=1');
  assert.equal(gb.reqId, 'req-123');
  const p = await fetch(base + '/api/claims', { method: 'POST', headers: { 'content-type': 'application/json', 'idempotency-key': 'abc12345' }, body: '{"a":1}' });
  assert.equal(p.status, 201);
  const pb = await p.json();
  assert.equal(pb.body, '{"a":1}');
  assert.equal(pb.idem, 'abc12345');
});

test('readiness follows the API', async () => {
  const r = await fetch(base + '/readyz');
  assert.equal(r.status, 200);
  assert.equal((await r.json()).checks.api, 'ok');
});

test('reports the version the pipeline stamped into dist/version.json', () => {
  assert.equal(loadWebConfig({ STATIC_DIR: dist }).version, 'abc1234');
  assert.equal(loadWebConfig({ STATIC_DIR: dist, APP_VERSION: 'v9' }).version, 'v9');
});

test('returns 502 when the API is unreachable', async () => {
  const { server } = createWebServer({ port: 0, apiBaseUrl: 'http://127.0.0.1:9', apiTimeoutMs: 1000, instance: 'w', version: 't', staticDir: dist });
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  try {
    const r = await fetch(`http://127.0.0.1:${server.address().port}/api/info`);
    assert.equal(r.status, 502);
    assert.equal((await r.json()).error.code, 'upstream_unavailable');
  } finally {
    server.closeAllConnections?.();
    await new Promise((r) => server.close(r));
  }
});
