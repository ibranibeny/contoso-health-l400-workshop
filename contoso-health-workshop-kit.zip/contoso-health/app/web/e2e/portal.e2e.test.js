// End-to-end test of a running Contoso Health portal in a real browser (Playwright library +
// Node's built-in test runner, no extra test framework). The same file tests every environment:
//   docker compose:                 BASE_URL=http://localhost:8080 npm run e2e
//   App Service behind the WAF:     BASE_URL="http://${APPGW_PUBLIC_IP}" npm run e2e
//   AKS behind the WAF (:8080):     BASE_URL="http://${APPGW_PUBLIC_IP}:8080" npm run e2e
// Options (environment variables):
//   E2E_READONLY=true      skip every step that writes data or needs the demo (seed) data: use it in
//                          production, which has neither
//   E2E_EXPECT_WAF=true    also prove that the Web Application Firewall blocks an attack in a claim
//   E2E_MEMBER_ID=CH-...   active member used for claims (default CH-100001); give parallel pipelines
//                          different members, the API allows each member five claims a minute
//   E2E_ARTIFACTS=dir      where screenshots of failed tests go (default e2e-artifacts)
//   E2E_CHROMIUM_PATH=...  use a preinstalled Chromium instead of `npx playwright install chromium`
// First run: npm run e2e:install (downloads Chromium and its system libraries).
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdir } from 'node:fs/promises';
import { chromium } from 'playwright';

const BASE_URL = (process.env.BASE_URL || 'http://localhost:8080').replace(/\/$/, '');
const READONLY = /^(1|true|yes)$/i.test(process.env.E2E_READONLY || '');
const EXPECT_WAF = /^(1|true|yes)$/i.test(process.env.E2E_EXPECT_WAF || '');
const ARTIFACTS = process.env.E2E_ARTIFACTS || 'e2e-artifacts';
const TIMEOUT = Number.parseInt(process.env.E2E_TIMEOUT_MS || '20000', 10);
const NEEDS_DEMO_DATA = { skip: READONLY && 'read-only run: needs the demo data' };
const MEMBER = process.env.E2E_MEMBER_ID || 'CH-100001';

let browser;
let page;

before(async () => {
  browser = await chromium.launch({ executablePath: process.env.E2E_CHROMIUM_PATH || undefined });
  const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  context.setDefaultTimeout(TIMEOUT);
  page = await context.newPage();
  console.log(`# e2e against ${BASE_URL}${READONLY ? ' (read-only)' : ''}${EXPECT_WAF ? ' (expect WAF)' : ''}`);
});

after(async () => {
  await browser?.close();
});

// Run a test body; on failure keep a full-page screenshot for the pipeline artefacts.
function inBrowser(name, body) {
  return async () => {
    try {
      await body();
    } catch (err) {
      await mkdir(ARTIFACTS, { recursive: true });
      await page.screenshot({ path: `${ARTIFACTS}/${name}.png`, fullPage: true }).catch(() => undefined);
      throw err;
    }
  };
}

const open = (route) => page.goto(`${BASE_URL}/#/${route}`, { waitUntil: 'domcontentloaded' });

// Claims page for the test member: load the member's claims and the providers in their city.
async function openClaims() {
  await open('claims');
  await page.getByLabel('Member ID').fill(MEMBER);
  await page.getByRole('button', { name: 'Show claims' }).click();
  await page.getByTestId('provider-select').locator('option').first().waitFor({ state: 'attached' });
}
const waitForText = (locator, pattern) => locator.filter({ hasText: pattern }).first().waitFor();

test('the portal loads through the gateway with strict security headers', inBrowser('portal', async () => {
  const response = await page.goto(`${BASE_URL}/`, { waitUntil: 'domcontentloaded' });
  assert.equal(response.status(), 200);
  const headers = response.headers();
  assert.match(headers['content-security-policy'] ?? '', /default-src 'self'/);
  assert.equal(headers['x-content-type-options'], 'nosniff');
  await page.getByRole('heading', { name: 'Am I covered today?' }).waitFor();
  await waitForText(page.getByTestId('status-bar'), /Served by web .+ api /);
}));

test('the web tier is ready and reaches the API', inBrowser('ready', async () => {
  const ready = await page.request.get(`${BASE_URL}/readyz`);
  assert.equal(ready.status(), 200);
  assert.equal((await ready.json()).checks.api, 'ok');
}));

test('Ayu is covered, and the second lookup comes from the cache', NEEDS_DEMO_DATA, inBrowser('coverage', async () => {
  await open('coverage');
  await page.getByLabel('Member ID').fill('CH-100001');
  const check = page.getByRole('button', { name: 'Check eligibility' });
  await check.click();
  await waitForText(page.getByTestId('eligibility-status'), /^Covered$/);
  await check.click();
  // Within the 60-second TTL the API answers from Redis (or the in-memory cache locally).
  await waitForText(page.getByTestId('cache-chip'), /cache HIT/);
}));

test('a member in the grace period and a suspended member are not covered', NEEDS_DEMO_DATA, inBrowser('not-covered', async () => {
  await open('coverage');
  await page.getByRole('button', { name: /Budi/ }).click();
  await waitForText(page.getByTestId('eligibility-status'), /Not covered/);
  await waitForText(page.getByTestId('eligibility-reason'), /grace/i);
  await page.getByRole('button', { name: /Citra/ }).click();
  await waitForText(page.getByTestId('eligibility-reason'), /suspended/i);
}));

test('an unknown member gets a clear 404, not a broken page', inBrowser('unknown-member', async () => {
  await open('coverage');
  await page.getByLabel('Member ID').fill('CH-999999');
  await page.getByRole('button', { name: 'Check eligibility' }).click();
  await waitForText(page.getByTestId('error-notice'), /not_found/);
}));

test('find care lists providers and caches the directory', NEEDS_DEMO_DATA, inBrowser('find-care', async () => {
  await open('care');
  const city = page.getByTestId('city-select');
  await city.locator('option').nth(1).waitFor({ state: 'attached' });
  await city.selectOption({ index: 1 });
  const search = page.getByRole('button', { name: 'Search' });
  await search.click();
  await waitForText(page.getByTestId('providers-count'), /[1-9]\d* providers/);
  await search.click();
  await waitForText(page.getByTestId('cache-chip'), /cache HIT/);
}));

test('a claim is created once; the same request sent again returns the original', { skip: READONLY && 'read-only run' }, inBrowser('claim-idempotency', async () => {
  await openClaims();
  await page.getByRole('button', { name: 'Submit claim' }).click();
  await waitForText(page.getByTestId('claim-result'), /Claim created/);
  const claimId = (await page.getByTestId('claim-id').textContent())?.trim();
  assert.match(claimId ?? '', /^CLM-\d{4}-\d{6}$/);
  await page.getByRole('button', { name: 'Send the same request again' }).click();
  await waitForText(page.getByTestId('claim-result'), /returned the original claim/);
  assert.equal((await page.getByTestId('claim-id').textContent())?.trim(), claimId);
}));

test('the per-member rate limit answers 429 after five claims a minute', { skip: READONLY && 'read-only run' }, inBrowser('rate-limit', async () => {
  await openClaims();
  const burst = page.getByRole('button', { name: 'Submit 7 claims quickly' });
  await burst.click();
  await waitForText(page.getByTestId('burst-result'), /Seven submissions returned/);
  let statuses = await page.getByTestId('burst-result').locator('li').allTextContents();
  if (!statuses.includes('429')) {
    // The API counts claims in fixed one-minute windows: a burst that straddles a minute boundary can
    // stay under the limit. A second burst lands in the same window and must hit it.
    const run = await page.getByTestId('burst-result').getAttribute('data-run');
    await burst.click();
    await page.waitForFunction((before) => document.querySelector('[data-testid="burst-result"]')?.getAttribute('data-run') !== before, run);
    statuses = await page.getByTestId('burst-result').locator('li').allTextContents();
  }
  assert.ok(statuses.includes('429'), `expected a 429 among ${statuses.join(', ')}`);
}));

test('the WAF blocks an SQL injection hidden in a claim note', { skip: (!EXPECT_WAF || READONLY) && 'set E2E_EXPECT_WAF=true behind Application Gateway' }, inBrowser('waf-block', async () => {
  await openClaims();
  await page.getByLabel('Note').fill("x' UNION SELECT password FROM users --");
  await page.getByRole('button', { name: 'Submit claim' }).click();
  await waitForText(page.getByTestId('error-notice'), /blocked/);
}));

test('the claims desk shows the queue, or says it is turned off', inBrowser('claims-desk', async () => {
  await open('desk');
  const state = page.getByTestId('desk-table').or(page.getByTestId('desk-empty')).or(page.getByTestId('desk-disabled'));
  await state.first().waitFor();
  if (!READONLY && (await page.getByTestId('desk-table').count()) > 0) {
    await page.getByRole('button', { name: 'Approve' }).first().click();
    await waitForText(page.getByTestId('decision-result'), /is now approved/);
  }
}));

test('the system page shows both tiers and where they run', inBrowser('system', async () => {
  await open('system');
  await page.getByTestId('web-tier').waitFor();
  await waitForText(page.getByTestId('api-tier'), /App Service|Kubernetes|Local/);
}));
