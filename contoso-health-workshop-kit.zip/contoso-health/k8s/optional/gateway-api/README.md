# Optional: Gateway API ingress (application routing, Istio implementation)

Why this folder exists: the community ingress-nginx project was retired (best-effort maintenance ended March 2026)
and Microsoft's support for the NGINX-based application routing add-on ends in November 2026. Learn's
migration targets are the application routing **Gateway API** implementation (`approuting-istio`, GA) or
Application Gateway for Containers (not offered in Indonesia Central).

The kit's default path stays simpler: Application Gateway WAF_v2 -> internal load balancer -> `web` service.
Use this folder when you add more services behind one entry point.

1. Enable: `az aks update -g rg-ch-aks-lab-idc -n aks-ch-lab-idc --enable-gateway-api --enable-app-routing-istio`
2. Change the `web` Service in your overlay to `type: ClusterIP`.
3. `kubectl apply -f k8s/optional/gateway-api/gateway.yaml`
4. `kubectl get gateway contoso-health -n contoso-health -o wide` -> note the address and point the
   Application Gateway :8080 backend pool at it (update `aksIngressPrivateIp`).
