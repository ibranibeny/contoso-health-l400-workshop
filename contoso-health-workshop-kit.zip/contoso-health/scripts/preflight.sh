#!/usr/bin/env bash
# preflight.sh: checks that an Azure subscription is ready for the Contoso Health workshop.
#   1. Azure CLI signed in, right subscription selected
#   2. Resource providers registered (Bicep deployments and AzureRM 5.x do NOT register them)
#   3. Indonesia Central offers every SKU / service the kit uses
#   4. vCPU quota for AKS and the ops VM
#   5. SSH public key for the ops VM (generated when OPS_SSH_PUBLIC_KEY is not set)
# Idempotent: only registers what is missing and never overwrites an existing key.
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: scripts/preflight.sh [--subscription <id-or-name>] [--skip-register]

  --subscription   Select this subscription first (az account set).
  --skip-register  Only report provider registration state; do not register anything.

Environment: AZURE_LOCATION (default indonesiacentral), OPS_SSH_PUBLIC_KEY (optional).
EOF
}

LOCATION="${AZURE_LOCATION:-indonesiacentral}"
LOCATION_DISPLAY="Indonesia Central"
SUBSCRIPTION=""
REGISTER=true
FAILURES=0

while [ "$#" -gt 0 ]; do
  case "$1" in
    --subscription) SUBSCRIPTION="${2:?--subscription needs a value}"; shift 2 ;;
    --skip-register) REGISTER=false; shift ;;
    -h|--help) usage; exit 0 ;;
    *) usage; exit 1 ;;
  esac
done

log()  { printf '\n==> %s\n' "$*"; }
ok()   { printf '    [ OK ] %s\n' "$*"; }
bad()  { printf '    [FAIL] %s\n' "$*"; FAILURES=$((FAILURES + 1)); }
note() { printf '    [INFO] %s\n' "$*"; }

command -v az > /dev/null 2>&1 || { echo "ERROR: Azure CLI (az) is required" >&2; exit 1; }

# ---------------------------------------------------------------------------------------------
log "1/5 Azure CLI sign-in and subscription"
if [ -n "${SUBSCRIPTION}" ]; then
  echo "    az account set --subscription ${SUBSCRIPTION}"
  az account set --subscription "${SUBSCRIPTION}"
fi
if ! az account show > /dev/null 2>&1; then
  echo "ERROR: not signed in. Run: az login --tenant <tenant-id>" >&2
  exit 1
fi
az account show --query "{subscription:name, id:id, tenant:tenantId, user:user.name}" -o table
note "Azure CLI $(az version --query '"azure-cli"' -o tsv) (Gateway API add-on in aks-postprovision.sh needs 2.86.0+)"

# ---------------------------------------------------------------------------------------------
log "2/5 Resource providers"
PROVIDERS=(
  Microsoft.Web Microsoft.DBforPostgreSQL Microsoft.Cache Microsoft.ContainerService
  Microsoft.ContainerRegistry Microsoft.Network Microsoft.KeyVault Microsoft.OperationalInsights
  Microsoft.Insights Microsoft.Monitor Microsoft.ManagedIdentity Microsoft.Compute Microsoft.Security
  Microsoft.PolicyInsights Microsoft.AlertsManagement Microsoft.Dashboard
)
pending=()
for ns in "${PROVIDERS[@]}"; do
  state="$(az provider show --namespace "${ns}" --query registrationState -o tsv 2> /dev/null || echo "Unknown")"
  if [ "${state}" = "Registered" ]; then
    ok "${ns} Registered"
  elif [ "${REGISTER}" = "true" ]; then
    echo "    az provider register --namespace ${ns}   (was: ${state})"
    # Registration is asynchronous: start all of them, then wait once below.
    az provider register --namespace "${ns}" > /dev/null
    pending+=("${ns}")
  else
    bad "${ns} ${state} (run without --skip-register to register it)"
  fi
done
if [ "${#pending[@]}" -gt 0 ]; then
  echo "    Waiting for ${#pending[@]} provider(s) to finish registering (usually 1-5 minutes)..."
  for ((attempt = 1; attempt <= 60; attempt++)); do
    still=()
    for ns in "${pending[@]}"; do
      state="$(az provider show --namespace "${ns}" --query registrationState -o tsv)"
      [ "${state}" = "Registered" ] || still+=("${ns}")
    done
    if [ "${#still[@]}" -eq 0 ]; then
      ok "all providers registered (after ${attempt} check(s))"
      break
    fi
    if [ "${attempt}" -eq 60 ]; then
      bad "still registering after 10 minutes: ${still[*]} (re-run this script later)"
      break
    fi
    pending=("${still[@]}")
    sleep 10
  done
fi

# ---------------------------------------------------------------------------------------------
log "3/5 Region capabilities in ${LOCATION}"
normalise() { tr -d ' ' | tr '[:upper:]' '[:lower:]'; }

echo "    az appservice list-locations --linux-workers-enabled --sku P0V4"
app_locations="$(az appservice list-locations --linux-workers-enabled --sku P0V4 --query "[].name" -o tsv 2> /dev/null || true)"
# grep reads all input (no -q) so it never closes the pipe early under pipefail.
if normalise <<< "${app_locations}" | grep -x "${LOCATION}" > /dev/null; then
  ok "App Service Premium v4 (Linux) available"
else
  bad "App Service P0V4 Linux workers not listed in ${LOCATION}"
fi

echo "    az postgres flexible-server list-skus -l ${LOCATION}"
pg_skus="$(az postgres flexible-server list-skus -l "${LOCATION}" -o json 2> /dev/null || echo '[]')"
for sku in Standard_B1ms Standard_D2ds_v5; do
  if grep -q "\"${sku}\"" <<< "${pg_skus}"; then ok "PostgreSQL flexible server SKU ${sku}"; else bad "PostgreSQL SKU ${sku} not offered"; fi
done
if grep -q 'ZoneRedundant' <<< "${pg_skus}"; then
  ok "PostgreSQL zone-redundant HA advertised"
else
  note "PostgreSQL zone-redundant HA not found in list-skus output: check before deploying prod"
fi
note "PostgreSQL geo-redundant backup is NOT available in ${LOCATION} (no paired region): the kit keeps it Disabled"

echo "    az aks get-versions -l ${LOCATION}"
aks_versions="$(az aks get-versions -l "${LOCATION}" --query "values[].version" -o tsv 2> /dev/null | tr '\n' ' ' || true)"
if grep -qw '1.36' <<< "${aks_versions}"; then
  ok "AKS Kubernetes 1.36 available (offered: ${aks_versions})"
else
  bad "AKS 1.36 not offered in ${LOCATION} (offered: ${aks_versions:-none})"
fi

check_resource_type() { # <namespace> <resourceType> <label>
  local locations
  locations="$(az provider show --namespace "$1" --query "resourceTypes[?resourceType=='$2'].locations[]" -o tsv 2> /dev/null || true)"
  if normalise <<< "${locations}" | grep -x "${LOCATION}" > /dev/null; then
    ok "$3 ($1/$2)"
  else
    bad "$3 ($1/$2) not available in ${LOCATION_DISPLAY}"
  fi
}
check_resource_type Microsoft.Cache redisEnterprise "Azure Managed Redis"
check_resource_type Microsoft.ContainerRegistry registries "Azure Container Registry"
check_resource_type Microsoft.Network azureFirewalls "Azure Firewall (prod egress)"

# ---------------------------------------------------------------------------------------------
log "4/5 vCPU quota in ${LOCATION}"
echo "    az vm list-usage -l ${LOCATION}"
az vm list-usage -l "${LOCATION}" \
  --query "[?name.value=='cores' || name.value=='standardDDSv5Family' || name.value=='standardDSv5Family' || name.value=='standardBSFamily'].{quota:localName, used:currentValue, limit:limit}" \
  -o table || bad "could not read vCPU usage"
# AKS: system pool 3 x Standard_D4ds_v5 (12 vCPU) + apps pool (2-6 nodes lab) + 1 surge node during
# upgrades; ops VM Standard_B2s (2 vCPU). Below ~26 free regional vCPUs the lab will not fit. [REL][COST]
free_cores="$(az vm list-usage -l "${LOCATION}" --query "[?name.value=='cores'] | [0].[limit, currentValue]" -o tsv 2> /dev/null | awk '{print $1 - $2}' || true)"
if [ -n "${free_cores}" ] && [ "${free_cores}" -ge 26 ]; then
  ok "${free_cores} regional vCPUs free (lab needs about 26 with AKS)"
else
  bad "only ${free_cores:-unknown} regional vCPUs free; request a quota increase (Total Regional vCPUs + DDSv5 family)"
fi

# ---------------------------------------------------------------------------------------------
log "5/5 SSH public key for the ops VM"
# The VM has no public IP and no inbound SSH: it is driven with `az vm run-command`. Azure still
# requires a key for Linux VMs, so the private key below is never used for anything. [SEC]
if [ -n "${OPS_SSH_PUBLIC_KEY:-}" ]; then
  ok "OPS_SSH_PUBLIC_KEY is set"
elif ! command -v ssh-keygen > /dev/null 2>&1; then
  bad "ssh-keygen not found: install the OpenSSH client, or export OPS_SSH_PUBLIC_KEY with an existing public key"
else
  key_file="${HOME}/.ssh/id_ed25519_ch_ops"
  if [ ! -f "${key_file}.pub" ]; then
    mkdir -p "${HOME}/.ssh"
    chmod 700 "${HOME}/.ssh"
    echo "    ssh-keygen -t ed25519 -f ${key_file}"
    ssh-keygen -t ed25519 -N '' -C "contoso-health-ops-vm" -f "${key_file}" -q
  fi
  ok "key: ${key_file}.pub. Export it for Bicep/Terraform (and run bootstrap-github-oidc.sh after):"
  echo
  echo "export OPS_SSH_PUBLIC_KEY=\"$(cat "${key_file}.pub")\""
  echo "export TF_VAR_ops_ssh_public_key=\"\${OPS_SSH_PUBLIC_KEY}\""
fi

# ---------------------------------------------------------------------------------------------
echo
if [ "${FAILURES}" -gt 0 ]; then
  echo "Preflight finished with ${FAILURES} failed check(s). Fix them before deploying."
  exit 1
fi
echo "Preflight passed. Next: scripts/bootstrap-github-oidc.sh <owner/repo> lab"
