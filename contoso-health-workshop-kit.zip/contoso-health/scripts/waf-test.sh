#!/usr/bin/env bash
# waf-test.sh: prove that the Web Application Firewall on Application Gateway protects the portal.
# It sends harmless requests that LOOK like attacks and checks who answered: the WAF blocks with
# HTTP 403 from the gateway itself; the application never sees the request. [SEC][REL]
#   - a normal page and a normal API call pass
#   - SQL injection and cross-site scripting in a query string, SQL injection inside a JSON claim
#     and a path-traversal attempt are blocked by the managed rules (DRS 2.2, anomaly score >= 5)
#   - DELETE is blocked by the custom rule BlockUnexpectedMethods
#   - a scanner user agent is reported (informational: bot classification is Microsoft's)
#   - optional: the custom rate limit on claim submissions (RateLimitClaimSubmissions)
set -euo pipefail

usage() {
  cat <<'USAGE'
Usage: scripts/waf-test.sh <base-url>

Examples:
  scripts/waf-test.sh "http://${APPGW_PUBLIC_IP}"        # App Service listener
  scripts/waf-test.sh "http://${APPGW_PUBLIC_IP}:8080"   # AKS listener (same WAF policy)

Environment (optional):
  WAF_EXPECT_MODE            Prevention (default): attacks must be blocked with 403.
                             Detection: attacks must reach the app (and appear in the WAF log).
  WAF_RATE_LIMIT             true = also send POST /api/claims until the rate limit blocks
                             (default false). Run it LAST: the WAF keeps blocking POST /api/claims
                             from your IP for up to a minute.
  WAF_RATE_LIMIT_PER_MINUTE  the threshold set in IaC: wafClaimsRateLimitPerMinute (default 60)
  WAF_TIMEOUT                per-request timeout in seconds (default 15)
USAGE
}

if [ "${1:-}" = "-h" ] || [ "${1:-}" = "--help" ]; then usage; exit 0; fi
if [ "$#" -ne 1 ]; then usage; exit 1; fi
command -v curl > /dev/null 2>&1 || { echo "ERROR: curl is required" >&2; exit 1; }

BASE_URL="${1%/}"
MODE="${WAF_EXPECT_MODE:-Prevention}"
RATE_LIMIT="${WAF_RATE_LIMIT:-false}"
RATE_LIMIT_PER_MINUTE="${WAF_RATE_LIMIT_PER_MINUTE:-60}"
TIMEOUT="${WAF_TIMEOUT:-15}"
ROWS=()
FAILED=0

# probe <method> <path> [json-body] [user-agent]: prints "<status> <gateway|app>".
# A WAF block comes from the gateway (Server: Microsoft-Azure-Application-Gateway/...) as HTML;
# everything the application answers is JSON.
probe() {
  local method="$1" path="$2" body="${3:-}" agent="${4:-contoso-waf-test/1.0}" out status server ctype
  local args=(-sS -o /dev/null -D - -X "${method}" --max-time "${TIMEOUT}" -A "${agent}" -H "accept: application/json")
  if [ -n "${body}" ]; then args+=(-H "content-type: application/json" --data "${body}"); fi
  if ! out="$(curl "${args[@]}" "${BASE_URL}${path}" 2> /dev/null)"; then
    echo "000 none"
    return 0
  fi
  out="${out//$'\r'/}"
  status="$(awk 'NR == 1 { print $2 }' <<< "${out}")"
  server="$(awk 'tolower($1) == "server:" { $1 = ""; print }' <<< "${out}")"
  ctype="$(awk 'tolower($1) == "content-type:" { $1 = ""; print }' <<< "${out}")"
  if [[ "${server}" == *Application-Gateway* ]] || { [ "${status}" = "403" ] && [[ "${ctype}" != *json* ]]; }; then
    echo "${status} gateway"
  else
    echo "${status} app"
  fi
}

record() { # <check> <expected> <actual> <PASS|FAIL|INFO>
  ROWS+=("$1|$2|$3|$4")
  if [ "$4" = "FAIL" ]; then FAILED=$((FAILED + 1)); fi
}

expect_pass() { # <label> <method> <path> [body]
  local r
  r="$(probe "$2" "$3" "${4:-}")"
  if [[ "${r}" == 2* ]]; then record "$1" "2xx from the app" "${r}" PASS; else record "$1" "2xx from the app" "${r}" FAIL; fi
}

expect_block() { # <label> <method> <path> [body] [user-agent]
  local r
  r="$(probe "$2" "$3" "${4:-}" "${5:-contoso-waf-test/1.0}")"
  if [ "${MODE}" = "Detection" ]; then
    # Detection mode logs the match and lets the request through to the application.
    if [ "${r}" != "403 gateway" ] && [ "${r%% *}" != "000" ]; then record "$1" "reaches the app (logged)" "${r}" PASS; else record "$1" "reaches the app (logged)" "${r}" FAIL; fi
  else
    if [ "${r}" = "403 gateway" ]; then record "$1" "403 from the WAF" "${r}" PASS; else record "$1" "403 from the WAF" "${r}" FAIL; fi
  fi
}

echo "WAF test against ${BASE_URL} (expected mode: ${MODE})"

# Baseline: if normal traffic fails, nothing below means anything.
expect_pass "normal page GET /" GET /
expect_pass "normal API call GET /api/info" GET /api/info

yesterday="$(date -u -d 'yesterday' +%Y-%m-%d 2> /dev/null || date -u -v-1d +%Y-%m-%d)"
expect_block "SQL injection in a query string" GET "/api/providers?city=Jakarta%27%20UNION%20SELECT%20username,password%20FROM%20users--"
expect_block "cross-site scripting in a query string" GET "/api/providers?q=%3Cscript%3Ealert(document.cookie)%3C/script%3E"
expect_block "SQL injection inside a JSON claim" POST /api/claims \
  "{\"memberId\":\"CH-100001\",\"providerId\":\"PRV-JAK-001\",\"claimType\":\"outpatient\",\"serviceDate\":\"${yesterday}\",\"amountIdr\":150000,\"note\":\"x' UNION SELECT password FROM users --\"}"
expect_block "path traversal in a parameter" GET "/api/providers?file=../../../../etc/passwd"
expect_block "unexpected method DELETE (custom rule)" DELETE /api/claims/CLM-2026-000001

# Bot Manager decides from Microsoft threat intelligence and the request's claimed identity; a
# made-up scanner agent may or may not be classified, so this row is informational only.
bot="$(probe GET /api/info "" "sqlmap/1.8.4#stable (https://sqlmap.org)")"
record "scanner user agent (Bot Manager 1.1)" "informational" "${bot}" INFO

# The WAF blocks requests, not clients: normal traffic from the same IP still passes.
expect_pass "normal traffic after the probes" GET /api/info

if [ "${RATE_LIMIT}" = "true" ]; then
  # Invalid claim bodies: the API rejects them with 400 and writes nothing, but the WAF counts every
  # POST /api/claims from this IP. Above the threshold the gateway answers 403. [SEC]
  total=$((RATE_LIMIT_PER_MINUTE + 20))
  blocked=0
  for ((i = 1; i <= total; i++)); do
    r="$(probe POST /api/claims '{}')"
    if [ "${r}" = "403 gateway" ]; then blocked=$((blocked + 1)); fi
  done
  if [ "${blocked}" -gt 0 ]; then
    record "rate limit: ${total} claim POSTs in a minute" ">=1 x 403 from the WAF" "${blocked} blocked" PASS
  else
    record "rate limit: ${total} claim POSTs in a minute" ">=1 x 403 from the WAF" "0 blocked" FAIL
  fi
fi

printf '\n%-44s %-26s %-16s %s\n' "CHECK" "EXPECTED" "ACTUAL" "RESULT"
for row in "${ROWS[@]}"; do
  IFS='|' read -r check expected actual result <<< "${row}"
  printf '%-44s %-26s %-16s %s\n' "${check}" "${expected}" "${actual}" "${result}"
done

# Prevention writes "Blocked" rows; Detection writes "Detected" for the same verdict.
LOG_ACTION="Blocked"
if [ "${MODE}" = "Detection" ]; then LOG_ACTION="Detected"; fi
cat <<KQL

See every decision in Log Analytics (resource-specific table of the Application Gateway logs):
  AGWFirewallLogs
  | where TimeGenerated > ago(30m)
  | where Action == "${LOG_ACTION}"
  | take 50
KQL

if [ "${FAILED}" -gt 0 ]; then
  echo "WAF TEST FAILED: ${FAILED} check(s)"
  exit 1
fi
echo "WAF TEST PASSED"
