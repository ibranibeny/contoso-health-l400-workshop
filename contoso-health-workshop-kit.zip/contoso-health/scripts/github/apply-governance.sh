#!/usr/bin/env bash
# apply-governance.sh: repository governance for the Contoso Health workshop repository, as code.
# Idempotent: safe to re-run; existing environments, labels and the ruleset are updated in place.
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: scripts/github/apply-governance.sh <owner/repo>

Creates or updates:
  1. GitHub environments lab, prod, copilot (prod: required reviewers + deployments from main only)
  2. Default GITHUB_TOKEN permissions = read-only
  3. Labels used by the issue forms
  4. Branch ruleset for the default branch (scripts/github/ruleset-main.json)
  5. Dependabot alerts + security updates, secret scanning + push protection, CodeQL default setup
Then prints the settings that only exist in the GitHub UI.

Environment variables (all optional):
  PROD_REVIEWERS   Comma-separated GitHub logins and/or org/team slugs that approve prod deployments
  SOLO_WORKSHOP    "true" for a one-person workshop repository: 0 required approvals, no code-owner
                   review, and prod reviewers may approve their own runs. Default "false".
  REQUIRED_CHECKS  Comma-separated check names to require, e.g. "app-unit (api),app-unit (web)".
                   Read the note "Required status checks" in this script first.
  GHAS_ENABLED     "true" when a PRIVATE repository has GitHub Code Security / Secret Protection.

Requires: gh (authenticated as a repository admin) and jq.
EOF
}

log()  { printf '\n==> %s\n' "$*"; }
info() { printf '    %s\n' "$*"; }
warn() { printf '    WARNING: %s\n' "$*" >&2; }
die()  { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

if [ "${1:-}" = "-h" ] || [ "${1:-}" = "--help" ]; then usage; exit 0; fi
if [ "$#" -ne 1 ]; then usage; exit 1; fi
REPO="$1"
[[ "${REPO}" =~ ^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$ ]] || die "Expected <owner/repo>, got '${REPO}'"

for cmd in gh jq; do
  command -v "${cmd}" > /dev/null 2>&1 || die "${cmd} is required"
done
gh auth status > /dev/null 2>&1 || die "Run 'gh auth login' first"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RULESET_FILE="${SCRIPT_DIR}/ruleset-main.json"
SOLO="${SOLO_WORKSHOP:-false}"
GHAS="${GHAS_ENABLED:-false}"

log "Repository ${REPO}"
repo_info="$(gh api "repos/${REPO}" --jq '[.private, .default_branch] | @tsv')" \
  || die "Cannot read ${REPO}: does it exist and are you an admin?"
PRIVATE="$(cut -f1 <<< "${repo_info}")"
DEFAULT_BRANCH="$(cut -f2 <<< "${repo_info}")"
info "private=${PRIVATE} default_branch=${DEFAULT_BRANCH} solo_workshop=${SOLO}"
# Code scanning, secret scanning and dependency review on PRIVATE repos need GitHub Code Security /
# Secret Protection licences; public repositories get them for free.
SECURITY_LICENSED=false
if [ "${PRIVATE}" = "false" ] || [ "${GHAS}" = "true" ]; then SECURITY_LICENSED=true; fi

# ---------------------------------------------------------------------------------------------
log "1/5 Environments"
# lab and copilot: no protection. Created only when missing so manual tweaks are never overwritten.
for env in lab copilot; do
  if gh api "repos/${REPO}/environments/${env}" --silent > /dev/null 2>&1; then
    info "${env}: exists"
  else
    gh api -X PUT "repos/${REPO}/environments/${env}" --silent
    info "${env}: created"
  fi
done

# prod: required reviewers (when given) and deployments from the default branch only. [SEC]
reviewers='[]'
if [ -n "${PROD_REVIEWERS:-}" ]; then
  IFS=',' read -r -a entries <<< "${PROD_REVIEWERS}"
  for entry in "${entries[@]}"; do
    entry="${entry// /}"
    [ -n "${entry}" ] || continue
    if [[ "${entry}" == */* ]]; then
      id="$(gh api "orgs/${entry%%/*}/teams/${entry#*/}" --jq '.id')"
      type="Team"
    else
      id="$(gh api "users/${entry}" --jq '.id')"
      type="User"
    fi
    reviewers="$(jq -c --arg type "${type}" --argjson id "${id}" '. + [{type: $type, id: $id}]' <<< "${reviewers}")"
    info "prod reviewer: ${type} ${entry} (${id})"
  done
fi
# A solo participant must be able to approve their own deployment, otherwise prod is unreachable.
prevent_self_review=true
if [ "${SOLO}" = "true" ]; then prevent_self_review=false; fi
prod_body="$(jq -n --argjson reviewers "${reviewers}" --argjson psr "${prevent_self_review}" '
  {wait_timer: 0, deployment_branch_policy: {protected_branches: false, custom_branch_policies: true}}
  + (if ($reviewers | length) > 0 then {reviewers: $reviewers, prevent_self_review: $psr} else {} end)')"
if gh api -X PUT "repos/${REPO}/environments/prod" --input - --silent <<< "${prod_body}"; then
  info "prod: protection rules applied"
else
  # Required reviewers on PRIVATE repositories need GitHub Enterprise (public repos: any plan).
  warn "prod: could not set required reviewers (private repository without GitHub Enterprise?). Retrying without reviewers."
  gh api -X PUT "repos/${REPO}/environments/prod" --input - --silent \
    <<< '{"wait_timer":0,"deployment_branch_policy":{"protected_branches":false,"custom_branch_policies":true}}' \
    || warn "prod: could not set the deployment branch policy either; configure it in Settings > Environments."
fi
if gh api "repos/${REPO}/environments/prod/deployment-branch-policies" --jq '.branch_policies[].name' 2> /dev/null | grep -x "${DEFAULT_BRANCH}" > /dev/null; then
  info "prod: deployments allowed from ${DEFAULT_BRANCH} only (already set)"
elif gh api -X POST "repos/${REPO}/environments/prod/deployment-branch-policies" \
  -f name="${DEFAULT_BRANCH}" -f type=branch --silent; then
  info "prod: deployments allowed from ${DEFAULT_BRANCH} only"
else
  warn "prod: could not add the ${DEFAULT_BRANCH} deployment branch policy"
fi

# ---------------------------------------------------------------------------------------------
log "2/5 Default GITHUB_TOKEN permissions"
# Read-only by default; each workflow job asks for exactly what it needs. Actions may not approve PRs. [SEC]
if gh api -X PUT "repos/${REPO}/actions/permissions/workflow" \
  -f default_workflow_permissions=read -F can_approve_pull_request_reviews=false --silent; then
  info "default_workflow_permissions=read, can_approve_pull_request_reviews=false"
else
  warn "could not change workflow permissions (organisation policy?)"
fi

# ---------------------------------------------------------------------------------------------
log "3/5 Labels"
create_label() {
  gh label create "$1" --repo "${REPO}" --color "$2" --description "$3" --force > /dev/null
  info "label: $1"
}
create_label "infra-change" "0E8A16" "Infrastructure change: Bicep + Terraform + k8s + pipelines"
create_label "bug" "D73A4A" "Something is not working"
create_label "needs-triage" "FBCA04" "New issue waiting for triage"

# ---------------------------------------------------------------------------------------------
log "4/5 Ruleset for ${DEFAULT_BRANCH}"
approvals=1
code_owner_review=true
last_push_approval=true
if [ "${SOLO}" = "true" ]; then
  # Nobody else can approve in a one-person repository; the Copilot cloud agent's PRs cannot be
  # approved by the person who assigned the issue either. PRs, linear history and no force pushes stay.
  approvals=0
  code_owner_review=false
  last_push_approval=false
fi
ruleset="$(jq --argjson n "${approvals}" --argjson co "${code_owner_review}" --argjson lp "${last_push_approval}" '
  (.rules[] | select(.type == "pull_request") | .parameters) |=
    (.required_approving_review_count = $n | .require_code_owner_review = $co | .require_last_push_approval = $lp)' \
  "${RULESET_FILE}")"

# Required status checks (opt-in): ci.yml and iac-validate.yml use path filters. A workflow that is
# skipped by a path filter reports NO check at all, so a required check from it stays "Expected"
# forever and blocks every PR that does not touch those paths (for example an infra-only PR waiting
# for "app-unit (api)"). Only require checks that run on every PR, or remove the path filters and
# filter inside the jobs instead.
if [ -n "${REQUIRED_CHECKS:-}" ]; then
  checks="$(jq -cn --arg s "${REQUIRED_CHECKS}" \
    '$s | split(",") | map(gsub("^\\s+|\\s+$"; "")) | map(select(length > 0)) | map({context: .})')"
  ruleset="$(jq --argjson checks "${checks}" '.rules += [{type: "required_status_checks",
    parameters: {strict_required_status_checks_policy: true, required_status_checks: $checks}}]' <<< "${ruleset}")"
  info "required status checks: ${REQUIRED_CHECKS}"
fi

ruleset_name="$(jq -r '.name' <<< "${ruleset}")"
existing_id="$(gh api "repos/${REPO}/rulesets" --jq ".[] | select(.name == \"${ruleset_name}\") | .id" | head -n 1 || true)"
if [ -n "${existing_id}" ]; then
  if gh api -X PUT "repos/${REPO}/rulesets/${existing_id}" --input - --silent <<< "${ruleset}"; then
    info "ruleset ${ruleset_name} updated (id ${existing_id})"
  else
    warn "could not update ruleset ${ruleset_name}"
  fi
else
  # Rulesets on PRIVATE repositories need GitHub Pro, Team or Enterprise.
  if gh api -X POST "repos/${REPO}/rulesets" --input - --silent <<< "${ruleset}"; then
    info "ruleset ${ruleset_name} created"
  else
    warn "could not create ruleset ${ruleset_name} (private repository on GitHub Free?)"
  fi
fi

# ---------------------------------------------------------------------------------------------
log "5/5 Security features"
if gh api -X PUT "repos/${REPO}/vulnerability-alerts" --silent; then
  info "Dependabot alerts: enabled"
else
  warn "could not enable Dependabot alerts"
fi
if gh api -X PUT "repos/${REPO}/automated-security-fixes" --silent; then
  info "Dependabot security updates: enabled"
else
  warn "could not enable Dependabot security updates"
fi

PUSH_PROTECTION_DONE=false
if [ "${SECURITY_LICENSED}" = "true" ]; then
  if gh api -X PATCH "repos/${REPO}" --input - --silent <<< \
    '{"security_and_analysis":{"secret_scanning":{"status":"enabled"},"secret_scanning_push_protection":{"status":"enabled"}}}'; then
    PUSH_PROTECTION_DONE=true
    info "secret scanning + push protection: enabled"
  else
    warn "could not enable secret scanning / push protection via the API"
  fi
  # CodeQL default setup analyses JavaScript and the workflows themselves on every PR and push.
  if gh api -X PATCH "repos/${REPO}/code-scanning/default-setup" -f state=configured --silent; then
    info "code scanning default setup: configured"
  else
    warn "could not configure code scanning default setup"
  fi
else
  info "secret scanning, push protection and code scanning skipped: private repository without GHAS_ENABLED=true"
fi

# ---------------------------------------------------------------------------------------------
log "Do these in the GitHub UI"
push_protection_note="(NOT enabled by this script)"
if [ "${PUSH_PROTECTION_DONE}" = "true" ]; then push_protection_note="(already enabled via the API)"; fi
cat <<EOF
    1. Settings > Rules > Rulesets > ${ruleset_name}: enable "Automatically request Copilot code review"
       (and "Review new pushes"). Copilot then reviews every PR to ${DEFAULT_BRANCH}.
    2. Settings > Advanced Security: confirm "Push protection" is ON ${push_protection_note},
       and enable Copilot Autofix for code scanning alerts.
    3. Settings > Copilot > Cloud agent: enable it for this repository. In the firewall allowlist add
       management.azure.com and login.microsoftonline.com if the read-only Azure login
       (copilot environment) should be usable by the agent.
    4. Settings > Environments > prod: check the reviewers. Required reviewers on PRIVATE repositories
       need GitHub Enterprise; in public repositories they work on every plan.
    5. Settings > Actions > General (optional, stricter): allow only selected actions and require
       actions to be pinned to a full-length commit SHA.
    6. Agentic workflows: gh aw compile, commit the .lock.yml files; personal repositories also need
       the secret COPILOT_GITHUB_TOKEN (fine-grained PAT with "Copilot Requests").
    7. Replace the @your-org/* placeholders in .github/CODEOWNERS with real teams.
EOF
