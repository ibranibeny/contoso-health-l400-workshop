#!/usr/bin/env bash
# aks-postprovision.sh: steps that follow the aks stack, run once per cluster by a cluster admin.
#   1. Managed Prometheus -> Azure Monitor workspace amw-ch-<env>-idc     (az aks update)
#   2. Container insights -> Log Analytics log-ch-idc                     (az aks enable-addons)
#   3. Optional: application routing Gateway API (Istio) when ENABLE_GATEWAY_API=true
#   4. kubeconfig with Microsoft Entra ID (kubelogin, azurecli mode)
#   5. Namespace contoso-health (the GitHub deploy identity is namespace-scoped and cannot create it)
#   6. Nodes per availability zone
# The IaC only creates the Azure Monitor workspace; enabling the add-ons uses the documented CLI
# commands, which also create the data collection rules/endpoints for you. [OPS]
# Idempotent: already-enabled features are skipped, the namespace is applied declaratively.
#
# prod (deployment stack with denyWriteAndDelete): run this as a principal excluded from the deny
# settings, or the az aks update calls are denied. prod is a private cluster: run kubectl steps from
# a VNet-connected machine or through `az aks command invoke` (printed below when kubectl fails).
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: scripts/aks-postprovision.sh <lab|prod>

Environment:
  ENABLE_GATEWAY_API=true   also enable the Gateway API + application routing Istio implementation
                            (needs Azure CLI 2.86.0 or later). Default: false.
Requires: az, kubectl, kubelogin; the signed-in user needs "Azure Kubernetes Service RBAC Cluster
Admin" on the cluster (aks stack parameter clusterAdminPrincipalIds) for steps 5 and 6.
EOF
}

log()  { printf '\n==> %s\n' "$*"; }
step() { printf '    $ %s\n' "$*"; }
ok()   { printf '    [ OK ] %s\n' "$*"; }
warn() { printf '    WARNING: %s\n' "$*" >&2; }
die()  { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

if [ "${1:-}" = "-h" ] || [ "${1:-}" = "--help" ]; then usage; exit 0; fi
if [ "$#" -ne 1 ]; then usage; exit 1; fi
ENV_NAME="$1"
case "${ENV_NAME}" in lab | prod) ;; *) die "Environment must be lab or prod" ;; esac
for cmd in az kubectl kubelogin; do
  command -v "${cmd}" > /dev/null 2>&1 || die "${cmd} is required (az aks install-cli installs kubectl and kubelogin)"
done
az account show > /dev/null 2>&1 || die "Run az login first"

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RG="rg-ch-aks-${ENV_NAME}-idc"
AKS="aks-ch-${ENV_NAME}-idc"
AMW="amw-ch-${ENV_NAME}-idc"
LAW_RG="rg-ch-mgmt-idc"
LAW="log-ch-idc"
NAMESPACE="contoso-health"

log "0/6 Looking up ${AKS} and its monitoring workspaces"
az aks show --resource-group "${RG}" --name "${AKS}" --output none 2> /dev/null || die "${AKS} not found in ${RG}. Deploy the aks stack first."
AMW_ID="$(az resource show --resource-group "${RG}" --name "${AMW}" --resource-type Microsoft.Monitor/accounts --query id -o tsv)"
LAW_ID="$(az monitor log-analytics workspace show --resource-group "${LAW_RG}" --workspace-name "${LAW}" --query id -o tsv)"
ok "Azure Monitor workspace ${AMW_ID}"
ok "Log Analytics workspace ${LAW_ID}"

# ---------------------------------------------------------------------------------------------
log "1/6 Managed Prometheus (Azure Monitor metrics)"
if [ "$(az aks show --resource-group "${RG}" --name "${AKS}" --query "azureMonitorProfile.metrics.enabled" -o tsv)" = "true" ]; then
  ok "already enabled"
else
  step "az aks update --enable-azure-monitor-metrics --azure-monitor-workspace-resource-id ${AMW_ID}"
  az aks update --resource-group "${RG}" --name "${AKS}" \
    --enable-azure-monitor-metrics --azure-monitor-workspace-resource-id "${AMW_ID}" --output none
  ok "enabled"
fi

# ---------------------------------------------------------------------------------------------
log "2/6 Container insights (monitoring add-on)"
if [ "$(az aks show --resource-group "${RG}" --name "${AKS}" --query "addonProfiles.omsagent.enabled" -o tsv)" = "true" ]; then
  ok "already enabled"
else
  step "az aks enable-addons --addon monitoring --workspace-resource-id ${LAW_ID}"
  az aks enable-addons --resource-group "${RG}" --name "${AKS}" \
    --addon monitoring --workspace-resource-id "${LAW_ID}" --output none
  ok "enabled"
fi

# ---------------------------------------------------------------------------------------------
log "3/6 Gateway API + application routing (Istio) [ENABLE_GATEWAY_API=${ENABLE_GATEWAY_API:-false}]"
if [ "${ENABLE_GATEWAY_API:-false}" = "true" ]; then
  cli_version="$(az version --query '"azure-cli"' -o tsv)"
  if [ "$(printf '%s\n%s\n' "2.86.0" "${cli_version}" | sort -V | head -n 1)" != "2.86.0" ]; then
    die "Azure CLI ${cli_version} is too old for --enable-gateway-api; run az upgrade (2.86.0+)"
  fi
  # Managed Gateway API CRDs + the approuting-istio GatewayClass. The Envoy proxies run on the
  # system pool (up to 2 CPU / 1 GiB per replica): check its headroom first. [PERF]
  step "az aks update --enable-gateway-api --enable-app-routing-istio"
  az aks update --resource-group "${RG}" --name "${AKS}" --enable-gateway-api --enable-app-routing-istio --output none
  ok "enabled (see k8s/optional/gateway-api/README.md)"
else
  ok "skipped (default path: Application Gateway WAF_v2 -> internal load balancer)"
fi

# ---------------------------------------------------------------------------------------------
log "4/6 kubeconfig with Microsoft Entra ID"
# Local accounts are disabled, so there is no admin kubeconfig: every call carries an Entra token. [SEC]
step "az aks get-credentials --resource-group ${RG} --name ${AKS} --overwrite-existing"
az aks get-credentials --resource-group "${RG}" --name "${AKS}" --overwrite-existing --output none
step "kubelogin convert-kubeconfig -l azurecli"
kubelogin convert-kubeconfig -l azurecli
ok "current context: $(kubectl config current-context)"

# ---------------------------------------------------------------------------------------------
log "5/6 Namespace ${NAMESPACE} (cluster-scoped, so created by an admin)"
# Rendered from the overlay so it is exactly what the "Deploy to AKS" workflow applies later: the
# workflow then finds it "unchanged" and needs no cluster-scoped permission. [SEC]
namespace_manifest="$(kubectl kustomize "${REPO_ROOT}/k8s/overlays/${ENV_NAME}" | awk '
  /^---$/ { if (isns) printf "%s", doc; doc = ""; isns = 0; next }
  { doc = doc $0 "\n"; if ($0 == "kind: Namespace") isns = 1 }
  END { if (isns) printf "%s", doc }')"
[ -n "${namespace_manifest}" ] || die "no Namespace found in k8s/overlays/${ENV_NAME}"

NODES_CMD=(kubectl get nodes -o wide -L topology.kubernetes.io/zone,kubernetes.azure.com/agentpool)
if kubectl version --request-timeout=15s > /dev/null 2>&1; then
  step "kubectl apply -f - (Namespace ${NAMESPACE}, Pod Security Admission: restricted)"
  kubectl apply -f - <<< "${namespace_manifest}"
  log "6/6 Nodes per availability zone"
  step "${NODES_CMD[*]}"
  "${NODES_CMD[@]}"
else
  # Private cluster (prod) and no VNet connectivity from here: run kubectl inside the cluster
  # through the AKS control plane instead (needs runCommand permission, which Contributor has).
  warn "API server not reachable from this machine (private cluster?): using az aks command invoke"
  work_dir="${REPO_ROOT}/.aks-postprovision"
  mkdir -p "${work_dir}"
  trap 'rm -rf "${work_dir}"' EXIT
  printf '%s' "${namespace_manifest}" > "${work_dir}/namespace.yaml"
  step "az aks command invoke --command \"kubectl apply -f namespace.yaml\" --file namespace.yaml"
  (cd "${work_dir}" && az aks command invoke --resource-group "${RG}" --name "${AKS}" \
    --command "kubectl apply -f namespace.yaml" --file namespace.yaml)
  log "6/6 Nodes per availability zone"
  step "az aks command invoke --command \"${NODES_CMD[*]}\""
  az aks command invoke --resource-group "${RG}" --name "${AKS}" --command "${NODES_CMD[*]}"
fi
echo
echo "Next: run the 'Deploy to AKS' workflow (or push to main to trigger 'Container build')."
