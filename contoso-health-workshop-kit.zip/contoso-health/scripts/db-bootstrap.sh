#!/usr/bin/env bash
# db-bootstrap.sh: one-time PostgreSQL setup after the workload stack is deployed:
#   - the API's Microsoft Entra principal (role "id-ch-api-<env>")
#   - the application database contoso_health (owned by the Entra admin, NOT created by IaC)
#   - least-privilege grants for the API on that database
#
# Why it runs on vm-ch-ops-<env> through `az vm run-command`:
#   PostgreSQL has public network access disabled and is reachable only through its private
#   endpoint. The ops VM sits in snet-ops, has no public IP and no inbound ports; run-command goes
#   through the Azure control plane, so no SSH, no Bastion and no firewall opening is needed. [SEC]
# Why no password exists anywhere:
#   the VM's user-assigned identity id-ch-dbadmin-<env> IS the server's Entra administrator. The
#   script asks the VM's instance metadata service (IMDS) for a token and uses it as the password. [SEC]
# Why the API gets only CONNECT, CREATE, TEMPORARY on ONE database:
#   the API creates and owns its own schema "app" through its migrations (MIGRATE_ON_START=true),
#   so it needs to create a schema in contoso_health, nothing else: no server-level rights, no
#   azure_pg_admin membership, no CREATEROLE/CREATEDB and no access to other databases. [SEC]
#
# Idempotent: existing roles, databases and grants are left as they are.
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: scripts/db-bootstrap.sh <lab|prod>

Prerequisites: workload stack deployed (PostgreSQL, identities, ops VM running), az login with
permission to run commands on the VM (Virtual Machine Contributor or Contributor).
EOF
}

log()  { printf '\n==> %s\n' "$*"; }
step() { printf '    $ %s\n' "$*"; }
ok()   { printf '    [ OK ] %s\n' "$*"; }
die()  { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

if [ "${1:-}" = "-h" ] || [ "${1:-}" = "--help" ]; then usage; exit 0; fi
if [ "$#" -ne 1 ]; then usage; exit 1; fi
ENV_NAME="$1"
case "${ENV_NAME}" in lab | prod) ;; *) die "Environment must be lab or prod" ;; esac
command -v az > /dev/null 2>&1 || die "Azure CLI (az) is required"
az account show > /dev/null 2>&1 || die "Run az login first"

RG="rg-ch-${ENV_NAME}-idc"
VM="vm-ch-ops-${ENV_NAME}"
DB_NAME="contoso_health"
API_IDENTITY="id-ch-api-${ENV_NAME}"
ADMIN_IDENTITY="id-ch-dbadmin-${ENV_NAME}"

# ---------------------------------------------------------------------------------------------
log "1/3 Reading names from the workload (${RG})"
# The server name has a unique suffix, so it is discovered rather than rebuilt.
step "az postgres flexible-server list --resource-group ${RG}"
PG_NAME="$(az postgres flexible-server list --resource-group "${RG}" --query "[0].name" -o tsv)"
PG_FQDN="$(az postgres flexible-server list --resource-group "${RG}" --query "[0].fullyQualifiedDomainName" -o tsv)"
[ -n "${PG_FQDN}" ] || die "No PostgreSQL flexible server in ${RG}. Deploy the workload stack first."
ok "server ${PG_NAME} (${PG_FQDN})"

step "az identity show --name ${ADMIN_IDENTITY} / ${API_IDENTITY}"
ADMIN_CLIENT_ID="$(az identity show --resource-group "${RG}" --name "${ADMIN_IDENTITY}" --query clientId -o tsv)"
API_PRINCIPAL_ID="$(az identity show --resource-group "${RG}" --name "${API_IDENTITY}" --query principalId -o tsv)"
ok "${ADMIN_IDENTITY} clientId ${ADMIN_CLIENT_ID}"
ok "${API_IDENTITY} principalId ${API_PRINCIPAL_ID}"

# Everything below is interpolated into SQL on the VM: accept only the shapes we expect. [SEC]
guid='^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
[[ "${ADMIN_CLIENT_ID}" =~ ${guid} ]] || die "unexpected client ID '${ADMIN_CLIENT_ID}'"
[[ "${API_PRINCIPAL_ID}" =~ ${guid} ]] || die "unexpected principal ID '${API_PRINCIPAL_ID}'"
[[ "${PG_FQDN}" =~ ^[a-z0-9.-]+$ ]] || die "unexpected server FQDN '${PG_FQDN}'"

step "az vm get-instance-view --name ${VM}"
power="$(az vm get-instance-view --resource-group "${RG}" --name "${VM}" \
  --query "instanceView.statuses[?starts_with(code, 'PowerState/')].displayStatus | [0]" -o tsv 2> /dev/null || true)"
[ "${power}" = "VM running" ] || die "${VM} is '${power:-not found}'. Start it: az vm start -g ${RG} -n ${VM}"
ok "${VM} is running"

# ---------------------------------------------------------------------------------------------
log "2/3 Running the bootstrap on ${VM} (az vm run-command invoke, RunShellScript)"
# Runs as root on the VM. Positional parameters: $1 server FQDN, $2 admin role name (= identity
# name, as registered in flexibleServers/administrators), $3 admin client ID, $4 API role name,
# $5 API principal (object) ID, $6 database name. The token is never printed.
read -r -d '' REMOTE_SCRIPT <<'REMOTE' || true
# POSIX sh on purpose: the run-command agent may execute the script with /bin/sh (dash).
set -eu
PG_HOST="$1"; ADMIN_NAME="$2"; ADMIN_CLIENT_ID="$3"; API_NAME="$4"; API_OID="$5"; DB="$6"
command -v psql > /dev/null || { echo "psql not found (cloud-init installs postgresql-client)"; exit 1; }

# Entra token for the dbadmin identity from IMDS; audience = Azure Database for PostgreSQL.
imds="http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fossrdbms-aad.database.windows.net&client_id=${ADMIN_CLIENT_ID}"
response="$(curl -sS --noproxy '*' -H 'Metadata: true' "${imds}")"
if command -v jq > /dev/null; then
  token="$(printf '%s' "${response}" | jq -r '.access_token // empty')"
else
  token="$(printf '%s' "${response}" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("access_token",""))')"
fi
[ -n "${token}" ] || { echo "IMDS returned no token for client_id ${ADMIN_CLIENT_ID}"; exit 1; }
# For Entra authentication the access token is the password (valid about one hour).
export PGPASSWORD="${token}"
unset response token

sql() { # run one statement as the Entra admin, connected to the "postgres" database
  psql "host=${PG_HOST} port=5432 dbname=postgres user=${ADMIN_NAME} sslmode=require" \
    -v ON_ERROR_STOP=1 -tAc "$1"
}

# 1) API principal. pgaadauth_create_principal_with_oid maps the managed identity's object ID to a
#    PostgreSQL role named like the identity ('service' = service principal / managed identity;
#    not admin, no MFA). Using the OID avoids a directory lookup and survives display-name changes.
if [ "$(sql "SELECT 1 FROM pg_roles WHERE rolname = '${API_NAME}'")" = "1" ]; then
  echo "role ${API_NAME}: already exists"
else
  sql "SELECT * FROM pgaadauth_create_principal_with_oid('${API_NAME}', '${API_OID}', 'service', false, false);"
  echo "role ${API_NAME}: created"
fi

# 2) Application database, owned by the Entra admin so the admin can GRANT on it.
if [ "$(sql "SELECT 1 FROM pg_database WHERE datname = '${DB}'")" = "1" ]; then
  echo "database ${DB}: already exists"
else
  sql "CREATE DATABASE ${DB}"
  echo "database ${DB}: created"
fi

# 3) Least privilege: connect, create its own schema (migrations create schema "app" and own it),
#    temporary tables. GRANT is idempotent.
sql "GRANT CONNECT, CREATE, TEMPORARY ON DATABASE ${DB} TO \"${API_NAME}\""
echo "grants: CONNECT, CREATE, TEMPORARY on ${DB} to ${API_NAME}"
echo "DB_BOOTSTRAP_OK"
REMOTE

step "az vm run-command invoke --resource-group ${RG} --name ${VM} --command-id RunShellScript"
output="$(az vm run-command invoke --resource-group "${RG}" --name "${VM}" --command-id RunShellScript \
  --scripts "${REMOTE_SCRIPT}" \
  --parameters "${PG_FQDN}" "${ADMIN_IDENTITY}" "${ADMIN_CLIENT_ID}" "${API_IDENTITY}" "${API_PRINCIPAL_ID}" "${DB_NAME}" \
  --query "value[0].message" -o tsv)"
printf '%s\n' "${output}" | sed 's/^/    | /'

# ---------------------------------------------------------------------------------------------
log "3/3 Result"
# run-command reports success even when the script fails, so look for the explicit marker.
if grep -q 'DB_BOOTSTRAP_OK' <<< "${output}"; then
  ok "PostgreSQL bootstrap complete. The API creates schema \"app\" on its next start (MIGRATE_ON_START=true)."
  echo "    Restart the API if it started before this script ran (App Service: az webapp restart; AKS: kubectl rollout restart deployment/api -n contoso-health)."
else
  die "bootstrap did not complete; see the [stderr] section above"
fi
