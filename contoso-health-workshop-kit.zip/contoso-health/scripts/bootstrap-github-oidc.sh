#!/usr/bin/env bash
# bootstrap-github-oidc.sh: lets ONE GitHub repository deploy to Azure for ONE environment with
# OpenID Connect. No client secret, no certificate: Entra ID trusts short-lived GitHub tokens whose
# subject matches a federated credential on a user-assigned managed identity. [SEC]
#
# What it does (idempotent, safe to re-run after each stack deployment to refresh variables):
#   1. rg-ch-identity-idc + user-assigned identity id-ch-github-<env>
#   2. reads owner/repo IDs and creation date from GitHub and picks the OIDC subject format
#   3. federated credentials: environment:<env> (+ pull_request for lab)
#   4. role assignments at subscription scope:
#        lab/prod: Contributor + Role Based Access Control Administrator CONSTRAINED by an ABAC
#                  condition to the roles the IaC assigns (documented "constrain roles" pattern)
#        prod:     + Azure Deployment Stack Owner (deny settings on deployment stacks)
#        copilot:  Reader + Monitoring Reader only (the Copilot cloud agent can look, not change)
#   5. GitHub environment + repository/environment variables (gh variable set)
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: scripts/bootstrap-github-oidc.sh <owner/repo> <lab|prod|copilot>

Run as a subscription Owner (or User Access Administrator + Contributor), signed in with
`az login` and `gh auth login` (repository admin).

Optional environment variables:
  IAC_TOOL=bicep|terraform       repository default for the deploy workflows (set when missing)
  PLATFORM_DEPLOY=true           also grant Resource Policy Contributor so the platform stack
                                 (Azure Policy assignments) can be deployed from GitHub
  OIDC_SUBJECT_FORMAT=immutable|legacy   override the automatic subject format detection
  OPS_SSH_PUBLIC_KEY=...         stored as a repository variable for the deploy workflows
  AZURE_LOCATION                 default indonesiacentral
EOF
}

log()  { printf '\n==> %s\n' "$*"; }
step() { printf '    $ %s\n' "$*"; }
ok()   { printf '    [ OK ] %s\n' "$*"; }
warn() { printf '    WARNING: %s\n' "$*" >&2; }
die()  { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

if [ "${1:-}" = "-h" ] || [ "${1:-}" = "--help" ]; then usage; exit 0; fi
if [ "$#" -ne 2 ]; then usage; exit 1; fi
REPO_ARG="$1"
ENV_NAME="$2"
[[ "${REPO_ARG}" =~ ^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$ ]] || die "Expected <owner/repo>, got '${REPO_ARG}'"
case "${ENV_NAME}" in lab | prod | copilot) ;; *) die "Environment must be lab, prod or copilot" ;; esac

for cmd in az gh; do
  command -v "${cmd}" > /dev/null 2>&1 || die "${cmd} is required"
done

LOCATION="${AZURE_LOCATION:-indonesiacentral}"
IDENTITY_RG="rg-ch-identity-idc"
IDENTITY_NAME="id-ch-github-${ENV_NAME}"
ISSUER="https://token.actions.githubusercontent.com"
AUDIENCE="api://AzureADTokenExchange"
# Repositories created from this date on use the immutable subject (owner/repo names + numeric IDs).
IMMUTABLE_SINCE=20260715

# Roles the IaC itself assigns (workload + aks stacks). The pipeline may grant ONLY these. [SEC]
ALLOWED_ROLES=(
  "7f951dda-4ed3-4680-a7ca-43fe172d538d" # AcrPull
  "8311e382-0749-4cb8-b61a-304f252e45ec" # AcrPush
  "4633458b-17de-408a-b874-0445c86b69e6" # Key Vault Secrets User
  "3913510d-42f4-4e42-8a64-420c390055eb" # Monitoring Metrics Publisher
  "4d97b98b-1d4f-4787-a291-c67834d212e7" # Network Contributor
  "de139f84-1756-47ae-9be6-808fbbe84772" # Website Contributor
  "a7ffa36f-339b-4b5c-8bdf-e2c188b2c0eb" # Azure Kubernetes Service RBAC Writer
  "4abbcc35-e782-43d8-92c5-2d3c1bd2b3ac" # Azure Kubernetes Service Cluster User Role
)
ROLE_CONTRIBUTOR="b24988ac-6180-42a0-ab88-20f7382dd24c"
ROLE_RBAC_ADMIN="f58310d9-a9f6-439a-9e8d-f62e7b41a168"
ROLE_READER="acdd72a7-3385-48ef-bd42-f606fba81ae7"
ROLE_MONITORING_READER="43d0d8ad-25c7-4714-9337-8ba259a9fe05"

# ---------------------------------------------------------------------------------------------
log "1/6 Azure context"
az account show > /dev/null 2>&1 || die "Run az login first"
SUB_ID="$(az account show --query id -o tsv)"
TENANT_ID="$(az account show --query tenantId -o tsv)"
SCOPE="/subscriptions/${SUB_ID}"
ok "subscription $(az account show --query name -o tsv) (${SUB_ID}), tenant ${TENANT_ID}"

# ---------------------------------------------------------------------------------------------
log "2/6 GitHub repository and OIDC subject format"
step "gh api repos/${REPO_ARG}"
repo_info="$(gh api "repos/${REPO_ARG}" --jq '[.owner.login, .owner.id, .name, .id, .created_at] | @tsv')" \
  || die "Cannot read ${REPO_ARG} with gh (run gh auth login)"
OWNER="$(cut -f1 <<< "${repo_info}")"
OWNER_ID="$(cut -f2 <<< "${repo_info}")"
REPO="$(cut -f3 <<< "${repo_info}")"
REPO_ID="$(cut -f4 <<< "${repo_info}")"
CREATED_AT="$(cut -f5 <<< "${repo_info}")"
FULL="${OWNER}/${REPO}"
ok "${FULL}: owner id ${OWNER_ID}, repo id ${REPO_ID}, created ${CREATED_AT}"

# Shows whether the repository opted in to the immutable subject or uses a custom claim template.
step "gh api repos/${FULL}/actions/oidc/customization/sub"
sub_settings="$(gh api "repos/${FULL}/actions/oidc/customization/sub" 2> /dev/null || echo '{}')"
echo "    ${sub_settings}"
opted_in="$(gh api "repos/${FULL}/actions/oidc/customization/sub" --jq '.use_immutable_subject // false' 2> /dev/null || echo false)"
use_default="$(gh api "repos/${FULL}/actions/oidc/customization/sub" --jq '.use_default // true' 2> /dev/null || echo true)"
if [ "${use_default}" = "false" ]; then
  warn "custom OIDC subject template (include_claim_keys) in use: the subjects below assume the default"
  warn "template. Compare with the 'OIDC debug' workflow output and adjust the federated credentials."
fi

created_ymd="${CREATED_AT:0:10}"
created_ymd="${created_ymd//-/}"
format="${OIDC_SUBJECT_FORMAT:-}"
if [ -z "${format}" ]; then
  if [ "${created_ymd}" -ge "${IMMUTABLE_SINCE}" ] || [ "${opted_in}" = "true" ]; then
    format="immutable"
  else
    format="legacy"
  fi
fi
case "${format}" in
  immutable) SUBJECT_PREFIX="repo:${OWNER}@${OWNER_ID}/${REPO}@${REPO_ID}" ;;
  legacy) SUBJECT_PREFIX="repo:${OWNER}/${REPO}" ;;
  *) die "OIDC_SUBJECT_FORMAT must be immutable or legacy" ;;
esac
ok "subject format: ${format} (${SUBJECT_PREFIX}:...)"

# ---------------------------------------------------------------------------------------------
log "3/6 Managed identity ${IDENTITY_NAME}"
step "az group create --name ${IDENTITY_RG} --location ${LOCATION}"
az group create --name "${IDENTITY_RG}" --location "${LOCATION}" --output none \
  --tags workload=contoso-health environment=shared owner=platform-team costCenter=CH-1001 \
  dataClassification=internal managedBy=script
step "az identity create --name ${IDENTITY_NAME} --resource-group ${IDENTITY_RG}"
az identity create --name "${IDENTITY_NAME}" --resource-group "${IDENTITY_RG}" --location "${LOCATION}" --output none \
  --tags workload=contoso-health environment="${ENV_NAME}" owner=platform-team costCenter=CH-1001 \
  dataClassification=internal managedBy=script
CLIENT_ID="$(az identity show --name "${IDENTITY_NAME}" --resource-group "${IDENTITY_RG}" --query clientId -o tsv)"
PRINCIPAL_ID="$(az identity show --name "${IDENTITY_NAME}" --resource-group "${IDENTITY_RG}" --query principalId -o tsv)"
ok "clientId ${CLIENT_ID}, principalId ${PRINCIPAL_ID}"

# ---------------------------------------------------------------------------------------------
log "4/6 Federated credentials (max 20 per identity, exact match, no wildcards)"
# Credential names are per repository, so one identity can trust a fork or a second repository too.
fic_base="$(printf '%s' "${OWNER}-${REPO}" | tr -c 'A-Za-z0-9-' '-' | cut -c1-80)"
add_fic() { # <name> <subject>
  step "az identity federated-credential create --name $1 --subject $2"
  # create is a PUT: re-running updates the subject in place (e.g. after switching format).
  az identity federated-credential create --name "$1" --identity-name "${IDENTITY_NAME}" \
    --resource-group "${IDENTITY_RG}" --issuer "${ISSUER}" --subject "$2" --audiences "${AUDIENCE}" --output none
  ok "$1"
}
add_fic "${fic_base}-env-${ENV_NAME}" "${SUBJECT_PREFIX}:environment:${ENV_NAME}"
if [ "${ENV_NAME}" = "lab" ]; then
  # PR what-if/plan (IaC validate "plan" job, no environment => subject ...:pull_request).
  # Trade-off: a PR runs the workflow version from its branch, so anyone with write access can use
  # this LAB identity from a PR. Acceptable for a lab subscription only; never add it for prod. [SEC]
  add_fic "${fic_base}-pull-request" "${SUBJECT_PREFIX}:pull_request"
fi

# ---------------------------------------------------------------------------------------------
log "5/6 Role assignments at ${SCOPE}"
assign_role() { # <role id or name> <label> [ABAC condition]
  local role="$1" label="$2" condition="${3:-}" existing current attempt
  existing="$(az role assignment list --scope "${SCOPE}" --role "${role}" \
    --query "[?principalId=='${PRINCIPAL_ID}'] | [0].id" -o tsv 2> /dev/null || true)"
  if [ -n "${existing}" ]; then
    if [ -z "${condition}" ]; then
      ok "${label} (already assigned)"
      return 0
    fi
    current="$(az role assignment list --scope "${SCOPE}" --role "${role}" \
      --query "[?principalId=='${PRINCIPAL_ID}'] | [0].condition" -o tsv)"
    if [ "$(tr -d '[:space:]' <<< "${current}")" = "$(tr -d '[:space:]' <<< "${condition}")" ]; then
      ok "${label} (already assigned with the same condition)"
      return 0
    fi
    # Never leave an UNCONSTRAINED RBAC administrator behind. [SEC]
    step "az role assignment delete (condition differs)"
    az role assignment delete --ids "${existing}"
  fi
  local args=(--assignee-object-id "${PRINCIPAL_ID}" --assignee-principal-type ServicePrincipal
    --role "${role}" --scope "${SCOPE}" --description "GitHub OIDC ${FULL} (${ENV_NAME})" --output none)
  if [ -n "${condition}" ]; then
    args+=(--condition "${condition}" --condition-version "2.0")
  fi
  step "az role assignment create --role ${label}${condition:+ --condition <ABAC>}"
  for attempt in 1 2 3 4 5; do
    if az role assignment create "${args[@]}"; then
      ok "${label}"
      return 0
    fi
    # A brand-new identity can take a short while to replicate across Entra ID.
    echo "    retry ${attempt}/5 in 15 s"
    sleep 15
  done
  die "could not assign ${label}"
}

if [ "${ENV_NAME}" = "copilot" ]; then
  assign_role "${ROLE_READER}" "Reader"
  assign_role "${ROLE_MONITORING_READER}" "Monitoring Reader"
else
  assign_role "${ROLE_CONTRIBUTOR}" "Contributor"
  # Constrain delegation (Learn: "Delegate Azure role assignment management using conditions"):
  # the identity may create or delete role assignments ONLY for the roles in ALLOWED_ROLES, so a
  # compromised pipeline cannot grant itself or anyone else Owner, Contributor or User Access
  # Administrator. Cluster-admin assignments therefore stay a human task. [SEC]
  printf -v allowed '%s, ' "${ALLOWED_ROLES[@]}"
  allowed="${allowed%, }"
  CONDITION="((!(ActionMatches{'Microsoft.Authorization/roleAssignments/write'})) OR (@Request[Microsoft.Authorization/roleAssignments:RoleDefinitionId] ForAnyOfAnyValues:GuidEquals {${allowed}})) AND ((!(ActionMatches{'Microsoft.Authorization/roleAssignments/delete'})) OR (@Resource[Microsoft.Authorization/roleAssignments:RoleDefinitionId] ForAnyOfAnyValues:GuidEquals {${allowed}}))"
  assign_role "${ROLE_RBAC_ADMIN}" "Role Based Access Control Administrator (ABAC-constrained)" "${CONDITION}"
  if [ "${ENV_NAME}" = "prod" ]; then
    # prod deployment stacks use denyWriteAndDelete, which needs this role. [OPS]
    assign_role "Azure Deployment Stack Owner" "Azure Deployment Stack Owner"
  fi
  if [ "${PLATFORM_DEPLOY:-false}" = "true" ]; then
    # Only when the platform stack (policy assignments) is deployed from this repository.
    assign_role "Resource Policy Contributor" "Resource Policy Contributor"
  fi
fi

# ---------------------------------------------------------------------------------------------
log "6/6 GitHub environment and variables (variables, not secrets: nothing here is sensitive)"
if gh api "repos/${FULL}/environments/${ENV_NAME}" --silent > /dev/null 2>&1; then
  ok "environment ${ENV_NAME} exists (protection rules untouched)"
else
  step "gh api -X PUT repos/${FULL}/environments/${ENV_NAME}"
  gh api -X PUT "repos/${FULL}/environments/${ENV_NAME}" --silent
  ok "environment ${ENV_NAME} created (run scripts/github/apply-governance.sh for protection rules)"
fi

set_var() { # <name> <value> [environment]
  if [ -n "${3:-}" ]; then
    gh variable set "$1" --repo "${FULL}" --env "$3" --body "$2"
    ok "env ${3}: $1 = $2"
  else
    gh variable set "$1" --repo "${FULL}" --body "$2"
    ok "repo: $1 = $2"
  fi
}

set_var AZURE_TENANT_ID "${TENANT_ID}"
set_var AZURE_SUBSCRIPTION_ID "${SUB_ID}"
set_var AZURE_LOCATION "${LOCATION}"
if [ -n "${IAC_TOOL:-}" ]; then
  set_var IAC_TOOL "${IAC_TOOL}"
elif ! gh variable list --repo "${FULL}" --json name --jq '.[].name' | grep -x IAC_TOOL > /dev/null; then
  set_var IAC_TOOL "bicep"
fi
if [ -n "${OPS_SSH_PUBLIC_KEY:-}" ]; then
  set_var OPS_SSH_PUBLIC_KEY "${OPS_SSH_PUBLIC_KEY}"
fi
set_var AZURE_CLIENT_ID "${CLIENT_ID}" "${ENV_NAME}"

if [ "${ENV_NAME}" != "copilot" ]; then
  if [ "${ENV_NAME}" = "lab" ]; then
    # Read by the "plan" job of IaC validate (pull_request subject, see the trade-off above).
    set_var AZURE_CLIENT_ID_PLAN "${CLIENT_ID}"
  fi
  WORKLOAD_RG="rg-ch-${ENV_NAME}-idc"
  AKS_RG="rg-ch-aks-${ENV_NAME}-idc"
  set_var WORKLOAD_RG "${WORKLOAD_RG}" "${ENV_NAME}"
  set_var AKS_RG "${AKS_RG}" "${ENV_NAME}"
  set_var AKS_NAME "aks-ch-${ENV_NAME}-idc" "${ENV_NAME}"

  # Names with a unique suffix are read from what is deployed (same naming rules as the IaC).
  web_app="$(az webapp list --resource-group "${WORKLOAD_RG}" --query "[?starts_with(name, 'app-ch-web-')].name | [0]" -o tsv 2> /dev/null || true)"
  api_app="$(az webapp list --resource-group "${WORKLOAD_RG}" --query "[?starts_with(name, 'app-ch-api-')].name | [0]" -o tsv 2> /dev/null || true)"
  appgw_ip="$(az network public-ip show --resource-group "${WORKLOAD_RG}" --name "pip-agw-ch-${ENV_NAME}-idc" --query ipAddress -o tsv 2> /dev/null || true)"
  acr_name="$(az acr list --resource-group "${AKS_RG}" --query "[0].name" -o tsv 2> /dev/null || true)"
  pending=()
  if [ -n "${web_app}" ]; then set_var WEB_APP_NAME "${web_app}" "${ENV_NAME}"; else pending+=(WEB_APP_NAME); fi
  if [ -n "${api_app}" ]; then set_var API_APP_NAME "${api_app}" "${ENV_NAME}"; else pending+=(API_APP_NAME); fi
  if [ -n "${appgw_ip}" ]; then set_var APPGW_PUBLIC_IP "${appgw_ip}" "${ENV_NAME}"; else pending+=(APPGW_PUBLIC_IP); fi
  if [ -n "${acr_name}" ]; then set_var ACR_NAME "${acr_name}" "${ENV_NAME}"; else pending+=(ACR_NAME); fi
  if [ "${#pending[@]}" -gt 0 ]; then
    warn "not deployed yet: ${pending[*]}. Re-run this script after the workload/aks stacks are deployed."
  fi
fi

# ---------------------------------------------------------------------------------------------
subjects="${SUBJECT_PREFIX}:environment:${ENV_NAME}"
if [ "${ENV_NAME}" = "lab" ]; then
  subjects="${subjects}, ${SUBJECT_PREFIX}:pull_request"
fi
cat <<EOF

Summary
  Repository        ${FULL} (subject format: ${format})
  Environment       ${ENV_NAME}
  Identity          ${IDENTITY_RG}/${IDENTITY_NAME}
  Client ID         ${CLIENT_ID}
  Principal ID      ${PRINCIPAL_ID}
  Trusted subjects  ${subjects}

Tip: if azure/login fails with AADSTS700213 ("no matching federated identity record"), run
  gh workflow run oidc-debug.yml --repo ${FULL} -f environment=${ENV_NAME}
and compare the printed "sub" claim with the subjects above.
EOF
