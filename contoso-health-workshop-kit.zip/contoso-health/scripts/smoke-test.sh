#!/usr/bin/env bash
# smoke-test.sh: end-to-end checks against a running Contoso Health deployment. Works against the
# web tier (it proxies /api) or the API directly; prints a pass/fail table and exits non-zero on
# any failure, so it can gate a pipeline. [REL][OPS]
#   - /healthz, /readyz, /api/info
#   - eligibility twice: x-cache MISS then HIT (Redis cache-aside works end to end)
#   - provider directory
#   - claim submission twice with the same Idempotency-Key: 201, then 200 + idempotent-replay
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: scripts/smoke-test.sh <base-url>

Examples:
  scripts/smoke-test.sh http://localhost:8080          # docker compose (web)
  scripts/smoke-test.sh "http://${APPGW_PUBLIC_IP}"     # App Service through Application Gateway
  scripts/smoke-test.sh "http://${APPGW_PUBLIC_IP}:8080" # AKS through Application Gateway

Environment (optional):
  SMOKE_MEMBER_ID     active member for the claim checks  (default CH-100001, seeded and active)
  SMOKE_CACHE_MEMBER  member for the cache MISS/HIT check (default: a random seeded member
                      CH-100100..CH-100299, so parallel pipelines don't warm each other's cache)
  SMOKE_PROVIDER_ID   provider for the claim              (default PRV-JAK-001)
  SMOKE_WRITE         false = skip the claim submission                          (default true)
  SMOKE_DATA          false = skip every check that needs the demo data (eligibility,
                      providers, claims): production has no seed data             (default true)
  SMOKE_WAIT_SECONDS  wait up to N seconds for /healthz before testing            (default 0)
  SMOKE_TIMEOUT       per-request timeout in seconds                              (default 15)
EOF
}

if [ "${1:-}" = "-h" ] || [ "${1:-}" = "--help" ]; then usage; exit 0; fi
if [ "$#" -ne 1 ]; then usage; exit 1; fi
command -v curl > /dev/null 2>&1 || { echo "ERROR: curl is required" >&2; exit 1; }

BASE_URL="${1%/}"
MEMBER="${SMOKE_MEMBER_ID:-CH-100001}"
CACHE_MEMBER="${SMOKE_CACHE_MEMBER:-CH-$((100100 + RANDOM % 200))}"
PROVIDER="${SMOKE_PROVIDER_ID:-PRV-JAK-001}"
WRITE="${SMOKE_WRITE:-true}"
DATA="${SMOKE_DATA:-true}"
WAIT_SECONDS="${SMOKE_WAIT_SECONDS:-0}"
TIMEOUT="${SMOKE_TIMEOUT:-15}"

STATUS=""
HEADERS=""
BODY=""
ROWS=()
FAILED=0
HINTS=()

# request <method> <path> [json-body] [extra header]: sets STATUS, HEADERS and BODY.
request() {
  local method="$1" path="$2" body="${3:-}" extra="${4:-}" raw
  local args=(-sS -i -X "${method}" --max-time "${TIMEOUT}" -H "accept: application/json")
  if [ -n "${body}" ]; then args+=(-H "content-type: application/json" --data "${body}"); fi
  if [ -n "${extra}" ]; then args+=(-H "${extra}"); fi
  if ! raw="$(curl "${args[@]}" "${BASE_URL}${path}" 2>&1)"; then
    STATUS="000"
    HEADERS=""
    BODY="${raw}"
    return 0
  fi
  raw="${raw//$'\r'/}"
  STATUS="$(awk 'NR == 1 { print $2 }' <<< "${raw}")"
  HEADERS="$(awk 'NR > 1 && /^$/ { exit } NR > 1 { print }' <<< "${raw}")"
  BODY="$(awk 'found { print } /^$/ && !found { found = 1 }' <<< "${raw}")"
}

# header <name>: value of a response header from the last request (case-insensitive name).
header() {
  awk -v name="$(tr '[:upper:]' '[:lower:]' <<< "$1")" \
    'index($0, ":") { key = tolower(substr($0, 1, index($0, ":") - 1)); if (key == name) { v = substr($0, index($0, ":") + 1); sub(/^[ \t]+/, "", v); print v; exit } }' \
    <<< "${HEADERS}"
}

# record <check> <expected> <actual> <PASS|FAIL|SKIP>
record() {
  ROWS+=("$1|$2|$3|$4")
  if [ "$4" = "FAIL" ]; then FAILED=$((FAILED + 1)); fi
}

check_status() { # <label> <expected status>
  if [ "${STATUS}" = "$2" ]; then record "$1" "$2" "${STATUS}" PASS; else record "$1" "$2" "${STATUS}" FAIL; fi
}

echo "Smoke testing ${BASE_URL}"

if [ "${WAIT_SECONDS}" -gt 0 ]; then
  echo "Waiting up to ${WAIT_SECONDS} s for ${BASE_URL}/healthz ..."
  deadline=$(($(date +%s) + WAIT_SECONDS))
  until curl -fsS --max-time 5 "${BASE_URL}/healthz" > /dev/null 2>&1; do
    if [ "$(date +%s)" -ge "${deadline}" ]; then break; fi
    sleep 5
  done
fi

# 1-3: liveness, readiness, build/instance information
request GET /healthz
check_status "GET /healthz" 200
request GET /readyz
check_status "GET /readyz (dependencies reachable)" 200
request GET /api/info
if [ "${STATUS}" = "200" ] && grep -q '"service"' <<< "${BODY}"; then
  record "GET /api/info" "200 + service info" "${STATUS}" PASS
  echo "  /api/info: ${BODY}"
else
  record "GET /api/info" "200 + service info" "${STATUS}" FAIL
fi

if [ "${DATA}" != "true" ]; then
  WRITE=false
  record "demo-data checks (eligibility, providers)" "-" "SMOKE_DATA=false" SKIP
else
# 4-5: cache-aside through Redis: first read MISS (from PostgreSQL), second read HIT
request GET "/api/members/${CACHE_MEMBER}/eligibility"
first_cache="$(header x-cache)"
if [ "${STATUS}" = "200" ] && [ "${first_cache}" = "MISS" ]; then
  record "eligibility ${CACHE_MEMBER} (1st)" "200 x-cache: MISS" "${STATUS} x-cache: ${first_cache:-none}" PASS
else
  record "eligibility ${CACHE_MEMBER} (1st)" "200 x-cache: MISS" "${STATUS} x-cache: ${first_cache:-none}" FAIL
  if [ "${first_cache}" = "HIT" ]; then
    HINTS+=("Eligibility was already cached by an earlier call: wait 60 s (CACHE_TTL_ELIGIBILITY_SECONDS) or use another SMOKE_MEMBER_ID.")
  elif [ "${first_cache}" = "BYPASS" ]; then
    HINTS+=("x-cache BYPASS: the API cannot reach Redis (check REDIS_* settings, private endpoint, access policy assignment).")
  fi
fi
request GET "/api/members/${CACHE_MEMBER}/eligibility"
second_cache="$(header x-cache)"
if [ "${STATUS}" = "200" ] && [ "${second_cache}" = "HIT" ]; then
  record "eligibility ${CACHE_MEMBER} (2nd)" "200 x-cache: HIT" "${STATUS} x-cache: ${second_cache:-none}" PASS
else
  record "eligibility ${CACHE_MEMBER} (2nd)" "200 x-cache: HIT" "${STATUS} x-cache: ${second_cache:-none}" FAIL
fi

# 6: provider directory (PostgreSQL text[] specialties, cached)
request GET "/api/providers?city=Jakarta"
if [ "${STATUS}" = "200" ] && grep -q '"providerId"' <<< "${BODY}"; then
  record "GET /api/providers?city=Jakarta" "200 + providers" "${STATUS}" PASS
else
  record "GET /api/providers?city=Jakarta" "200 + providers" "${STATUS}" FAIL
fi
fi # SMOKE_DATA

# 7-8: claim submission with an Idempotency-Key, sent twice: created once, replayed once
if [ "${WRITE}" = "true" ]; then
  yesterday="$(date -u -d 'yesterday' +%Y-%m-%d 2> /dev/null || date -u -v-1d +%Y-%m-%d)"
  # Unique per run: a replay must come from THIS run, and the per-member rate limit is 5/minute.
  key="smoke-$(date +%s)-${RANDOM}"
  claim="{\"memberId\":\"${MEMBER}\",\"providerId\":\"${PROVIDER}\",\"claimType\":\"outpatient\",\"serviceDate\":\"${yesterday}\",\"amountIdr\":150000,\"note\":\"smoke test\"}"

  request POST /api/claims "${claim}" "Idempotency-Key: ${key}"
  if [ "${STATUS}" = "429" ]; then
    # The member's five-claims-a-minute budget is used up (an earlier test run): wait it out once.
    wait_s="$(header retry-after)"
    wait_s="${wait_s:-60}"
    if [ "${wait_s}" -gt 65 ]; then wait_s=65; fi
    echo "  claim rate-limited for ${MEMBER}: waiting ${wait_s} s (Retry-After) and retrying once"
    sleep "${wait_s}"
    request POST /api/claims "${claim}" "Idempotency-Key: ${key}"
  fi
  first_id="$(grep -o '"claimId":"[^"]*"' <<< "${BODY}" | head -n 1 | cut -d '"' -f 4 || true)"
  if [ "${STATUS}" = "201" ] && [ -n "${first_id}" ]; then
    record "POST /api/claims (new key)" "201" "${STATUS} ${first_id}" PASS
  else
    record "POST /api/claims (new key)" "201" "${STATUS}" FAIL
    HINTS+=("Claim rejected: ${BODY}")
  fi

  request POST /api/claims "${claim}" "Idempotency-Key: ${key}"
  replay="$(header idempotent-replay)"
  second_id="$(grep -o '"claimId":"[^"]*"' <<< "${BODY}" | head -n 1 | cut -d '"' -f 4 || true)"
  if [ "${STATUS}" = "200" ] && [ "${replay}" = "true" ] && [ -n "${first_id}" ] && [ "${second_id}" = "${first_id}" ]; then
    record "POST /api/claims (same key)" "200 idempotent-replay" "${STATUS} replay=${replay} ${second_id}" PASS
  else
    record "POST /api/claims (same key)" "200 idempotent-replay" "${STATUS} replay=${replay:-none} ${second_id}" FAIL
  fi
else
  record "POST /api/claims (new key)" "201" "-" SKIP
  record "POST /api/claims (same key)" "200 idempotent-replay" "-" SKIP
fi

# ---------------------------------------------------------------------------------------------
echo
printf '%-36s %-24s %-38s %s\n' "CHECK" "EXPECTED" "ACTUAL" "RESULT"
printf '%-36s %-24s %-38s %s\n' "-----" "--------" "------" "------"
for row in "${ROWS[@]}"; do
  IFS='|' read -r check expected actual result <<< "${row}"
  printf '%-36s %-24s %-38s %s\n' "${check}" "${expected}" "${actual}" "${result}"
done
if [ "${#HINTS[@]}" -gt 0 ]; then
  echo
  for hint in "${HINTS[@]}"; do echo "hint: ${hint}"; done
fi
echo
if [ "${FAILED}" -gt 0 ]; then
  echo "FAILED: ${FAILED} check(s) failed against ${BASE_URL}"
  exit 1
fi
echo "PASSED: all checks passed against ${BASE_URL}"
