#!/usr/bin/env bash
# bootstrap-tfstate.sh: remote state for the Terraform flavour of the kit, with Entra ID only.
#   - rg-ch-tfstate-idc + a zone-redundant StorageV2 account (Standard_ZRS) [REL]
#   - TLS 1.2 minimum, shared keys DISABLED (no access keys, no SAS), no public blob access [SEC]
#   - blob versioning + soft delete (blobs and containers): a corrupted/deleted state is recoverable [REL]
#   - container "tfstate" created through ARM (no data-plane permission needed for that)
#   - Storage Blob Data Contributor on the container for you and for id-ch-github-<env>
#   - writes infra/terraform/{platform,workload,aks}/backend-<env>.hcl (no secrets inside)
#   - optional: sets the TFSTATE_* repository variables used by the workflows
# Idempotent: existing resources are updated, never recreated.
#
# Organisation policies such as "Storage accounts should disable public network access" block
# this layout: then add a private endpoint for the account and run Terraform from a runner inside
# the VNet (self-hosted/ARC), because GitHub-hosted runners reach the account over the internet.
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: scripts/bootstrap-tfstate.sh <lab|prod> [owner/repo]

  <env>         environment whose deploy identity (id-ch-github-<env>) gets access to the state
  [owner/repo]  also set TFSTATE_RESOURCE_GROUP / TFSTATE_STORAGE_ACCOUNT / TFSTATE_CONTAINER
                repository variables with gh

Run scripts/bootstrap-github-oidc.sh <owner/repo> <env> first so the identity exists.
Optional: TFSTATE_STORAGE_ACCOUNT to choose the account name, AZURE_LOCATION (default indonesiacentral).
EOF
}

log()  { printf '\n==> %s\n' "$*"; }
step() { printf '    $ %s\n' "$*"; }
ok()   { printf '    [ OK ] %s\n' "$*"; }
warn() { printf '    WARNING: %s\n' "$*" >&2; }
die()  { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

if [ "${1:-}" = "-h" ] || [ "${1:-}" = "--help" ]; then usage; exit 0; fi
if [ "$#" -lt 1 ] || [ "$#" -gt 2 ]; then usage; exit 1; fi
ENV_NAME="$1"
GH_REPO="${2:-}"
case "${ENV_NAME}" in lab | prod) ;; *) die "Environment must be lab or prod" ;; esac
command -v az > /dev/null 2>&1 || die "Azure CLI (az) is required"
az account show > /dev/null 2>&1 || die "Run az login first"

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LOCATION="${AZURE_LOCATION:-indonesiacentral}"
RG="rg-ch-tfstate-idc"
CONTAINER="tfstate"
SUB_ID="$(az account show --query id -o tsv)"

# Globally unique, deterministic per subscription: 6 hex chars of sha1(<subscription>-ch-tfstate).
sha1_hex() { # portable: GNU coreutils, macOS, OpenSSL or Python
  if command -v sha1sum > /dev/null 2>&1; then sha1sum | cut -d ' ' -f 1
  elif command -v shasum > /dev/null 2>&1; then shasum -a 1 | cut -d ' ' -f 1
  elif command -v openssl > /dev/null 2>&1; then openssl dgst -sha1 | awk '{print $NF}'
  else python3 -c 'import hashlib,sys; print(hashlib.sha1(sys.stdin.buffer.read()).hexdigest())'
  fi
}
SFX="$(printf '%s' "${SUB_ID}-ch-tfstate" | sha1_hex | cut -c1-6)"
SA="${TFSTATE_STORAGE_ACCOUNT:-stchtfstate${SFX}}"
TAGS=(workload=contoso-health environment=shared owner=platform-team costCenter=CH-1001
  dataClassification=confidential managedBy=script)

# ---------------------------------------------------------------------------------------------
log "1/5 Resource group ${RG}"
step "az group create --name ${RG} --location ${LOCATION}"
az group create --name "${RG}" --location "${LOCATION}" --tags "${TAGS[@]}" --output none
ok "${RG}"

# ---------------------------------------------------------------------------------------------
log "2/5 Storage account ${SA}"
# State files can contain sensitive values: the account is reachable with Entra ID tokens only. [SEC]
if az storage account show --name "${SA}" --resource-group "${RG}" --output none 2> /dev/null; then
  step "az storage account update --name ${SA} (enforce settings)"
  az storage account update --name "${SA}" --resource-group "${RG}" \
    --min-tls-version TLS1_2 --allow-shared-key-access false --allow-blob-public-access false \
    --https-only true --output none
else
  step "az storage account create --name ${SA} --sku Standard_ZRS"
  az storage account create --name "${SA}" --resource-group "${RG}" --location "${LOCATION}" \
    --sku Standard_ZRS --kind StorageV2 --access-tier Hot \
    --min-tls-version TLS1_2 --allow-shared-key-access false --allow-blob-public-access false \
    --https-only true --tags "${TAGS[@]}" --output none
fi
ok "Standard_ZRS, TLS1_2, shared keys disabled, public blob access disabled"

step "az storage account blob-service-properties update (versioning + soft delete)"
az storage account blob-service-properties update --account-name "${SA}" --resource-group "${RG}" \
  --enable-versioning true \
  --enable-delete-retention true --delete-retention-days 30 \
  --enable-container-delete-retention true --container-delete-retention-days 30 \
  --output none
ok "versioning on, 30-day soft delete for blobs and containers"

# ---------------------------------------------------------------------------------------------
log "3/5 Container ${CONTAINER}"
# container-rm goes through ARM, so it works with shared keys disabled and before data roles exist.
if [ "$(az storage container-rm exists --storage-account "${SA}" --resource-group "${RG}" --name "${CONTAINER}" --query exists -o tsv)" = "true" ]; then
  ok "${CONTAINER} exists"
else
  step "az storage container-rm create --name ${CONTAINER}"
  az storage container-rm create --storage-account "${SA}" --resource-group "${RG}" \
    --name "${CONTAINER}" --public-access off --output none
  ok "${CONTAINER} created"
fi
SA_ID="$(az storage account show --name "${SA}" --resource-group "${RG}" --query id -o tsv)"
CONTAINER_SCOPE="${SA_ID}/blobServices/default/containers/${CONTAINER}"

# ---------------------------------------------------------------------------------------------
log "4/5 Storage Blob Data Contributor on the container"
# Scoped to the container, not the account or subscription. One shared container keeps the kit
# simple; for strict lab/prod isolation use one storage account per environment instead. [SEC]
ROLE="ba92f5b4-2d11-453d-a403-e96b0029c9fe" # Storage Blob Data Contributor
grant() { # <object id> <principal type> <label>
  local existing
  existing="$(az role assignment list --scope "${CONTAINER_SCOPE}" --role "${ROLE}" \
    --query "[?principalId=='$1'] | [0].id" -o tsv 2> /dev/null || true)"
  if [ -n "${existing}" ]; then
    ok "$3 (already assigned)"
    return 0
  fi
  step "az role assignment create --role 'Storage Blob Data Contributor' --assignee-object-id $1"
  az role assignment create --assignee-object-id "$1" --assignee-principal-type "$2" \
    --role "${ROLE}" --scope "${CONTAINER_SCOPE}" --output none
  ok "$3"
}

me="$(az ad signed-in-user show --query id -o tsv 2> /dev/null || true)"
if [ -n "${me}" ]; then
  grant "${me}" User "you ($(az account show --query user.name -o tsv))"
else
  warn "signed in as a service principal: grant yourself access manually if you run Terraform locally"
fi
gh_principal="$(az identity show --resource-group rg-ch-identity-idc --name "id-ch-github-${ENV_NAME}" --query principalId -o tsv 2> /dev/null || true)"
if [ -n "${gh_principal}" ]; then
  grant "${gh_principal}" ServicePrincipal "id-ch-github-${ENV_NAME}"
else
  warn "id-ch-github-${ENV_NAME} not found: run scripts/bootstrap-github-oidc.sh <owner/repo> ${ENV_NAME}, then re-run this script"
fi
echo "    Note: new data-plane role assignments can take a few minutes to become effective."

# ---------------------------------------------------------------------------------------------
log "5/5 Backend configuration files"
for stack in platform workload aks; do
  dir="${REPO_ROOT}/infra/terraform/${stack}"
  if [ ! -d "${dir}" ]; then
    warn "${dir} does not exist; skipped"
    continue
  fi
  cat > "${dir}/backend-${ENV_NAME}.hcl" <<EOF
# Generated by scripts/bootstrap-tfstate.sh. No secrets: authentication is Microsoft Entra ID
# (use_azuread_auth; OIDC in GitHub Actions through ARM_USE_OIDC=true).
# terraform -chdir=infra/terraform/${stack} init -backend-config=backend-${ENV_NAME}.hcl
resource_group_name  = "${RG}"
storage_account_name = "${SA}"
container_name       = "${CONTAINER}"
key                  = "ch/${stack}/${ENV_NAME}.tfstate"
use_azuread_auth     = true
EOF
  ok "infra/terraform/${stack}/backend-${ENV_NAME}.hcl"
done

if [ -n "${GH_REPO}" ]; then
  command -v gh > /dev/null 2>&1 || die "gh is required to set repository variables"
  for pair in "TFSTATE_RESOURCE_GROUP=${RG}" "TFSTATE_STORAGE_ACCOUNT=${SA}" "TFSTATE_CONTAINER=${CONTAINER}"; do
    gh variable set "${pair%%=*}" --repo "${GH_REPO}" --body "${pair#*=}"
    ok "repo variable ${pair}"
  done
fi

cat <<EOF

Remote state ready.
  Storage account  ${SA} (${RG})
  Container        ${CONTAINER}
  Keys             ch/<stack>/${ENV_NAME}.tfstate

Local use:
  terraform -chdir=infra/terraform/platform init -backend-config=backend-${ENV_NAME}.hcl
EOF
